// @ds-preview generated 72376008683f — generated; to OWN it, copy to .design-sync/previews/ and delete this line there.
import * as React from 'react';
import * as S from "@ds-stories/src/components/Badge/Badge.stories";

function compose(S: any, key: string) {
  const meta: any = S.default ?? {};
  const st: any = S[key];
  const args: any = { ...(meta.args ?? {}), ...(st && st.args ? st.args : {}) };
  // Storybook resolves argTypes.mapping (control value -> real arg) before
  // rendering; mirror that so mapped args don't render raw.
  const at: any = { ...(meta.argTypes ?? {}), ...(st && st.argTypes ? st.argTypes : {}) };
  for (const k of Object.keys(args)) {
    const m = at[k] && at[k].mapping;
    if (m && typeof m === 'object' && args[k] in m) args[k] = m[args[k]];
  }
  const title: string = typeof meta.title === 'string' ? meta.title : '';
  const ctx: any = {
    args, name: key, title, kind: title, id: '', componentId: '',
    globals: {}, viewMode: 'story',
    parameters: (st && st.parameters) ?? meta.parameters ?? {},
  };
  let render: (() => any) | null = null;
  if (st && typeof st.render === 'function') render = () => st.render(args, ctx);
  else if (typeof st === 'function') render = () => st(args, ctx);
  else if (typeof meta.render === 'function') render = () => meta.render(args, ctx);
  else {
    const C = (st && st.component) || meta.component;
    if (C) render = () => React.createElement(C, args);
  }
  if (!render) return () => null;
  // [].concat: a single function is legal CSF decorator shorthand. A
  // decorator returning undefined (stubbed addon) falls through to the inner
  // render — otherwise one unrecognized addon blanks the cell silently.
  const decorators: any[] = ([] as any[]).concat((st && st.decorators) ?? []).concat(meta.decorators ?? []);
  return decorators.reduce((inner: any, dec: any) => () => {
    const out = dec(inner, ctx);
    return out === undefined ? inner() : out;
  }, render);
}

export const Default = /* Default */ compose(S, "Default");
export const Neutral = /* Neutral */ compose(S, "Neutral");
export const Soft = /* Soft */ compose(S, "Soft");
export const Secondary = /* Secondary */ compose(S, "Secondary");
export const Outline = /* Outline */ compose(S, "Outline");
export const Success = /* Success */ compose(S, "Success");
export const Warning = /* Warning */ compose(S, "Warning");
export const Danger = /* Danger */ compose(S, "Danger");
export const Accent = /* Accent */ compose(S, "Accent");
export const Primary = /* Primary */ compose(S, "Primary");
export const Small = /* Small */ compose(S, "Small");
export const FormsMigrationMap = /* Forms → UI map */ compose(S, "FormsMigrationMap");
export const AllTones = /* All Tones */ compose(S, "AllTones");
export const Sizes = /* Sizes */ compose(S, "Sizes");
