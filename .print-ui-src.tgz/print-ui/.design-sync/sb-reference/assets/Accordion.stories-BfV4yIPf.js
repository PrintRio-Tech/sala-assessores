import{i as e,s as t}from"./preload-helper-CT_b8DTk.js";import{t as n}from"./react-B7Te67-h.js";import{t as r}from"./jsx-runtime-DqZldVDK.js";import{d as i,f as a,p as o,u as s}from"./iframe-DiXF9pnZ.js";import{n as c,t as l}from"./Button-FMHbx6tf.js";import{n as u,t as d}from"./Text-BlaLK81_.js";var f,p,m,h,g,_,v,y,b,x,S,C,w,T,E=e((()=>{f=`_root_alnaj_1`,p=`_header_alnaj_8`,m=`_trigger_alnaj_14`,h=`_aside_alnaj_30`,g=`_chevronButton_alnaj_38`,_=`_actions_alnaj_56`,v=`_triggerContent_alnaj_62`,y=`_title_alnaj_69`,b=`_chevron_alnaj_38`,x=`_chevronExpanded_alnaj_84`,S=`_panel_alnaj_88`,C=`_panelExpanded_alnaj_99`,w=`_panelInner_alnaj_103`,T={root:f,header:p,trigger:m,aside:h,chevronButton:g,actions:_,triggerContent:v,title:y,chevron:b,chevronExpanded:x,panel:S,panelExpanded:C,panelInner:w}}));function D({id:e,title:t,description:n,expanded:r,onExpandedChange:i,actions:o,children:c}){let l=(0,O.useId)(),u=e??l,f=`${u}-panel`,p=`${u}-trigger`;return(0,k.jsxs)(`section`,{className:T.root,children:[(0,k.jsxs)(`div`,{className:T.header,children:[(0,k.jsx)(`button`,{id:p,type:`button`,className:T.trigger,"aria-expanded":r,"aria-controls":f,onClick:()=>i(!r),children:(0,k.jsxs)(`span`,{className:T.triggerContent,children:[(0,k.jsx)(d,{as:`span`,variant:`labelMd`,className:T.title,children:t}),n?(0,k.jsx)(d,{as:`span`,variant:`bodyMd`,tone:`muted`,children:n}):null]})}),(0,k.jsxs)(`div`,{className:T.aside,children:[(0,k.jsx)(`button`,{type:`button`,className:T.chevronButton,"aria-expanded":r,"aria-controls":f,"aria-label":r?`Recolher seção`:`Expandir seção`,onClick:()=>i(!r),children:(0,k.jsx)(s,{src:a.ui.chevronDown,size:16,className:[T.chevron,r?T.chevronExpanded:``].filter(Boolean).join(` `)})}),o?(0,k.jsx)(`div`,{className:T.actions,children:o}):null]})]}),(0,k.jsx)(`div`,{id:f,role:`region`,"aria-labelledby":p,className:[T.panel,r?T.panelExpanded:``].filter(Boolean).join(` `),"aria-hidden":!r,inert:r?void 0:!0,children:(0,k.jsx)(`div`,{className:T.panelInner,children:c})})]})}var O,k,A=e((()=>{O=t(n(),1),o(),i(),u(),E(),k=r(),D.__docgenInfo={description:``,methods:[],displayName:`Accordion`,props:{id:{required:!1,tsType:{name:`string`},description:``},title:{required:!0,tsType:{name:`string`},description:``},description:{required:!1,tsType:{name:`string`},description:``},expanded:{required:!0,tsType:{name:`boolean`},description:``},onExpandedChange:{required:!0,tsType:{name:`signature`,type:`function`,raw:`(expanded: boolean) => void`,signature:{arguments:[{type:{name:`boolean`},name:`expanded`}],return:{name:`void`}}},description:``},actions:{required:!1,tsType:{name:`ReactNode`},description:``},children:{required:!0,tsType:{name:`ReactNode`},description:``}}}}));function j({initialExpanded:e=!1,withActions:t=!1}){let[n,r]=(0,M.useState)(e);return(0,N.jsx)(D,{title:`Adicionar inserção`,description:`Opcional — detalhes da publicação.`,expanded:n,onExpandedChange:r,actions:t?(0,N.jsx)(l,{type:`button`,variant:`ghost`,size:`sm`,children:`Remover`}):void 0,children:(0,N.jsx)(d,{variant:`bodyMd`,children:`Conteúdo da seção: campos de clipping, veículos e observações.`})})}var M,N,P,F,I,L,R;e((()=>{M=t(n(),1),c(),u(),A(),N=r(),P={title:`Layout/Accordion`,component:D,tags:[`autodocs`]},F={args:{title:`Seção`,expanded:!1,onExpandedChange:()=>void 0,children:`Conteúdo`},render:()=>(0,N.jsx)(j,{})},I={args:{title:`Seção`,expanded:!0,onExpandedChange:()=>void 0,children:`Conteúdo`},render:()=>(0,N.jsx)(j,{initialExpanded:!0})},L={args:{title:`Seção`,expanded:!1,onExpandedChange:()=>void 0,children:`Conteúdo`},render:()=>(0,N.jsx)(j,{withActions:!0})},F.parameters={...F.parameters,docs:{...F.parameters?.docs,source:{originalSource:`{
  args: {
    title: 'Seção',
    expanded: false,
    onExpandedChange: () => undefined,
    children: 'Conteúdo'
  },
  render: () => <ControlledDemo />
}`,...F.parameters?.docs?.source}}},I.parameters={...I.parameters,docs:{...I.parameters?.docs,source:{originalSource:`{
  args: {
    title: 'Seção',
    expanded: true,
    onExpandedChange: () => undefined,
    children: 'Conteúdo'
  },
  render: () => <ControlledDemo initialExpanded />
}`,...I.parameters?.docs?.source}}},L.parameters={...L.parameters,docs:{...L.parameters?.docs,source:{originalSource:`{
  args: {
    title: 'Seção',
    expanded: false,
    onExpandedChange: () => undefined,
    children: 'Conteúdo'
  },
  render: () => <ControlledDemo withActions />
}`,...L.parameters?.docs?.source}}},R=[`Default`,`Expanded`,`WithActions`]}))();export{F as Default,I as Expanded,L as WithActions,R as __namedExportsOrder,P as default};