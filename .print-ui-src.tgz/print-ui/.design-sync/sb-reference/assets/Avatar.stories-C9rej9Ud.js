import{i as e}from"./preload-helper-CT_b8DTk.js";import{t}from"./jsx-runtime-DqZldVDK.js";import{n,t as r}from"./types-CKoYbOJk.js";var i,a,o,s,c,l=e((()=>{i=`_avatar_lal9q_1`,a=`_sm_lal9q_23`,o=`_lg_lal9q_29`,s=`_image_lal9q_42`,c={avatar:i,sm:a,lg:o,image:s}}));function u({name:e,initials:t,src:n,alt:i,size:a=`md`,className:o,children:s,...l}){let u=t??(e?r(e):void 0)??`?`,p=i??e??u;return(0,d.jsx)(`span`,{className:[c.avatar,f[a],o].filter(Boolean).join(` `),role:n?void 0:`img`,"aria-label":n?void 0:p,...l,children:n?(0,d.jsx)(`img`,{className:c.image,src:n,alt:i??e??``}):s??u})}var d,f,p=e((()=>{n(),l(),d=t(),f={sm:c.sm,md:void 0,lg:c.lg},u.__docgenInfo={description:``,methods:[],displayName:`Avatar`,props:{name:{required:!1,tsType:{name:`string`},description:"Nome completo — gera iniciais quando `initials` / `src` ausentes."},initials:{required:!1,tsType:{name:`string`},description:"Iniciais explícitas (sobrescreve as geradas a partir de `name`)."},src:{required:!1,tsType:{name:`string`},description:``},alt:{required:!1,tsType:{name:`string`},description:``},size:{required:!1,tsType:{name:`union`,raw:`'sm' | 'md' | 'lg'`,elements:[{name:`literal`,value:`'sm'`},{name:`literal`,value:`'md'`},{name:`literal`,value:`'lg'`}]},description:``,defaultValue:{value:`'md'`,computed:!1}},children:{required:!1,tsType:{name:`ReactNode`},description:``}}}})),m,h,g,_,v,y,b,x,S,C;e((()=>{p(),m=t(),h={title:`Foundation/Avatar`,component:u,tags:[`autodocs`],args:{name:`Ana Silva`,size:`md`},argTypes:{size:{control:`select`,options:[`sm`,`md`,`lg`]}}},g={},_={args:{size:`sm`,name:`Ana Silva`}},v={args:{size:`md`,name:`Ana Silva`}},y={args:{size:`lg`,name:`Ana Silva`}},b={args:{initials:`PF`,name:void 0}},x={args:{name:`Ana Silva`,src:`https://i.pravatar.cc/128?u=print-forms`,alt:`Ana Silva`}},S={render:()=>(0,m.jsxs)(`div`,{style:{display:`flex`,gap:12,alignItems:`center`},children:[(0,m.jsx)(u,{size:`sm`,name:`Ana Silva`}),(0,m.jsx)(u,{size:`md`,name:`Ana Silva`}),(0,m.jsx)(u,{size:`lg`,name:`Ana Silva`})]})},g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{}`,...g.parameters?.docs?.source}}},_.parameters={..._.parameters,docs:{..._.parameters?.docs,source:{originalSource:`{
  args: {
    size: 'sm',
    name: 'Ana Silva'
  }
}`,..._.parameters?.docs?.source}}},v.parameters={...v.parameters,docs:{...v.parameters?.docs,source:{originalSource:`{
  args: {
    size: 'md',
    name: 'Ana Silva'
  }
}`,...v.parameters?.docs?.source}}},y.parameters={...y.parameters,docs:{...y.parameters?.docs,source:{originalSource:`{
  args: {
    size: 'lg',
    name: 'Ana Silva'
  }
}`,...y.parameters?.docs?.source}}},b.parameters={...b.parameters,docs:{...b.parameters?.docs,source:{originalSource:`{
  args: {
    initials: 'PF',
    name: undefined
  }
}`,...b.parameters?.docs?.source}}},x.parameters={...x.parameters,docs:{...x.parameters?.docs,source:{originalSource:`{
  args: {
    name: 'Ana Silva',
    src: 'https://i.pravatar.cc/128?u=print-forms',
    alt: 'Ana Silva'
  }
}`,...x.parameters?.docs?.source}}},S.parameters={...S.parameters,docs:{...S.parameters?.docs,source:{originalSource:`{
  render: () => <div style={{
    display: 'flex',
    gap: 12,
    alignItems: 'center'
  }}>
      <Avatar size="sm" name="Ana Silva" />
      <Avatar size="md" name="Ana Silva" />
      <Avatar size="lg" name="Ana Silva" />
    </div>
}`,...S.parameters?.docs?.source}}},C=[`Default`,`Small`,`Medium`,`Large`,`WithInitials`,`WithImage`,`Sizes`]}))();export{g as Default,y as Large,v as Medium,S as Sizes,_ as Small,x as WithImage,b as WithInitials,C as __namedExportsOrder,h as default};