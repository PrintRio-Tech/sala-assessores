import{i as e}from"./preload-helper-CT_b8DTk.js";import{t}from"./jsx-runtime-DqZldVDK.js";var n,r,i,a,o,s,c,l,u,d,f,p,m=e((()=>{n=`_badge_gj61e_2`,r=`_sm_gj61e_23`,i=`_neutral_gj61e_28`,a=`_success_gj61e_34`,o=`_warning_gj61e_40`,s=`_danger_gj61e_46`,c=`_accent_gj61e_52`,l=`_primary_gj61e_58`,u=`_soft_gj61e_65`,d=`_secondary_gj61e_71`,f=`_outline_gj61e_77`,p={badge:n,sm:r,neutral:i,success:a,warning:o,danger:s,accent:c,primary:l,soft:u,secondary:d,outline:f}}));function h({children:e,tone:t=`neutral`,size:n=`md`,className:r}){return(0,g.jsx)(`span`,{className:[p.badge,_[t],v[n],r].filter(Boolean).join(` `),children:e})}var g,_,v,y=e((()=>{m(),g=t(),_={neutral:p.neutral,success:p.success,warning:p.warning,danger:p.danger,accent:p.accent,primary:p.primary,soft:p.soft,secondary:p.secondary,outline:p.outline},v={sm:p.sm,md:void 0},h.__docgenInfo={description:``,methods:[],displayName:`Badge`,props:{children:{required:!0,tsType:{name:`ReactNode`},description:``},tone:{required:!1,tsType:{name:`union`,raw:`| 'neutral'
| 'success'
| 'warning'
| 'danger'
| 'accent'
| 'primary'
| 'soft'
| 'secondary'
| 'outline'`,elements:[{name:`literal`,value:`'neutral'`},{name:`literal`,value:`'success'`},{name:`literal`,value:`'warning'`},{name:`literal`,value:`'danger'`},{name:`literal`,value:`'accent'`},{name:`literal`,value:`'primary'`},{name:`literal`,value:`'soft'`},{name:`literal`,value:`'secondary'`},{name:`literal`,value:`'outline'`}]},description:``,defaultValue:{value:`'neutral'`,computed:!1}},size:{required:!1,tsType:{name:`union`,raw:`'sm' | 'md'`,elements:[{name:`literal`,value:`'sm'`},{name:`literal`,value:`'md'`}]},description:``,defaultValue:{value:`'md'`,computed:!1}},className:{required:!1,tsType:{name:`string`},description:``}}}})),b,x,S,C,w,T,E,D,O,k,A,j,M,N,P,F,I;e((()=>{y(),b=t(),x={title:`Foundation/Badge`,component:h,tags:[`autodocs`],parameters:{docs:{description:{component:["Chip de status/etiqueta. API canônica: `tone` + `size`.",``,"**Mapa forms `variant` → UI `tone`:**","- `default` → `neutral`","- `primary` (salvia container) → `soft`","- `secondary` → `secondary`","- `accent` → `accent`","- `outline` → `outline`","- `primary` no UI = solid (`$primary`); não existe no Badge do forms."].join(`
`)}}},args:{children:`Badge`,tone:`neutral`,size:`md`},argTypes:{tone:{control:`select`,options:[`neutral`,`success`,`warning`,`danger`,`accent`,`primary`,`soft`,`secondary`,`outline`]},size:{control:`select`,options:[`sm`,`md`]}}},S={},C={args:{tone:`neutral`,children:`Neutro`}},w={args:{tone:`soft`,children:`Soft (forms primary)`}},T={args:{tone:`secondary`,children:`Secundário`}},E={args:{tone:`outline`,children:`Outline`}},D={args:{tone:`success`,children:`Sucesso`}},O={args:{tone:`warning`,children:`Atenção`}},k={args:{tone:`danger`,children:`Erro`}},A={args:{tone:`accent`,children:`Destaque`}},j={args:{tone:`primary`,children:`Primário solid`}},M={args:{size:`sm`,children:`Pequeno`}},N={name:`Forms → UI map`,render:()=>(0,b.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:12},children:[(0,b.jsxs)(`div`,{style:{display:`flex`,flexWrap:`wrap`,gap:8,alignItems:`center`},children:[(0,b.jsx)(h,{tone:`neutral`,children:`default → neutral`}),(0,b.jsx)(h,{tone:`soft`,children:`primary → soft`}),(0,b.jsx)(h,{tone:`secondary`,children:`secondary → secondary`}),(0,b.jsx)(h,{tone:`accent`,children:`accent → accent`}),(0,b.jsx)(h,{tone:`outline`,children:`outline → outline`})]}),(0,b.jsxs)(`div`,{style:{display:`flex`,flexWrap:`wrap`,gap:8,alignItems:`center`},children:[(0,b.jsx)(h,{tone:`primary`,children:`UI-only primary (solid)`}),(0,b.jsx)(h,{tone:`success`,children:`success`}),(0,b.jsx)(h,{tone:`warning`,children:`warning`}),(0,b.jsx)(h,{tone:`danger`,children:`danger`})]})]})},P={render:()=>(0,b.jsxs)(`div`,{style:{display:`flex`,flexWrap:`wrap`,gap:8,alignItems:`center`},children:[(0,b.jsx)(h,{tone:`neutral`,children:`Neutral`}),(0,b.jsx)(h,{tone:`soft`,children:`Soft`}),(0,b.jsx)(h,{tone:`secondary`,children:`Secondary`}),(0,b.jsx)(h,{tone:`outline`,children:`Outline`}),(0,b.jsx)(h,{tone:`success`,children:`Success`}),(0,b.jsx)(h,{tone:`warning`,children:`Warning`}),(0,b.jsx)(h,{tone:`danger`,children:`Danger`}),(0,b.jsx)(h,{tone:`accent`,children:`Accent`}),(0,b.jsx)(h,{tone:`primary`,children:`Primary`})]})},F={render:()=>(0,b.jsxs)(`div`,{style:{display:`flex`,gap:8,alignItems:`center`},children:[(0,b.jsx)(h,{size:`sm`,children:`Small`}),(0,b.jsx)(h,{size:`md`,children:`Medium`})]})},S.parameters={...S.parameters,docs:{...S.parameters?.docs,source:{originalSource:`{}`,...S.parameters?.docs?.source}}},C.parameters={...C.parameters,docs:{...C.parameters?.docs,source:{originalSource:`{
  args: {
    tone: 'neutral',
    children: 'Neutro'
  }
}`,...C.parameters?.docs?.source}}},w.parameters={...w.parameters,docs:{...w.parameters?.docs,source:{originalSource:`{
  args: {
    tone: 'soft',
    children: 'Soft (forms primary)'
  }
}`,...w.parameters?.docs?.source}}},T.parameters={...T.parameters,docs:{...T.parameters?.docs,source:{originalSource:`{
  args: {
    tone: 'secondary',
    children: 'Secundário'
  }
}`,...T.parameters?.docs?.source}}},E.parameters={...E.parameters,docs:{...E.parameters?.docs,source:{originalSource:`{
  args: {
    tone: 'outline',
    children: 'Outline'
  }
}`,...E.parameters?.docs?.source}}},D.parameters={...D.parameters,docs:{...D.parameters?.docs,source:{originalSource:`{
  args: {
    tone: 'success',
    children: 'Sucesso'
  }
}`,...D.parameters?.docs?.source}}},O.parameters={...O.parameters,docs:{...O.parameters?.docs,source:{originalSource:`{
  args: {
    tone: 'warning',
    children: 'Atenção'
  }
}`,...O.parameters?.docs?.source}}},k.parameters={...k.parameters,docs:{...k.parameters?.docs,source:{originalSource:`{
  args: {
    tone: 'danger',
    children: 'Erro'
  }
}`,...k.parameters?.docs?.source}}},A.parameters={...A.parameters,docs:{...A.parameters?.docs,source:{originalSource:`{
  args: {
    tone: 'accent',
    children: 'Destaque'
  }
}`,...A.parameters?.docs?.source}}},j.parameters={...j.parameters,docs:{...j.parameters?.docs,source:{originalSource:`{
  args: {
    tone: 'primary',
    children: 'Primário solid'
  }
}`,...j.parameters?.docs?.source}}},M.parameters={...M.parameters,docs:{...M.parameters?.docs,source:{originalSource:`{
  args: {
    size: 'sm',
    children: 'Pequeno'
  }
}`,...M.parameters?.docs?.source}}},N.parameters={...N.parameters,docs:{...N.parameters?.docs,source:{originalSource:`{
  name: 'Forms → UI map',
  render: () => <div style={{
    display: 'flex',
    flexDirection: 'column',
    gap: 12
  }}>
      <div style={{
      display: 'flex',
      flexWrap: 'wrap',
      gap: 8,
      alignItems: 'center'
    }}>
        <Badge tone="neutral">default → neutral</Badge>
        <Badge tone="soft">primary → soft</Badge>
        <Badge tone="secondary">secondary → secondary</Badge>
        <Badge tone="accent">accent → accent</Badge>
        <Badge tone="outline">outline → outline</Badge>
      </div>
      <div style={{
      display: 'flex',
      flexWrap: 'wrap',
      gap: 8,
      alignItems: 'center'
    }}>
        <Badge tone="primary">UI-only primary (solid)</Badge>
        <Badge tone="success">success</Badge>
        <Badge tone="warning">warning</Badge>
        <Badge tone="danger">danger</Badge>
      </div>
    </div>
}`,...N.parameters?.docs?.source}}},P.parameters={...P.parameters,docs:{...P.parameters?.docs,source:{originalSource:`{
  render: () => <div style={{
    display: 'flex',
    flexWrap: 'wrap',
    gap: 8,
    alignItems: 'center'
  }}>
      <Badge tone="neutral">Neutral</Badge>
      <Badge tone="soft">Soft</Badge>
      <Badge tone="secondary">Secondary</Badge>
      <Badge tone="outline">Outline</Badge>
      <Badge tone="success">Success</Badge>
      <Badge tone="warning">Warning</Badge>
      <Badge tone="danger">Danger</Badge>
      <Badge tone="accent">Accent</Badge>
      <Badge tone="primary">Primary</Badge>
    </div>
}`,...P.parameters?.docs?.source}}},F.parameters={...F.parameters,docs:{...F.parameters?.docs,source:{originalSource:`{
  render: () => <div style={{
    display: 'flex',
    gap: 8,
    alignItems: 'center'
  }}>
      <Badge size="sm">Small</Badge>
      <Badge size="md">Medium</Badge>
    </div>
}`,...F.parameters?.docs?.source}}},I=[`Default`,`Neutral`,`Soft`,`Secondary`,`Outline`,`Success`,`Warning`,`Danger`,`Accent`,`Primary`,`Small`,`FormsMigrationMap`,`AllTones`,`Sizes`]}))();export{A as Accent,P as AllTones,k as Danger,S as Default,N as FormsMigrationMap,C as Neutral,E as Outline,j as Primary,T as Secondary,F as Sizes,M as Small,w as Soft,D as Success,O as Warning,I as __namedExportsOrder,x as default};