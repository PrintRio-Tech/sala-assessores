import{i as e}from"./preload-helper-CT_b8DTk.js";import{n as t,t as n}from"./Button-FMHbx6tf.js";var r,i,a,o,s,c,l,u,d,f,p;e((()=>{t(),r={title:`Foundation/Button`,component:n,tags:[`autodocs`],args:{children:`Continuar`,variant:`primary`,size:`md`,disabled:!1},argTypes:{variant:{control:`select`,options:[`primary`,`secondary`,`outline`,`ghost`,`danger`]},size:{control:`select`,options:[`sm`,`md`,`lg`]}}},i={},a={args:{variant:`secondary`}},o={args:{variant:`outline`}},s={args:{variant:`ghost`}},c={args:{variant:`danger`,children:`Excluir`}},l={args:{size:`sm`}},u={args:{size:`lg`}},d={args:{disabled:!0}},f={args:{iconOnly:!0,children:`×`,"aria-label":`Fechar`}},i.parameters={...i.parameters,docs:{...i.parameters?.docs,source:{originalSource:`{}`,...i.parameters?.docs?.source}}},a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'secondary'
  }
}`,...a.parameters?.docs?.source}}},o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'outline'
  }
}`,...o.parameters?.docs?.source}}},s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'ghost'
  }
}`,...s.parameters?.docs?.source}}},c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'danger',
    children: 'Excluir'
  }
}`,...c.parameters?.docs?.source}}},l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  args: {
    size: 'sm'
  }
}`,...l.parameters?.docs?.source}}},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  args: {
    size: 'lg'
  }
}`,...u.parameters?.docs?.source}}},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  args: {
    disabled: true
  }
}`,...d.parameters?.docs?.source}}},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  args: {
    iconOnly: true,
    children: '×',
    'aria-label': 'Fechar'
  }
}`,...f.parameters?.docs?.source}}},p=[`Default`,`Secondary`,`Outline`,`Ghost`,`Danger`,`Small`,`Large`,`Disabled`,`IconOnly`]}))();export{c as Danger,i as Default,d as Disabled,s as Ghost,f as IconOnly,u as Large,o as Outline,a as Secondary,l as Small,p as __namedExportsOrder,r as default};