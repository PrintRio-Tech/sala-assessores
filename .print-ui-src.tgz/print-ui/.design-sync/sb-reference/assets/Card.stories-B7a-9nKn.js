import{i as e}from"./preload-helper-CT_b8DTk.js";import{t}from"./jsx-runtime-DqZldVDK.js";import{n,t as r}from"./Text-BlaLK81_.js";import{n as i,t as a}from"./Card-BGTqnrpd.js";function o({title:e=`Card`}){return(0,l.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:8},children:[(0,l.jsx)(r,{as:`strong`,variant:`labelMd`,children:e}),(0,l.jsx)(r,{tone:`muted`,variant:`bodyMd`,children:`Conteúdo de exemplo para visualizar o card.`})]})}function s(){return(0,l.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:8},children:[(0,l.jsx)(`span`,{style:{color:`rgba(255, 255, 255, 0.75)`,fontSize:12,fontWeight:500,letterSpacing:`0.04em`,textTransform:`uppercase`},children:`Inserções na imprensa`}),(0,l.jsx)(`span`,{style:{color:`#ffffff`,fontSize:28,fontWeight:600,lineHeight:1.1,fontVariantNumeric:`tabular-nums`},children:`1.248`}),(0,l.jsx)(`span`,{style:{color:`#f0ebe4`,fontSize:13},children:`+12% vs. período anterior`})]})}function c(){return(0,l.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:8},children:[(0,l.jsx)(r,{as:`strong`,variant:`labelMd`,style:{color:`#4b3d19`},children:`Relatório semanal`}),(0,l.jsx)(r,{variant:`bodyMd`,style:{color:`#4b3d19`},children:`Resumo das menções e releases publicados nesta semana.`})]})}var l,u,d,f,p,m,h,g,_,v,y,b,x,S,C,w;e((()=>{n(),i(),l=t(),{fn:u}=__STORYBOOK_MODULE_TEST__,d={title:`Foundation/Card`,component:a,tags:[`autodocs`],parameters:{docs:{description:{component:"Superfície de conteúdo. Largura intrínseca (sem `width: 100%`) — o layout do consumidor controla. `primary` = KPI/destaque (texto branco/off-white). `accent` = banner secundário (texto marrom). Não usar `primary` como CTA full-bleed."}}},decorators:[e=>(0,l.jsx)(`div`,{style:{maxWidth:360},children:(0,l.jsx)(e,{})})],args:{children:`Conteúdo do card`,variant:`surface`,padding:`md`,interactive:!1},argTypes:{variant:{control:`select`,options:[`surface`,`elevated`,`soft`,`inset`,`primary`,`accent`]},padding:{control:`select`,options:[`none`,`sm`,`md`,`lg`]},interactive:{control:`boolean`}}},f={args:{children:(0,l.jsx)(o,{title:`Surface`})}},p={args:{variant:`surface`,children:(0,l.jsx)(o,{title:`Surface`})}},m={args:{variant:`elevated`,children:(0,l.jsx)(o,{title:`Elevated`})}},h={args:{variant:`soft`,children:(0,l.jsx)(o,{title:`Soft`})}},g={args:{variant:`inset`,children:(0,l.jsx)(o,{title:`Inset`})}},_={parameters:{docs:{description:{story:"Uso: KPI / destaque numérico. Preferir texto branco ou off-white (`#f0ebe4`) sobre o container — contraste do `$on-primary-container` sozinho pode ser insuficiente para body pequeno."}}},args:{variant:`primary`,children:(0,l.jsx)(s,{})}},v={parameters:{docs:{description:{story:"Uso: banner secundário com copy. Par ouro + marrom (`$on-tertiary-container` / `#4b3d19`) — melhor legibilidade para texto corrido."}}},args:{variant:`accent`,children:(0,l.jsx)(c,{})}},y={args:{padding:`none`,children:(0,l.jsx)(o,{title:`Padding none`})}},b={args:{padding:`sm`,children:(0,l.jsx)(o,{title:`Padding sm`})}},x={args:{padding:`lg`,children:(0,l.jsx)(o,{title:`Padding lg`})}},S={args:{interactive:!0,onClick:u(),children:(0,l.jsx)(o,{title:`Interactive`})}},C={decorators:[e=>(0,l.jsx)(`div`,{style:{maxWidth:720},children:(0,l.jsx)(e,{})})],render:()=>(0,l.jsx)(`div`,{style:{display:`grid`,gridTemplateColumns:`repeat(auto-fill, minmax(200px, 1fr))`,gap:16},children:[`surface`,`elevated`,`soft`,`inset`,`primary`,`accent`].map(e=>(0,l.jsx)(a,{variant:e,children:e===`primary`?(0,l.jsx)(s,{}):e===`accent`?(0,l.jsx)(c,{}):(0,l.jsx)(o,{title:e})},e))})},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  args: {
    children: <SampleContent title="Surface" />
  }
}`,...f.parameters?.docs?.source}}},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'surface',
    children: <SampleContent title="Surface" />
  }
}`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'elevated',
    children: <SampleContent title="Elevated" />
  }
}`,...m.parameters?.docs?.source}}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'soft',
    children: <SampleContent title="Soft" />
  }
}`,...h.parameters?.docs?.source}}},g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'inset',
    children: <SampleContent title="Inset" />
  }
}`,...g.parameters?.docs?.source}}},_.parameters={..._.parameters,docs:{..._.parameters?.docs,source:{originalSource:`{
  parameters: {
    docs: {
      description: {
        story: 'Uso: KPI / destaque numérico. Preferir texto branco ou off-white (\`#f0ebe4\`) sobre o container — contraste do \`$on-primary-container\` sozinho pode ser insuficiente para body pequeno.'
      }
    }
  },
  args: {
    variant: 'primary',
    children: <PrimaryKpiContent />
  }
}`,..._.parameters?.docs?.source}}},v.parameters={...v.parameters,docs:{...v.parameters?.docs,source:{originalSource:`{
  parameters: {
    docs: {
      description: {
        story: 'Uso: banner secundário com copy. Par ouro + marrom (\`$on-tertiary-container\` / \`#4b3d19\`) — melhor legibilidade para texto corrido.'
      }
    }
  },
  args: {
    variant: 'accent',
    children: <AccentBannerContent />
  }
}`,...v.parameters?.docs?.source}}},y.parameters={...y.parameters,docs:{...y.parameters?.docs,source:{originalSource:`{
  args: {
    padding: 'none',
    children: <SampleContent title="Padding none" />
  }
}`,...y.parameters?.docs?.source}}},b.parameters={...b.parameters,docs:{...b.parameters?.docs,source:{originalSource:`{
  args: {
    padding: 'sm',
    children: <SampleContent title="Padding sm" />
  }
}`,...b.parameters?.docs?.source}}},x.parameters={...x.parameters,docs:{...x.parameters?.docs,source:{originalSource:`{
  args: {
    padding: 'lg',
    children: <SampleContent title="Padding lg" />
  }
}`,...x.parameters?.docs?.source}}},S.parameters={...S.parameters,docs:{...S.parameters?.docs,source:{originalSource:`{
  args: {
    interactive: true,
    onClick: fn(),
    children: <SampleContent title="Interactive" />
  }
}`,...S.parameters?.docs?.source}}},C.parameters={...C.parameters,docs:{...C.parameters?.docs,source:{originalSource:`{
  decorators: [Story => <div style={{
    maxWidth: 720
  }}>
        <Story />
      </div>],
  render: () => <div style={{
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
    gap: 16
  }}>
      {(['surface', 'elevated', 'soft', 'inset', 'primary', 'accent'] as const).map(variant => <Card key={variant} variant={variant}>
          {variant === 'primary' ? <PrimaryKpiContent /> : variant === 'accent' ? <AccentBannerContent /> : <SampleContent title={variant} />}
        </Card>)}
    </div>
}`,...C.parameters?.docs?.source}}},w=[`Default`,`Surface`,`Elevated`,`Soft`,`Inset`,`Primary`,`Accent`,`PaddingNone`,`PaddingSm`,`PaddingLg`,`Interactive`,`AllVariants`]}))();export{v as Accent,C as AllVariants,f as Default,m as Elevated,g as Inset,S as Interactive,x as PaddingLg,y as PaddingNone,b as PaddingSm,_ as Primary,h as Soft,p as Surface,w as __namedExportsOrder,d as default};