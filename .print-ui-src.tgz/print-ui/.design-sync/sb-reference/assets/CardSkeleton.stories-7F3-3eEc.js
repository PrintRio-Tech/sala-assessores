import{i as e}from"./preload-helper-CT_b8DTk.js";import{t}from"./jsx-runtime-DqZldVDK.js";import{n,t as r}from"./Card-BGTqnrpd.js";import{i,n as a,r as o,t as s}from"./bones-3A6-Z4mP.js";var c,l,u,d,f=e((()=>{c=`_root_1f10m_1`,l=`_stack_1f10m_5`,u=`_media_1f10m_12`,d={root:c,stack:l,media:u}}));function p({variant:e=`surface`,padding:t=`md`,withMedia:n=!1,className:i,...c}){return(0,m.jsx)(r,{variant:e,padding:t,className:[d.root,i].filter(Boolean).join(` `),"aria-busy":`true`,"aria-label":`Carregando`,...c,children:(0,m.jsxs)(o,{className:d.stack,children:[n?(0,m.jsx)(s,{className:d.media,height:120}):null,(0,m.jsx)(a,{width:`55%`}),(0,m.jsx)(a,{width:`100%`}),(0,m.jsx)(a,{width:`72%`})]})})}var m,h=e((()=>{i(),n(),f(),m=t(),p.__docgenInfo={description:``,methods:[],displayName:`CardSkeleton`,props:{variant:{required:!1,tsType:{name:`union`,raw:`| 'surface'
| 'elevated'
| 'soft'
| 'inset'
| 'primary'
| 'accent'`,elements:[{name:`literal`,value:`'surface'`},{name:`literal`,value:`'elevated'`},{name:`literal`,value:`'soft'`},{name:`literal`,value:`'inset'`},{name:`literal`,value:`'primary'`},{name:`literal`,value:`'accent'`}]},description:``,defaultValue:{value:`'surface'`,computed:!1}},padding:{required:!1,tsType:{name:`union`,raw:`'none' | 'sm' | 'md' | 'lg'`,elements:[{name:`literal`,value:`'none'`},{name:`literal`,value:`'sm'`},{name:`literal`,value:`'md'`},{name:`literal`,value:`'lg'`}]},description:``,defaultValue:{value:`'md'`,computed:!1}},withMedia:{required:!1,tsType:{name:`boolean`},description:`Inclui bloco de mídia no topo.`,defaultValue:{value:`false`,computed:!1}},className:{required:!1,tsType:{name:`string`},description:``}}}})),g,_,v,y,b,x;e((()=>{h(),g=t(),_={title:`Foundation/Card/CardSkeleton`,component:p,tags:[`autodocs`],decorators:[e=>(0,g.jsx)(`div`,{style:{maxWidth:360},children:(0,g.jsx)(e,{})})],args:{variant:`surface`,padding:`md`,withMedia:!1},argTypes:{variant:{control:`select`,options:[`surface`,`elevated`,`soft`,`inset`,`primary`,`accent`]},padding:{control:`select`,options:[`none`,`sm`,`md`,`lg`]}}},v={},y={args:{withMedia:!0}},b={args:{variant:`elevated`,withMedia:!0}},v.parameters={...v.parameters,docs:{...v.parameters?.docs,source:{originalSource:`{}`,...v.parameters?.docs?.source}}},y.parameters={...y.parameters,docs:{...y.parameters?.docs,source:{originalSource:`{
  args: {
    withMedia: true
  }
}`,...y.parameters?.docs?.source}}},b.parameters={...b.parameters,docs:{...b.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'elevated',
    withMedia: true
  }
}`,...b.parameters?.docs?.source}}},x=[`Default`,`WithMedia`,`Elevated`]}))();export{v as Default,b as Elevated,y as WithMedia,x as __namedExportsOrder,_ as default};