import{i as e}from"./preload-helper-CT_b8DTk.js";import{t}from"./jsx-runtime-DqZldVDK.js";import{a as n,i as r,n as i,o as a,r as o,t as s}from"./Detailed-DMuT-lDo.js";var c,l,u,d,f,p,m,h,g,_,v;e((()=>{a(),r(),i(),c=t(),{fn:l}=__STORYBOOK_MODULE_TEST__,u={display:`flex`,flexDirection:`column`,gap:24,maxWidth:360},d={title:`Data/TableCells`,component:o,tags:[`autodocs`],args:{name:`Ana Costa`,subtitle:`ana@print.com`},argTypes:{variant:{control:`select`,options:[`default`,`compact`,`card`]}}},f={},p={args:{variant:`compact`}},m={args:{variant:`card`,subtitle:`Editora · Política`}},h={args:{name:`Bruno Lima`,subtitle:`Repórter`,avatarUrl:`https://i.pravatar.cc/80?u=bruno`}},g={render:()=>(0,c.jsxs)(`div`,{style:u,children:[(0,c.jsx)(s,{name:`Ana Costa`,subtitle:`Editora`,email:`ana@print.com`,phone:`(11) 98888-1111`,contactAction:{label:`Enviar mensagem`,onClick:l()}}),(0,c.jsx)(`p`,{style:{margin:0,fontSize:13,opacity:.7},children:`Passe o mouse sobre o nome para abrir o preview.`})]})},_={render:()=>(0,c.jsx)(n,{trigger:(0,c.jsx)(`span`,{style:{cursor:`pointer`,textDecoration:`underline`},children:`Ver detalhes`}),side:`bottom`,align:`start`,children:(0,c.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:8,padding:4},children:[(0,c.jsx)(o,{name:`Carla Dias`,subtitle:`Designer`}),(0,c.jsx)(`p`,{style:{margin:0,fontSize:13},children:`Responsável pela identidade visual das capas semanais.`})]})})},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{}`,...f.parameters?.docs?.source}}},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'compact'
  }
}`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'card',
    subtitle: 'Editora · Política'
  }
}`,...m.parameters?.docs?.source}}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  args: {
    name: 'Bruno Lima',
    subtitle: 'Repórter',
    avatarUrl: 'https://i.pravatar.cc/80?u=bruno'
  }
}`,...h.parameters?.docs?.source}}},g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  render: () => <div style={stack}>
      <PersonDetailedCell name="Ana Costa" subtitle="Editora" email="ana@print.com" phone="(11) 98888-1111" contactAction={{
      label: 'Enviar mensagem',
      onClick: fn()
    }} />
      <p style={{
      margin: 0,
      fontSize: 13,
      opacity: 0.7
    }}>
        Passe o mouse sobre o nome para abrir o preview.
      </p>
    </div>
}`,...g.parameters?.docs?.source}}},_.parameters={..._.parameters,docs:{..._.parameters?.docs,source:{originalSource:`{
  render: () => <DetailPreview trigger={<span style={{
    cursor: 'pointer',
    textDecoration: 'underline'
  }}>Ver detalhes</span>} side="bottom" align="start">
      <div style={{
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      padding: 4
    }}>
        <PersonCell name="Carla Dias" subtitle="Designer" />
        <p style={{
        margin: 0,
        fontSize: 13
      }}>
          Responsável pela identidade visual das capas semanais.
        </p>
      </div>
    </DetailPreview>
}`,..._.parameters?.docs?.source}}},v=[`Person`,`PersonCompact`,`PersonCard`,`PersonWithAvatar`,`PersonDetailed`,`DetailPreviewCard`]}))();export{_ as DetailPreviewCard,f as Person,m as PersonCard,p as PersonCompact,g as PersonDetailed,h as PersonWithAvatar,v as __namedExportsOrder,d as default};