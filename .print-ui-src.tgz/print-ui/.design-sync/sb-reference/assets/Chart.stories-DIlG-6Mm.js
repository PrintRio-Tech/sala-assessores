import{i as e,s as t}from"./preload-helper-CT_b8DTk.js";import{t as n}from"./react-B7Te67-h.js";import{t as r}from"./jsx-runtime-DqZldVDK.js";import{i,t as a}from"./bones-3A6-Z4mP.js";var o,s,c,l,u,d,f,p,m,h,g,_,v,y=e((()=>{o=`_root_1c039_2`,s=`_svg_1c039_7`,c=`_axisLabel_1c039_13`,l=`_gridLine_1c039_19`,u=`_baseline_1c039_27`,d=`_barTrack_1c039_34`,f=`_hitTarget_1c039_38`,p=`_skeleton_1c039_42`,m=`_barGrowY_1c039_73`,h=`_barGrowX_1c039_80`,g=`_areaReveal_1c039_87`,_=`_lineReveal_1c039_91`,v={root:o,svg:s,axisLabel:c,gridLine:l,baseline:u,barTrack:d,hitTarget:f,skeleton:p,barGrowY:m,"chart-bar-grow-y":`_chart-bar-grow-y_1c039_1`,barGrowX:h,"chart-bar-grow-x":`_chart-bar-grow-x_1c039_1`,areaReveal:g,"chart-area-fade":`_chart-area-fade_1c039_1`,lineReveal:_}}));function b(e,t){return t===`single`?N:P[e%P.length]}function x(e){return Math.max(1,...e.map(e=>e.value))}function S(e,t=6){if(e<=0)return new Set;if(e<=t)return new Set(Array.from({length:e},(e,t)=>t));let n=new Set([0,e-1]),r=t-2;for(let t=1;t<=r;t++)n.add(Math.round(t*(e-1)/(r+1)));return n}function C(){return typeof window<`u`&&window.matchMedia(`(prefers-reduced-motion: reduce)`).matches}function w(e){return`${Math.min(e*24,120)}ms`}function T(e,t,n,r){let i=r-t.left-t.right,a=n-t.top-t.bottom,o=x(e);return e.map((n,r)=>({x:e.length===1?t.left+i/2:t.left+r/(e.length-1)*i,y:t.top+a-n.value/o*a,label:n.label,value:n.value}))}function E({data:e,height:t,animate:n}){let r=(0,j.useId)().replace(/:/g,``),i=(0,j.useRef)(null),a={top:16,right:16,bottom:28,left:16},o=t-a.top-a.bottom,s=a.top+o,c=a.top+o/2,l=T(e,a,t,F),u=S(e.length),d=n&&!C(),f=l.map((e,t)=>`${t===0?`M`:`L`} ${e.x.toFixed(1)} ${e.y.toFixed(1)}`).join(` `),p=l.length===0?``:[`M ${l[0].x.toFixed(1)} ${s.toFixed(1)}`,...l.map(e=>`L ${e.x.toFixed(1)} ${e.y.toFixed(1)}`),`L ${l[l.length-1].x.toFixed(1)} ${s.toFixed(1)}`,`Z`].join(` `);return(0,j.useLayoutEffect)(()=>{let e=i.current;if(!e||!f)return;if(!d||typeof e.getTotalLength!=`function`){e.style.strokeDasharray=``,e.style.strokeDashoffset=``;return}let t=e.getTotalLength();e.style.transition=`none`,e.style.strokeDasharray=`${t}`,e.style.strokeDashoffset=`${t}`,e.getBoundingClientRect(),e.style.transition=``,e.style.strokeDashoffset=`0`},[f,d]),(0,M.jsxs)(`svg`,{className:v.svg,viewBox:`0 0 ${F} ${t}`,width:`100%`,height:t,preserveAspectRatio:`none`,"aria-hidden":`true`,children:[(0,M.jsx)(`defs`,{children:(0,M.jsxs)(`linearGradient`,{id:`area-${r}`,x1:`0`,y1:`0`,x2:`0`,y2:`1`,children:[(0,M.jsx)(`stop`,{offset:`0%`,stopColor:N,stopOpacity:`0.22`}),(0,M.jsx)(`stop`,{offset:`100%`,stopColor:N,stopOpacity:`0.02`})]})}),(0,M.jsx)(`line`,{x1:a.left,y1:c,x2:F-a.right,y2:c,className:v.gridLine}),(0,M.jsx)(`line`,{x1:a.left,y1:s,x2:F-a.right,y2:s,className:v.baseline}),p?(0,M.jsx)(`path`,{d:p,fill:`url(#area-${r})`,stroke:`none`,className:d?v.areaReveal:void 0}):null,f?(0,M.jsx)(`path`,{ref:i,d:f,fill:`none`,stroke:N,strokeWidth:`2.5`,strokeLinejoin:`round`,strokeLinecap:`round`,vectorEffect:`non-scaling-stroke`,className:d?v.lineReveal:void 0}):null,l.map(e=>(0,M.jsx)(`circle`,{cx:e.x,cy:e.y,r:`8`,fill:`transparent`,className:v.hitTarget,children:(0,M.jsxs)(`title`,{children:[e.label,`: `,e.value]})},e.label)),l.map((e,n)=>u.has(n)?(0,M.jsx)(`text`,{x:e.x,y:t-8,textAnchor:`middle`,className:v.axisLabel,children:e.label},`label-${e.label}`):null)]})}function D({data:e,height:t,colorMode:n,animate:r}){let i={top:12,right:12,bottom:28,left:12},a=F-i.left-i.right,o=t-i.top-i.bottom,s=x(e),c=Math.max(6,Math.min(14,a/(e.length*6))),l=Math.max(10,(a-c*Math.max(e.length-1,0))/e.length),u=S(e.length,e.length<=10?10:6),d=i.top+o,f=r&&!C();return(0,M.jsxs)(`svg`,{className:v.svg,viewBox:`0 0 ${F} ${t}`,width:`100%`,height:t,preserveAspectRatio:`none`,"aria-hidden":`true`,children:[(0,M.jsx)(`line`,{x1:i.left,y1:d,x2:F-i.right,y2:d,className:v.baseline}),e.map((e,r)=>{let a=e.value/s*o,d=i.left+r*(l+c),p=i.top+o-a,m=b(r,n);return(0,M.jsxs)(`g`,{children:[(0,M.jsx)(`rect`,{x:d,y:p,width:l,height:Math.max(a,2),rx:`6`,ry:`6`,fill:m,className:f?v.barGrowY:void 0,style:f?{"--chart-stagger":w(r)}:void 0,children:(0,M.jsxs)(`title`,{children:[e.label,`: `,e.value]})}),u.has(r)?(0,M.jsx)(`text`,{x:d+l/2,y:t-8,textAnchor:`middle`,className:v.axisLabel,children:e.label}):null]},e.label)})]})}function O({data:e,height:t,colorMode:n,animate:r}){let i={top:8,right:16,bottom:8,left:88},a=Math.max(32,(t-i.top-i.bottom)/Math.max(e.length,1)),o=F-i.left-i.right,s=x(e),c=Math.max(t,i.top+i.bottom+a*e.length),l=Math.max(10,a-14),u=r&&!C();return(0,M.jsx)(`svg`,{className:v.svg,viewBox:`0 0 ${F} ${c}`,width:`100%`,height:c,preserveAspectRatio:`xMidYMid meet`,"aria-hidden":`true`,children:e.map((e,t)=>{let r=e.value/s*o,c=i.top+t*a+(a-l)/2,d=b(t,n);return(0,M.jsxs)(`g`,{children:[(0,M.jsx)(`text`,{x:i.left-10,y:i.top+t*a+a/2,textAnchor:`end`,dominantBaseline:`middle`,className:v.axisLabel,children:e.label}),(0,M.jsx)(`rect`,{x:i.left,y:c,width:o,height:l,rx:`6`,ry:`6`,className:v.barTrack}),(0,M.jsx)(`rect`,{x:i.left,y:c,width:Math.max(r,4),height:l,rx:`6`,ry:`6`,fill:d,className:u?v.barGrowX:void 0,style:u?{"--chart-stagger":w(t)}:void 0,children:(0,M.jsxs)(`title`,{children:[e.label,`: `,e.value]})})]},e.label)})})}function k(e,t){return t||(e===`horizontal-bar`?`auto`:`single`)}function A({type:e,data:t,height:n=200,colorMode:r,animate:i=!0,loading:o=!1,className:s,"aria-label":c=`Gráfico`}){let l=[v.root,s].filter(Boolean).join(` `),u={"--chart-height":`${n}px`},d=k(e,r);return o?(0,M.jsx)(`div`,{className:l,style:u,role:`img`,"aria-label":c,"aria-busy":`true`,children:(0,M.jsx)(a,{className:v.skeleton,height:n,width:`100%`})}):(0,M.jsxs)(`div`,{className:l,style:u,role:`img`,"aria-label":c,children:[e===`line`?(0,M.jsx)(E,{data:t,height:n,animate:i}):null,e===`bar`?(0,M.jsx)(D,{data:t,height:n,colorMode:d,animate:i}):null,e===`horizontal-bar`?(0,M.jsx)(O,{data:t,height:n,colorMode:d,animate:i}):null]})}var j,M,N,P,F,I=e((()=>{j=t(n(),1),i(),y(),M=r(),N=`var(--pf-primary)`,P=[N,`var(--pf-tertiary)`,`var(--pf-accent-gold)`],F=640,A.__docgenInfo={description:``,methods:[],displayName:`Chart`,props:{type:{required:!0,tsType:{name:`union`,raw:`'line' | 'bar' | 'horizontal-bar'`,elements:[{name:`literal`,value:`'line'`},{name:`literal`,value:`'bar'`},{name:`literal`,value:`'horizontal-bar'`}]},description:``},data:{required:!0,tsType:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  label: string;
  value: number;
}`,signature:{properties:[{key:`label`,value:{name:`string`,required:!0}},{key:`value`,value:{name:`number`,required:!0}}]}}],raw:`ChartDatum[]`},description:``},height:{required:!1,tsType:{name:`number`},description:``,defaultValue:{value:`200`,computed:!1}},colorMode:{required:!1,tsType:{name:`union`,raw:`'auto' | 'single'`,elements:[{name:`literal`,value:`'auto'`},{name:`literal`,value:`'single'`}]},description:"Bar fill strategy. Defaults: `single` for `bar`, `auto` for `horizontal-bar`.\nIgnored for `line`."},animate:{required:!1,tsType:{name:`boolean`},description:"Entrance motion. Honors `prefers-reduced-motion`. Default true.",defaultValue:{value:`true`,computed:!1}},loading:{required:!1,tsType:{name:`boolean`},description:``,defaultValue:{value:`false`,computed:!1}},className:{required:!1,tsType:{name:`string`},description:``},"aria-label":{required:!1,tsType:{name:`string`},description:``,defaultValue:{value:`'Gráfico'`,computed:!1}}}}})),L,R,z,B,V,H,U,W,G,K,q,J,Y,X;e((()=>{I(),L=r(),R=[{label:`Seg`,value:12},{label:`Ter`,value:18},{label:`Qua`,value:9},{label:`Qui`,value:22},{label:`Sex`,value:15},{label:`Sáb`,value:7},{label:`Dom`,value:4}],z=Array.from({length:30},(e,t)=>({label:`${t+1}`,value:Math.round(8+10*Math.sin(t/3.2)+t%5*1.4)})),B=[{label:`Política`,value:42},{label:`Esporte`,value:28},{label:`Cultura`,value:19},{label:`Economia`,value:31}],V={title:`Data/Chart`,component:A,tags:[`autodocs`],args:{type:`line`,data:R,height:200,animate:!0,loading:!1,"aria-label":`Matérias por dia`},argTypes:{type:{control:`select`,options:[`line`,`bar`,`horizontal-bar`]},colorMode:{control:`select`,options:[`single`,`auto`]},animate:{control:`boolean`},height:{control:{type:`number`,min:120,max:400,step:10}},loading:{control:`boolean`}},decorators:[e=>(0,L.jsx)(`div`,{style:{maxWidth:720,padding:16},children:(0,L.jsx)(e,{})})]},H={args:{type:`line`,data:R,"aria-label":`Tendência semanal`}},U={name:`Line (30 days)`,args:{type:`line`,data:z,height:220,"aria-label":`Tendência do mês`}},W={name:`Line in wide card`,decorators:[e=>(0,L.jsx)(`div`,{style:{maxWidth:960,padding:24,borderRadius:16,background:`var(--pf-surface-container-lowest, #fff)`,boxShadow:`0 8px 30px rgba(0,0,0,0.06)`},children:(0,L.jsx)(e,{})})],args:{type:`line`,data:z,height:240,"aria-label":`Série em card largo`}},G={name:`Bar (single primary)`,args:{type:`bar`,data:R,"aria-label":`Matérias por dia`}},K={name:`Bar colorMode=auto`,args:{type:`bar`,data:R,colorMode:`auto`,"aria-label":`Matérias por dia (categórico)`}},q={name:`Horizontal bar (auto)`,args:{type:`horizontal-bar`,data:B,height:220,"aria-label":`Matérias por categoria`}},J={args:{loading:!0,"aria-label":`Carregando gráfico`}},Y={args:{type:`line`,data:[{label:`Hoje`,value:14}],"aria-label":`Publicações de hoje`}},H.parameters={...H.parameters,docs:{...H.parameters?.docs,source:{originalSource:`{
  args: {
    type: 'line',
    data: weekly,
    'aria-label': 'Tendência semanal'
  }
}`,...H.parameters?.docs?.source}}},U.parameters={...U.parameters,docs:{...U.parameters?.docs,source:{originalSource:`{
  name: 'Line (30 days)',
  args: {
    type: 'line',
    data: month,
    height: 220,
    'aria-label': 'Tendência do mês'
  }
}`,...U.parameters?.docs?.source}}},W.parameters={...W.parameters,docs:{...W.parameters?.docs,source:{originalSource:`{
  name: 'Line in wide card',
  decorators: [Story => <div style={{
    maxWidth: 960,
    padding: 24,
    borderRadius: 16,
    background: 'var(--pf-surface-container-lowest, #fff)',
    boxShadow: '0 8px 30px rgba(0,0,0,0.06)'
  }}>
        <Story />
      </div>],
  args: {
    type: 'line',
    data: month,
    height: 240,
    'aria-label': 'Série em card largo'
  }
}`,...W.parameters?.docs?.source}}},G.parameters={...G.parameters,docs:{...G.parameters?.docs,source:{originalSource:`{
  name: 'Bar (single primary)',
  args: {
    type: 'bar',
    data: weekly,
    'aria-label': 'Matérias por dia'
  }
}`,...G.parameters?.docs?.source}}},K.parameters={...K.parameters,docs:{...K.parameters?.docs,source:{originalSource:`{
  name: 'Bar colorMode=auto',
  args: {
    type: 'bar',
    data: weekly,
    colorMode: 'auto',
    'aria-label': 'Matérias por dia (categórico)'
  }
}`,...K.parameters?.docs?.source}}},q.parameters={...q.parameters,docs:{...q.parameters?.docs,source:{originalSource:`{
  name: 'Horizontal bar (auto)',
  args: {
    type: 'horizontal-bar',
    data: categories,
    height: 220,
    'aria-label': 'Matérias por categoria'
  }
}`,...q.parameters?.docs?.source}}},J.parameters={...J.parameters,docs:{...J.parameters?.docs,source:{originalSource:`{
  args: {
    loading: true,
    'aria-label': 'Carregando gráfico'
  }
}`,...J.parameters?.docs?.source}}},Y.parameters={...Y.parameters,docs:{...Y.parameters?.docs,source:{originalSource:`{
  args: {
    type: 'line',
    data: [{
      label: 'Hoje',
      value: 14
    }],
    'aria-label': 'Publicações de hoje'
  }
}`,...Y.parameters?.docs?.source}}},X=[`Line`,`LineMonth`,`LineWideCard`,`Bar`,`BarCategorical`,`HorizontalBar`,`Loading`,`SinglePoint`]}))();export{G as Bar,K as BarCategorical,q as HorizontalBar,H as Line,U as LineMonth,W as LineWideCard,J as Loading,Y as SinglePoint,X as __namedExportsOrder,V as default};