import{i as e,s as t}from"./preload-helper-CT_b8DTk.js";import{t as n}from"./react-B7Te67-h.js";import{t as r}from"./jsx-runtime-DqZldVDK.js";import{n as i,t as a}from"./Checkbox-DEl92WRV.js";var o,s,c,l,u,d,f,p,m,h,g;e((()=>{o=t(n(),1),i(),s=r(),c={title:`Forms/Checkbox`,component:a,tags:[`autodocs`],args:{label:`Aceito os termos de uso`,disabled:!1,indeterminate:!1}},l={},u={args:{defaultChecked:!0}},d={args:{disabled:!0}},f={args:{disabled:!0,defaultChecked:!0}},p={args:{indeterminate:!0,label:`Selecionar todos`}},m={args:{label:void 0}},h={render:function(){let[e,t]=(0,o.useState)(!1);return(0,s.jsx)(a,{label:e?`Notificações ativas`:`Ativar notificações`,checked:e,onCheckedChange:t})}},l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{}`,...l.parameters?.docs?.source}}},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  args: {
    defaultChecked: true
  }
}`,...u.parameters?.docs?.source}}},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  args: {
    disabled: true
  }
}`,...d.parameters?.docs?.source}}},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  args: {
    disabled: true,
    defaultChecked: true
  }
}`,...f.parameters?.docs?.source}}},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  args: {
    indeterminate: true,
    label: 'Selecionar todos'
  }
}`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  args: {
    label: undefined
  }
}`,...m.parameters?.docs?.source}}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  render: function ControlledCheckbox() {
    const [checked, setChecked] = useState(false);
    return <Checkbox label={checked ? 'Notificações ativas' : 'Ativar notificações'} checked={checked} onCheckedChange={setChecked} />;
  }
}`,...h.parameters?.docs?.source}}},g=[`Default`,`Checked`,`Disabled`,`DisabledChecked`,`Indeterminate`,`WithoutLabel`,`Controlled`]}))();export{u as Checked,h as Controlled,l as Default,d as Disabled,f as DisabledChecked,p as Indeterminate,m as WithoutLabel,g as __namedExportsOrder,c as default};