import{i as e,s as t}from"./preload-helper-CT_b8DTk.js";import{t as n}from"./react-B7Te67-h.js";import{t as r}from"./jsx-runtime-DqZldVDK.js";import{i,n as a,r as o,t as s}from"./Checkbox-DEl92WRV.js";function c({legend:e,name:t,options:n,value:r,defaultValue:a,onValueChange:o,disabled:c=!1,className:d}){let[f,p]=(0,l.useState)(a??[]),m=r!==void 0,h=m?r:f,g=(e,t)=>{let n=t?[...h,e]:h.filter(t=>t!==e);m||p(n),o?.(n)};return(0,u.jsxs)(`fieldset`,{className:[i.group,d].filter(Boolean).join(` `),disabled:c,children:[(0,u.jsx)(`legend`,{className:i.groupLegend,children:e}),n.map(e=>(0,u.jsx)(s,{name:`${t}-${e.value}`,label:e.label,checked:h.includes(e.value),onCheckedChange:t=>g(e.value,t),disabled:c},e.value))]})}var l,u,d=e((()=>{l=t(n(),1),a(),o(),u=r(),c.__docgenInfo={description:``,methods:[],displayName:`CheckboxGroup`,props:{legend:{required:!0,tsType:{name:`string`},description:``},name:{required:!0,tsType:{name:`string`},description:``},options:{required:!0,tsType:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  value: string;
  label: string;
}`,signature:{properties:[{key:`value`,value:{name:`string`,required:!0}},{key:`label`,value:{name:`string`,required:!0}}]}}],raw:`CheckboxGroupOption[]`},description:``},value:{required:!1,tsType:{name:`Array`,elements:[{name:`string`}],raw:`string[]`},description:``},defaultValue:{required:!1,tsType:{name:`Array`,elements:[{name:`string`}],raw:`string[]`},description:``},onValueChange:{required:!1,tsType:{name:`signature`,type:`function`,raw:`(value: string[]) => void`,signature:{arguments:[{type:{name:`Array`,elements:[{name:`string`}],raw:`string[]`},name:`value`}],return:{name:`void`}}},description:``},disabled:{required:!1,tsType:{name:`boolean`},description:``,defaultValue:{value:`false`,computed:!1}},className:{required:!1,tsType:{name:`string`},description:``}}}})),f,p,m,h,g,_,v;e((()=>{f=t(n(),1),d(),p=r(),m={title:`Forms/CheckboxGroup`,component:c,tags:[`autodocs`],args:{legend:`Canais monitorados`,name:`channels`,options:[{value:`print`,label:`Imprensa`},{value:`social`,label:`Redes sociais`},{value:`tv`,label:`TV`}],disabled:!1}},h={args:{defaultValue:[`print`]}},g={args:{disabled:!0,defaultValue:[`print`,`social`]}},_={render:function(e){let[t,n]=(0,f.useState)([`social`]);return(0,p.jsx)(c,{...e,value:t,onValueChange:n})}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  args: {
    defaultValue: ['print']
  }
}`,...h.parameters?.docs?.source}}},g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  args: {
    disabled: true,
    defaultValue: ['print', 'social']
  }
}`,...g.parameters?.docs?.source}}},_.parameters={..._.parameters,docs:{..._.parameters?.docs,source:{originalSource:`{
  render: function ControlledGroup(args) {
    const [value, setValue] = useState<string[]>(['social']);
    return <CheckboxGroup {...args} value={value} onValueChange={setValue} />;
  }
}`,..._.parameters?.docs?.source}}},v=[`Default`,`Disabled`,`Controlled`]}))();export{_ as Controlled,h as Default,g as Disabled,v as __namedExportsOrder,m as default};