import{i as e}from"./preload-helper-CT_b8DTk.js";import{t}from"./jsx-runtime-DqZldVDK.js";import{a as n,r,t as i}from"./theme-CiMS1Kdp.js";function a({tokens:e}){return(0,o.jsx)(`div`,{style:s,children:Object.entries(e).map(([e,t])=>(0,o.jsxs)(`div`,{style:c,children:[(0,o.jsx)(`div`,{style:{...l,backgroundColor:t}}),(0,o.jsx)(`div`,{style:{fontSize:13,fontWeight:600},children:e}),(0,o.jsx)(`div`,{style:{fontSize:12,opacity:.7,fontFamily:`monospace`},children:t})]},e))})}var o,s,c,l,u,d,f,p,m;e((()=>{i(),o=t(),s={display:`grid`,gridTemplateColumns:`repeat(auto-fill, minmax(140px, 1fr))`,gap:16},c={display:`flex`,flexDirection:`column`,gap:8},l={width:`100%`,height:72,borderRadius:8,border:`1px solid color-mix(in srgb, currentColor 12%, transparent)`},u={title:`Foundation/Colors`,tags:[`autodocs`],parameters:{layout:`padded`}},d={render:()=>(0,o.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:24},children:[(0,o.jsx)(`h3`,{style:{margin:0},children:`Palette`}),(0,o.jsx)(a,{tokens:r})]})},f={render:()=>(0,o.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:24},children:[(0,o.jsx)(`h3`,{style:{margin:0},children:`Semantic`}),(0,o.jsx)(a,{tokens:n})]})},p={render:()=>(0,o.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:40},children:[(0,o.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:24},children:[(0,o.jsx)(`h3`,{style:{margin:0},children:`Palette`}),(0,o.jsx)(a,{tokens:r})]}),(0,o.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:24},children:[(0,o.jsx)(`h3`,{style:{margin:0},children:`Semantic`}),(0,o.jsx)(a,{tokens:n})]})]})},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  render: () => <div style={{
    display: 'flex',
    flexDirection: 'column',
    gap: 24
  }}>
      <h3 style={{
      margin: 0
    }}>Palette</h3>
      <ColorSwatches tokens={palette} />
    </div>
}`,...d.parameters?.docs?.source}}},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  render: () => <div style={{
    display: 'flex',
    flexDirection: 'column',
    gap: 24
  }}>
      <h3 style={{
      margin: 0
    }}>Semantic</h3>
      <ColorSwatches tokens={semantic} />
    </div>
}`,...f.parameters?.docs?.source}}},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  render: () => <div style={{
    display: 'flex',
    flexDirection: 'column',
    gap: 40
  }}>
      <div style={{
      display: 'flex',
      flexDirection: 'column',
      gap: 24
    }}>
        <h3 style={{
        margin: 0
      }}>Palette</h3>
        <ColorSwatches tokens={palette} />
      </div>
      <div style={{
      display: 'flex',
      flexDirection: 'column',
      gap: 24
    }}>
        <h3 style={{
        margin: 0
      }}>Semantic</h3>
        <ColorSwatches tokens={semantic} />
      </div>
    </div>
}`,...p.parameters?.docs?.source}}},m=[`Palette`,`Semantic`,`All`]}))();export{p as All,d as Palette,f as Semantic,m as __namedExportsOrder,u as default};