import{i as e,s as t}from"./preload-helper-CT_b8DTk.js";import{t as n}from"./react-B7Te67-h.js";import{t as r}from"./jsx-runtime-DqZldVDK.js";import{n as i,t as a}from"./Button-FMHbx6tf.js";import{n as o,t as s}from"./ConfirmDialog-uopal3mz.js";var c,l,u,d,f,p,m,h,g;e((()=>{c=t(n(),1),i(),o(),l=r(),u={title:`Overlay/ConfirmDialog`,component:s,tags:[`autodocs`],parameters:{docs:{description:{component:["Diálogo de confirmação canônico do DS (substitui o uso de `Modal`/`Dialog` do print-forms na migração).",``,`**Paridade com Modal do forms:**`,"- Trigger: passe `children` (ex.: botão) — modo não controlado","- Controlled: `open` + `onOpenChange`","- `destructive` → botão confirmar com variante `danger`","- `loading` / `loadingLabel` — bloqueia fechar enquanto confirma",``,"`Dialog`/`Modal` crus do forms ficam no app até migrar; não há export paralelo no print-ui."].join(`
`)}}},args:{title:`Confirmar ação?`,description:`Esta ação pode ser revertida depois.`,confirmLabel:`Confirmar`,cancelLabel:`Cancelar`}},d={render:function(e){let[t,n]=(0,c.useState)(!1);return(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(a,{type:`button`,onClick:()=>n(!0),children:`Abrir diálogo`}),(0,l.jsx)(s,{...e,open:t,onOpenChange:n,onConfirm:()=>n(!1)})]})}},f={name:`Trigger (como Modal forms)`,render:function(e){return(0,l.jsx)(s,{...e,title:`Publicar release?`,description:`O conteúdo ficará visível para a equipe.`,onConfirm:()=>void 0,children:(0,l.jsx)(a,{type:`button`,children:`Abrir via trigger`})})}},p={args:{title:`Excluir item?`,description:`Esta ação não pode ser desfeita.`,confirmLabel:`Excluir`,destructive:!0},render:function(e){let[t,n]=(0,c.useState)(!1);return(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(a,{type:`button`,variant:`danger`,onClick:()=>n(!0),children:`Excluir`}),(0,l.jsx)(s,{...e,open:t,onOpenChange:n,onConfirm:()=>n(!1)})]})}},m={args:{title:`Revogar acesso?`,description:`Esta ação bloqueia o login.`,body:(0,l.jsx)(`p`,{children:`Revogar o acesso de Maria Silva?`}),confirmLabel:`Revogar`},render:function(e){let[t,n]=(0,c.useState)(!1);return(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(a,{type:`button`,onClick:()=>n(!0),children:`Revogar acesso`}),(0,l.jsx)(s,{...e,open:t,onOpenChange:n,onConfirm:()=>n(!1)})]})}},h={args:{title:`Salvar alterações?`,description:`O diálogo permanece aberto enquanto a confirmação roda.`,confirmLabel:`Salvar`,loadingLabel:`Salvando…`},render:function(e){let[t,n]=(0,c.useState)(!1),[r,i]=(0,c.useState)(!1);return(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(a,{type:`button`,onClick:()=>n(!0),children:`Abrir com loading`}),(0,l.jsx)(s,{...e,open:t,onOpenChange:e=>{r||n(e)},loading:r,onConfirm:async()=>{i(!0),await new Promise(e=>{setTimeout(e,1500)}),i(!1),n(!1)}})]})}},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  render: function Render(args) {
    const [open, setOpen] = useState(false);
    return <>
        <Button type="button" onClick={() => setOpen(true)}>
          Abrir diálogo
        </Button>
        <ConfirmDialog {...args} open={open} onOpenChange={setOpen} onConfirm={() => setOpen(false)} />
      </>;
  }
}`,...d.parameters?.docs?.source}}},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  name: 'Trigger (como Modal forms)',
  render: function Render(args) {
    return <ConfirmDialog {...args} title="Publicar release?" description="O conteúdo ficará visível para a equipe." onConfirm={() => undefined}>
        <Button type="button">Abrir via trigger</Button>
      </ConfirmDialog>;
  }
}`,...f.parameters?.docs?.source}}},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  args: {
    title: 'Excluir item?',
    description: 'Esta ação não pode ser desfeita.',
    confirmLabel: 'Excluir',
    destructive: true
  },
  render: function Render(args) {
    const [open, setOpen] = useState(false);
    return <>
        <Button type="button" variant="danger" onClick={() => setOpen(true)}>
          Excluir
        </Button>
        <ConfirmDialog {...args} open={open} onOpenChange={setOpen} onConfirm={() => setOpen(false)} />
      </>;
  }
}`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  args: {
    title: 'Revogar acesso?',
    description: 'Esta ação bloqueia o login.',
    body: <p>Revogar o acesso de Maria Silva?</p>,
    confirmLabel: 'Revogar'
  },
  render: function Render(args) {
    const [open, setOpen] = useState(false);
    return <>
        <Button type="button" onClick={() => setOpen(true)}>
          Revogar acesso
        </Button>
        <ConfirmDialog {...args} open={open} onOpenChange={setOpen} onConfirm={() => setOpen(false)} />
      </>;
  }
}`,...m.parameters?.docs?.source}}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  args: {
    title: 'Salvar alterações?',
    description: 'O diálogo permanece aberto enquanto a confirmação roda.',
    confirmLabel: 'Salvar',
    loadingLabel: 'Salvando…'
  },
  render: function Render(args) {
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    return <>
        <Button type="button" onClick={() => setOpen(true)}>
          Abrir com loading
        </Button>
        <ConfirmDialog {...args} open={open} onOpenChange={next => {
        if (!loading) {
          setOpen(next);
        }
      }} loading={loading} onConfirm={async () => {
        setLoading(true);
        await new Promise(resolve => {
          setTimeout(resolve, 1500);
        });
        setLoading(false);
        setOpen(false);
      }} />
      </>;
  }
}`,...h.parameters?.docs?.source}}},g=[`Default`,`WithTrigger`,`Destructive`,`WithBody`,`Loading`]}))();export{d as Default,p as Destructive,h as Loading,m as WithBody,f as WithTrigger,g as __namedExportsOrder,u as default};