import{i as e,s as t}from"./preload-helper-CT_b8DTk.js";import{t as n}from"./react-B7Te67-h.js";import{t as r}from"./jsx-runtime-DqZldVDK.js";import{i,n as a,r as o,t as s}from"./Detailed-DMuT-lDo.js";import{a as c,c as l,l as u,n as ee,o as te,r as ne,s as d,t as re,u as f}from"./primitives-llyJwXJR.js";import{n as p,t as m}from"./RowActions-D-rCmrvg.js";var h,g,_,v,y,b,x,S,C,w,T,E,D,O,k,A=e((()=>{h=`_root_igarw_1`,g=`_tableView_igarw_5`,_=`_cardView_igarw_14`,v=`_hideOnTablet_igarw_26`,y=`_actionsHead_igarw_31`,b=`_card_igarw_14`,x=`_cardHeader_igarw_46`,S=`_cardLead_igarw_52`,C=`_cardTitle_igarw_60`,w=`_cardActions_igarw_73`,T=`_cardMeta_igarw_78`,E=`_cardMetaItem_igarw_93`,D=`_cardMetaSep_igarw_99`,O=`_emptyCards_igarw_104`,k={root:h,tableView:g,cardView:_,hideOnTablet:v,actionsHead:y,card:b,cardHeader:x,cardLead:S,cardTitle:C,cardActions:w,cardMeta:T,cardMetaItem:E,cardMetaSep:D,emptyCards:O}}));function j(e,t){return[...e].filter(e=>e.visible?.[t]!==!1).sort((e,n)=>e.priority[t]-n.priority[t])}function M(e,t){if(e)return typeof e==`string`?e:e[t]??e.desktop??e.tablet??e.mobile}function N(e,t){let n=j(e,`tablet`).slice(0,t),r=new Set(n.map(e=>e.id));return new Set(e.filter(e=>!r.has(e.id)).map(e=>e.id))}function ie(e){let[t,...n]=j(e,`mobile`);return{primary:t,secondary:n}}var ae=e((()=>{}));function P(e){return e?{"data-col-size":e}:{}}function oe(e,t){return e.cellType===`personDetailed`?(0,z.jsx)(s,{...e.cell(t)}):e.cellType===`person`?(0,z.jsx)(o,{...e.cell(t)}):e.cell(t)}function F(e,t){return e.mobileCell?e.mobileCell(t):e.cellType===`personDetailed`?e.cell(t).name:e.cellType===`person`?(0,z.jsx)(o,{compact:!0,...e.cell(t)}):e.cell(t)}function I(e){return e.cellType===`person`||e.cellType===`personDetailed`}function se(e){let{primary:t,secondary:n}=ie(e);return{primary:t,personColumns:n.filter(e=>I(e)),metaColumns:n.filter(e=>!I(e))}}function L({columns:e,data:t,getRowKey:n,striped:r=!1,sort:i,onSort:a,rowActions:f,emptyState:p=`Nenhum registro encontrado.`,tabletColumnLimit:m=4,className:h}){let g=(0,R.useMemo)(()=>j(e,`desktop`),[e]),_=(0,R.useMemo)(()=>N(e,m),[e,m]),{primary:v,personColumns:y,metaColumns:b}=(0,R.useMemo)(()=>se(e),[e]),x=!!f;return(0,z.jsxs)(`div`,{className:[k.root,h].filter(Boolean).join(` `),children:[(0,z.jsx)(`div`,{className:k.tableView,children:(0,z.jsxs)(re,{striped:r,children:[(0,z.jsx)(l,{children:(0,z.jsxs)(u,{children:[g.map(e=>(0,z.jsx)(d,{align:e.align,sortable:e.sortable,sortDirection:i?.key===e.id?i.direction??null:null,onSort:e.sortable&&a?()=>a(e.id):void 0,className:_.has(e.id)?k.hideOnTablet:void 0,...P(M(e.size,`desktop`)),children:e.header},e.id)),x?(0,z.jsx)(d,{className:k.actionsHead,"aria-label":`Ações`}):null]})}),(0,z.jsx)(ne,{children:t.length===0?(0,z.jsx)(te,{children:p}):t.map(e=>(0,z.jsxs)(u,{children:[g.map(t=>(0,z.jsx)(c,{align:t.align,className:_.has(t.id)?k.hideOnTablet:void 0,...P(M(t.size,`desktop`)),children:oe(t,e)},t.id)),x?(0,z.jsx)(ee,{children:f?.(e)}):null]},n(e)))})]})}),(0,z.jsx)(`div`,{className:k.cardView,children:t.length===0?(0,z.jsx)(`p`,{className:k.emptyCards,children:p}):t.map(e=>(0,z.jsxs)(`article`,{className:k.card,children:[(0,z.jsxs)(`header`,{className:k.cardHeader,children:[(0,z.jsxs)(`div`,{className:k.cardLead,children:[v?(0,z.jsx)(`div`,{className:k.cardTitle,children:F(v,e)}):null,y.map(t=>t.cellType===`personDetailed`?(0,z.jsx)(s,{...t.cell(e)},t.id):(0,z.jsx)(o,{variant:`card`,...t.cell(e)},t.id))]}),x?(0,z.jsx)(`div`,{className:k.cardActions,children:f?.(e)}):null]}),b.length>0?(0,z.jsx)(`p`,{className:k.cardMeta,children:b.map((t,n)=>(0,z.jsxs)(`span`,{className:k.cardMetaItem,children:[n>0?(0,z.jsx)(`span`,{className:k.cardMetaSep,"aria-hidden":!0,children:`·`}):null,F(t,e)]},t.id))}):null]},n(e)))})]})}var R,z,ce=e((()=>{R=t(n(),1),i(),a(),A(),ae(),f(),z=r(),L.__docgenInfo={description:``,methods:[],displayName:`DataTable`,props:{columns:{required:!0,tsType:{name:`Array`,elements:[{name:`union`,raw:`| (TableColumnBase<T> & {
    cellType?: 'default';
    cell: (row: T) => ReactNode;
  })
| (TableColumnBase<T> & {
    cellType: 'person';
    cell: (row: T) => TablePersonValue;
  })
| (TableColumnBase<T> & {
    cellType: 'personDetailed';
    cell: (row: T) => TablePersonDetailValue;
  })`,elements:[{name:`unknown`},{name:`unknown`},{name:`unknown`}]}],raw:`TableColumnDef<T>[]`},description:``},data:{required:!0,tsType:{name:`Array`,elements:[{name:`T`}],raw:`T[]`},description:``},getRowKey:{required:!0,tsType:{name:`signature`,type:`function`,raw:`(row: T) => string`,signature:{arguments:[{type:{name:`T`},name:`row`}],return:{name:`string`}}},description:``},striped:{required:!1,tsType:{name:`boolean`},description:``,defaultValue:{value:`false`,computed:!1}},sort:{required:!1,tsType:{name:`signature`,type:`object`,raw:`{
  key: string;
  direction: SortDirection | null;
}`,signature:{properties:[{key:`key`,value:{name:`string`,required:!0}},{key:`direction`,value:{name:`union`,raw:`SortDirection | null`,elements:[{name:`union`,raw:`'asc' | 'desc'`,elements:[{name:`literal`,value:`'asc'`},{name:`literal`,value:`'desc'`}]},{name:`null`}],required:!0}}]}},description:``},onSort:{required:!1,tsType:{name:`signature`,type:`function`,raw:`(columnId: string) => void`,signature:{arguments:[{type:{name:`string`},name:`columnId`}],return:{name:`void`}}},description:``},rowActions:{required:!1,tsType:{name:`signature`,type:`function`,raw:`(row: T) => ReactNode`,signature:{arguments:[{type:{name:`T`},name:`row`}],return:{name:`ReactNode`}}},description:``},emptyState:{required:!1,tsType:{name:`ReactNode`},description:``,defaultValue:{value:`'Nenhum registro encontrado.'`,computed:!1}},tabletColumnLimit:{required:!1,tsType:{name:`number`},description:`Quantas colunas de dados exibir no tablet (ações sempre visíveis).`,defaultValue:{value:`4`,computed:!1}},className:{required:!1,tsType:{name:`string`},description:``}}}}));function le(e,t){if(!t?.direction||!t.key)return e;let n=t.direction===`asc`?1:-1;return[...e].sort((e,r)=>{let i=e[t.key],a=r[t.key];return typeof i==`number`&&typeof a==`number`?(i-a)*n:String(i).localeCompare(String(a))*n})}var B,V,H,U,W,G,K,q,J,Y,X,Z,Q,$;e((()=>{B=t(n(),1),ce(),p(),V=r(),{fn:H}=__STORYBOOK_MODULE_TEST__,U=[{id:`1`,name:`Ana Costa`,email:`ana@print.com`,role:`Editora`,department:`Política`,articles:24},{id:`2`,name:`Bruno Lima`,email:`bruno@print.com`,role:`Repórter`,department:`Esporte`,articles:18},{id:`3`,name:`Carla Dias`,email:`carla@print.com`,role:`Designer`,department:`Arte`,articles:9},{id:`4`,name:`Diego Alves`,email:`diego@print.com`,role:`Fotógrafo`,department:`Foto`,articles:31}],W=[{id:`name`,header:`Nome`,cellType:`person`,cell:e=>({name:e.name,subtitle:e.email}),priority:{mobile:1,tablet:1,desktop:1},size:`lg`,sortable:!0},{id:`role`,header:`Função`,cell:e=>e.role,priority:{mobile:2,tablet:2,desktop:2},size:`md`,sortable:!0},{id:`department`,header:`Departamento`,cell:e=>e.department,priority:{mobile:3,tablet:3,desktop:3},size:`md`},{id:`articles`,header:`Matérias`,cell:e=>e.articles,priority:{mobile:4,tablet:4,desktop:4},size:`sm`,align:`right`,sortable:!0}],G=[{id:`person`,header:`Pessoa`,cellType:`personDetailed`,cell:e=>({name:e.name,subtitle:e.role,email:e.email,phone:`(11) 99999-0000`,contactAction:{label:`Enviar mensagem`,onClick:H()}}),priority:{mobile:1,tablet:1,desktop:1},size:`xl`},{id:`department`,header:`Departamento`,cell:e=>e.department,priority:{mobile:2,tablet:2,desktop:2},size:`md`},{id:`articles`,header:`Matérias`,cell:e=>e.articles,priority:{mobile:3,tablet:3,desktop:3},size:`sm`,align:`right`}],K={title:`Data/DataTable`,component:L,tags:[`autodocs`],args:{columns:W,data:U,getRowKey:e=>e.id,striped:!1,emptyState:`Nenhum registro encontrado.`}},q={},J={args:{striped:!0}},Y={render:e=>{let[t,n]=(0,B.useState)({key:`name`,direction:`asc`});return(0,V.jsx)(L,{columns:W,data:le(U,t),getRowKey:e=>e.id,striped:e.striped,emptyState:e.emptyState,sort:t,onSort:e=>{n(t=>t.key===e?t.direction===`asc`?{key:e,direction:`desc`}:t.direction===`desc`?{key:e,direction:null}:{key:e,direction:`asc`}:{key:e,direction:`asc`})}})}},X={args:{rowActions:e=>(0,V.jsx)(m,{"aria-label":`Ações de ${e.name}`,actions:[{label:`Ver`,icon:`view`,onSelect:H()},{label:`Editar`,icon:`edit`,onSelect:H()},{label:`Excluir`,icon:`delete`,destructive:!0,onSelect:H()}]})}},Z={args:{data:[]}},Q={args:{columns:G}},q.parameters={...q.parameters,docs:{...q.parameters?.docs,source:{originalSource:`{}`,...q.parameters?.docs?.source}}},J.parameters={...J.parameters,docs:{...J.parameters?.docs,source:{originalSource:`{
  args: {
    striped: true
  }
}`,...J.parameters?.docs?.source}}},Y.parameters={...Y.parameters,docs:{...Y.parameters?.docs,source:{originalSource:`{
  render: args => {
    const [sort, setSort] = useState<TableSortState>({
      key: 'name',
      direction: 'asc'
    });
    return <DataTable columns={columns} data={sortRows(employees, sort)} getRowKey={row => row.id} striped={args.striped} emptyState={args.emptyState} sort={sort} onSort={columnId => {
      setSort(current => {
        if (current.key !== columnId) {
          return {
            key: columnId,
            direction: 'asc'
          };
        }
        if (current.direction === 'asc') {
          return {
            key: columnId,
            direction: 'desc'
          };
        }
        if (current.direction === 'desc') {
          return {
            key: columnId,
            direction: null
          };
        }
        return {
          key: columnId,
          direction: 'asc'
        };
      });
    }} />;
  }
}`,...Y.parameters?.docs?.source}}},X.parameters={...X.parameters,docs:{...X.parameters?.docs,source:{originalSource:`{
  args: {
    rowActions: row => <TableRowActions aria-label={\`Ações de \${row.name}\`} actions={[{
      label: 'Ver',
      icon: 'view',
      onSelect: fn()
    }, {
      label: 'Editar',
      icon: 'edit',
      onSelect: fn()
    }, {
      label: 'Excluir',
      icon: 'delete',
      destructive: true,
      onSelect: fn()
    }]} />
  }
}`,...X.parameters?.docs?.source}}},Z.parameters={...Z.parameters,docs:{...Z.parameters?.docs,source:{originalSource:`{
  args: {
    data: []
  }
}`,...Z.parameters?.docs?.source}}},Q.parameters={...Q.parameters,docs:{...Q.parameters?.docs,source:{originalSource:`{
  args: {
    columns: detailedColumns
  }
}`,...Q.parameters?.docs?.source}}},$=[`Default`,`Striped`,`WithSorting`,`WithRowActions`,`Empty`,`PersonDetailed`]}))();export{q as Default,Z as Empty,Q as PersonDetailed,J as Striped,X as WithRowActions,Y as WithSorting,$ as __namedExportsOrder,K as default};