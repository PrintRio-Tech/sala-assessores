import{i as e,s as t}from"./preload-helper-CT_b8DTk.js";import{t as n}from"./react-B7Te67-h.js";import{t as r}from"./jsx-runtime-DqZldVDK.js";import{n as i,t as a}from"./Button-FMHbx6tf.js";import{c as o,f as s,g as c,i as l,m as u,n as d,o as f,t as p,u as m}from"./dialog-BJ-3TVvJ.js";import{a as h,i as g,o as _,r as v}from"./DrawerSteps-DHJDbmIC.js";function y({children:e,title:t,description:n,body:r,confirmLabel:i=`Confirmar`,cancelLabel:p=`Cancelar`,onConfirm:h,size:g=`md`}){let v=[_.panel,x[g],S[g]].join(` `),y=[_.backdrop,g===`xl`?_.backdropInset:void 0].filter(Boolean).join(` `);return(0,b.jsxs)(f,{children:[(0,b.jsx)(d,{render:e}),(0,b.jsxs)(o,{children:[(0,b.jsx)(c,{className:y}),(0,b.jsxs)(m,{className:v,children:[(0,b.jsx)(`div`,{className:_.handle,"aria-hidden":`true`}),(0,b.jsx)(`header`,{className:_.headerRow,children:(0,b.jsxs)(`div`,{className:_.header,children:[(0,b.jsx)(l,{className:_.title,children:t}),n?(0,b.jsx)(s,{className:_.description,children:n}):null]})}),r?(0,b.jsx)(`div`,{className:_.bodyScroll,"data-layout":`scroll`,children:(0,b.jsx)(`div`,{className:_.bodyInner,children:r})}):null,(0,b.jsx)(`footer`,{className:_.footer,children:(0,b.jsxs)(`div`,{className:_.footerInner,children:[(0,b.jsx)(u,{render:(0,b.jsx)(a,{variant:`ghost`,className:_.footerAction,children:p})}),(0,b.jsx)(u,{render:(0,b.jsx)(a,{variant:`primary`,className:_.footerAction,onClick:h,children:i})})]})})]})]})]})}var b,x,S,C=e((()=>{p(),i(),h(),b=r(),g(),x={md:_.panelMd,lg:_.panelLg,xl:_.panelXl},S={md:_.panelMobileMd,lg:_.panelMobileLg,xl:_.panelMobileXl},y.__docgenInfo={description:``,methods:[],displayName:`Drawer`,props:{children:{required:!0,tsType:{name:`ReactElement`,elements:[{name:`Record`,elements:[{name:`string`},{name:`unknown`}],raw:`Record<string, unknown>`}],raw:`ReactElement<Record<string, unknown>>`},description:``},title:{required:!0,tsType:{name:`string`},description:``},description:{required:!1,tsType:{name:`string`},description:``},body:{required:!1,tsType:{name:`ReactNode`},description:``},confirmLabel:{required:!1,tsType:{name:`string`},description:``,defaultValue:{value:`'Confirmar'`,computed:!1}},cancelLabel:{required:!1,tsType:{name:`string`},description:``,defaultValue:{value:`'Cancelar'`,computed:!1}},onConfirm:{required:!1,tsType:{name:`signature`,type:`function`,raw:`() => void`,signature:{arguments:[],return:{name:`void`}}},description:``},size:{required:!1,tsType:{name:`union`,raw:`'md' | 'lg' | 'xl'`,elements:[{name:`literal`,value:`'md'`},{name:`literal`,value:`'lg'`},{name:`literal`,value:`'xl'`}]},description:``,defaultValue:{value:`'md'`,computed:!1}}}}})),w,T,E,D,O,k,A;e((()=>{w=t(n(),1),i(),C(),T=r(),E={title:`Overlay/Drawer`,component:y,tags:[`autodocs`],args:{title:`Detalhes`,description:`Revise as informações antes de confirmar.`,confirmLabel:`Confirmar`,cancelLabel:`Cancelar`,size:`md`,children:(0,T.jsx)(a,{type:`button`,children:`Abrir drawer`}),body:(0,T.jsx)(`p`,{children:`Conteúdo do painel lateral. Em viewports estreitas o drawer sobe como sheet; em desktop abre pela lateral.`})},argTypes:{size:{control:`select`,options:[`md`,`lg`,`xl`]},children:{control:!1},body:{control:!1}}},D={render:e=>(0,T.jsx)(y,{...e})},O={args:{size:`lg`,title:`Drawer grande`,children:(0,T.jsx)(a,{type:`button`,children:`Abrir drawer lg`})},render:e=>(0,T.jsx)(y,{...e})},k={name:`DrawerShell`,parameters:{docs:{description:{story:`Shell controlado com footer customizado — base usada por fluxos como DrawerSteps.`}}},render:function(){let[e,t]=(0,w.useState)(!1);return(0,T.jsxs)(T.Fragment,{children:[(0,T.jsx)(a,{type:`button`,onClick:()=>t(!0),children:`Abrir DrawerShell`}),(0,T.jsx)(v,{open:e,onOpenChange:t,title:`Editar perfil`,description:`Atualize os dados do usuário.`,size:`lg`,footer:(0,T.jsxs)(T.Fragment,{children:[(0,T.jsx)(a,{type:`button`,variant:`ghost`,onClick:()=>t(!1),children:`Cancelar`}),(0,T.jsx)(a,{type:`button`,variant:`primary`,onClick:()=>t(!1),children:`Salvar`})]}),children:(0,T.jsxs)(`label`,{style:{display:`grid`,gap:4},children:[`Nome`,(0,T.jsx)(`input`,{defaultValue:`Maria Silva`})]})})]})}},D.parameters={...D.parameters,docs:{...D.parameters?.docs,source:{originalSource:`{
  render: args => <Drawer {...args} />
}`,...D.parameters?.docs?.source}}},O.parameters={...O.parameters,docs:{...O.parameters?.docs,source:{originalSource:`{
  args: {
    size: 'lg',
    title: 'Drawer grande',
    children: <Button type="button">Abrir drawer lg</Button>
  },
  render: args => <Drawer {...args} />
}`,...O.parameters?.docs?.source}}},k.parameters={...k.parameters,docs:{...k.parameters?.docs,source:{originalSource:`{
  name: 'DrawerShell',
  parameters: {
    docs: {
      description: {
        story: 'Shell controlado com footer customizado — base usada por fluxos como DrawerSteps.'
      }
    }
  },
  render: function Render() {
    const [open, setOpen] = useState(false);
    return <>
        <Button type="button" onClick={() => setOpen(true)}>
          Abrir DrawerShell
        </Button>
        <DrawerShell open={open} onOpenChange={setOpen} title="Editar perfil" description="Atualize os dados do usuário." size="lg" footer={<>
              <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
                Cancelar
              </Button>
              <Button type="button" variant="primary" onClick={() => setOpen(false)}>
                Salvar
              </Button>
            </>}>
          <label style={{
          display: 'grid',
          gap: 4
        }}>
            Nome
            <input defaultValue="Maria Silva" />
          </label>
        </DrawerShell>
      </>;
  }
}`,...k.parameters?.docs?.source}}},A=[`Default`,`Large`,`Shell`]}))();export{D as Default,O as Large,k as Shell,A as __namedExportsOrder,E as default};