import{i as e}from"./preload-helper-CT_b8DTk.js";import{t}from"./jsx-runtime-DqZldVDK.js";import{n,t as r}from"./Button-FMHbx6tf.js";import{n as i,t as a}from"./Text-BlaLK81_.js";import{n as o,t as s}from"./Heading-DD4784Mz.js";var c,l,u,d=e((()=>{c=`_root_hpiqu_1`,l=`_mark_hpiqu_21`,u={root:c,mark:l}}));function f(e){return e===`empty`?`primary`:`outline`}function p({variant:e,title:t,description:n,action:i,mark:o,className:c}){return(0,m.jsxs)(`section`,{className:[u.root,c].filter(Boolean).join(` `),role:e===`error`?`alert`:void 0,children:[o==null?null:(0,m.jsx)(`span`,{className:u.mark,"aria-hidden":`true`,children:o}),(0,m.jsx)(s,{level:2,children:t}),(0,m.jsx)(a,{tone:`muted`,children:n}),i?(0,m.jsx)(r,{type:`button`,variant:f(e),onClick:i.onClick,children:i.label}):null]})}var m,h=e((()=>{n(),o(),i(),d(),m=t(),p.__docgenInfo={description:``,methods:[],displayName:`EmptyState`,props:{variant:{required:!0,tsType:{name:`union`,raw:`'empty' | 'filtered' | 'error'`,elements:[{name:`literal`,value:`'empty'`},{name:`literal`,value:`'filtered'`},{name:`literal`,value:`'error'`}]},description:``},title:{required:!0,tsType:{name:`string`},description:``},description:{required:!0,tsType:{name:`string`},description:``},action:{required:!1,tsType:{name:`signature`,type:`object`,raw:`{
  label: string;
  onClick: () => void;
}`,signature:{properties:[{key:`label`,value:{name:`string`,required:!0}},{key:`onClick`,value:{name:`signature`,type:`function`,raw:`() => void`,signature:{arguments:[],return:{name:`void`}},required:!0}}]}},description:``},mark:{required:!1,tsType:{name:`ReactNode`},description:``},className:{required:!1,tsType:{name:`string`},description:``}}}})),g,_,v,y,b,x,S,C;e((()=>{h(),{fn:g}=__STORYBOOK_MODULE_TEST__,_={title:`Foundation/EmptyState`,component:p,tags:[`autodocs`],args:{variant:`empty`,title:`Nenhum item ainda`,description:`Comece criando o primeiro registro para ver os dados aqui.`,action:{label:`Criar item`,onClick:g()}},argTypes:{variant:{control:`select`,options:[`empty`,`filtered`,`error`]}}},v={},y={args:{variant:`empty`,title:`Nenhum clipping`,description:`Adicione um clipping para começar a acompanhar a cobertura.`,action:{label:`Novo clipping`,onClick:g()}}},b={args:{variant:`filtered`,title:`Nenhum resultado`,description:`Ajuste os filtros ou limpe a busca para ver mais itens.`,action:{label:`Limpar filtros`,onClick:g()}}},x={args:{variant:`error`,title:`Não foi possível carregar`,description:`Ocorreu um erro ao buscar os dados. Tente novamente.`,action:{label:`Tentar de novo`,onClick:g()}}},S={args:{variant:`empty`,title:`Lista vazia`,description:`Não há itens para exibir no momento.`,action:void 0}},v.parameters={...v.parameters,docs:{...v.parameters?.docs,source:{originalSource:`{}`,...v.parameters?.docs?.source}}},y.parameters={...y.parameters,docs:{...y.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'empty',
    title: 'Nenhum clipping',
    description: 'Adicione um clipping para começar a acompanhar a cobertura.',
    action: {
      label: 'Novo clipping',
      onClick: fn()
    }
  }
}`,...y.parameters?.docs?.source}}},b.parameters={...b.parameters,docs:{...b.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'filtered',
    title: 'Nenhum resultado',
    description: 'Ajuste os filtros ou limpe a busca para ver mais itens.',
    action: {
      label: 'Limpar filtros',
      onClick: fn()
    }
  }
}`,...b.parameters?.docs?.source}}},x.parameters={...x.parameters,docs:{...x.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'error',
    title: 'Não foi possível carregar',
    description: 'Ocorreu um erro ao buscar os dados. Tente novamente.',
    action: {
      label: 'Tentar de novo',
      onClick: fn()
    }
  }
}`,...x.parameters?.docs?.source}}},S.parameters={...S.parameters,docs:{...S.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'empty',
    title: 'Lista vazia',
    description: 'Não há itens para exibir no momento.',
    action: undefined
  }
}`,...S.parameters?.docs?.source}}},C=[`Default`,`Empty`,`Filtered`,`Error`,`WithoutAction`]}))();export{v as Default,y as Empty,x as Error,b as Filtered,S as WithoutAction,C as __namedExportsOrder,_ as default};