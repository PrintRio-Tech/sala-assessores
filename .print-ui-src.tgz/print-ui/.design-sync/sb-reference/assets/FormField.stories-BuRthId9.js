import{i as e}from"./preload-helper-CT_b8DTk.js";import{t}from"./jsx-runtime-DqZldVDK.js";import{i as n,n as r,r as i,t as a}from"./TextInput-Bq2RwQQG.js";import{n as o,t as s}from"./FormField-DK3kFsCC.js";var c,l,u,d,f,p,m,h,g,_,v;e((()=>{i(),r(),o(),c=t(),l={title:`Forms/FormField`,component:s,tags:[`autodocs`],args:{label:`E-mail`,labelHidden:!1,labelSize:`md`,required:!1,description:void 0,error:void 0,htmlFor:`email`,children:(0,c.jsx)(`input`,{id:`email`,name:`email`,type:`email`,className:n.input,placeholder:`voce@empresa.com`})},argTypes:{labelSize:{control:`select`,options:[`md`,`sm`]},children:{control:!1}}},u={},d={args:{required:!0}},f={args:{description:`Usamos este e-mail para enviar o recibo.`}},p={args:{error:`Informe um e-mail válido.`,children:(0,c.jsx)(`input`,{id:`email`,name:`email`,type:`email`,className:[n.input,n.inputInvalid].join(` `),defaultValue:`invalido`,"aria-invalid":!0})}},m={args:{labelSize:`sm`}},h={args:{labelHidden:!0}},g={args:{disabled:!0,name:`email`,children:(0,c.jsx)(`input`,{id:`email`,name:`email`,type:`email`,className:n.input,placeholder:`voce@empresa.com`,disabled:!0})}},_={render:()=>(0,c.jsx)(a,{label:`Nome completo`,name:`fullName`,placeholder:`Maria Silva`,description:`Como aparece no comprovante.`})},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{}`,...u.parameters?.docs?.source}}},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  args: {
    required: true
  }
}`,...d.parameters?.docs?.source}}},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  args: {
    description: 'Usamos este e-mail para enviar o recibo.'
  }
}`,...f.parameters?.docs?.source}}},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  args: {
    error: 'Informe um e-mail válido.',
    children: <input id="email" name="email" type="email" className={[inputStyles.input, inputStyles.inputInvalid].join(' ')} defaultValue="invalido" aria-invalid />
  }
}`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  args: {
    labelSize: 'sm'
  }
}`,...m.parameters?.docs?.source}}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  args: {
    labelHidden: true
  }
}`,...h.parameters?.docs?.source}}},g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  args: {
    disabled: true,
    name: 'email',
    children: <input id="email" name="email" type="email" className={inputStyles.input} placeholder="voce@empresa.com" disabled />
  }
}`,...g.parameters?.docs?.source}}},_.parameters={..._.parameters,docs:{..._.parameters?.docs,source:{originalSource:`{
  render: () => <TextInput label="Nome completo" name="fullName" placeholder="Maria Silva" description="Como aparece no comprovante." />
}`,..._.parameters?.docs?.source},description:{story:`TextInput already composes FormField internally.`,..._.parameters?.docs?.description}}},v=[`Default`,`Required`,`WithDescription`,`Error`,`SmallLabel`,`LabelHidden`,`Disabled`,`WithTextInput`]}))();export{u as Default,g as Disabled,p as Error,h as LabelHidden,d as Required,m as SmallLabel,f as WithDescription,_ as WithTextInput,v as __namedExportsOrder,l as default};