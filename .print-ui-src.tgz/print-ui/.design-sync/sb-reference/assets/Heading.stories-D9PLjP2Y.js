import{i as e}from"./preload-helper-CT_b8DTk.js";import{t}from"./jsx-runtime-DqZldVDK.js";import{n,t as r}from"./Heading-DD4784Mz.js";var i,a,o,s,c,l;e((()=>{n(),i=t(),a={title:`Foundation/Heading`,component:r,tags:[`autodocs`],args:{children:`Título do Print Forms`,level:2},argTypes:{level:{control:`select`,options:[1,2,3,4,5,6]},variant:{control:`select`,options:[`xl`,`lg`,`md`]}}},o={},s={render:()=>(0,i.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:16},children:[(0,i.jsx)(r,{level:1,children:`Heading level 1`}),(0,i.jsx)(r,{level:2,children:`Heading level 2`}),(0,i.jsx)(r,{level:3,children:`Heading level 3`}),(0,i.jsx)(r,{level:4,children:`Heading level 4`}),(0,i.jsx)(r,{level:5,children:`Heading level 5`}),(0,i.jsx)(r,{level:6,children:`Heading level 6`})]})},c={render:()=>(0,i.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:16},children:[(0,i.jsx)(r,{variant:`xl`,children:`Variant xl`}),(0,i.jsx)(r,{variant:`lg`,children:`Variant lg`}),(0,i.jsx)(r,{variant:`md`,children:`Variant md`})]})},o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{}`,...o.parameters?.docs?.source}}},s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  render: () => <div style={{
    display: 'flex',
    flexDirection: 'column',
    gap: 16
  }}>
      <Heading level={1}>Heading level 1</Heading>
      <Heading level={2}>Heading level 2</Heading>
      <Heading level={3}>Heading level 3</Heading>
      <Heading level={4}>Heading level 4</Heading>
      <Heading level={5}>Heading level 5</Heading>
      <Heading level={6}>Heading level 6</Heading>
    </div>
}`,...s.parameters?.docs?.source}}},c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  render: () => <div style={{
    display: 'flex',
    flexDirection: 'column',
    gap: 16
  }}>
      <Heading variant="xl">Variant xl</Heading>
      <Heading variant="lg">Variant lg</Heading>
      <Heading variant="md">Variant md</Heading>
    </div>
}`,...c.parameters?.docs?.source}}},l=[`Default`,`Levels`,`Variants`]}))();export{o as Default,s as Levels,c as Variants,l as __namedExportsOrder,a as default};