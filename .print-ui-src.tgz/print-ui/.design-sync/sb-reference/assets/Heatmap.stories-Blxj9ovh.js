import{i as e}from"./preload-helper-CT_b8DTk.js";import{t}from"./jsx-runtime-DqZldVDK.js";import{i as n,t as r}from"./bones-3A6-Z4mP.js";var i,a,o,s,c,l,u,d,f,p=e((()=>{i=`_root_vjuqt_1`,a=`_grid_vjuqt_6`,o=`_hoursRow_vjuqt_13`,s=`_row_vjuqt_14`,c=`_hourLabel_vjuqt_21`,l=`_weekdayLabel_vjuqt_34`,u=`_cell_vjuqt_46`,d=`_skeleton_vjuqt_54`,f={root:i,grid:a,hoursRow:o,row:s,hourLabel:c,weekdayLabel:l,cell:u,skeleton:d}}));function m(e,t){return t<=0||e<=0?0:Math.min(1,e/t)}function h(e){return e<=0?`var(--pf-o-white)`:`rgb(${Math.round(136+-92*e)} ${Math.round(144+-79*e)} ${Math.round(100+-58*e)})`}function g({cells:e,loading:t=!1,className:n,"aria-label":i=`Mapa de calor por dia e hora`}){let a=[f.root,n].filter(Boolean).join(` `),o=Math.max(0,...e.map(e=>e.count)),s=new Map(e.map(e=>[`${e.weekday}-${e.hour}`,e.count]));return t?(0,_.jsx)(`div`,{className:a,role:`img`,"aria-label":i,"aria-busy":`true`,children:(0,_.jsx)(r,{className:f.skeleton,height:180,width:`100%`})}):(0,_.jsx)(`div`,{className:a,role:`img`,"aria-label":i,children:(0,_.jsxs)(`div`,{className:f.grid,"aria-hidden":`true`,children:[(0,_.jsxs)(`div`,{className:f.hoursRow,children:[(0,_.jsx)(`span`,{className:f.weekdayLabel}),y.map(e=>(0,_.jsx)(`span`,{className:f.hourLabel,children:e%3==0?String(e).padStart(2,`0`):``},`h-${e}`))]}),v.map((e,t)=>(0,_.jsxs)(`div`,{className:f.row,children:[(0,_.jsx)(`span`,{className:f.weekdayLabel,children:e}),y.map(n=>{let r=s.get(`${t}-${n}`)??0,i=m(r,o);return(0,_.jsx)(`span`,{className:f.cell,style:{backgroundColor:h(i)},title:`${e} ${n}h: ${r}`},`${t}-${n}`)})]},e))]})})}var _,v,y,b=e((()=>{n(),p(),_=t(),v=[`Dom`,`Seg`,`Ter`,`Qua`,`Qui`,`Sex`,`Sáb`],y=Array.from({length:24},(e,t)=>t),g.__docgenInfo={description:``,methods:[],displayName:`Heatmap`,props:{cells:{required:!0,tsType:{name:`Array`,elements:[{name:`signature`,type:`object`,raw:`{
  /** 0 = domingo … 6 = sábado */
  weekday: number;
  /** 0–23 */
  hour: number;
  count: number;
}`,signature:{properties:[{key:`weekday`,value:{name:`number`,required:!0},description:`0 = domingo … 6 = sábado`},{key:`hour`,value:{name:`number`,required:!0},description:`0–23`},{key:`count`,value:{name:`number`,required:!0}}]}}],raw:`HeatmapCell[]`},description:``},loading:{required:!1,tsType:{name:`boolean`},description:``,defaultValue:{value:`false`,computed:!1}},className:{required:!1,tsType:{name:`string`},description:``},"aria-label":{required:!1,tsType:{name:`string`},description:``,defaultValue:{value:`'Mapa de calor por dia e hora'`,computed:!1}}}}}));function x(){let e=[];for(let t=0;t<7;t+=1)for(let n=0;n<24;n+=1){let r=t===0||t===6,i=n>=8&&n<=11?1:n>=14&&n<=18?.85:n>=20&&n<=22?.45:.1,a=r?.55:1,o=(t*17+n*13)%7/7,s=Math.round(i*a*(8+o*20));s>0&&e.push({weekday:t,hour:n,count:s})}return e}var S,C,w,T,E,D;e((()=>{b(),S={title:`Data/Heatmap`,component:g,tags:[`autodocs`],args:{cells:x(),loading:!1,"aria-label":`Mapa de calor por dia e hora`},argTypes:{loading:{control:`boolean`}}},C={},w={args:{loading:!0}},T={args:{cells:[{weekday:1,hour:9,count:12},{weekday:1,hour:10,count:18},{weekday:2,hour:15,count:7},{weekday:3,hour:11,count:22},{weekday:4,hour:16,count:9},{weekday:5,hour:8,count:14},{weekday:5,hour:20,count:5}],"aria-label":`Picos de publicação`}},E={args:{cells:[]}},C.parameters={...C.parameters,docs:{...C.parameters?.docs,source:{originalSource:`{}`,...C.parameters?.docs?.source}}},w.parameters={...w.parameters,docs:{...w.parameters?.docs,source:{originalSource:`{
  args: {
    loading: true
  }
}`,...w.parameters?.docs?.source}}},T.parameters={...T.parameters,docs:{...T.parameters?.docs,source:{originalSource:`{
  args: {
    cells: [{
      weekday: 1,
      hour: 9,
      count: 12
    }, {
      weekday: 1,
      hour: 10,
      count: 18
    }, {
      weekday: 2,
      hour: 15,
      count: 7
    }, {
      weekday: 3,
      hour: 11,
      count: 22
    }, {
      weekday: 4,
      hour: 16,
      count: 9
    }, {
      weekday: 5,
      hour: 8,
      count: 14
    }, {
      weekday: 5,
      hour: 20,
      count: 5
    }],
    'aria-label': 'Picos de publicação'
  }
}`,...T.parameters?.docs?.source}}},E.parameters={...E.parameters,docs:{...E.parameters?.docs,source:{originalSource:`{
  args: {
    cells: []
  }
}`,...E.parameters?.docs?.source}}},D=[`Default`,`Loading`,`Sparse`,`Empty`]}))();export{C as Default,E as Empty,w as Loading,T as Sparse,D as __namedExportsOrder,S as default};