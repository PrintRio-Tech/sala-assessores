import{i as e}from"./preload-helper-CT_b8DTk.js";import{t}from"./jsx-runtime-DqZldVDK.js";import{d as n,f as r,p as i,u as a}from"./iframe-DiXF9pnZ.js";var o,s,c,l,u,d,f,p,m,h;e((()=>{i(),n(),o=t(),s={title:`Foundation/Icon`,component:a,tags:[`autodocs`],args:{src:r.nav.home,size:24,label:`Home`},argTypes:{size:{control:{type:`number`,min:12,max:48,step:4}}}},c={},l={args:{src:r.nav.home,label:`Home`}},u={args:{src:r.ui.search,label:`Search`}},d={args:{src:r.ui.check,label:`Check`}},f={args:{src:r.toast.success,label:`Success`}},p={render:()=>(0,o.jsx)(`div`,{style:{display:`flex`,gap:16,alignItems:`center`,flexWrap:`wrap`},children:Object.entries(r.nav).map(([e,t])=>(0,o.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,alignItems:`center`,gap:6},children:[(0,o.jsx)(a,{src:t,size:24,label:e}),(0,o.jsx)(`span`,{style:{fontSize:11},children:e})]},e))})},m={render:()=>(0,o.jsxs)(`div`,{style:{display:`flex`,gap:16,alignItems:`center`},children:[(0,o.jsx)(a,{src:r.nav.home,size:16,label:`16`}),(0,o.jsx)(a,{src:r.nav.home,size:20,label:`20`}),(0,o.jsx)(a,{src:r.nav.home,size:24,label:`24`}),(0,o.jsx)(a,{src:r.nav.home,size:32,label:`32`})]})},c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{}`,...c.parameters?.docs?.source}}},l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  args: {
    src: ICONS.nav.home,
    label: 'Home'
  }
}`,...l.parameters?.docs?.source}}},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  args: {
    src: ICONS.ui.search,
    label: 'Search'
  }
}`,...u.parameters?.docs?.source}}},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  args: {
    src: ICONS.ui.check,
    label: 'Check'
  }
}`,...d.parameters?.docs?.source}}},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  args: {
    src: ICONS.toast.success,
    label: 'Success'
  }
}`,...f.parameters?.docs?.source}}},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  render: () => <div style={{
    display: 'flex',
    gap: 16,
    alignItems: 'center',
    flexWrap: 'wrap'
  }}>
      {Object.entries(ICONS.nav).map(([name, src]) => <div key={name} style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 6
    }}>
          <Icon src={src} size={24} label={name} />
          <span style={{
        fontSize: 11
      }}>{name}</span>
        </div>)}
    </div>
}`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  render: () => <div style={{
    display: 'flex',
    gap: 16,
    alignItems: 'center'
  }}>
      <Icon src={ICONS.nav.home} size={16} label="16" />
      <Icon src={ICONS.nav.home} size={20} label="20" />
      <Icon src={ICONS.nav.home} size={24} label="24" />
      <Icon src={ICONS.nav.home} size={32} label="32" />
    </div>
}`,...m.parameters?.docs?.source}}},h=[`Default`,`Home`,`Search`,`Check`,`ToastSuccess`,`NavSet`,`Sizes`]}))();export{d as Check,c as Default,l as Home,p as NavSet,u as Search,m as Sizes,f as ToastSuccess,h as __namedExportsOrder,s as default};