import{i as e}from"./preload-helper-CT_b8DTk.js";import{t}from"./jsx-runtime-DqZldVDK.js";import{d as n,f as r,p as i,u as a}from"./iframe-DiXF9pnZ.js";function o(e){return Object.entries(e).flatMap(([e,t])=>Object.entries(t).map(([t,n])=>({group:e,name:t,src:n})))}var s,c,l,u,d,f,p,m;e((()=>{i(),n(),s=t(),c=o(r),l={display:`grid`,gridTemplateColumns:`repeat(auto-fill, minmax(120px, 1fr))`,gap:16},u={display:`flex`,flexDirection:`column`,alignItems:`center`,gap:8,padding:12,borderRadius:8,backgroundColor:`color-mix(in srgb, currentColor 5%, transparent)`},d={title:`Foundation/Icons`,tags:[`autodocs`],parameters:{layout:`padded`}},f={render:()=>(0,s.jsx)(`div`,{style:l,children:c.map(({group:e,name:t,src:n})=>(0,s.jsxs)(`div`,{style:u,children:[(0,s.jsx)(a,{src:n,size:24,label:`${e}.${t}`}),(0,s.jsxs)(`span`,{style:{fontSize:11,textAlign:`center`,wordBreak:`break-all`},children:[e,`.`,t]})]},`${e}.${t}`))})},p={render:()=>(0,s.jsx)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:32},children:Object.entries(r).map(([e,t])=>(0,s.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:12},children:[(0,s.jsx)(`h3`,{style:{margin:0,textTransform:`capitalize`},children:e}),(0,s.jsx)(`div`,{style:l,children:Object.entries(t).map(([t,n])=>(0,s.jsxs)(`div`,{style:u,children:[(0,s.jsx)(a,{src:n,size:24,label:`${e}.${t}`}),(0,s.jsx)(`span`,{style:{fontSize:11,textAlign:`center`},children:t})]},t))})]},e))})},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  render: () => <div style={grid}>
      {flatIcons.map(({
      group,
      name,
      src
    }) => <div key={\`\${group}.\${name}\`} style={cell}>
          <Icon src={src} size={24} label={\`\${group}.\${name}\`} />
          <span style={{
        fontSize: 11,
        textAlign: 'center',
        wordBreak: 'break-all'
      }}>
            {group}.{name}
          </span>
        </div>)}
    </div>
}`,...f.parameters?.docs?.source}}},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  render: () => <div style={{
    display: 'flex',
    flexDirection: 'column',
    gap: 32
  }}>
      {Object.entries(ICONS).map(([group, icons]) => <div key={group} style={{
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }}>
          <h3 style={{
        margin: 0,
        textTransform: 'capitalize'
      }}>{group}</h3>
          <div style={grid}>
            {Object.entries(icons).map(([name, src]) => <div key={name} style={cell}>
                <Icon src={src} size={24} label={\`\${group}.\${name}\`} />
                <span style={{
            fontSize: 11,
            textAlign: 'center'
          }}>{name}</span>
              </div>)}
          </div>
        </div>)}
    </div>
}`,...p.parameters?.docs?.source}}},m=[`All`,`ByGroup`]}))();export{f as All,p as ByGroup,m as __namedExportsOrder,d as default};