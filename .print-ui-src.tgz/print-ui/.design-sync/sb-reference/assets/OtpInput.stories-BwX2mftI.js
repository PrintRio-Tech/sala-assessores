import{i as e,s as t}from"./preload-helper-CT_b8DTk.js";import{t as n}from"./react-B7Te67-h.js";import{t as r}from"./jsx-runtime-DqZldVDK.js";import{n as i,t as a}from"./FormField-DK3kFsCC.js";var o,s,c,l=e((()=>{o=`_group_ajvc0_1`,s=`_digit_ajvc0_6`,c={group:o,digit:s}}));function u(e,t){return Array.from({length:t},(t,n)=>e[n]??``)}function d({label:e,required:t=!1,name:n,value:r,onChange:i,onComplete:o,length:s=m,error:l,disabled:d=!1,autoFocus:h=!1}){let g=(0,f.useRef)([]),_=u(r,s);function v(e){g.current[e]?.focus(),g.current[e]?.select()}function y(e){let t=e.join(``).slice(0,s);i(t),t.length===s&&/^\d+$/.test(t)&&o?.(t)}function b(e,t=0){let n=e.replace(/\D/g,``).slice(0,s-t);if(!n)return;let i=u(r,s);for(let e=0;e<n.length;e+=1)i[t+e]=n[e]??``;y(i);let a=Math.min(t+n.length,s-1);i.join(``).length<s&&v(a)}function x(e,t){let n=t.replace(/\D/g,``),i=u(r,s);if(n.length>1){b(n,e);return}i[e]=n.slice(-1),y(i),n&&e<s-1&&v(e+1)}function S(e,t){if(t.key===`Backspace`){t.preventDefault();let n=u(r,s);if(n[e]){n[e]=``,y(n);return}e>0&&(n[e-1]=``,y(n),v(e-1));return}if(t.key===`ArrowLeft`&&e>0){t.preventDefault(),v(e-1);return}t.key===`ArrowRight`&&e<s-1&&(t.preventDefault(),v(e+1))}function C(e,t){e.preventDefault(),b(e.clipboardData.getData(`text`),t)}return(0,p.jsxs)(a,{label:e,required:t,name:n,error:l,disabled:d,invalid:!!l,children:[(0,p.jsx)(`input`,{type:`hidden`,name:n,value:r,autoComplete:`off`}),(0,p.jsx)(`div`,{className:c.group,role:`group`,"aria-label":e,"data-invalid":l?!0:void 0,children:_.map((e,t)=>(0,p.jsx)(`input`,{ref:e=>{g.current[t]=e},className:c.digit,type:`text`,inputMode:`numeric`,pattern:`[0-9]*`,autoComplete:t===0?`one-time-code`:`off`,autoFocus:h&&t===0,"aria-label":`Dígito ${t+1} de ${s}`,maxLength:1,value:e,disabled:d,"aria-invalid":l?!0:void 0,onChange:e=>x(t,e.target.value),onKeyDown:e=>S(t,e),onPaste:e=>C(e,t),onFocus:e=>e.currentTarget.select()},t))})]})}var f,p,m,h=e((()=>{f=t(n(),1),i(),l(),p=r(),m=6,d.__docgenInfo={description:``,methods:[],displayName:`OtpInput`,props:{label:{required:!0,tsType:{name:`string`},description:``},required:{required:!1,tsType:{name:`boolean`},description:``,defaultValue:{value:`false`,computed:!1}},name:{required:!0,tsType:{name:`string`},description:``},value:{required:!0,tsType:{name:`string`},description:``},onChange:{required:!0,tsType:{name:`signature`,type:`function`,raw:`(value: string) => void`,signature:{arguments:[{type:{name:`string`},name:`value`}],return:{name:`void`}}},description:``},onComplete:{required:!1,tsType:{name:`signature`,type:`function`,raw:`(value: string) => void`,signature:{arguments:[{type:{name:`string`},name:`value`}],return:{name:`void`}}},description:``},length:{required:!1,tsType:{name:`number`},description:``,defaultValue:{value:`6`,computed:!1}},error:{required:!1,tsType:{name:`string`},description:``},disabled:{required:!1,tsType:{name:`boolean`},description:``,defaultValue:{value:`false`,computed:!1}},autoFocus:{required:!1,tsType:{name:`boolean`},description:``,defaultValue:{value:`false`,computed:!1}}}}})),g,_,v,y,b,x,S,C,w,T,E;e((()=>{g=t(n(),1),h(),_=r(),v={title:`Forms/OtpInput`,component:d,tags:[`autodocs`],args:{label:`Código de verificação`,name:`otp`,value:``,onChange:()=>void 0,length:6,required:!1,disabled:!1,autoFocus:!1},argTypes:{length:{control:{type:`number`,min:4,max:8}}},render:function(e){let[t,n]=(0,g.useState)(e.value);return(0,_.jsx)(d,{...e,value:t,onChange:n})}},y={},b={args:{required:!0}},x={args:{value:`482910`}},S={args:{length:4,label:`PIN`}},C={args:{value:`123456`,error:`Código inválido. Tente novamente.`}},w={args:{disabled:!0,value:`000000`}},T={args:{autoFocus:!0}},y.parameters={...y.parameters,docs:{...y.parameters?.docs,source:{originalSource:`{}`,...y.parameters?.docs?.source}}},b.parameters={...b.parameters,docs:{...b.parameters?.docs,source:{originalSource:`{
  args: {
    required: true
  }
}`,...b.parameters?.docs?.source}}},x.parameters={...x.parameters,docs:{...x.parameters?.docs,source:{originalSource:`{
  args: {
    value: '482910'
  }
}`,...x.parameters?.docs?.source}}},S.parameters={...S.parameters,docs:{...S.parameters?.docs,source:{originalSource:`{
  args: {
    length: 4,
    label: 'PIN'
  }
}`,...S.parameters?.docs?.source}}},C.parameters={...C.parameters,docs:{...C.parameters?.docs,source:{originalSource:`{
  args: {
    value: '123456',
    error: 'Código inválido. Tente novamente.'
  }
}`,...C.parameters?.docs?.source}}},w.parameters={...w.parameters,docs:{...w.parameters?.docs,source:{originalSource:`{
  args: {
    disabled: true,
    value: '000000'
  }
}`,...w.parameters?.docs?.source}}},T.parameters={...T.parameters,docs:{...T.parameters?.docs,source:{originalSource:`{
  args: {
    autoFocus: true
  }
}`,...T.parameters?.docs?.source}}},E=[`Default`,`Required`,`Filled`,`FourDigits`,`Error`,`Disabled`,`AutoFocus`]}))();export{T as AutoFocus,y as Default,w as Disabled,C as Error,x as Filled,S as FourDigits,b as Required,E as __namedExportsOrder,v as default};