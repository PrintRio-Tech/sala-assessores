import{i as e,s as t}from"./preload-helper-CT_b8DTk.js";import{t as n}from"./react-B7Te67-h.js";import{t as r}from"./jsx-runtime-DqZldVDK.js";var i,a,o,s,c,l,u,d,f=e((()=>{i=`_pagination_1nfnz_1`,a=`_summary_1nfnz_10`,o=`_controls_1nfnz_20`,s=`_pages_1nfnz_26`,c=`_navButton_1nfnz_35`,l=`_pageButton_1nfnz_36`,u=`_ellipsis_1nfnz_82`,d={pagination:i,summary:a,controls:o,pages:s,navButton:c,pageButton:l,ellipsis:u}}));function p(e,t){return Array.from({length:t-e+1},(t,n)=>e+n)}function m(e,t,n){if(t<=1)return[1];if(t<=n*2+5)return p(1,t);let r=Math.max(e-n,1),i=Math.min(e+n,t),a=r>2,o=i<t-1;return!a&&o?[...p(1,3+n*2),`ellipsis`,t]:a&&!o?[1,`ellipsis`,...p(t-(2+n*2),t)]:[1,`ellipsis`,...p(r,i),`ellipsis`,t]}function h({page:e,pageSize:t,totalItems:n,onPageChange:r,siblingCount:i=1,className:a,...o}){let s=Math.max(1,Math.ceil(n/t)),c=Math.min(Math.max(e,1),s),l=n===0?0:(c-1)*t+1,u=Math.min(c*t,n),f=m(c,s,i);return(0,g.jsxs)(`nav`,{className:[d.pagination,a].filter(Boolean).join(` `),"aria-label":`Paginação`,...o,children:[(0,g.jsx)(`p`,{className:d.summary,children:n===0?`Nenhum item`:`${l}–${u} de ${n}`}),(0,g.jsxs)(`div`,{className:d.controls,children:[(0,g.jsx)(`button`,{type:`button`,className:d.navButton,onClick:()=>r(c-1),disabled:c<=1,"aria-label":`Página anterior`,children:`‹`}),(0,g.jsx)(`ul`,{className:d.pages,children:f.map((e,t)=>e===`ellipsis`?(0,g.jsx)(`li`,{className:d.ellipsis,"aria-hidden":!0,children:`…`},`ellipsis-${t}`):(0,g.jsx)(`li`,{children:(0,g.jsx)(`button`,{type:`button`,className:d.pageButton,"data-active":e===c||void 0,onClick:()=>{typeof e==`number`&&r(e)},"aria-label":`Página ${e}`,"aria-current":e===c?`page`:void 0,children:e})},e))}),(0,g.jsx)(`button`,{type:`button`,className:d.navButton,onClick:()=>r(c+1),disabled:c>=s,"aria-label":`Próxima página`,children:`›`})]})]})}var g,_=e((()=>{f(),g=r(),h.__docgenInfo={description:``,methods:[],displayName:`Pagination`,props:{page:{required:!0,tsType:{name:`number`},description:``},pageSize:{required:!0,tsType:{name:`number`},description:``},totalItems:{required:!0,tsType:{name:`number`},description:``},onPageChange:{required:!0,tsType:{name:`signature`,type:`function`,raw:`(page: number) => void`,signature:{arguments:[{type:{name:`number`},name:`page`}],return:{name:`void`}}},description:``},siblingCount:{required:!1,tsType:{name:`number`},description:``,defaultValue:{value:`1`,computed:!1}},className:{required:!1,tsType:{name:`string`},description:``}}}})),v,y,b,x,S,C,w,T,E,D;e((()=>{v=t(n(),1),_(),y=r(),{fn:b}=__STORYBOOK_MODULE_TEST__,x={title:`Data/Pagination`,component:h,tags:[`autodocs`],args:{page:1,pageSize:10,totalItems:95,siblingCount:1,onPageChange:b()},argTypes:{page:{control:{type:`number`,min:1}},pageSize:{control:{type:`number`,min:1}},totalItems:{control:{type:`number`,min:0}},siblingCount:{control:{type:`number`,min:0,max:3}}}},S={},C={args:{page:5,totalItems:95}},w={args:{page:1,pageSize:10,totalItems:25}},T={args:{page:1,pageSize:10,totalItems:0}},E={render:e=>{let[t,n]=(0,v.useState)(e.page);return(0,y.jsx)(h,{...e,page:t,onPageChange:t=>{n(t),e.onPageChange(t)}})}},S.parameters={...S.parameters,docs:{...S.parameters?.docs,source:{originalSource:`{}`,...S.parameters?.docs?.source}}},C.parameters={...C.parameters,docs:{...C.parameters?.docs,source:{originalSource:`{
  args: {
    page: 5,
    totalItems: 95
  }
}`,...C.parameters?.docs?.source}}},w.parameters={...w.parameters,docs:{...w.parameters?.docs,source:{originalSource:`{
  args: {
    page: 1,
    pageSize: 10,
    totalItems: 25
  }
}`,...w.parameters?.docs?.source}}},T.parameters={...T.parameters,docs:{...T.parameters?.docs,source:{originalSource:`{
  args: {
    page: 1,
    pageSize: 10,
    totalItems: 0
  }
}`,...T.parameters?.docs?.source}}},E.parameters={...E.parameters,docs:{...E.parameters?.docs,source:{originalSource:`{
  render: args => {
    const [page, setPage] = useState(args.page);
    return <Pagination {...args} page={page} onPageChange={next => {
      setPage(next);
      args.onPageChange(next);
    }} />;
  }
}`,...E.parameters?.docs?.source}}},D=[`Default`,`MiddlePage`,`FewPages`,`Empty`,`Interactive`]}))();export{S as Default,T as Empty,w as FewPages,E as Interactive,C as MiddlePage,D as __namedExportsOrder,x as default};