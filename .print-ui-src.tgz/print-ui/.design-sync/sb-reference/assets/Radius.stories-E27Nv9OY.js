import{i as e}from"./preload-helper-CT_b8DTk.js";import{t}from"./jsx-runtime-DqZldVDK.js";import{i as n,n as r,t as i}from"./theme-CiMS1Kdp.js";var a,o,s,c,l,u,d;e((()=>{i(),a=t(),o={display:`grid`,gridTemplateColumns:`repeat(auto-fill, minmax(140px, 1fr))`,gap:20},s={width:96,height:96,backgroundColor:`var(--pf-primary, #2C412A)`,opacity:.9},c={title:`Foundation/Radius`,tags:[`autodocs`],parameters:{layout:`padded`}},l={name:`Radius`,render:()=>(0,a.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:24},children:[(0,a.jsx)(`h3`,{style:{margin:0},children:`Radius`}),(0,a.jsx)(`div`,{style:o,children:Object.entries(n).map(([e,t])=>(0,a.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:8,alignItems:`flex-start`},children:[(0,a.jsx)(`div`,{style:{...s,borderRadius:t}}),(0,a.jsx)(`span`,{style:{fontSize:13,fontWeight:600},children:e}),(0,a.jsxs)(`span`,{style:{fontSize:12,opacity:.7,fontFamily:`monospace`},children:[t,`px`]})]},e))})]})},u={name:`Layout`,render:()=>(0,a.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:16,maxWidth:420},children:[(0,a.jsx)(`h3`,{style:{margin:0},children:`Layout`}),Object.entries(r).map(([e,t])=>(0,a.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`1fr auto`,gap:12,padding:`10px 12px`,borderRadius:n.default,backgroundColor:`color-mix(in srgb, currentColor 6%, transparent)`},children:[(0,a.jsx)(`span`,{style:{fontSize:13,fontWeight:600},children:e}),(0,a.jsxs)(`span`,{style:{fontSize:12,opacity:.7,fontFamily:`monospace`},children:[t,`px`]})]},e))]})},l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  name: 'Radius',
  render: () => <div style={{
    display: 'flex',
    flexDirection: 'column',
    gap: 24
  }}>
      <h3 style={{
      margin: 0
    }}>Radius</h3>
      <div style={grid}>
        {Object.entries(radius).map(([name, value]) => <div key={name} style={{
        display: 'flex',
        flexDirection: 'column',
        gap: 8,
        alignItems: 'flex-start'
      }}>
            <div style={{
          ...boxBase,
          borderRadius: value
        }} />
            <span style={{
          fontSize: 13,
          fontWeight: 600
        }}>{name}</span>
            <span style={{
          fontSize: 12,
          opacity: 0.7,
          fontFamily: 'monospace'
        }}>
              {value}px
            </span>
          </div>)}
      </div>
    </div>
}`,...l.parameters?.docs?.source}}},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  name: 'Layout',
  render: () => <div style={{
    display: 'flex',
    flexDirection: 'column',
    gap: 16,
    maxWidth: 420
  }}>
      <h3 style={{
      margin: 0
    }}>Layout</h3>
      {Object.entries(layout).map(([name, value]) => <div key={name} style={{
      display: 'grid',
      gridTemplateColumns: '1fr auto',
      gap: 12,
      padding: '10px 12px',
      borderRadius: radius.default,
      backgroundColor: 'color-mix(in srgb, currentColor 6%, transparent)'
    }}>
          <span style={{
        fontSize: 13,
        fontWeight: 600
      }}>{name}</span>
          <span style={{
        fontSize: 12,
        opacity: 0.7,
        fontFamily: 'monospace'
      }}>
            {value}px
          </span>
        </div>)}
    </div>
}`,...u.parameters?.docs?.source}}},d=[`RadiusTokens`,`LayoutTokens`]}))();export{u as LayoutTokens,l as RadiusTokens,d as __namedExportsOrder,c as default};