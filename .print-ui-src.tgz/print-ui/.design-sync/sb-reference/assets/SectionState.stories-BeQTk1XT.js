import{i as e}from"./preload-helper-CT_b8DTk.js";import{t}from"./jsx-runtime-DqZldVDK.js";import{n,t as r}from"./Button-FMHbx6tf.js";import{n as i,t as a}from"./Text-BlaLK81_.js";var o,s,c,l,u,d=e((()=>{o=`_panel_1ejkr_1`,s=`_loadingRow_1ejkr_20`,c=`_loadingIndicator_1ejkr_26`,l=`_spin_1ejkr_1`,u={panel:o,loadingRow:s,loadingIndicator:c,spin:l}}));function f(e){return[u.panel,e].filter(Boolean).join(` `)}function p(e){return e==null?void 0:{minHeight:e}}function m(e){let{className:t,minHeight:n}=e;if(e.status===`success`)return(0,h.jsx)(h.Fragment,{children:e.children});if(e.status===`loading`){let r=e.loadingLabel??`Carregando…`;return(0,h.jsx)(`div`,{className:f(t),style:p(n),role:`status`,"aria-live":`polite`,children:(0,h.jsxs)(`div`,{className:u.loadingRow,children:[(0,h.jsx)(`span`,{className:u.loadingIndicator,"aria-hidden":`true`}),(0,h.jsx)(a,{tone:`muted`,children:r})]})})}return(0,h.jsxs)(`div`,{className:f(t),style:p(n),role:`alert`,children:[(0,h.jsx)(a,{tone:`error`,children:e.errorMessage}),e.errorDescription?(0,h.jsx)(a,{tone:`muted`,children:e.errorDescription}):null,(0,h.jsx)(r,{type:`button`,variant:`outline`,size:`sm`,onClick:e.onRetry,children:`Tentar novamente`})]})}var h,g=e((()=>{n(),i(),d(),h=t(),m.__docgenInfo={description:``,methods:[],displayName:`SectionState`}})),_,v,y,b,x,S,C,w,T;e((()=>{g(),_=t(),{fn:v}=__STORYBOOK_MODULE_TEST__,y={title:`Data/SectionState`,component:m,tags:[`autodocs`],args:{minHeight:160}},b={args:{status:`loading`,loadingLabel:`Carregando relatório…`}},x={args:{status:`loading`}},S={args:{status:`error`,errorMessage:`Não foi possível carregar o relatório.`,errorDescription:`Verifique sua conexão e tente novamente.`,onRetry:v()}},C={args:{status:`error`,errorMessage:`Falha ao buscar dados.`,onRetry:v()}},w={args:{status:`success`,children:(0,_.jsxs)(`div`,{style:{padding:16},children:[(0,_.jsx)(`p`,{style:{margin:0,fontWeight:600},children:`Relatório carregado`}),(0,_.jsx)(`p`,{style:{margin:`8px 0 0`,opacity:.7},children:`24 matérias publicadas nesta semana.`})]})}},b.parameters={...b.parameters,docs:{...b.parameters?.docs,source:{originalSource:`{
  args: {
    status: 'loading',
    loadingLabel: 'Carregando relatório…'
  }
}`,...b.parameters?.docs?.source}}},x.parameters={...x.parameters,docs:{...x.parameters?.docs,source:{originalSource:`{
  args: {
    status: 'loading'
  }
}`,...x.parameters?.docs?.source}}},S.parameters={...S.parameters,docs:{...S.parameters?.docs,source:{originalSource:`{
  args: {
    status: 'error',
    errorMessage: 'Não foi possível carregar o relatório.',
    errorDescription: 'Verifique sua conexão e tente novamente.',
    onRetry: fn()
  }
}`,...S.parameters?.docs?.source}}},C.parameters={...C.parameters,docs:{...C.parameters?.docs,source:{originalSource:`{
  args: {
    status: 'error',
    errorMessage: 'Falha ao buscar dados.',
    onRetry: fn()
  }
}`,...C.parameters?.docs?.source}}},w.parameters={...w.parameters,docs:{...w.parameters?.docs,source:{originalSource:`{
  args: {
    status: 'success',
    children: <div style={{
      padding: 16
    }}>
        <p style={{
        margin: 0,
        fontWeight: 600
      }}>Relatório carregado</p>
        <p style={{
        margin: '8px 0 0',
        opacity: 0.7
      }}>
          24 matérias publicadas nesta semana.
        </p>
      </div>
  }
}`,...w.parameters?.docs?.source}}},T=[`Loading`,`LoadingDefaultLabel`,`Error`,`ErrorWithoutDescription`,`Success`]}))();export{S as Error,C as ErrorWithoutDescription,b as Loading,x as LoadingDefaultLabel,w as Success,T as __namedExportsOrder,y as default};