import{i as e}from"./preload-helper-CT_b8DTk.js";import{t}from"./jsx-runtime-DqZldVDK.js";import{o as n,t as r}from"./theme-CiMS1Kdp.js";var i,a,o,s,c;e((()=>{r(),i=t(),a={display:`grid`,gridTemplateColumns:`160px 1fr 64px`,alignItems:`center`,gap:16,padding:`8px 0`},o={title:`Foundation/Spacing`,tags:[`autodocs`],parameters:{layout:`padded`}},s={render:()=>(0,i.jsx)(`div`,{style:{display:`flex`,flexDirection:`column`,maxWidth:560},children:Object.entries(n).map(([e,t])=>(0,i.jsxs)(`div`,{style:a,children:[(0,i.jsx)(`span`,{style:{fontSize:13,fontWeight:600},children:e}),(0,i.jsx)(`div`,{style:{height:16,width:t,maxWidth:`100%`,borderRadius:4,backgroundColor:`var(--pf-primary, #2C412A)`,opacity:.85}}),(0,i.jsxs)(`span`,{style:{fontSize:12,opacity:.7,fontFamily:`monospace`},children:[t,`px`]})]},e))})},s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  render: () => <div style={{
    display: 'flex',
    flexDirection: 'column',
    maxWidth: 560
  }}>
      {Object.entries(spacing).map(([name, value]) => <div key={name} style={row}>
          <span style={{
        fontSize: 13,
        fontWeight: 600
      }}>{name}</span>
          <div style={{
        height: 16,
        width: value,
        maxWidth: '100%',
        borderRadius: 4,
        backgroundColor: 'var(--pf-primary, #2C412A)',
        opacity: 0.85
      }} />
          <span style={{
        fontSize: 12,
        opacity: 0.7,
        fontFamily: 'monospace'
      }}>
            {value}px
          </span>
        </div>)}
    </div>
}`,...s.parameters?.docs?.source}}},c=[`Default`]}))();export{s as Default,c as __namedExportsOrder,o as default};