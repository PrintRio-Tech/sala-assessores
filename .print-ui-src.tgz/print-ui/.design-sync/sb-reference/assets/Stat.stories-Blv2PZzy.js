import{i as e}from"./preload-helper-CT_b8DTk.js";import{t}from"./jsx-runtime-DqZldVDK.js";import{n,t as r}from"./Text-BlaLK81_.js";import{i,n as a}from"./bones-3A6-Z4mP.js";var o,s,c,l,u,d,f=e((()=>{o=`_stat_1399y_1`,s=`_label_1399y_7`,c=`_value_1399y_13`,l=`_primary_1399y_35`,u=`_valueSkeleton_1399y_39`,d={stat:o,label:s,value:c,primary:l,valueSkeleton:u}}));function p({value:e,label:t,emphasis:n=`default`,loading:i=!1,className:o,...s}){let c=[d.stat,o].filter(Boolean).join(` `),l=[d.value,n===`primary`?d.primary:void 0].filter(Boolean).join(` `);return i?(0,m.jsxs)(`div`,{role:`group`,"aria-label":t,"aria-busy":`true`,className:c,...s,children:[(0,m.jsx)(r,{as:`p`,variant:`labelSm`,tone:`muted`,className:d.label,children:t}),(0,m.jsx)(a,{className:d.valueSkeleton,width:`55%`,"aria-hidden":`true`})]}):(0,m.jsxs)(`div`,{role:`group`,"aria-label":`${e}, ${t}`,className:c,...s,children:[(0,m.jsx)(r,{as:`p`,variant:`labelSm`,tone:`muted`,className:d.label,children:t}),(0,m.jsx)(`p`,{className:l,children:e})]})}var m,h=e((()=>{i(),n(),f(),m=t(),p.__docgenInfo={description:``,methods:[],displayName:`Stat`,props:{value:{required:!0,tsType:{name:`string`},description:``},label:{required:!0,tsType:{name:`string`},description:``},emphasis:{required:!1,tsType:{name:`union`,raw:`'default' | 'primary'`,elements:[{name:`literal`,value:`'default'`},{name:`literal`,value:`'primary'`}]},description:``,defaultValue:{value:`'default'`,computed:!1}},loading:{required:!1,tsType:{name:`boolean`},description:``,defaultValue:{value:`false`,computed:!1}}}}})),g,_,v,y,b,x,S;e((()=>{h(),g=t(),_={title:`Foundation/Stat`,component:p,tags:[`autodocs`],args:{value:`1.284`,label:`Clippings`,emphasis:`default`,loading:!1},argTypes:{emphasis:{control:`select`,options:[`default`,`primary`]},loading:{control:`boolean`}}},v={},y={name:`Primary emphasis`,args:{emphasis:`primary`,value:`98%`,label:`Taxa de entrega`}},b={args:{loading:!0,label:`Clippings`}},x={render:()=>(0,g.jsxs)(`div`,{style:{display:`flex`,gap:32,flexWrap:`wrap`},children:[(0,g.jsx)(p,{value:`1.284`,label:`Clippings`}),(0,g.jsx)(p,{value:`56`,label:`Jornalistas`,emphasis:`primary`}),(0,g.jsx)(p,{value:`—`,label:`Relatórios`,loading:!0})]})},v.parameters={...v.parameters,docs:{...v.parameters?.docs,source:{originalSource:`{}`,...v.parameters?.docs?.source}}},y.parameters={...y.parameters,docs:{...y.parameters?.docs,source:{originalSource:`{
  name: 'Primary emphasis',
  args: {
    emphasis: 'primary',
    value: '98%',
    label: 'Taxa de entrega'
  }
}`,...y.parameters?.docs?.source}}},b.parameters={...b.parameters,docs:{...b.parameters?.docs,source:{originalSource:`{
  args: {
    loading: true,
    label: 'Clippings'
  }
}`,...b.parameters?.docs?.source}}},x.parameters={...x.parameters,docs:{...x.parameters?.docs,source:{originalSource:`{
  render: () => <div style={{
    display: 'flex',
    gap: 32,
    flexWrap: 'wrap'
  }}>
      <Stat value="1.284" label="Clippings" />
      <Stat value="56" label="Jornalistas" emphasis="primary" />
      <Stat value="—" label="Relatórios" loading />
    </div>
}`,...x.parameters?.docs?.source}}},S=[`Default`,`Primary`,`Loading`,`Group`]}))();export{v as Default,x as Group,b as Loading,y as Primary,S as __namedExportsOrder,_ as default};