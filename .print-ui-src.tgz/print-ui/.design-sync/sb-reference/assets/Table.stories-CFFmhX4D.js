import{i as e,s as t}from"./preload-helper-CT_b8DTk.js";import{t as n}from"./react-B7Te67-h.js";import{t as r}from"./jsx-runtime-DqZldVDK.js";import{a as i,c as a,i as o,l as s,n as c,o as l,r as u,s as d,t as f,u as p}from"./primitives-llyJwXJR.js";import{n as m,t as h}from"./RowActions-D-rCmrvg.js";var g,_,v,y,b,x,S,C,w,T;e((()=>{g=t(n(),1),p(),m(),_=r(),{fn:v}=__STORYBOOK_MODULE_TEST__,y=[{id:`1`,name:`Ana Costa`,role:`Editora`,status:`Ativo`},{id:`2`,name:`Bruno Lima`,role:`Repórter`,status:`Ativo`},{id:`3`,name:`Carla Dias`,role:`Designer`,status:`Inativo`}],b={title:`Data/Table`,component:f,tags:[`autodocs`],args:{striped:!1,children:(0,_.jsxs)(_.Fragment,{children:[(0,_.jsx)(o,{children:`Equipe editorial`}),(0,_.jsx)(a,{children:(0,_.jsxs)(s,{children:[(0,_.jsx)(d,{children:`Nome`}),(0,_.jsx)(d,{children:`Função`}),(0,_.jsx)(d,{children:`Status`}),(0,_.jsx)(d,{"aria-label":`Ações`})]})}),(0,_.jsx)(u,{children:y.map(e=>(0,_.jsxs)(s,{children:[(0,_.jsx)(i,{children:e.name}),(0,_.jsx)(i,{children:e.role}),(0,_.jsx)(i,{children:e.status}),(0,_.jsx)(c,{children:(0,_.jsx)(h,{actions:[{label:`Ver`,icon:`view`,onSelect:v()},{label:`Editar`,icon:`edit`,onSelect:v()},{label:`Excluir`,icon:`delete`,destructive:!0,onSelect:v()}]})})]},e.id))})]})},argTypes:{striped:{control:`boolean`}}},x={},S={args:{striped:!0,children:(0,_.jsxs)(_.Fragment,{children:[(0,_.jsx)(a,{children:(0,_.jsxs)(s,{children:[(0,_.jsx)(d,{children:`Nome`}),(0,_.jsx)(d,{align:`right`,children:`Matérias`})]})}),(0,_.jsx)(u,{children:y.map((e,t)=>(0,_.jsxs)(s,{children:[(0,_.jsx)(i,{children:e.name}),(0,_.jsx)(i,{align:`right`,children:12+t*4})]},e.id))})]})}},C={render:e=>{let[t,n]=(0,g.useState)(`asc`);return(0,_.jsxs)(f,{striped:e.striped,children:[(0,_.jsx)(a,{children:(0,_.jsxs)(s,{children:[(0,_.jsx)(d,{sortable:!0,sortDirection:t,onSort:()=>n(e=>e===`asc`?`desc`:`asc`),children:`Nome`}),(0,_.jsx)(d,{children:`Função`})]})}),(0,_.jsx)(u,{children:[...y].sort((e,n)=>{let r=e.name.localeCompare(n.name);return t===`desc`?-r:r}).map(e=>(0,_.jsxs)(s,{children:[(0,_.jsx)(i,{children:e.name}),(0,_.jsx)(i,{children:e.role})]},e.id))})]})}},w={args:{children:(0,_.jsxs)(_.Fragment,{children:[(0,_.jsx)(a,{children:(0,_.jsxs)(s,{children:[(0,_.jsx)(d,{children:`Nome`}),(0,_.jsx)(d,{children:`Função`})]})}),(0,_.jsx)(u,{children:(0,_.jsx)(l,{children:`Nenhum registro encontrado.`})})]})}},x.parameters={...x.parameters,docs:{...x.parameters?.docs,source:{originalSource:`{}`,...x.parameters?.docs?.source}}},S.parameters={...S.parameters,docs:{...S.parameters?.docs,source:{originalSource:`{
  args: {
    striped: true,
    children: <>
        <TableHeader>
          <TableRow>
            <TableHead>Nome</TableHead>
            <TableHead align="right">Matérias</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.map((row, index) => <TableRow key={row.id}>
              <TableCell>{row.name}</TableCell>
              <TableCell align="right">{12 + index * 4}</TableCell>
            </TableRow>)}
        </TableBody>
      </>
  }
}`,...S.parameters?.docs?.source}}},C.parameters={...C.parameters,docs:{...C.parameters?.docs,source:{originalSource:`{
  render: args => {
    const [direction, setDirection] = useState<'asc' | 'desc' | null>('asc');
    return <Table striped={args.striped}>
        <TableHeader>
          <TableRow>
            <TableHead sortable sortDirection={direction} onSort={() => setDirection(current => current === 'asc' ? 'desc' : 'asc')}>
              Nome
            </TableHead>
            <TableHead>Função</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {[...rows].sort((a, b) => {
          const cmp = a.name.localeCompare(b.name);
          return direction === 'desc' ? -cmp : cmp;
        }).map(row => <TableRow key={row.id}>
                <TableCell>{row.name}</TableCell>
                <TableCell>{row.role}</TableCell>
              </TableRow>)}
        </TableBody>
      </Table>;
  }
}`,...C.parameters?.docs?.source}}},w.parameters={...w.parameters,docs:{...w.parameters?.docs,source:{originalSource:`{
  args: {
    children: <>
        <TableHeader>
          <TableRow>
            <TableHead>Nome</TableHead>
            <TableHead>Função</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          <TableEmpty>Nenhum registro encontrado.</TableEmpty>
        </TableBody>
      </>
  }
}`,...w.parameters?.docs?.source}}},T=[`Default`,`Striped`,`Sortable`,`Empty`]}))();export{x as Default,w as Empty,C as Sortable,S as Striped,T as __namedExportsOrder,b as default};