import{i as e}from"./preload-helper-CT_b8DTk.js";import{n as t,t as n}from"./RowActions-D-rCmrvg.js";var r,i,a,o,s,c,l;e((()=>{t(),{fn:r}=__STORYBOOK_MODULE_TEST__,i={title:`Data/TableRowActions`,component:n,tags:[`autodocs`],args:{"aria-label":`Ações da linha`,actions:[{label:`Ver`,icon:`view`,onSelect:r()},{label:`Editar`,icon:`edit`,onSelect:r()},{label:`Excluir`,icon:`delete`,destructive:!0,onSelect:r()}]}},a={},o={args:{actions:[{label:`Ver`,icon:`view`,onSelect:r()},{label:`Editar`,icon:`edit`,onSelect:r()}]}},s={args:{actions:[{label:`Excluir`,icon:`delete`,destructive:!0,onSelect:r()}]}},c={args:{actions:[{label:`Duplicar`,onSelect:r()},{label:`Arquivar`,onSelect:r()},{label:`Remover`,destructive:!0,onSelect:r()}]}},a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{}`,...a.parameters?.docs?.source}}},o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  args: {
    actions: [{
      label: 'Ver',
      icon: 'view',
      onSelect: fn()
    }, {
      label: 'Editar',
      icon: 'edit',
      onSelect: fn()
    }]
  }
}`,...o.parameters?.docs?.source}}},s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  args: {
    actions: [{
      label: 'Excluir',
      icon: 'delete',
      destructive: true,
      onSelect: fn()
    }]
  }
}`,...s.parameters?.docs?.source}}},c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  args: {
    actions: [{
      label: 'Duplicar',
      onSelect: fn()
    }, {
      label: 'Arquivar',
      onSelect: fn()
    }, {
      label: 'Remover',
      destructive: true,
      onSelect: fn()
    }]
  }
}`,...c.parameters?.docs?.source}}},l=[`Default`,`ViewAndEdit`,`DestructiveOnly`,`WithoutIcons`]}))();export{a as Default,s as DestructiveOnly,o as ViewAndEdit,c as WithoutIcons,l as __namedExportsOrder,i as default};