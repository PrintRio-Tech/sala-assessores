import{i as e}from"./preload-helper-CT_b8DTk.js";import{t}from"./jsx-runtime-DqZldVDK.js";import{n,t as r}from"./Text-BlaLK81_.js";var i,a,o,s,c,l,u,d;e((()=>{n(),i=t(),a={title:`Foundation/Text`,component:r,tags:[`autodocs`],args:{children:`Texto de corpo do design system Print Forms.`,variant:`bodyMd`,tone:`default`},argTypes:{variant:{control:`select`,options:[`bodyLg`,`bodyMd`,`labelMd`,`labelSm`]},tone:{control:`select`,options:[`default`,`muted`,`error`,`primary`]},wrap:{control:`select`,options:[`normal`,`balance`,`pretty`]},tabular:{control:`boolean`}}},o={},s={render:()=>(0,i.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:12},children:[(0,i.jsx)(r,{variant:`bodyLg`,children:`bodyLg — parágrafo destacado`}),(0,i.jsx)(r,{variant:`bodyMd`,children:`bodyMd — parágrafo padrão`}),(0,i.jsx)(r,{variant:`labelMd`,children:`labelMd — rótulo médio`}),(0,i.jsx)(r,{variant:`labelSm`,children:`labelSm — rótulo pequeno`})]})},c={render:()=>(0,i.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:12},children:[(0,i.jsx)(r,{tone:`default`,children:`tone default`}),(0,i.jsx)(r,{tone:`muted`,children:`tone muted`}),(0,i.jsx)(r,{tone:`error`,children:`tone error`}),(0,i.jsx)(r,{tone:`primary`,children:`tone primary`})]})},l={args:{tabular:!0,children:`1.234.567,89`}},u={args:{wrap:`balance`,children:`Texto longo com wrap balance para demonstrar o comportamento tipográfico em títulos e parágrafos.`}},o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{}`,...o.parameters?.docs?.source}}},s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  render: () => <div style={{
    display: 'flex',
    flexDirection: 'column',
    gap: 12
  }}>
      <Text variant="bodyLg">bodyLg — parágrafo destacado</Text>
      <Text variant="bodyMd">bodyMd — parágrafo padrão</Text>
      <Text variant="labelMd">labelMd — rótulo médio</Text>
      <Text variant="labelSm">labelSm — rótulo pequeno</Text>
    </div>
}`,...s.parameters?.docs?.source}}},c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  render: () => <div style={{
    display: 'flex',
    flexDirection: 'column',
    gap: 12
  }}>
      <Text tone="default">tone default</Text>
      <Text tone="muted">tone muted</Text>
      <Text tone="error">tone error</Text>
      <Text tone="primary">tone primary</Text>
    </div>
}`,...c.parameters?.docs?.source}}},l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  args: {
    tabular: true,
    children: '1.234.567,89'
  }
}`,...l.parameters?.docs?.source}}},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  args: {
    wrap: 'balance',
    children: 'Texto longo com wrap balance para demonstrar o comportamento tipográfico em títulos e parágrafos.'
  }
}`,...u.parameters?.docs?.source}}},d=[`Default`,`Variants`,`Tones`,`Tabular`,`WrapBalance`]}))();export{o as Default,l as Tabular,c as Tones,s as Variants,u as WrapBalance,d as __namedExportsOrder,a as default};