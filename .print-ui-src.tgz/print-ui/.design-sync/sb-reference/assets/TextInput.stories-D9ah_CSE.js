import{i as e}from"./preload-helper-CT_b8DTk.js";import{n as t,t as n}from"./TextInput-Bq2RwQQG.js";var r,i,a,o,s,c,l,u,d,f;e((()=>{t(),r={title:`Forms/TextInput`,component:n,tags:[`autodocs`],args:{label:`Nome completo`,name:`fullName`,placeholder:`Maria Silva`,size:`md`,labelSize:`md`,required:!1,disabled:!1},argTypes:{size:{control:`select`,options:[`md`,`sm`]},labelSize:{control:`select`,options:[`md`,`sm`]},type:{control:`select`,options:[`text`,`email`,`password`,`tel`,`url`,`search`]}}},i={},a={args:{required:!0}},o={args:{description:`Como aparece no comprovante.`}},s={args:{error:`Campo obrigatório.`,defaultValue:``}},c={args:{size:`sm`,labelSize:`sm`}},l={args:{disabled:!0,defaultValue:`Valor bloqueado`}},u={args:{label:`Senha`,name:`password`,type:`password`,placeholder:`••••••••`}},d={args:{labelHidden:!0,placeholder:`Buscar…`}},i.parameters={...i.parameters,docs:{...i.parameters?.docs,source:{originalSource:`{}`,...i.parameters?.docs?.source}}},a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  args: {
    required: true
  }
}`,...a.parameters?.docs?.source}}},o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  args: {
    description: 'Como aparece no comprovante.'
  }
}`,...o.parameters?.docs?.source}}},s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  args: {
    error: 'Campo obrigatório.',
    defaultValue: ''
  }
}`,...s.parameters?.docs?.source}}},c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  args: {
    size: 'sm',
    labelSize: 'sm'
  }
}`,...c.parameters?.docs?.source}}},l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  args: {
    disabled: true,
    defaultValue: 'Valor bloqueado'
  }
}`,...l.parameters?.docs?.source}}},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  args: {
    label: 'Senha',
    name: 'password',
    type: 'password',
    placeholder: '••••••••'
  }
}`,...u.parameters?.docs?.source}}},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  args: {
    labelHidden: true,
    placeholder: 'Buscar…'
  }
}`,...d.parameters?.docs?.source}}},f=[`Default`,`Required`,`WithDescription`,`Error`,`Small`,`Disabled`,`Password`,`LabelHidden`]}))();export{i as Default,l as Disabled,s as Error,d as LabelHidden,u as Password,a as Required,c as Small,o as WithDescription,f as __namedExportsOrder,r as default};