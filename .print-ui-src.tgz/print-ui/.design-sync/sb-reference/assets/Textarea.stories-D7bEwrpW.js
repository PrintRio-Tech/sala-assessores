import{i as e,s as t}from"./preload-helper-CT_b8DTk.js";import{t as n}from"./react-B7Te67-h.js";import{t as r}from"./jsx-runtime-DqZldVDK.js";import{n as i,t as a}from"./FormField-DK3kFsCC.js";var o,s,c=e((()=>{o=`_textarea_fm7vs_1`,s={textarea:o}}));function l({label:e,required:t=!1,description:n,error:r,name:i,className:o,placeholder:c,autoComplete:l=`off`,id:f,...p}){let m=(0,u.useId)(),h=f??m;return(0,d.jsx)(a,{label:e,required:t,description:n,error:r,htmlFor:h,children:(0,d.jsx)(`textarea`,{id:h,name:i,className:[s.textarea,o].filter(Boolean).join(` `),placeholder:c,autoComplete:l,"aria-invalid":r?!0:void 0,...p})})}var u,d,f=e((()=>{u=t(n(),1),i(),c(),d=r(),l.__docgenInfo={description:``,methods:[],displayName:`Textarea`,props:{label:{required:!0,tsType:{name:`string`},description:``},required:{required:!1,tsType:{name:`boolean`},description:``,defaultValue:{value:`false`,computed:!1}},description:{required:!1,tsType:{name:`string`},description:``},error:{required:!1,tsType:{name:`string`},description:``},name:{required:!1,tsType:{name:`string`},description:``},autoComplete:{defaultValue:{value:`'off'`,computed:!1},required:!1}}}})),p,m,h,g,_,v,y;e((()=>{f(),p={title:`Forms/Textarea`,component:l,tags:[`autodocs`],args:{label:`Observações`,name:`notes`,placeholder:`Descreva o contexto…`,required:!1,disabled:!1}},m={},h={args:{required:!0}},g={args:{description:`Aparece no relatório e no e-mail de confirmação.`}},_={args:{error:`Campo obrigatório.`,defaultValue:``}},v={args:{disabled:!0,defaultValue:`Texto bloqueado.`}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{}`,...m.parameters?.docs?.source}}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  args: {
    required: true
  }
}`,...h.parameters?.docs?.source}}},g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  args: {
    description: 'Aparece no relatório e no e-mail de confirmação.'
  }
}`,...g.parameters?.docs?.source}}},_.parameters={..._.parameters,docs:{..._.parameters?.docs,source:{originalSource:`{
  args: {
    error: 'Campo obrigatório.',
    defaultValue: ''
  }
}`,..._.parameters?.docs?.source}}},v.parameters={...v.parameters,docs:{...v.parameters?.docs,source:{originalSource:`{
  args: {
    disabled: true,
    defaultValue: 'Texto bloqueado.'
  }
}`,...v.parameters?.docs?.source}}},y=[`Default`,`Required`,`WithDescription`,`Error`,`Disabled`]}))();export{m as Default,v as Disabled,_ as Error,h as Required,g as WithDescription,y as __namedExportsOrder,p as default};