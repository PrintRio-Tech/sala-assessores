import{i as e}from"./preload-helper-CT_b8DTk.js";import{t}from"./jsx-runtime-DqZldVDK.js";import{r as n,t as r}from"./iframe-DiXF9pnZ.js";import{n as i,t as a}from"./Button-FMHbx6tf.js";var o,s,c,l,u,d,f;e((()=>{i(),n(),o=t(),s={title:`Feedback/Tooltip`,component:r,tags:[`autodocs`],args:{content:`Dica útil sobre esta ação`,sideOffset:6,children:(0,o.jsx)(a,{type:`button`,children:`Passe o mouse`})},argTypes:{side:{control:`select`,options:[`top`,`bottom`,`left`,`right`]},placement:{control:`select`,options:[`top`,`bottom`,`left`,`right`]},children:{control:!1}},render:e=>(0,o.jsx)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`center`,minHeight:160},children:(0,o.jsx)(r,{...e})})},c={args:{side:`top`}},l={args:{side:`bottom`}},u={args:{side:`left`}},d={args:{side:`right`}},c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  args: {
    side: 'top'
  }
}`,...c.parameters?.docs?.source}}},l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  args: {
    side: 'bottom'
  }
}`,...l.parameters?.docs?.source}}},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  args: {
    side: 'left'
  }
}`,...u.parameters?.docs?.source}}},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  args: {
    side: 'right'
  }
}`,...d.parameters?.docs?.source}}},f=[`Top`,`Bottom`,`Left`,`Right`]}))();export{l as Bottom,u as Left,d as Right,c as Top,f as __namedExportsOrder,s as default};