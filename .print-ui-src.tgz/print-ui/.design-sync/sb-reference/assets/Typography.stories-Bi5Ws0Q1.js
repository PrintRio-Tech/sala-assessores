import{i as e}from"./preload-helper-CT_b8DTk.js";import{t}from"./jsx-runtime-DqZldVDK.js";import{n,t as r}from"./Text-BlaLK81_.js";import{n as i,t as a}from"./Heading-DD4784Mz.js";import{s as o,t as s}from"./theme-CiMS1Kdp.js";var c,l,u,d;e((()=>{i(),n(),s(),c=t(),l={title:`Foundation/Typography`,tags:[`autodocs`],parameters:{controls:{disable:!0}}},u={render:()=>(0,c.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:24,maxWidth:640},children:[(0,c.jsxs)(r,{tone:`muted`,variant:`labelSm`,children:[`Primary: `,o.fontPrimary]}),(0,c.jsxs)(r,{tone:`muted`,variant:`labelSm`,children:[`Fallback: `,o.fontFallback]}),(0,c.jsx)(a,{level:1,children:`Heading XL (level 1)`}),(0,c.jsx)(a,{level:2,children:`Heading LG (level 2)`}),(0,c.jsx)(a,{level:3,children:`Heading MD (level 3)`}),(0,c.jsx)(r,{variant:`bodyLg`,children:`Body large — texto corrido para leitura em destaques.`}),(0,c.jsx)(r,{variant:`bodyMd`,children:`Body medium — texto padrão de interface e formulários.`}),(0,c.jsx)(r,{variant:`labelMd`,children:`Label medium — rótulos de campo e ações.`}),(0,c.jsx)(r,{variant:`labelSm`,children:`Label small — metadados e legendas.`}),(0,c.jsx)(r,{tone:`muted`,children:`Tone muted`}),(0,c.jsx)(r,{tone:`primary`,children:`Tone primary`}),(0,c.jsx)(r,{tone:`error`,children:`Tone error`})]})},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  render: () => <div style={{
    display: 'flex',
    flexDirection: 'column',
    gap: 24,
    maxWidth: 640
  }}>
      <Text tone="muted" variant="labelSm">
        Primary: {typography.fontPrimary}
      </Text>
      <Text tone="muted" variant="labelSm">
        Fallback: {typography.fontFallback}
      </Text>

      <Heading level={1}>Heading XL (level 1)</Heading>
      <Heading level={2}>Heading LG (level 2)</Heading>
      <Heading level={3}>Heading MD (level 3)</Heading>

      <Text variant="bodyLg">Body large — texto corrido para leitura em destaques.</Text>
      <Text variant="bodyMd">Body medium — texto padrão de interface e formulários.</Text>
      <Text variant="labelMd">Label medium — rótulos de campo e ações.</Text>
      <Text variant="labelSm">Label small — metadados e legendas.</Text>

      <Text tone="muted">Tone muted</Text>
      <Text tone="primary">Tone primary</Text>
      <Text tone="error">Tone error</Text>
    </div>
}`,...u.parameters?.docs?.source}}},d=[`Scale`]}))();export{u as Scale,d as __namedExportsOrder,l as default};