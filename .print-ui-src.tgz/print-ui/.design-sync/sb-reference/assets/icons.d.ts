/**
 * Catálogo de ícones SVG do design system.
 *
 * Contrato D-ICON-04=A: apps consumidoras copiam `public/icons/` do pacote
 * para o próprio `public/icons/` (servidos em `/icons/*` em runtime).
 * Ver `docs/icons.md`.
 */
export declare const ICONS: {
    readonly nav: {
        readonly home: "/icons/nav/home.svg";
        readonly activities: "/icons/nav/activities.svg";
        readonly journalists: "/icons/nav/journalists.svg";
        readonly releases: "/icons/nav/releases.svg";
        readonly clippings: "/icons/nav/clippings.svg";
        readonly reports: "/icons/nav/reports.svg";
        readonly playground: "/icons/nav/playground.svg";
    };
    readonly home: {
        readonly location: "/icons/home/location.svg";
        readonly arrowForward: "/icons/home/arrow-forward.svg";
        readonly addCircle: "/icons/home/add-circle.svg";
        readonly article: "/icons/home/article.svg";
        readonly release: "/icons/home/release.svg";
        readonly chart: "/icons/home/chart.svg";
    };
    readonly ui: {
        readonly menu: "/icons/ui/menu.svg";
        readonly search: "/icons/ui/search.svg";
        readonly download: "/icons/ui/download.svg";
        readonly chevronLeft: "/icons/ui/chevron-left.svg";
        readonly chevronRight: "/icons/ui/chevron-right.svg";
        readonly chevronDown: "/icons/ui/chevron-down.svg";
        readonly filter: "/icons/ui/filter.svg";
        readonly check: "/icons/ui/check.svg";
    };
    readonly toast: {
        readonly success: "/icons/toast/success.svg";
        readonly error: "/icons/toast/error.svg";
        readonly warning: "/icons/toast/warning.svg";
        readonly info: "/icons/toast/info.svg";
        readonly default: "/icons/toast/default.svg";
    };
    readonly table: {
        readonly view: "/icons/table/view.svg";
        readonly edit: "/icons/table/edit.svg";
        readonly delete: "/icons/table/delete.svg";
    };
    readonly datePicker: {
        readonly calendar: "/icons/date-picker/calendar.svg";
        readonly clock: "/icons/date-picker/clock.svg";
    };
};
//# sourceMappingURL=icons.d.ts.map