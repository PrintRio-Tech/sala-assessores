# @print/ui

Design system Print — tokens SCSS/CSS, tipografia Nexa + Barlow e componentes React compartilhados.

Extraído de `print-forms/src/ui/theme` (validado com cliente). Publicado como pacote npm privado no GitHub Packages.

Playground interativo: **Storybook** (`bun run storybook` → `http://localhost:6006`). Ver seção [Playground (Storybook)](#playground-storybook).

## Instalação

Copie [`.npmrc.example`](./.npmrc.example) para o app consumidor e exporte `NPM_TOKEN`:

```bash
cp .npmrc.example ../print-adm/.npmrc
gh auth refresh -h github.com -s read:packages
export NPM_TOKEN=$(gh auth token)
```

```bash
bun add @print/ui@^0.5.11
```

Dev local (WIP sem tag nova): `file:../print-ui` após `bun run build` no print-ui.

O alias `@print/ui` no consumidor aponta para `npm:@printrio-tech/print-ui` no GitHub Packages (org [PrintRio-Tech](https://github.com/PrintRio-Tech)).

### Autenticação (token scoped)

| Contexto | Token | Escopos |
|----------|-------|---------|
| CI consumidor (`print-adm`) | Secret `NPM_TOKEN` | `read:packages` |
| Dev local | `gh auth token` após `gh auth refresh -s read:packages`, ou PAT | `read:packages` |
| CI publish (`print-ui`) | `GITHUB_TOKEN` automático | `packages: write` (workflow) |

O escopo `@printrio-tech` aponta para `https://npm.pkg.github.com`. O pacote publica a partir de `PrintRio-Tech/print-ui` via tag `v*` (ex.: `v0.5.11`).

Guia completo: [`docs/publishing.md`](./docs/publishing.md).

### Publicar nova versão

```bash
# 1. Atualize version em package.json (ou deixe o CI sincronizar pela tag)
# 2. Commit + tag
git tag v0.5.11
git push origin v0.5.11
```

O workflow [`.github/workflows/publish.yml`](./.github/workflows/publish.yml) faz build, `bun publish` e **depois** verify (`needs: publish`).

### Desenvolvimento local (antes do primeiro publish)

```bash
# No repo print-ui
bun install && bun run build
bun link

# No app consumidor (ex.: print-adm)
bun link @print/ui
```

Alternativa com tarball: `bun pack` → `bun add ../print-ui/print-ui-0.1.0.tgz`.

## Uso

### Variáveis CSS globais (`--pf-*`)

```typescript
// main.tsx
import '@print/ui/css';
```

Isso injeta em `:root` todas as custom properties `--pf-verde-floresta`, `--pf-primary`, `--pf-space-*`, etc.

### Tokens SCSS

```scss
@use '@print/ui/tokens' as t;
@use '@print/ui/mixins' as m;

.card {
  background: t.$surface-bright;
  border-radius: t.$radius-md;
  @include m.body-md;
}
```

### Theme completo (reset + layout utilities)

```scss
@use '@print/ui/theme';
```

Inclui `@font-face` Nexa, variáveis CSS, estilos base (`body`, `h1`–`h3`) e classes `.page-section`, `.form-section`, etc.

### Tokens TypeScript

```typescript
import { palette, semantic, spacing, cssVar } from '@print/ui';

const chartColor = palette.verdeFloresta;
const surface = cssVar('surface');
```

## Componentes React

Barrel público `@print/ui` (ver inventário em `../docs/print-ui/02-inventario-componentes.md`). Docs curtas de composição P0:

| Área | Doc |
| --- | --- |
| Shell (`AppShell` / `AppNav`) | [`docs/appshell.md`](./docs/appshell.md) |
| Charts (`Chart` line\|bar\|horizontal-bar\|donut + `Heatmap`) | [`docs/chart.md`](./docs/chart.md) |

Storybook cobre stories em `src/components/**/*.stories.tsx`.  
Smoke de consumibilidade P0: `src/components/s4-p0.consumability.test.tsx`.

## Riscos / peers

Há **dois** pacotes Base UI na árvore (peer `@base-ui-components/react` + dependency `@base-ui/react` para Toast). Sem migração neste slice. Detalhe e impacto no consumidor: [`docs/base-ui-dual-package.md`](./docs/base-ui-dual-package.md).

## Fontes

| Família | Origem | Uso |
|---------|--------|-----|
| **Nexa** | Fontfabric (licenciada) | Tipografia oficial |
| **Barlow** | Google Fonts | Fallback digital |

O pacote inclui as definições `@font-face` e o `@import` do Barlow. Para Nexa, copie os arquivos `.woff2` licenciados para `public/fonts/nexa/` no app consumidor (mesmos paths que `print-forms`):

```
public/fonts/nexa/
  NexaLight.woff2
  NexaRegular.woff2
  NexaItalic.woff2
  NexaBold.woff2
  NexaBoldItalic.woff2
  NexaExtraBold.woff2
```

## Ícones (`Icon` + `ICONS`)

Contrato **D-ICON-04=A**: o pacote publica o catálogo em `dist/icons/`; cada app copia para o próprio `public/icons/` para servir em `/icons/*`.

```tsx
import { Icon, ICONS } from '@print/ui';

<Icon src={ICONS.nav.home} size={20} label="Início" />
```

```bash
# Sincronizar SVGs no app consumidor (dist-only desde 0.3.0)
bash node_modules/@print/ui/dist/scripts/sync-icons.sh
```

Detalhes: [`docs/icons.md`](./docs/icons.md).

## Exports

| Subpath | Conteúdo |
|---------|----------|
| `@print/ui` | Componentes React + `ICONS` + tokens TypeScript |
| `@print/ui/css` | `dist/css/variables.css` — apenas `--pf-*` em `:root` |
| `@print/ui/tokens` | SCSS tokens (`$primary`, `$space-*`, …) — em `dist/tokens/` |
| `@print/ui/mixins` | Mixins SCSS (`body-md`, `button-primary`, …) — em `dist/mixins/` |
| `@print/ui/fonts` | `@font-face` Nexa + import Barlow — em `dist/fonts/` |
| `@print/ui/theme` | Bundle SCSS completo — em `dist/theme/` |

## Playground (Storybook)

Documentação interativa e playground dos componentes (só local — não entra no pacote npm):

```bash
bun install
bun run storybook        # http://localhost:6006
bun run build-storybook  # build estático em storybook-static/
```

Stories ficam em `src/components/**/*.stories.tsx` e páginas de tokens em `src/storybook/`. O tarball publicado continua limitado a `dist/`.

## Build

```bash
bun install
bun run build    # sass → dist/css/variables.css + Vite ESM/CJS + .d.ts
bun run typecheck
```

## Referências

- [ADR-008 — @print/ui npm privado](../docs/architecture/adr-008-print-ui-npm.md)
- [Brief — print-ui npm](../docs/product/print-ui-npm-brief.md)
