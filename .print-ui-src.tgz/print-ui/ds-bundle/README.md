## Print design system — build conventions

**Wrap every mounted tree in the provider chain**, outermost first — several components (`Tooltip`, `Toaster`/`useToast`) read required React context and throw or render nothing without it:

```jsx
const { TooltipProvider, Toaster } = window.PrintUI;

ReactDOM.createRoot(document.getElementById('ds-root')).render(
  <TooltipProvider>
    <Toaster>
      <App />
    </Toaster>
  </TooltipProvider>
);
```

**Compose with component props, not utility classes.** Print has no Tailwind-style class vocabulary. Each component owns its internal styling (CSS Modules) and exposes its variation surface as typed props — e.g. `Button` takes `variant?: "primary"|"outline"|"danger"|"secondary"|"ghost"` and `size?: "sm"|"md"|"lg"`; `Card` takes `variant?: "primary"|"accent"|"soft"|"surface"|"elevated"|"inset"` and `padding?: "sm"|"md"|"lg"|"none"`. Read a component's own `.d.ts`/`.prompt.md` for its exact prop set before composing it — don't guess variant names.

**For your own layout glue (not component internals), style with the real `--pf-*` custom properties** — never invent a class or a raw hex value. 96 tokens ship in `_ds_bundle.css`, grouped by family:
- Color/surface: `--pf-surface`, `--pf-surface-dim`, `--pf-on-surface`, `--pf-on-surface-variant`, `--pf-primary`, `--pf-primary-container`, `--pf-error`, `--pf-error-container`, `--pf-outline`, `--pf-outline-variant`, plus brand hues (`--pf-verde-floresta`, `--pf-dourado`, `--pf-areia`, …)
- Spacing: `--pf-space-base`, `--pf-space-1` … `--pf-space-*`, `--pf-gutter`, `--pf-margin-desktop`, `--pf-margin-mobile`
- Typography: `--pf-font-primary`, `--pf-font-fallback`, `--pf-font-weight-light|regular|medium|semibold|bold|extrabold`
- Radius: `--pf-radius-sm`, `--pf-radius`, `--pf-radius-md`, `--pf-radius-lg`, `--pf-radius-full`
- Shadow/motion: `--pf-shadow-ambient`, `--pf-duration-fast|normal|slow`, `--pf-ease-default`

Two page-shell utility classes also ship (from the DS's own `theme.scss`, compiled into the same stylesheet): `.page-section` and `.form-section` — reach for these before hand-rolling section spacing.

**Typography**: the brand font is `Nexa` (falls back to `Barlow`, then `system-ui`) via `--pf-font-primary` — both are wired into `body`/headings already, so plain text elements inherit the right family without any extra class.

**Where the truth lives**: `styles.css` is the one stylesheet to link — it `@import`s everything (tokens + component CSS), so never link `_ds_bundle.css` directly. `guidelines/index.md` plus `guidelines/docs/*.md` hold the DS's own usage guidance (icons, publishing, ActionTile, DrawerSteps) — read these before building anything in those areas. Every component's `<Name>.prompt.md` is the authoritative usage reference (real JSX + variants); `<Name>.d.ts` is the authoritative prop contract.

**Known gap**: icon glyphs (`Icon` component, and any component that renders one internally — chevrons on `Select`/`SearchableSelectField`, calendar/clock glyphs on `DatePicker`/`TimeInput`, nav icons on `AppShell`) render blank in this bundle — the source library resolves icons via a root-absolute URL that can't reach the uploaded bundle. Everything else (color, layout, typography, motion) is real and faithful. Don't invent an icon workaround; build around it (e.g. rely on the component's text label) until the DS ships a portable icon delivery mechanism.

**Note**: some components (`TextInput`, `Textarea`) accept the full native `<input>`/`<textarea>` attribute set (`placeholder`, `disabled`, `type`, …) at runtime, but their shipped `.d.ts` only lists the DS-specific props (`label`, `required`, `description`, `error`, `size`, …) — the extractor filters inherited HTML attributes. Don't assume a native attr is unsupported just because it's absent from the `.d.ts`; check `.prompt.md`'s examples too.

**One idiomatic composed example** (a card containing a labeled input and an action button, actual prop shapes verified against the shipped `.d.ts`):

```jsx
const { Card, TextInput, Button } = window.PrintUI;

<Card variant="surface" padding="lg">
  <TextInput label="Nome completo" name="fullName" required />
  <Button variant="primary" size="md">Salvar</Button>
</Card>
```

# PrintUI (@printrio-tech/print-ui@0.5.10)

This design system is the published @printrio-tech/print-ui React library, bundled as a single
browser global. All 40 components are the real upstream code.

## Where things are

- `_ds_bundle.js` — the whole-DS bundle at the project root; loads every component to `window.PrintUI`. First line is a `/* @ds-bundle: … */` metadata header.
- `styles.css` — the single stylesheet entry: it `@import`s the tokens, fonts, and component styles (`_ds_bundle.css`). Link this one file.
- `components/<group>/<Name>/<Name>.prompt.md` (example JSX + variants), `<Name>.d.ts` (types), `<Name>.html` (variant grid).
- `tokens/*.css` — CSS custom properties, names verbatim from upstream.
- `fonts/` — `@font-face` files + `fonts.css` (when the package ships fonts).
- `guidelines/` — the design system's own usage guidance (4 doc(s), see `guidelines/index.md`). Read these before composing larger layouts.

For a specific component, `read_file("components/<group>/<Name>/<Name>.prompt.md")`.

## Loading

Add these two lines to your page once (React must be on the page first):

```html
<link rel="stylesheet" href="styles.css">
<script src="_ds_bundle.js"></script>
```

Components are then available at `window.PrintUI.*`. Mount into a dedicated child node (e.g. `<div id="ds-root">`), not the host page's own React root, so the two trees don't collide:

```jsx
const { Accordion } = window.PrintUI;
ReactDOM.createRoot(document.getElementById('ds-root')).render(<Accordion />);
```

Wrap the tree in the provider — most components read theme/i18n from context:

```jsx
<TooltipProvider><Toaster>{children}</Toaster></TooltipProvider>
```

## Tokens

104 CSS custom properties from @printrio-tech/print-ui. Names are
preserved verbatim from upstream. They are declared inside `_ds_bundle.css` (this DS ships one compiled stylesheet rather than separate token files).

- **color** (19): `--pf-surface`, `--pf-surface-dim`, `--pf-surface-bright`, …
- **spacing** (19): `--pf-space-base`, `--pf-space-1`, `--pf-space-2`, …
- **typography** (8): `--pf-font-primary`, `--pf-font-fallback`, `--pf-font-weight-light`, …
- **radius** (6): `--pf-radius-sm`, `--pf-radius`, `--pf-radius-md`, …
- **shadow** (3): `--pf-shadow-ambient`, `--pf-shadow-none`, `--pf-transition-shadow`
- **other** (49): `--pf-verde-floresta`, `--pf-verde-salvia`, `--pf-o-white`, …

## Components

### layout
- `Accordion`
- `AppShell`
- `Tabs`

### foundation
- `ActionTile`
- `Avatar`
- `Badge`
- `Button`
- `Card`
- `EmptyState`
- `Heading`
- `Icon`
- `Stat`
- `Text`

### card
- `CardSkeleton`

### data
- `Chart`
- `DataTable`
- `Heatmap`
- `Pagination`
- `PersonCell`
- `SectionState`
- `Table`
- `TableRowActions`

### forms
- `Checkbox`
- `CheckboxGroup`
- `DatePicker`
- `FormField`
- `OtpInput`
- `RadioGroup`
- `SearchableSelectField`
- `SelectField`
- `Switch`
- `Textarea`
- `TextInput`
- `TimeInput`

### overlay
- `ConfirmDialog`
- `Drawer`
- `DrawerSteps`

### table
- `TableSkeleton`

### feedback
- `Toaster`
- `Tooltip`
