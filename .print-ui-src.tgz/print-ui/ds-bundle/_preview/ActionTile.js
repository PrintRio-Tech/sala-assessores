"use strict";
var __dsPreview = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx2(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs2(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx2;
      module.exports.jsxs = jsxs2;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs2 : jsx2)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // ds-raw:__ds_raw__
  var require_ds_raw = __commonJS({
    "ds-raw:__ds_raw__"(exports, module) {
      init_define_import_meta_env();
      module.exports = window.PrintUI;
    }
  });

  // .design-sync/.cache/previews/ActionTile.tsx
  var ActionTile_exports = {};
  __export(ActionTile_exports, {
    AsLink: () => AsLink2,
    Disabled: () => Disabled2,
    Grid: () => Grid2,
    Muted: () => Muted2,
    Outline: () => Outline2,
    Primary: () => Primary2
  });
  init_define_import_meta_env();
  var React = __toESM(require_react_shim(), 1);

  // src/components/ActionTile/ActionTile.stories.tsx
  var ActionTile_stories_exports = {};
  __export(ActionTile_stories_exports, {
    AsLink: () => AsLink,
    Disabled: () => Disabled,
    Grid: () => Grid,
    Muted: () => Muted,
    Outline: () => Outline,
    Primary: () => Primary,
    default: () => ActionTile_stories_default
  });
  init_define_import_meta_env();

  // src/assets/icons.ts
  init_define_import_meta_env();
  var ICONS = {
    nav: {
      home: "/icons/nav/home.svg",
      activities: "/icons/nav/activities.svg",
      journalists: "/icons/nav/journalists.svg",
      releases: "/icons/nav/releases.svg",
      clippings: "/icons/nav/clippings.svg",
      reports: "/icons/nav/reports.svg",
      playground: "/icons/nav/playground.svg"
    },
    home: {
      location: "/icons/home/location.svg",
      arrowForward: "/icons/home/arrow-forward.svg",
      addCircle: "/icons/home/add-circle.svg",
      article: "/icons/home/article.svg",
      release: "/icons/home/release.svg",
      chart: "/icons/home/chart.svg"
    },
    ui: {
      menu: "/icons/ui/menu.svg",
      search: "/icons/ui/search.svg",
      download: "/icons/ui/download.svg",
      chevronLeft: "/icons/ui/chevron-left.svg",
      chevronRight: "/icons/ui/chevron-right.svg",
      chevronDown: "/icons/ui/chevron-down.svg",
      filter: "/icons/ui/filter.svg",
      check: "/icons/ui/check.svg"
    },
    toast: {
      success: "/icons/toast/success.svg",
      error: "/icons/toast/error.svg",
      warning: "/icons/toast/warning.svg",
      info: "/icons/toast/info.svg",
      default: "/icons/toast/default.svg"
    },
    table: {
      view: "/icons/table/view.svg",
      edit: "/icons/table/edit.svg",
      delete: "/icons/table/delete.svg"
    },
    datePicker: {
      calendar: "/icons/date-picker/calendar.svg",
      clock: "/icons/date-picker/clock.svg"
    }
  };

  // ds-shim:ds:Icon
  var ds_Icon_exports = {};
  __export(ds_Icon_exports, {
    default: () => ds_Icon_default
  });
  init_define_import_meta_env();
  __reExport(ds_Icon_exports, __toESM(require_ds_raw()));
  var g = window.PrintUI;
  var ds_Icon_default = g["Icon"] !== void 0 ? g["Icon"] : g;

  // ds-shim:ds:ActionTile
  var ds_ActionTile_exports = {};
  __export(ds_ActionTile_exports, {
    default: () => ds_ActionTile_default
  });
  init_define_import_meta_env();
  __reExport(ds_ActionTile_exports, __toESM(require_ds_raw()));
  var g2 = window.PrintUI;
  var ds_ActionTile_default = g2["ActionTile"] !== void 0 ? g2["ActionTile"] : g2;

  // src/components/ActionTile/ActionTile.stories.tsx
  var import_jsx_runtime = __toESM(require_react_shim());
  var meta = {
    title: "Foundation/ActionTile",
    component: ds_ActionTile_exports.ActionTile,
    tags: ["autodocs"],
    args: {
      title: "Novo clipping",
      eyebrow: "Ação rápida",
      icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Icon_exports.Icon, { src: ICONS.home.addCircle, size: 28 }),
      variant: "primary"
    },
    argTypes: {
      variant: {
        control: "select",
        options: ["primary", "outline", "muted"]
      }
    },
    decorators: [
      (Story) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { maxWidth: 280 }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Story, {}) })
    ]
  };
  var ActionTile_stories_default = meta;
  var Primary = {};
  var Outline = {
    args: {
      variant: "outline",
      title: "Ver releases",
      eyebrow: "Conteúdo",
      icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Icon_exports.Icon, { src: ICONS.home.release, size: 28 })
    }
  };
  var Muted = {
    args: {
      variant: "muted",
      title: "Relatórios",
      eyebrow: "Análise",
      icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Icon_exports.Icon, { src: ICONS.home.chart, size: 28 })
    }
  };
  var AsLink = {
    args: {
      href: "#",
      title: "Abrir artigo",
      eyebrow: "Leitura",
      icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Icon_exports.Icon, { src: ICONS.home.article, size: 28 }),
      variant: "outline"
    }
  };
  var Disabled = {
    args: {
      disabled: true,
      variant: "muted"
    }
  };
  var Grid = {
    render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(
      "div",
      {
        style: {
          display: "grid",
          gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
          gap: 16,
          maxWidth: 560
        },
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
            ds_ActionTile_exports.ActionTile,
            {
              variant: "primary",
              eyebrow: "Criar",
              title: "Novo clipping",
              icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Icon_exports.Icon, { src: ICONS.home.addCircle, size: 28 }),
              href: "#"
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
            ds_ActionTile_exports.ActionTile,
            {
              variant: "outline",
              eyebrow: "Conteúdo",
              title: "Ver releases",
              icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Icon_exports.Icon, { src: ICONS.home.release, size: 28 }),
              href: "#"
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
            ds_ActionTile_exports.ActionTile,
            {
              variant: "muted",
              eyebrow: "Análise",
              title: "Relatórios",
              icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Icon_exports.Icon, { src: ICONS.home.chart, size: 28 }),
              href: "#"
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
            ds_ActionTile_exports.ActionTile,
            {
              variant: "muted",
              eyebrow: "Leitura",
              title: "Artigos",
              icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Icon_exports.Icon, { src: ICONS.home.article, size: 28 }),
              href: "#"
            }
          )
        ]
      }
    )
  };

  // .design-sync/.cache/previews/ActionTile.tsx
  function compose(S, key) {
    const meta2 = S.default ?? {};
    const st = S[key];
    const args = { ...meta2.args ?? {}, ...st && st.args ? st.args : {} };
    const at = { ...meta2.argTypes ?? {}, ...st && st.argTypes ? st.argTypes : {} };
    for (const k of Object.keys(args)) {
      const m = at[k] && at[k].mapping;
      if (m && typeof m === "object" && args[k] in m) args[k] = m[args[k]];
    }
    const title = typeof meta2.title === "string" ? meta2.title : "";
    const ctx = {
      args,
      name: key,
      title,
      kind: title,
      id: "",
      componentId: "",
      globals: {},
      viewMode: "story",
      parameters: (st && st.parameters) ?? meta2.parameters ?? {}
    };
    let render = null;
    if (st && typeof st.render === "function") render = () => st.render(args, ctx);
    else if (typeof st === "function") render = () => st(args, ctx);
    else if (typeof meta2.render === "function") render = () => meta2.render(args, ctx);
    else {
      const C = st && st.component || meta2.component;
      if (C) render = () => React.createElement(C, args);
    }
    if (!render) return () => null;
    const decorators = [].concat((st && st.decorators) ?? []).concat(meta2.decorators ?? []);
    return decorators.reduce((inner, dec) => () => {
      const out = dec(inner, ctx);
      return out === void 0 ? inner() : out;
    }, render);
  }
  var Primary2 = (
    /* Primary */
    compose(ActionTile_stories_exports, "Primary")
  );
  var Outline2 = (
    /* Outline */
    compose(ActionTile_stories_exports, "Outline")
  );
  var Muted2 = (
    /* Muted */
    compose(ActionTile_stories_exports, "Muted")
  );
  var AsLink2 = (
    /* As Link */
    compose(ActionTile_stories_exports, "AsLink")
  );
  var Disabled2 = (
    /* Disabled */
    compose(ActionTile_stories_exports, "Disabled")
  );
  var Grid2 = (
    /* Grid */
    compose(ActionTile_stories_exports, "Grid")
  );
  return __toCommonJS(ActionTile_exports);
})();
