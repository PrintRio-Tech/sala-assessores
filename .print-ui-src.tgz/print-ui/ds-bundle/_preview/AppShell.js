"use strict";
var __dsPreview = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx2(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs2(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx2;
      module.exports.jsxs = jsxs2;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs2 : jsx2)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // ds-raw:__ds_raw__
  var require_ds_raw = __commonJS({
    "ds-raw:__ds_raw__"(exports, module) {
      init_define_import_meta_env();
      module.exports = window.PrintUI;
    }
  });

  // .design-sync/.cache/previews/AppShell.tsx
  var AppShell_exports = {};
  __export(AppShell_exports, {
    Contained: () => Contained2,
    Default: () => Default2
  });
  init_define_import_meta_env();
  var React = __toESM(require_react_shim(), 1);

  // src/components/AppShell/AppShell.stories.tsx
  var AppShell_stories_exports = {};
  __export(AppShell_stories_exports, {
    Contained: () => Contained,
    Default: () => Default,
    default: () => AppShell_stories_default
  });
  init_define_import_meta_env();

  // src/assets/icons.ts
  init_define_import_meta_env();
  var ICONS = {
    nav: {
      home: "/icons/nav/home.svg",
      activities: "/icons/nav/activities.svg",
      journalists: "/icons/nav/journalists.svg",
      releases: "/icons/nav/releases.svg",
      clippings: "/icons/nav/clippings.svg",
      reports: "/icons/nav/reports.svg",
      playground: "/icons/nav/playground.svg"
    },
    home: {
      location: "/icons/home/location.svg",
      arrowForward: "/icons/home/arrow-forward.svg",
      addCircle: "/icons/home/add-circle.svg",
      article: "/icons/home/article.svg",
      release: "/icons/home/release.svg",
      chart: "/icons/home/chart.svg"
    },
    ui: {
      menu: "/icons/ui/menu.svg",
      search: "/icons/ui/search.svg",
      download: "/icons/ui/download.svg",
      chevronLeft: "/icons/ui/chevron-left.svg",
      chevronRight: "/icons/ui/chevron-right.svg",
      chevronDown: "/icons/ui/chevron-down.svg",
      filter: "/icons/ui/filter.svg",
      check: "/icons/ui/check.svg"
    },
    toast: {
      success: "/icons/toast/success.svg",
      error: "/icons/toast/error.svg",
      warning: "/icons/toast/warning.svg",
      info: "/icons/toast/info.svg",
      default: "/icons/toast/default.svg"
    },
    table: {
      view: "/icons/table/view.svg",
      edit: "/icons/table/edit.svg",
      delete: "/icons/table/delete.svg"
    },
    datePicker: {
      calendar: "/icons/date-picker/calendar.svg",
      clock: "/icons/date-picker/clock.svg"
    }
  };

  // ds-shim:ds:Icon
  var ds_Icon_exports = {};
  __export(ds_Icon_exports, {
    default: () => ds_Icon_default
  });
  init_define_import_meta_env();
  __reExport(ds_Icon_exports, __toESM(require_ds_raw()));
  var g = window.PrintUI;
  var ds_Icon_default = g["Icon"] !== void 0 ? g["Icon"] : g;

  // ds-shim:ds:AppShell
  var ds_AppShell_exports = {};
  __export(ds_AppShell_exports, {
    default: () => ds_AppShell_default
  });
  init_define_import_meta_env();
  __reExport(ds_AppShell_exports, __toESM(require_ds_raw()));
  var g2 = window.PrintUI;
  var ds_AppShell_default = g2["AppShell"] !== void 0 ? g2["AppShell"] : g2;

  // src/components/AppShell/AppShell.stories.tsx
  var import_jsx_runtime = __toESM(require_react_shim());
  var navItems = [
    {
      id: "home",
      label: "Início",
      icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Icon_exports.Icon, { src: ICONS.nav.home, size: 20 }),
      active: true,
      onClick: () => void 0
    },
    {
      id: "activities",
      label: "Atividades",
      icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Icon_exports.Icon, { src: ICONS.nav.activities, size: 20 }),
      onClick: () => void 0
    },
    {
      id: "releases",
      label: "Releases",
      icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Icon_exports.Icon, { src: ICONS.nav.releases, size: 20 }),
      onClick: () => void 0
    },
    {
      id: "reports",
      label: "Relatórios",
      icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Icon_exports.Icon, { src: ICONS.nav.reports, size: 20 }),
      onClick: () => void 0
    }
  ];
  var meta = {
    title: "Layout/AppShell",
    component: ds_AppShell_exports.AppShell,
    tags: ["autodocs"],
    parameters: {
      layout: "fullscreen"
    },
    args: {
      logo: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Print" }),
      logoCollapsed: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "P" }),
      navItems,
      footerSlot: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Ana" }),
      contentWidth: "fluid",
      children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { style: { margin: "0 0 8px", fontSize: 20 }, children: "Dashboard" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { style: { margin: 0 }, children: "Conteúdo fluid — ocupa a largura do workspace (padrão forms)." })
      ] })
    },
    argTypes: {
      contentWidth: {
        control: "select",
        options: ["fluid", "contained"]
      }
    }
  };
  var AppShell_stories_default = meta;
  var Default = {};
  var Contained = {
    args: {
      contentWidth: "contained",
      children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { style: { margin: "0 0 8px", fontSize: 20 }, children: "Contained" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { style: { margin: 0 }, children: "Coluna centrada com max-width (legado / Storybook)." })
      ] })
    }
  };

  // .design-sync/.cache/previews/AppShell.tsx
  function compose(S, key) {
    const meta2 = S.default ?? {};
    const st = S[key];
    const args = { ...meta2.args ?? {}, ...st && st.args ? st.args : {} };
    const at = { ...meta2.argTypes ?? {}, ...st && st.argTypes ? st.argTypes : {} };
    for (const k of Object.keys(args)) {
      const m = at[k] && at[k].mapping;
      if (m && typeof m === "object" && args[k] in m) args[k] = m[args[k]];
    }
    const title = typeof meta2.title === "string" ? meta2.title : "";
    const ctx = {
      args,
      name: key,
      title,
      kind: title,
      id: "",
      componentId: "",
      globals: {},
      viewMode: "story",
      parameters: (st && st.parameters) ?? meta2.parameters ?? {}
    };
    let render = null;
    if (st && typeof st.render === "function") render = () => st.render(args, ctx);
    else if (typeof st === "function") render = () => st(args, ctx);
    else if (typeof meta2.render === "function") render = () => meta2.render(args, ctx);
    else {
      const C = st && st.component || meta2.component;
      if (C) render = () => React.createElement(C, args);
    }
    if (!render) return () => null;
    const decorators = [].concat((st && st.decorators) ?? []).concat(meta2.decorators ?? []);
    return decorators.reduce((inner, dec) => () => {
      const out = dec(inner, ctx);
      return out === void 0 ? inner() : out;
    }, render);
  }
  var Default2 = (
    /* Default */
    compose(AppShell_stories_exports, "Default")
  );
  var Contained2 = (
    /* Contained */
    compose(AppShell_stories_exports, "Contained")
  );
  return __toCommonJS(AppShell_exports);
})();
