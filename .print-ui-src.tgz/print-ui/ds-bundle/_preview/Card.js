"use strict";
var __dsPreview = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn2, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn2 && (res = (0, fn2[__getOwnPropNames(fn2)[0]])(fn2 = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx2(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs2(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx2;
      module.exports.jsxs = jsxs2;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs2 : jsx2)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // sb-stub:storybook/test
  var require_test = __commonJS({
    "sb-stub:storybook/test"(exports, module) {
      init_define_import_meta_env();
      var inert = new Proxy(function() {
      }, { get: function(t, k) {
        if (k === "then") return void 0;
        if (k === "prototype") return t.prototype;
        if (k === "valueOf" || k === "toString" || k === Symbol.toPrimitive) return function() {
          return "";
        };
        return inert;
      }, apply: function() {
        return inert;
      }, construct: function() {
        return {};
      } });
      var m = {};
      "fn action actions expect userEvent within waitFor screen fireEvent spyOn mocked jest vi configureActions decorateAction setupWorker http HttpResponse graphql rest".split(" ").forEach(function(k) {
        m[k] = inert;
      });
      var def = function(p) {
        return p && p.children !== void 0 ? p.children : null;
      };
      Object.assign(def, m);
      module.exports = new Proxy(def, { get: function(t, k) {
        if (k === "then") return void 0;
        if (k === "prototype") return t.prototype;
        return k in m ? m[k] : k === "__esModule" ? void 0 : inert;
      } });
    }
  });

  // ds-raw:__ds_raw__
  var require_ds_raw = __commonJS({
    "ds-raw:__ds_raw__"(exports, module) {
      init_define_import_meta_env();
      module.exports = window.PrintUI;
    }
  });

  // .design-sync/.cache/previews/Card.tsx
  var Card_exports = {};
  __export(Card_exports, {
    Accent: () => Accent2,
    AllVariants: () => AllVariants2,
    Default: () => Default2,
    Elevated: () => Elevated2,
    Inset: () => Inset2,
    Interactive: () => Interactive2,
    PaddingLg: () => PaddingLg2,
    PaddingNone: () => PaddingNone2,
    PaddingSm: () => PaddingSm2,
    Primary: () => Primary2,
    Soft: () => Soft2,
    Surface: () => Surface2
  });
  init_define_import_meta_env();
  var React = __toESM(require_react_shim(), 1);

  // src/components/Card/Card.stories.tsx
  var Card_stories_exports = {};
  __export(Card_stories_exports, {
    Accent: () => Accent,
    AllVariants: () => AllVariants,
    Default: () => Default,
    Elevated: () => Elevated,
    Inset: () => Inset,
    Interactive: () => Interactive,
    PaddingLg: () => PaddingLg,
    PaddingNone: () => PaddingNone,
    PaddingSm: () => PaddingSm,
    Primary: () => Primary,
    Soft: () => Soft,
    Surface: () => Surface,
    default: () => Card_stories_default
  });
  init_define_import_meta_env();
  var import_test = __toESM(require_test());

  // ds-shim:ds:Text
  var ds_Text_exports = {};
  __export(ds_Text_exports, {
    default: () => ds_Text_default
  });
  init_define_import_meta_env();
  __reExport(ds_Text_exports, __toESM(require_ds_raw()));
  var g = window.PrintUI;
  var ds_Text_default = g["Text"] !== void 0 ? g["Text"] : g;

  // ds-shim:ds:Card
  var ds_Card_exports = {};
  __export(ds_Card_exports, {
    default: () => ds_Card_default
  });
  init_define_import_meta_env();
  __reExport(ds_Card_exports, __toESM(require_ds_raw()));
  var g2 = window.PrintUI;
  var ds_Card_default = g2["Card"] !== void 0 ? g2["Card"] : g2;

  // src/components/Card/Card.stories.tsx
  var import_jsx_runtime = __toESM(require_react_shim());
  var meta = {
    title: "Foundation/Card",
    component: ds_Card_exports.Card,
    tags: ["autodocs"],
    parameters: {
      docs: {
        description: {
          component: "Superfície de conteúdo. Largura intrínseca (sem `width: 100%`) — o layout do consumidor controla. `primary` = KPI/destaque (texto branco/off-white). `accent` = banner secundário (texto marrom). Não usar `primary` como CTA full-bleed."
        }
      }
    },
    decorators: [
      (Story) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { maxWidth: 360 }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Story, {}) })
    ],
    args: {
      children: "Conteúdo do card",
      variant: "surface",
      padding: "md",
      interactive: false
    },
    argTypes: {
      variant: {
        control: "select",
        options: ["surface", "elevated", "soft", "inset", "primary", "accent"]
      },
      padding: {
        control: "select",
        options: ["none", "sm", "md", "lg"]
      },
      interactive: { control: "boolean" }
    }
  };
  var Card_stories_default = meta;
  function SampleContent({ title = "Card" }) {
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { display: "flex", flexDirection: "column", gap: 8 }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Text_exports.Text, { as: "strong", variant: "labelMd", children: title }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Text_exports.Text, { tone: "muted", variant: "bodyMd", children: "Conteúdo de exemplo para visualizar o card." })
    ] });
  }
  function PrimaryKpiContent() {
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { display: "flex", flexDirection: "column", gap: 8 }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "span",
        {
          style: {
            color: "rgba(255, 255, 255, 0.75)",
            fontSize: 12,
            fontWeight: 500,
            letterSpacing: "0.04em",
            textTransform: "uppercase"
          },
          children: "Inserções na imprensa"
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "span",
        {
          style: {
            color: "#ffffff",
            fontSize: 28,
            fontWeight: 600,
            lineHeight: 1.1,
            fontVariantNumeric: "tabular-nums"
          },
          children: "1.248"
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { color: "#f0ebe4", fontSize: 13 }, children: "+12% vs. período anterior" })
    ] });
  }
  function AccentBannerContent() {
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { display: "flex", flexDirection: "column", gap: 8 }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Text_exports.Text, { as: "strong", variant: "labelMd", style: { color: "#4b3d19" }, children: "Relatório semanal" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Text_exports.Text, { variant: "bodyMd", style: { color: "#4b3d19" }, children: "Resumo das menções e releases publicados nesta semana." })
    ] });
  }
  var Default = {
    args: {
      children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SampleContent, { title: "Surface" })
    }
  };
  var Surface = {
    args: {
      variant: "surface",
      children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SampleContent, { title: "Surface" })
    }
  };
  var Elevated = {
    args: {
      variant: "elevated",
      children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SampleContent, { title: "Elevated" })
    }
  };
  var Soft = {
    args: {
      variant: "soft",
      children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SampleContent, { title: "Soft" })
    }
  };
  var Inset = {
    args: {
      variant: "inset",
      children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SampleContent, { title: "Inset" })
    }
  };
  var Primary = {
    parameters: {
      docs: {
        description: {
          story: "Uso: KPI / destaque numérico. Preferir texto branco ou off-white (`#f0ebe4`) sobre o container — contraste do `$on-primary-container` sozinho pode ser insuficiente para body pequeno."
        }
      }
    },
    args: {
      variant: "primary",
      children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryKpiContent, {})
    }
  };
  var Accent = {
    parameters: {
      docs: {
        description: {
          story: "Uso: banner secundário com copy. Par ouro + marrom (`$on-tertiary-container` / `#4b3d19`) — melhor legibilidade para texto corrido."
        }
      }
    },
    args: {
      variant: "accent",
      children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccentBannerContent, {})
    }
  };
  var PaddingNone = {
    args: {
      padding: "none",
      children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SampleContent, { title: "Padding none" })
    }
  };
  var PaddingSm = {
    args: {
      padding: "sm",
      children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SampleContent, { title: "Padding sm" })
    }
  };
  var PaddingLg = {
    args: {
      padding: "lg",
      children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SampleContent, { title: "Padding lg" })
    }
  };
  var Interactive = {
    args: {
      interactive: true,
      onClick: (0, import_test.fn)(),
      children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SampleContent, { title: "Interactive" })
    }
  };
  var AllVariants = {
    decorators: [
      (Story) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { maxWidth: 720 }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Story, {}) })
    ],
    render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "div",
      {
        style: {
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))",
          gap: 16
        },
        children: ["surface", "elevated", "soft", "inset", "primary", "accent"].map((variant) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Card_exports.Card, { variant, children: variant === "primary" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryKpiContent, {}) : variant === "accent" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccentBannerContent, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SampleContent, { title: variant }) }, variant))
      }
    )
  };

  // .design-sync/.cache/previews/Card.tsx
  function compose(S, key) {
    const meta2 = S.default ?? {};
    const st = S[key];
    const args = { ...meta2.args ?? {}, ...st && st.args ? st.args : {} };
    const at = { ...meta2.argTypes ?? {}, ...st && st.argTypes ? st.argTypes : {} };
    for (const k of Object.keys(args)) {
      const m = at[k] && at[k].mapping;
      if (m && typeof m === "object" && args[k] in m) args[k] = m[args[k]];
    }
    const title = typeof meta2.title === "string" ? meta2.title : "";
    const ctx = {
      args,
      name: key,
      title,
      kind: title,
      id: "",
      componentId: "",
      globals: {},
      viewMode: "story",
      parameters: (st && st.parameters) ?? meta2.parameters ?? {}
    };
    let render = null;
    if (st && typeof st.render === "function") render = () => st.render(args, ctx);
    else if (typeof st === "function") render = () => st(args, ctx);
    else if (typeof meta2.render === "function") render = () => meta2.render(args, ctx);
    else {
      const C = st && st.component || meta2.component;
      if (C) render = () => React.createElement(C, args);
    }
    if (!render) return () => null;
    const decorators = [].concat((st && st.decorators) ?? []).concat(meta2.decorators ?? []);
    return decorators.reduce((inner, dec) => () => {
      const out = dec(inner, ctx);
      return out === void 0 ? inner() : out;
    }, render);
  }
  var Default2 = (
    /* Default */
    compose(Card_stories_exports, "Default")
  );
  var Surface2 = (
    /* Surface */
    compose(Card_stories_exports, "Surface")
  );
  var Elevated2 = (
    /* Elevated */
    compose(Card_stories_exports, "Elevated")
  );
  var Soft2 = (
    /* Soft */
    compose(Card_stories_exports, "Soft")
  );
  var Inset2 = (
    /* Inset */
    compose(Card_stories_exports, "Inset")
  );
  var Primary2 = (
    /* Primary */
    compose(Card_stories_exports, "Primary")
  );
  var Accent2 = (
    /* Accent */
    compose(Card_stories_exports, "Accent")
  );
  var PaddingNone2 = (
    /* Padding None */
    compose(Card_stories_exports, "PaddingNone")
  );
  var PaddingSm2 = (
    /* Padding Sm */
    compose(Card_stories_exports, "PaddingSm")
  );
  var PaddingLg2 = (
    /* Padding Lg */
    compose(Card_stories_exports, "PaddingLg")
  );
  var Interactive2 = (
    /* Interactive */
    compose(Card_stories_exports, "Interactive")
  );
  var AllVariants2 = (
    /* All Variants */
    compose(Card_stories_exports, "AllVariants")
  );
  return __toCommonJS(Card_exports);
})();
