"use strict";
var __dsPreview = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx2(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx2;
      module.exports.jsxs = jsxs;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs : jsx2)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // ds-raw:__ds_raw__
  var require_ds_raw = __commonJS({
    "ds-raw:__ds_raw__"(exports, module) {
      init_define_import_meta_env();
      module.exports = window.PrintUI;
    }
  });

  // .design-sync/.cache/previews/Chart.tsx
  var Chart_exports = {};
  __export(Chart_exports, {
    Bar: () => Bar2,
    BarCategorical: () => BarCategorical2,
    HorizontalBar: () => HorizontalBar2,
    Line: () => Line2,
    LineMonth: () => LineMonth2,
    LineWideCard: () => LineWideCard2,
    Loading: () => Loading2,
    SinglePoint: () => SinglePoint2
  });
  init_define_import_meta_env();
  var React = __toESM(require_react_shim(), 1);

  // src/components/Chart/Chart.stories.tsx
  var Chart_stories_exports = {};
  __export(Chart_stories_exports, {
    Bar: () => Bar,
    BarCategorical: () => BarCategorical,
    HorizontalBar: () => HorizontalBar,
    Line: () => Line,
    LineMonth: () => LineMonth,
    LineWideCard: () => LineWideCard,
    Loading: () => Loading,
    SinglePoint: () => SinglePoint,
    default: () => Chart_stories_default
  });
  init_define_import_meta_env();

  // ds-shim:ds:Chart
  var ds_Chart_exports = {};
  __export(ds_Chart_exports, {
    default: () => ds_Chart_default
  });
  init_define_import_meta_env();
  __reExport(ds_Chart_exports, __toESM(require_ds_raw()));
  var g = window.PrintUI;
  var ds_Chart_default = g["Chart"] !== void 0 ? g["Chart"] : g;

  // src/components/Chart/Chart.stories.tsx
  var import_jsx_runtime = __toESM(require_react_shim());
  var weekly = [
    { label: "Seg", value: 12 },
    { label: "Ter", value: 18 },
    { label: "Qua", value: 9 },
    { label: "Qui", value: 22 },
    { label: "Sex", value: 15 },
    { label: "Sáb", value: 7 },
    { label: "Dom", value: 4 }
  ];
  var month = Array.from({ length: 30 }, (_, i) => ({
    label: `${i + 1}`,
    value: Math.round(8 + 10 * Math.sin(i / 3.2) + i % 5 * 1.4)
  }));
  var categories = [
    { label: "Política", value: 42 },
    { label: "Esporte", value: 28 },
    { label: "Cultura", value: 19 },
    { label: "Economia", value: 31 }
  ];
  var meta = {
    title: "Data/Chart",
    component: ds_Chart_exports.Chart,
    tags: ["autodocs"],
    args: {
      type: "line",
      data: weekly,
      height: 200,
      animate: true,
      loading: false,
      "aria-label": "Matérias por dia"
    },
    argTypes: {
      type: {
        control: "select",
        options: ["line", "bar", "horizontal-bar"]
      },
      colorMode: {
        control: "select",
        options: ["single", "auto"]
      },
      animate: { control: "boolean" },
      height: { control: { type: "number", min: 120, max: 400, step: 10 } },
      loading: { control: "boolean" }
    },
    decorators: [
      (Story) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { maxWidth: 720, padding: 16 }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Story, {}) })
    ]
  };
  var Chart_stories_default = meta;
  var Line = {
    args: {
      type: "line",
      data: weekly,
      "aria-label": "Tendência semanal"
    }
  };
  var LineMonth = {
    name: "Line (30 days)",
    args: {
      type: "line",
      data: month,
      height: 220,
      "aria-label": "Tendência do mês"
    }
  };
  var LineWideCard = {
    name: "Line in wide card",
    decorators: [
      (Story) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "div",
        {
          style: {
            maxWidth: 960,
            padding: 24,
            borderRadius: 16,
            background: "var(--pf-surface-container-lowest, #fff)",
            boxShadow: "0 8px 30px rgba(0,0,0,0.06)"
          },
          children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Story, {})
        }
      )
    ],
    args: {
      type: "line",
      data: month,
      height: 240,
      "aria-label": "Série em card largo"
    }
  };
  var Bar = {
    name: "Bar (single primary)",
    args: {
      type: "bar",
      data: weekly,
      "aria-label": "Matérias por dia"
    }
  };
  var BarCategorical = {
    name: "Bar colorMode=auto",
    args: {
      type: "bar",
      data: weekly,
      colorMode: "auto",
      "aria-label": "Matérias por dia (categórico)"
    }
  };
  var HorizontalBar = {
    name: "Horizontal bar (auto)",
    args: {
      type: "horizontal-bar",
      data: categories,
      height: 220,
      "aria-label": "Matérias por categoria"
    }
  };
  var Loading = {
    args: {
      loading: true,
      "aria-label": "Carregando gráfico"
    }
  };
  var SinglePoint = {
    args: {
      type: "line",
      data: [{ label: "Hoje", value: 14 }],
      "aria-label": "Publicações de hoje"
    }
  };

  // .design-sync/.cache/previews/Chart.tsx
  function compose(S, key) {
    const meta2 = S.default ?? {};
    const st = S[key];
    const args = { ...meta2.args ?? {}, ...st && st.args ? st.args : {} };
    const at = { ...meta2.argTypes ?? {}, ...st && st.argTypes ? st.argTypes : {} };
    for (const k of Object.keys(args)) {
      const m = at[k] && at[k].mapping;
      if (m && typeof m === "object" && args[k] in m) args[k] = m[args[k]];
    }
    const title = typeof meta2.title === "string" ? meta2.title : "";
    const ctx = {
      args,
      name: key,
      title,
      kind: title,
      id: "",
      componentId: "",
      globals: {},
      viewMode: "story",
      parameters: (st && st.parameters) ?? meta2.parameters ?? {}
    };
    let render = null;
    if (st && typeof st.render === "function") render = () => st.render(args, ctx);
    else if (typeof st === "function") render = () => st(args, ctx);
    else if (typeof meta2.render === "function") render = () => meta2.render(args, ctx);
    else {
      const C = st && st.component || meta2.component;
      if (C) render = () => React.createElement(C, args);
    }
    if (!render) return () => null;
    const decorators = [].concat((st && st.decorators) ?? []).concat(meta2.decorators ?? []);
    return decorators.reduce((inner, dec) => () => {
      const out = dec(inner, ctx);
      return out === void 0 ? inner() : out;
    }, render);
  }
  var Line2 = (
    /* Line */
    compose(Chart_stories_exports, "Line")
  );
  var LineMonth2 = (
    /* Line (30 days) */
    compose(Chart_stories_exports, "LineMonth")
  );
  var LineWideCard2 = (
    /* Line in wide card */
    compose(Chart_stories_exports, "LineWideCard")
  );
  var Bar2 = (
    /* Bar (single primary) */
    compose(Chart_stories_exports, "Bar")
  );
  var BarCategorical2 = (
    /* Bar colorMode=auto */
    compose(Chart_stories_exports, "BarCategorical")
  );
  var HorizontalBar2 = (
    /* Horizontal bar (auto) */
    compose(Chart_stories_exports, "HorizontalBar")
  );
  var Loading2 = (
    /* Loading */
    compose(Chart_stories_exports, "Loading")
  );
  var SinglePoint2 = (
    /* Single Point */
    compose(Chart_stories_exports, "SinglePoint")
  );
  return __toCommonJS(Chart_exports);
})();
