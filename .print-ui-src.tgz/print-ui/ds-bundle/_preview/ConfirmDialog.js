"use strict";
var __dsPreview = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx2(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs2(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx2;
      module.exports.jsxs = jsxs2;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs2 : jsx2)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // ds-raw:__ds_raw__
  var require_ds_raw = __commonJS({
    "ds-raw:__ds_raw__"(exports, module) {
      init_define_import_meta_env();
      module.exports = window.PrintUI;
    }
  });

  // .design-sync/.cache/previews/ConfirmDialog.tsx
  var ConfirmDialog_exports = {};
  __export(ConfirmDialog_exports, {
    Default: () => Default2,
    Destructive: () => Destructive2,
    Loading: () => Loading2,
    WithBody: () => WithBody2,
    WithTrigger: () => WithTrigger2
  });
  init_define_import_meta_env();
  var React = __toESM(require_react_shim(), 1);

  // src/components/ConfirmDialog/ConfirmDialog.stories.tsx
  var ConfirmDialog_stories_exports = {};
  __export(ConfirmDialog_stories_exports, {
    Default: () => Default,
    Destructive: () => Destructive,
    Loading: () => Loading,
    WithBody: () => WithBody,
    WithTrigger: () => WithTrigger,
    default: () => ConfirmDialog_stories_default
  });
  init_define_import_meta_env();
  var import_react = __toESM(require_react_shim());

  // ds-shim:ds:Button
  var ds_Button_exports = {};
  __export(ds_Button_exports, {
    default: () => ds_Button_default
  });
  init_define_import_meta_env();
  __reExport(ds_Button_exports, __toESM(require_ds_raw()));
  var g = window.PrintUI;
  var ds_Button_default = g["Button"] !== void 0 ? g["Button"] : g;

  // ds-shim:ds:ConfirmDialog
  var ds_ConfirmDialog_exports = {};
  __export(ds_ConfirmDialog_exports, {
    default: () => ds_ConfirmDialog_default
  });
  init_define_import_meta_env();
  __reExport(ds_ConfirmDialog_exports, __toESM(require_ds_raw()));
  var g2 = window.PrintUI;
  var ds_ConfirmDialog_default = g2["ConfirmDialog"] !== void 0 ? g2["ConfirmDialog"] : g2;

  // src/components/ConfirmDialog/ConfirmDialog.stories.tsx
  var import_jsx_runtime = __toESM(require_react_shim());
  var meta = {
    title: "Overlay/ConfirmDialog",
    component: ds_ConfirmDialog_exports.ConfirmDialog,
    tags: ["autodocs"],
    parameters: {
      docs: {
        description: {
          component: [
            "Diálogo de confirmação canônico do DS (substitui o uso de `Modal`/`Dialog` do print-forms na migração).",
            "",
            "**Paridade com Modal do forms:**",
            "- Trigger: passe `children` (ex.: botão) — modo não controlado",
            "- Controlled: `open` + `onOpenChange`",
            "- `destructive` → botão confirmar com variante `danger`",
            "- `loading` / `loadingLabel` — bloqueia fechar enquanto confirma",
            "",
            "`Dialog`/`Modal` crus do forms ficam no app até migrar; não há export paralelo no print-ui."
          ].join("\n")
        }
      }
    },
    args: {
      title: "Confirmar ação?",
      description: "Esta ação pode ser revertida depois.",
      confirmLabel: "Confirmar",
      cancelLabel: "Cancelar"
    }
  };
  var ConfirmDialog_stories_default = meta;
  var Default = {
    render: function Render(args) {
      const [open, setOpen] = (0, import_react.useState)(false);
      return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Button_exports.Button, { type: "button", onClick: () => setOpen(true), children: "Abrir diálogo" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          ds_ConfirmDialog_exports.ConfirmDialog,
          {
            ...args,
            open,
            onOpenChange: setOpen,
            onConfirm: () => setOpen(false)
          }
        )
      ] });
    }
  };
  var WithTrigger = {
    name: "Trigger (como Modal forms)",
    render: function Render2(args) {
      return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        ds_ConfirmDialog_exports.ConfirmDialog,
        {
          ...args,
          title: "Publicar release?",
          description: "O conteúdo ficará visível para a equipe.",
          onConfirm: () => void 0,
          children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Button_exports.Button, { type: "button", children: "Abrir via trigger" })
        }
      );
    }
  };
  var Destructive = {
    args: {
      title: "Excluir item?",
      description: "Esta ação não pode ser desfeita.",
      confirmLabel: "Excluir",
      destructive: true
    },
    render: function Render3(args) {
      const [open, setOpen] = (0, import_react.useState)(false);
      return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Button_exports.Button, { type: "button", variant: "danger", onClick: () => setOpen(true), children: "Excluir" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          ds_ConfirmDialog_exports.ConfirmDialog,
          {
            ...args,
            open,
            onOpenChange: setOpen,
            onConfirm: () => setOpen(false)
          }
        )
      ] });
    }
  };
  var WithBody = {
    args: {
      title: "Revogar acesso?",
      description: "Esta ação bloqueia o login.",
      body: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Revogar o acesso de Maria Silva?" }),
      confirmLabel: "Revogar"
    },
    render: function Render4(args) {
      const [open, setOpen] = (0, import_react.useState)(false);
      return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Button_exports.Button, { type: "button", onClick: () => setOpen(true), children: "Revogar acesso" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          ds_ConfirmDialog_exports.ConfirmDialog,
          {
            ...args,
            open,
            onOpenChange: setOpen,
            onConfirm: () => setOpen(false)
          }
        )
      ] });
    }
  };
  var Loading = {
    args: {
      title: "Salvar alterações?",
      description: "O diálogo permanece aberto enquanto a confirmação roda.",
      confirmLabel: "Salvar",
      loadingLabel: "Salvando…"
    },
    render: function Render5(args) {
      const [open, setOpen] = (0, import_react.useState)(false);
      const [loading, setLoading] = (0, import_react.useState)(false);
      return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Button_exports.Button, { type: "button", onClick: () => setOpen(true), children: "Abrir com loading" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          ds_ConfirmDialog_exports.ConfirmDialog,
          {
            ...args,
            open,
            onOpenChange: (next) => {
              if (!loading) {
                setOpen(next);
              }
            },
            loading,
            onConfirm: async () => {
              setLoading(true);
              await new Promise((resolve) => {
                setTimeout(resolve, 1500);
              });
              setLoading(false);
              setOpen(false);
            }
          }
        )
      ] });
    }
  };

  // .design-sync/.cache/previews/ConfirmDialog.tsx
  function compose(S, key) {
    const meta2 = S.default ?? {};
    const st = S[key];
    const args = { ...meta2.args ?? {}, ...st && st.args ? st.args : {} };
    const at = { ...meta2.argTypes ?? {}, ...st && st.argTypes ? st.argTypes : {} };
    for (const k of Object.keys(args)) {
      const m = at[k] && at[k].mapping;
      if (m && typeof m === "object" && args[k] in m) args[k] = m[args[k]];
    }
    const title = typeof meta2.title === "string" ? meta2.title : "";
    const ctx = {
      args,
      name: key,
      title,
      kind: title,
      id: "",
      componentId: "",
      globals: {},
      viewMode: "story",
      parameters: (st && st.parameters) ?? meta2.parameters ?? {}
    };
    let render = null;
    if (st && typeof st.render === "function") render = () => st.render(args, ctx);
    else if (typeof st === "function") render = () => st(args, ctx);
    else if (typeof meta2.render === "function") render = () => meta2.render(args, ctx);
    else {
      const C = st && st.component || meta2.component;
      if (C) render = () => React.createElement(C, args);
    }
    if (!render) return () => null;
    const decorators = [].concat((st && st.decorators) ?? []).concat(meta2.decorators ?? []);
    return decorators.reduce((inner, dec) => () => {
      const out = dec(inner, ctx);
      return out === void 0 ? inner() : out;
    }, render);
  }
  var Default2 = (
    /* Default */
    compose(ConfirmDialog_stories_exports, "Default")
  );
  var WithTrigger2 = (
    /* Trigger (como Modal forms) */
    compose(ConfirmDialog_stories_exports, "WithTrigger")
  );
  var Destructive2 = (
    /* Destructive */
    compose(ConfirmDialog_stories_exports, "Destructive")
  );
  var WithBody2 = (
    /* With Body */
    compose(ConfirmDialog_stories_exports, "WithBody")
  );
  var Loading2 = (
    /* Loading */
    compose(ConfirmDialog_stories_exports, "Loading")
  );
  return __toCommonJS(ConfirmDialog_exports);
})();
