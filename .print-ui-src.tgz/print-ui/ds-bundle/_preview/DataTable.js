"use strict";
var __dsPreview = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn2, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn2 && (res = (0, fn2[__getOwnPropNames(fn2)[0]])(fn2 = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx2(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx2;
      module.exports.jsxs = jsxs;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs : jsx2)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // sb-stub:storybook/test
  var require_test = __commonJS({
    "sb-stub:storybook/test"(exports, module) {
      init_define_import_meta_env();
      var inert = new Proxy(function() {
      }, { get: function(t, k) {
        if (k === "then") return void 0;
        if (k === "prototype") return t.prototype;
        if (k === "valueOf" || k === "toString" || k === Symbol.toPrimitive) return function() {
          return "";
        };
        return inert;
      }, apply: function() {
        return inert;
      }, construct: function() {
        return {};
      } });
      var m = {};
      "fn action actions expect userEvent within waitFor screen fireEvent spyOn mocked jest vi configureActions decorateAction setupWorker http HttpResponse graphql rest".split(" ").forEach(function(k) {
        m[k] = inert;
      });
      var def = function(p) {
        return p && p.children !== void 0 ? p.children : null;
      };
      Object.assign(def, m);
      module.exports = new Proxy(def, { get: function(t, k) {
        if (k === "then") return void 0;
        if (k === "prototype") return t.prototype;
        return k in m ? m[k] : k === "__esModule" ? void 0 : inert;
      } });
    }
  });

  // ds-raw:__ds_raw__
  var require_ds_raw = __commonJS({
    "ds-raw:__ds_raw__"(exports, module) {
      init_define_import_meta_env();
      module.exports = window.PrintUI;
    }
  });

  // .design-sync/.cache/previews/DataTable.tsx
  var DataTable_exports = {};
  __export(DataTable_exports, {
    Default: () => Default2,
    Empty: () => Empty2,
    PersonDetailed: () => PersonDetailed2,
    Striped: () => Striped2,
    WithRowActions: () => WithRowActions2,
    WithSorting: () => WithSorting2
  });
  init_define_import_meta_env();
  var React = __toESM(require_react_shim(), 1);

  // src/components/Table/DataTable.stories.tsx
  var DataTable_stories_exports = {};
  __export(DataTable_stories_exports, {
    Default: () => Default,
    Empty: () => Empty,
    PersonDetailed: () => PersonDetailed,
    Striped: () => Striped,
    WithRowActions: () => WithRowActions,
    WithSorting: () => WithSorting,
    default: () => DataTable_stories_default
  });
  init_define_import_meta_env();
  var import_react = __toESM(require_react_shim());
  var import_test = __toESM(require_test());

  // ds-shim:ds:DataTable
  var ds_DataTable_exports = {};
  __export(ds_DataTable_exports, {
    default: () => ds_DataTable_default
  });
  init_define_import_meta_env();
  __reExport(ds_DataTable_exports, __toESM(require_ds_raw()));
  var g = window.PrintUI;
  var ds_DataTable_default = g["DataTable"] !== void 0 ? g["DataTable"] : g;

  // ds-shim:ds
  var ds_exports = {};
  __export(ds_exports, {
    default: () => ds_default
  });
  init_define_import_meta_env();
  __reExport(ds_exports, __toESM(require_ds_raw()));
  var g2 = window.PrintUI;
  var ds_default = "default" in g2 ? g2.default : g2;

  // src/components/Table/DataTable.stories.tsx
  var import_jsx_runtime = __toESM(require_react_shim());
  var employees = [
    {
      id: "1",
      name: "Ana Costa",
      email: "ana@print.com",
      role: "Editora",
      department: "Política",
      articles: 24
    },
    {
      id: "2",
      name: "Bruno Lima",
      email: "bruno@print.com",
      role: "Repórter",
      department: "Esporte",
      articles: 18
    },
    {
      id: "3",
      name: "Carla Dias",
      email: "carla@print.com",
      role: "Designer",
      department: "Arte",
      articles: 9
    },
    {
      id: "4",
      name: "Diego Alves",
      email: "diego@print.com",
      role: "Fotógrafo",
      department: "Foto",
      articles: 31
    }
  ];
  var columns = [
    {
      id: "name",
      header: "Nome",
      cellType: "person",
      cell: (row) => ({ name: row.name, subtitle: row.email }),
      priority: { mobile: 1, tablet: 1, desktop: 1 },
      size: "lg",
      sortable: true
    },
    {
      id: "role",
      header: "Função",
      cell: (row) => row.role,
      priority: { mobile: 2, tablet: 2, desktop: 2 },
      size: "md",
      sortable: true
    },
    {
      id: "department",
      header: "Departamento",
      cell: (row) => row.department,
      priority: { mobile: 3, tablet: 3, desktop: 3 },
      size: "md"
    },
    {
      id: "articles",
      header: "Matérias",
      cell: (row) => row.articles,
      priority: { mobile: 4, tablet: 4, desktop: 4 },
      size: "sm",
      align: "right",
      sortable: true
    }
  ];
  var detailedColumns = [
    {
      id: "person",
      header: "Pessoa",
      cellType: "personDetailed",
      cell: (row) => ({
        name: row.name,
        subtitle: row.role,
        email: row.email,
        phone: "(11) 99999-0000",
        contactAction: {
          label: "Enviar mensagem",
          onClick: (0, import_test.fn)()
        }
      }),
      priority: { mobile: 1, tablet: 1, desktop: 1 },
      size: "xl"
    },
    {
      id: "department",
      header: "Departamento",
      cell: (row) => row.department,
      priority: { mobile: 2, tablet: 2, desktop: 2 },
      size: "md"
    },
    {
      id: "articles",
      header: "Matérias",
      cell: (row) => row.articles,
      priority: { mobile: 3, tablet: 3, desktop: 3 },
      size: "sm",
      align: "right"
    }
  ];
  function sortRows(data, sort) {
    if (!sort?.direction || !sort.key) {
      return data;
    }
    const dir = sort.direction === "asc" ? 1 : -1;
    return [...data].sort((a, b) => {
      const left = a[sort.key];
      const right = b[sort.key];
      if (typeof left === "number" && typeof right === "number") {
        return (left - right) * dir;
      }
      return String(left).localeCompare(String(right)) * dir;
    });
  }
  var meta = {
    title: "Data/DataTable",
    component: ds_DataTable_exports.DataTable,
    tags: ["autodocs"],
    args: {
      columns,
      data: employees,
      getRowKey: (row) => row.id,
      striped: false,
      emptyState: "Nenhum registro encontrado."
    }
  };
  var DataTable_stories_default = meta;
  var Default = {};
  var Striped = {
    args: { striped: true }
  };
  var WithSorting = {
    render: (args) => {
      const [sort, setSort] = (0, import_react.useState)({
        key: "name",
        direction: "asc"
      });
      return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        ds_DataTable_exports.DataTable,
        {
          columns,
          data: sortRows(employees, sort),
          getRowKey: (row) => row.id,
          striped: args.striped,
          emptyState: args.emptyState,
          sort,
          onSort: (columnId) => {
            setSort((current) => {
              if (current.key !== columnId) {
                return { key: columnId, direction: "asc" };
              }
              if (current.direction === "asc") {
                return { key: columnId, direction: "desc" };
              }
              if (current.direction === "desc") {
                return { key: columnId, direction: null };
              }
              return { key: columnId, direction: "asc" };
            });
          }
        }
      );
    }
  };
  var WithRowActions = {
    args: {
      rowActions: (row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        ds_exports.TableRowActions,
        {
          "aria-label": `Ações de ${row.name}`,
          actions: [
            { label: "Ver", icon: "view", onSelect: (0, import_test.fn)() },
            { label: "Editar", icon: "edit", onSelect: (0, import_test.fn)() },
            {
              label: "Excluir",
              icon: "delete",
              destructive: true,
              onSelect: (0, import_test.fn)()
            }
          ]
        }
      )
    }
  };
  var Empty = {
    args: {
      data: []
    }
  };
  var PersonDetailed = {
    args: {
      columns: detailedColumns
    }
  };

  // .design-sync/.cache/previews/DataTable.tsx
  function compose(S, key) {
    const meta2 = S.default ?? {};
    const st = S[key];
    const args = { ...meta2.args ?? {}, ...st && st.args ? st.args : {} };
    const at = { ...meta2.argTypes ?? {}, ...st && st.argTypes ? st.argTypes : {} };
    for (const k of Object.keys(args)) {
      const m = at[k] && at[k].mapping;
      if (m && typeof m === "object" && args[k] in m) args[k] = m[args[k]];
    }
    const title = typeof meta2.title === "string" ? meta2.title : "";
    const ctx = {
      args,
      name: key,
      title,
      kind: title,
      id: "",
      componentId: "",
      globals: {},
      viewMode: "story",
      parameters: (st && st.parameters) ?? meta2.parameters ?? {}
    };
    let render = null;
    if (st && typeof st.render === "function") render = () => st.render(args, ctx);
    else if (typeof st === "function") render = () => st(args, ctx);
    else if (typeof meta2.render === "function") render = () => meta2.render(args, ctx);
    else {
      const C = st && st.component || meta2.component;
      if (C) render = () => React.createElement(C, args);
    }
    if (!render) return () => null;
    const decorators = [].concat((st && st.decorators) ?? []).concat(meta2.decorators ?? []);
    return decorators.reduce((inner, dec) => () => {
      const out = dec(inner, ctx);
      return out === void 0 ? inner() : out;
    }, render);
  }
  var Default2 = (
    /* Default */
    compose(DataTable_stories_exports, "Default")
  );
  var Striped2 = (
    /* Striped */
    compose(DataTable_stories_exports, "Striped")
  );
  var WithSorting2 = (
    /* With Sorting */
    compose(DataTable_stories_exports, "WithSorting")
  );
  var WithRowActions2 = (
    /* With Row Actions */
    compose(DataTable_stories_exports, "WithRowActions")
  );
  var Empty2 = (
    /* Empty */
    compose(DataTable_stories_exports, "Empty")
  );
  var PersonDetailed2 = (
    /* Person Detailed */
    compose(DataTable_stories_exports, "PersonDetailed")
  );
  return __toCommonJS(DataTable_exports);
})();
