"use strict";
var __dsPreview = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx2(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs2(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx2;
      module.exports.jsxs = jsxs2;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs2 : jsx2)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // ds-raw:__ds_raw__
  var require_ds_raw = __commonJS({
    "ds-raw:__ds_raw__"(exports, module) {
      init_define_import_meta_env();
      module.exports = window.PrintUI;
    }
  });

  // .design-sync/.cache/previews/Drawer.tsx
  var Drawer_exports = {};
  __export(Drawer_exports, {
    Default: () => Default2,
    Large: () => Large2,
    Shell: () => Shell2
  });
  init_define_import_meta_env();
  var React = __toESM(require_react_shim(), 1);

  // src/components/Drawer/Drawer.stories.tsx
  var Drawer_stories_exports = {};
  __export(Drawer_stories_exports, {
    Default: () => Default,
    Large: () => Large,
    Shell: () => Shell,
    default: () => Drawer_stories_default
  });
  init_define_import_meta_env();
  var import_react = __toESM(require_react_shim());

  // ds-shim:ds:Button
  var ds_Button_exports = {};
  __export(ds_Button_exports, {
    default: () => ds_Button_default
  });
  init_define_import_meta_env();
  __reExport(ds_Button_exports, __toESM(require_ds_raw()));
  var g = window.PrintUI;
  var ds_Button_default = g["Button"] !== void 0 ? g["Button"] : g;

  // ds-shim:ds:Drawer
  var ds_Drawer_exports = {};
  __export(ds_Drawer_exports, {
    default: () => ds_Drawer_default
  });
  init_define_import_meta_env();
  __reExport(ds_Drawer_exports, __toESM(require_ds_raw()));
  var g2 = window.PrintUI;
  var ds_Drawer_default = g2["Drawer"] !== void 0 ? g2["Drawer"] : g2;

  // src/components/Drawer/Drawer.stories.tsx
  var import_jsx_runtime = __toESM(require_react_shim());
  var meta = {
    title: "Overlay/Drawer",
    component: ds_Drawer_exports.Drawer,
    tags: ["autodocs"],
    args: {
      title: "Detalhes",
      description: "Revise as informações antes de confirmar.",
      confirmLabel: "Confirmar",
      cancelLabel: "Cancelar",
      size: "md",
      children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Button_exports.Button, { type: "button", children: "Abrir drawer" }),
      body: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Conteúdo do painel lateral. Em viewports estreitas o drawer sobe como sheet; em desktop abre pela lateral." })
    },
    argTypes: {
      size: {
        control: "select",
        options: ["md", "lg", "xl"]
      },
      children: { control: false },
      body: { control: false }
    }
  };
  var Drawer_stories_default = meta;
  var Default = {
    render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Drawer_exports.Drawer, { ...args })
  };
  var Large = {
    args: {
      size: "lg",
      title: "Drawer grande",
      children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Button_exports.Button, { type: "button", children: "Abrir drawer lg" })
    },
    render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Drawer_exports.Drawer, { ...args })
  };
  var Shell = {
    name: "DrawerShell",
    parameters: {
      docs: {
        description: {
          story: "Shell controlado com footer customizado — base usada por fluxos como DrawerSteps."
        }
      }
    },
    render: function Render() {
      const [open, setOpen] = (0, import_react.useState)(false);
      return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Button_exports.Button, { type: "button", onClick: () => setOpen(true), children: "Abrir DrawerShell" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          ds_Drawer_exports.DrawerShell,
          {
            open,
            onOpenChange: setOpen,
            title: "Editar perfil",
            description: "Atualize os dados do usuário.",
            size: "lg",
            footer: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Button_exports.Button, { type: "button", variant: "ghost", onClick: () => setOpen(false), children: "Cancelar" }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_Button_exports.Button, { type: "button", variant: "primary", onClick: () => setOpen(false), children: "Salvar" })
            ] }),
            children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { style: { display: "grid", gap: 4 }, children: [
              "Nome",
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", { defaultValue: "Maria Silva" })
            ] })
          }
        )
      ] });
    }
  };

  // .design-sync/.cache/previews/Drawer.tsx
  function compose(S, key) {
    const meta2 = S.default ?? {};
    const st = S[key];
    const args = { ...meta2.args ?? {}, ...st && st.args ? st.args : {} };
    const at = { ...meta2.argTypes ?? {}, ...st && st.argTypes ? st.argTypes : {} };
    for (const k of Object.keys(args)) {
      const m = at[k] && at[k].mapping;
      if (m && typeof m === "object" && args[k] in m) args[k] = m[args[k]];
    }
    const title = typeof meta2.title === "string" ? meta2.title : "";
    const ctx = {
      args,
      name: key,
      title,
      kind: title,
      id: "",
      componentId: "",
      globals: {},
      viewMode: "story",
      parameters: (st && st.parameters) ?? meta2.parameters ?? {}
    };
    let render = null;
    if (st && typeof st.render === "function") render = () => st.render(args, ctx);
    else if (typeof st === "function") render = () => st(args, ctx);
    else if (typeof meta2.render === "function") render = () => meta2.render(args, ctx);
    else {
      const C = st && st.component || meta2.component;
      if (C) render = () => React.createElement(C, args);
    }
    if (!render) return () => null;
    const decorators = [].concat((st && st.decorators) ?? []).concat(meta2.decorators ?? []);
    return decorators.reduce((inner, dec) => () => {
      const out = dec(inner, ctx);
      return out === void 0 ? inner() : out;
    }, render);
  }
  var Default2 = (
    /* Default */
    compose(Drawer_stories_exports, "Default")
  );
  var Large2 = (
    /* Large */
    compose(Drawer_stories_exports, "Large")
  );
  var Shell2 = (
    /* DrawerShell */
    compose(Drawer_stories_exports, "Shell")
  );
  return __toCommonJS(Drawer_exports);
})();
