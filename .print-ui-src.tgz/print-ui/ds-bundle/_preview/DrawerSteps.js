"use strict";
var __dsPreview = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx2(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs2(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx2;
      module.exports.jsxs = jsxs2;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs2 : jsx2)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // ds-raw:__ds_raw__
  var require_ds_raw = __commonJS({
    "ds-raw:__ds_raw__"(exports, module) {
      init_define_import_meta_env();
      module.exports = window.PrintUI;
    }
  });

  // .design-sync/.cache/previews/DrawerSteps.tsx
  var DrawerSteps_exports = {};
  __export(DrawerSteps_exports, {
    ProvisionAccess: () => ProvisionAccess2
  });
  init_define_import_meta_env();
  var React = __toESM(require_react_shim(), 1);

  // src/components/Drawer/DrawerSteps.stories.tsx
  var DrawerSteps_stories_exports = {};
  __export(DrawerSteps_stories_exports, {
    ProvisionAccess: () => ProvisionAccess,
    default: () => DrawerSteps_stories_default
  });
  init_define_import_meta_env();
  var import_react = __toESM(require_react_shim());

  // ds-shim:ds:Button
  var ds_Button_exports = {};
  __export(ds_Button_exports, {
    default: () => ds_Button_default
  });
  init_define_import_meta_env();
  __reExport(ds_Button_exports, __toESM(require_ds_raw()));
  var g = window.PrintUI;
  var ds_Button_default = g["Button"] !== void 0 ? g["Button"] : g;

  // ds-shim:ds:ConfirmDialog
  var ds_ConfirmDialog_exports = {};
  __export(ds_ConfirmDialog_exports, {
    default: () => ds_ConfirmDialog_default
  });
  init_define_import_meta_env();
  __reExport(ds_ConfirmDialog_exports, __toESM(require_ds_raw()));
  var g2 = window.PrintUI;
  var ds_ConfirmDialog_default = g2["ConfirmDialog"] !== void 0 ? g2["ConfirmDialog"] : g2;

  // ds-shim:ds:DrawerSteps
  var ds_DrawerSteps_exports = {};
  __export(ds_DrawerSteps_exports, {
    default: () => ds_DrawerSteps_default
  });
  init_define_import_meta_env();
  __reExport(ds_DrawerSteps_exports, __toESM(require_ds_raw()));
  var g3 = window.PrintUI;
  var ds_DrawerSteps_default = g3["DrawerSteps"] !== void 0 ? g3["DrawerSteps"] : g3;

  // src/components/Drawer/DrawerSteps.stories.tsx
  var import_jsx_runtime = __toESM(require_react_shim());
  function ProvisionAccessDemo() {
    const [open, setOpen] = (0, import_react.useState)(false);
    const [stepIndex, setStepIndex] = (0, import_react.useState)(0);
    const [personName, setPersonName] = (0, import_react.useState)("");
    const [email, setEmail] = (0, import_react.useState)("");
    const [confirmDiscardOpen, setConfirmDiscardOpen] = (0, import_react.useState)(false);
    const [isCompleting, setIsCompleting] = (0, import_react.useState)(false);
    const hasUnsavedChanges = personName.trim().length > 0 || email.trim().length > 0;
    const steps = (0, import_react.useMemo)(
      () => [
        {
          id: "person",
          label: "Buscar pessoa",
          isValid: personName.trim().length > 0,
          content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { style: { display: "grid", gap: 4 }, children: [
            "Nome",
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
              "input",
              {
                "aria-label": "Nome",
                value: personName,
                onChange: (event) => setPersonName(event.target.value),
                placeholder: "Maria Silva"
              }
            )
          ] })
        },
        {
          id: "access",
          label: "Atribuir acesso",
          isValid: email.includes("@"),
          content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { style: { display: "grid", gap: 4 }, children: [
            "E-mail",
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
              "input",
              {
                "aria-label": "E-mail",
                type: "email",
                value: email,
                onChange: (event) => setEmail(event.target.value),
                placeholder: "maria@empresa.com"
              }
            )
          ] })
        }
      ],
      [personName, email]
    );
    const resetFlow = () => {
      setStepIndex(0);
      setPersonName("");
      setEmail("");
      setIsCompleting(false);
    };
    const handleRequestClose = () => {
      if (hasUnsavedChanges) {
        setConfirmDiscardOpen(true);
        return;
      }
      setOpen(false);
      resetFlow();
    };
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        ds_Button_exports.Button,
        {
          type: "button",
          onClick: () => {
            resetFlow();
            setOpen(true);
          },
          children: "Conceder acesso"
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        ds_DrawerSteps_exports.DrawerSteps,
        {
          open,
          onOpenChange: setOpen,
          flowTitle: "Conceder acesso",
          steps,
          currentStepIndex: stepIndex,
          onStepChange: setStepIndex,
          completeLabel: "Conceder acesso",
          isCompleting,
          size: "lg",
          onComplete: async () => {
            setIsCompleting(true);
            await new Promise((resolve) => {
              setTimeout(resolve, 800);
            });
            setIsCompleting(false);
            resetFlow();
          },
          onRequestClose: handleRequestClose
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        ds_ConfirmDialog_exports.ConfirmDialog,
        {
          open: confirmDiscardOpen,
          onOpenChange: setConfirmDiscardOpen,
          title: "Descartar progresso?",
          description: "As informações preenchidas neste fluxo serão perdidas.",
          confirmLabel: "Descartar",
          cancelLabel: "Continuar editando",
          destructive: true,
          onConfirm: () => {
            setConfirmDiscardOpen(false);
            setOpen(false);
            resetFlow();
          }
        }
      )
    ] });
  }
  var meta = {
    title: "Overlay/DrawerSteps",
    tags: ["autodocs"],
    parameters: {
      docs: {
        description: {
          component: "Painel multi-etapas sobre DrawerShell. Persistência e validação ficam no consumidor; fechamento com dados não salvos usa ConfirmDialog externo."
        }
      }
    }
  };
  var DrawerSteps_stories_default = meta;
  var ProvisionAccess = {
    name: "Conceder acesso",
    render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProvisionAccessDemo, {})
  };

  // .design-sync/.cache/previews/DrawerSteps.tsx
  function compose(S, key) {
    const meta2 = S.default ?? {};
    const st = S[key];
    const args = { ...meta2.args ?? {}, ...st && st.args ? st.args : {} };
    const at = { ...meta2.argTypes ?? {}, ...st && st.argTypes ? st.argTypes : {} };
    for (const k of Object.keys(args)) {
      const m = at[k] && at[k].mapping;
      if (m && typeof m === "object" && args[k] in m) args[k] = m[args[k]];
    }
    const title = typeof meta2.title === "string" ? meta2.title : "";
    const ctx = {
      args,
      name: key,
      title,
      kind: title,
      id: "",
      componentId: "",
      globals: {},
      viewMode: "story",
      parameters: (st && st.parameters) ?? meta2.parameters ?? {}
    };
    let render = null;
    if (st && typeof st.render === "function") render = () => st.render(args, ctx);
    else if (typeof st === "function") render = () => st(args, ctx);
    else if (typeof meta2.render === "function") render = () => meta2.render(args, ctx);
    else {
      const C = st && st.component || meta2.component;
      if (C) render = () => React.createElement(C, args);
    }
    if (!render) return () => null;
    const decorators = [].concat((st && st.decorators) ?? []).concat(meta2.decorators ?? []);
    return decorators.reduce((inner, dec) => () => {
      const out = dec(inner, ctx);
      return out === void 0 ? inner() : out;
    }, render);
  }
  var ProvisionAccess2 = (
    /* Conceder acesso */
    compose(DrawerSteps_stories_exports, "ProvisionAccess")
  );
  return __toCommonJS(DrawerSteps_exports);
})();
