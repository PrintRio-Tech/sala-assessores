"use strict";
var __dsPreview = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn2, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn2 && (res = (0, fn2[__getOwnPropNames(fn2)[0]])(fn2 = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx;
      module.exports.jsxs = jsxs;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs : jsx)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // sb-stub:storybook/test
  var require_test = __commonJS({
    "sb-stub:storybook/test"(exports, module) {
      init_define_import_meta_env();
      var inert = new Proxy(function() {
      }, { get: function(t, k) {
        if (k === "then") return void 0;
        if (k === "prototype") return t.prototype;
        if (k === "valueOf" || k === "toString" || k === Symbol.toPrimitive) return function() {
          return "";
        };
        return inert;
      }, apply: function() {
        return inert;
      }, construct: function() {
        return {};
      } });
      var m = {};
      "fn action actions expect userEvent within waitFor screen fireEvent spyOn mocked jest vi configureActions decorateAction setupWorker http HttpResponse graphql rest".split(" ").forEach(function(k) {
        m[k] = inert;
      });
      var def = function(p) {
        return p && p.children !== void 0 ? p.children : null;
      };
      Object.assign(def, m);
      module.exports = new Proxy(def, { get: function(t, k) {
        if (k === "then") return void 0;
        if (k === "prototype") return t.prototype;
        return k in m ? m[k] : k === "__esModule" ? void 0 : inert;
      } });
    }
  });

  // ds-raw:__ds_raw__
  var require_ds_raw = __commonJS({
    "ds-raw:__ds_raw__"(exports, module) {
      init_define_import_meta_env();
      module.exports = window.PrintUI;
    }
  });

  // .design-sync/.cache/previews/EmptyState.tsx
  var EmptyState_exports = {};
  __export(EmptyState_exports, {
    Default: () => Default2,
    Empty: () => Empty2,
    Error: () => Error3,
    Filtered: () => Filtered2,
    WithoutAction: () => WithoutAction2
  });
  init_define_import_meta_env();
  var React = __toESM(require_react_shim(), 1);

  // src/components/EmptyState/EmptyState.stories.tsx
  var EmptyState_stories_exports = {};
  __export(EmptyState_stories_exports, {
    Default: () => Default,
    Empty: () => Empty,
    Error: () => Error2,
    Filtered: () => Filtered,
    WithoutAction: () => WithoutAction,
    default: () => EmptyState_stories_default
  });
  init_define_import_meta_env();
  var import_test = __toESM(require_test());

  // ds-shim:ds:EmptyState
  var ds_EmptyState_exports = {};
  __export(ds_EmptyState_exports, {
    default: () => ds_EmptyState_default
  });
  init_define_import_meta_env();
  __reExport(ds_EmptyState_exports, __toESM(require_ds_raw()));
  var g = window.PrintUI;
  var ds_EmptyState_default = g["EmptyState"] !== void 0 ? g["EmptyState"] : g;

  // src/components/EmptyState/EmptyState.stories.tsx
  var meta = {
    title: "Foundation/EmptyState",
    component: ds_EmptyState_exports.EmptyState,
    tags: ["autodocs"],
    args: {
      variant: "empty",
      title: "Nenhum item ainda",
      description: "Comece criando o primeiro registro para ver os dados aqui.",
      action: {
        label: "Criar item",
        onClick: (0, import_test.fn)()
      }
    },
    argTypes: {
      variant: {
        control: "select",
        options: ["empty", "filtered", "error"]
      }
    }
  };
  var EmptyState_stories_default = meta;
  var Default = {};
  var Empty = {
    args: {
      variant: "empty",
      title: "Nenhum clipping",
      description: "Adicione um clipping para começar a acompanhar a cobertura.",
      action: {
        label: "Novo clipping",
        onClick: (0, import_test.fn)()
      }
    }
  };
  var Filtered = {
    args: {
      variant: "filtered",
      title: "Nenhum resultado",
      description: "Ajuste os filtros ou limpe a busca para ver mais itens.",
      action: {
        label: "Limpar filtros",
        onClick: (0, import_test.fn)()
      }
    }
  };
  var Error2 = {
    args: {
      variant: "error",
      title: "Não foi possível carregar",
      description: "Ocorreu um erro ao buscar os dados. Tente novamente.",
      action: {
        label: "Tentar de novo",
        onClick: (0, import_test.fn)()
      }
    }
  };
  var WithoutAction = {
    args: {
      variant: "empty",
      title: "Lista vazia",
      description: "Não há itens para exibir no momento.",
      action: void 0
    }
  };

  // .design-sync/.cache/previews/EmptyState.tsx
  function compose(S, key) {
    const meta2 = S.default ?? {};
    const st = S[key];
    const args = { ...meta2.args ?? {}, ...st && st.args ? st.args : {} };
    const at = { ...meta2.argTypes ?? {}, ...st && st.argTypes ? st.argTypes : {} };
    for (const k of Object.keys(args)) {
      const m = at[k] && at[k].mapping;
      if (m && typeof m === "object" && args[k] in m) args[k] = m[args[k]];
    }
    const title = typeof meta2.title === "string" ? meta2.title : "";
    const ctx = {
      args,
      name: key,
      title,
      kind: title,
      id: "",
      componentId: "",
      globals: {},
      viewMode: "story",
      parameters: (st && st.parameters) ?? meta2.parameters ?? {}
    };
    let render = null;
    if (st && typeof st.render === "function") render = () => st.render(args, ctx);
    else if (typeof st === "function") render = () => st(args, ctx);
    else if (typeof meta2.render === "function") render = () => meta2.render(args, ctx);
    else {
      const C = st && st.component || meta2.component;
      if (C) render = () => React.createElement(C, args);
    }
    if (!render) return () => null;
    const decorators = [].concat((st && st.decorators) ?? []).concat(meta2.decorators ?? []);
    return decorators.reduce((inner, dec) => () => {
      const out = dec(inner, ctx);
      return out === void 0 ? inner() : out;
    }, render);
  }
  var Default2 = (
    /* Default */
    compose(EmptyState_stories_exports, "Default")
  );
  var Empty2 = (
    /* Empty */
    compose(EmptyState_stories_exports, "Empty")
  );
  var Filtered2 = (
    /* Filtered */
    compose(EmptyState_stories_exports, "Filtered")
  );
  var Error3 = (
    /* Error */
    compose(EmptyState_stories_exports, "Error")
  );
  var WithoutAction2 = (
    /* Without Action */
    compose(EmptyState_stories_exports, "WithoutAction")
  );
  return __toCommonJS(EmptyState_exports);
})();
