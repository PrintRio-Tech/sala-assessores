"use strict";
var __dsPreview = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx;
      module.exports.jsxs = jsxs;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs : jsx)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // ds-raw:__ds_raw__
  var require_ds_raw = __commonJS({
    "ds-raw:__ds_raw__"(exports, module) {
      init_define_import_meta_env();
      module.exports = window.PrintUI;
    }
  });

  // .design-sync/.cache/previews/Heatmap.tsx
  var Heatmap_exports = {};
  __export(Heatmap_exports, {
    Default: () => Default2,
    Empty: () => Empty2,
    Loading: () => Loading2,
    Sparse: () => Sparse2
  });
  init_define_import_meta_env();
  var React = __toESM(require_react_shim(), 1);

  // src/components/Heatmap/Heatmap.stories.tsx
  var Heatmap_stories_exports = {};
  __export(Heatmap_stories_exports, {
    Default: () => Default,
    Empty: () => Empty,
    Loading: () => Loading,
    Sparse: () => Sparse,
    default: () => Heatmap_stories_default
  });
  init_define_import_meta_env();

  // ds-shim:ds:Heatmap
  var ds_Heatmap_exports = {};
  __export(ds_Heatmap_exports, {
    default: () => ds_Heatmap_default
  });
  init_define_import_meta_env();
  __reExport(ds_Heatmap_exports, __toESM(require_ds_raw()));
  var g = window.PrintUI;
  var ds_Heatmap_default = g["Heatmap"] !== void 0 ? g["Heatmap"] : g;

  // src/components/Heatmap/Heatmap.stories.tsx
  function buildMockCells() {
    const cells = [];
    for (let weekday = 0; weekday < 7; weekday += 1) {
      for (let hour = 0; hour < 24; hour += 1) {
        const isWeekend = weekday === 0 || weekday === 6;
        const peak = hour >= 8 && hour <= 11 ? 1 : hour >= 14 && hour <= 18 ? 0.85 : hour >= 20 && hour <= 22 ? 0.45 : 0.1;
        const weekendFactor = isWeekend ? 0.55 : 1;
        const noise = (weekday * 17 + hour * 13) % 7 / 7;
        const count = Math.round(peak * weekendFactor * (8 + noise * 20));
        if (count > 0) {
          cells.push({ weekday, hour, count });
        }
      }
    }
    return cells;
  }
  var mockCells = buildMockCells();
  var meta = {
    title: "Data/Heatmap",
    component: ds_Heatmap_exports.Heatmap,
    tags: ["autodocs"],
    args: {
      cells: mockCells,
      loading: false,
      "aria-label": "Mapa de calor por dia e hora"
    },
    argTypes: {
      loading: { control: "boolean" }
    }
  };
  var Heatmap_stories_default = meta;
  var Default = {};
  var Loading = {
    args: {
      loading: true
    }
  };
  var Sparse = {
    args: {
      cells: [
        { weekday: 1, hour: 9, count: 12 },
        { weekday: 1, hour: 10, count: 18 },
        { weekday: 2, hour: 15, count: 7 },
        { weekday: 3, hour: 11, count: 22 },
        { weekday: 4, hour: 16, count: 9 },
        { weekday: 5, hour: 8, count: 14 },
        { weekday: 5, hour: 20, count: 5 }
      ],
      "aria-label": "Picos de publicação"
    }
  };
  var Empty = {
    args: {
      cells: []
    }
  };

  // .design-sync/.cache/previews/Heatmap.tsx
  function compose(S, key) {
    const meta2 = S.default ?? {};
    const st = S[key];
    const args = { ...meta2.args ?? {}, ...st && st.args ? st.args : {} };
    const at = { ...meta2.argTypes ?? {}, ...st && st.argTypes ? st.argTypes : {} };
    for (const k of Object.keys(args)) {
      const m = at[k] && at[k].mapping;
      if (m && typeof m === "object" && args[k] in m) args[k] = m[args[k]];
    }
    const title = typeof meta2.title === "string" ? meta2.title : "";
    const ctx = {
      args,
      name: key,
      title,
      kind: title,
      id: "",
      componentId: "",
      globals: {},
      viewMode: "story",
      parameters: (st && st.parameters) ?? meta2.parameters ?? {}
    };
    let render = null;
    if (st && typeof st.render === "function") render = () => st.render(args, ctx);
    else if (typeof st === "function") render = () => st(args, ctx);
    else if (typeof meta2.render === "function") render = () => meta2.render(args, ctx);
    else {
      const C = st && st.component || meta2.component;
      if (C) render = () => React.createElement(C, args);
    }
    if (!render) return () => null;
    const decorators = [].concat((st && st.decorators) ?? []).concat(meta2.decorators ?? []);
    return decorators.reduce((inner, dec) => () => {
      const out = dec(inner, ctx);
      return out === void 0 ? inner() : out;
    }, render);
  }
  var Default2 = (
    /* Default */
    compose(Heatmap_stories_exports, "Default")
  );
  var Loading2 = (
    /* Loading */
    compose(Heatmap_stories_exports, "Loading")
  );
  var Sparse2 = (
    /* Sparse */
    compose(Heatmap_stories_exports, "Sparse")
  );
  var Empty2 = (
    /* Empty */
    compose(Heatmap_stories_exports, "Empty")
  );
  return __toCommonJS(Heatmap_exports);
})();
