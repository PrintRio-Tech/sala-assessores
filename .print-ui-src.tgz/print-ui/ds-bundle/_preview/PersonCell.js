"use strict";
var __dsPreview = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn2, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn2 && (res = (0, fn2[__getOwnPropNames(fn2)[0]])(fn2 = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx2(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs2(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx2;
      module.exports.jsxs = jsxs2;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs2 : jsx2)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // sb-stub:storybook/test
  var require_test = __commonJS({
    "sb-stub:storybook/test"(exports, module) {
      init_define_import_meta_env();
      var inert = new Proxy(function() {
      }, { get: function(t, k) {
        if (k === "then") return void 0;
        if (k === "prototype") return t.prototype;
        if (k === "valueOf" || k === "toString" || k === Symbol.toPrimitive) return function() {
          return "";
        };
        return inert;
      }, apply: function() {
        return inert;
      }, construct: function() {
        return {};
      } });
      var m = {};
      "fn action actions expect userEvent within waitFor screen fireEvent spyOn mocked jest vi configureActions decorateAction setupWorker http HttpResponse graphql rest".split(" ").forEach(function(k) {
        m[k] = inert;
      });
      var def = function(p) {
        return p && p.children !== void 0 ? p.children : null;
      };
      Object.assign(def, m);
      module.exports = new Proxy(def, { get: function(t, k) {
        if (k === "then") return void 0;
        if (k === "prototype") return t.prototype;
        return k in m ? m[k] : k === "__esModule" ? void 0 : inert;
      } });
    }
  });

  // ds-raw:__ds_raw__
  var require_ds_raw = __commonJS({
    "ds-raw:__ds_raw__"(exports, module) {
      init_define_import_meta_env();
      module.exports = window.PrintUI;
    }
  });

  // .design-sync/.cache/previews/PersonCell.tsx
  var PersonCell_exports = {};
  __export(PersonCell_exports, {
    DetailPreviewCard: () => DetailPreviewCard2,
    Person: () => Person2,
    PersonCard: () => PersonCard2,
    PersonCompact: () => PersonCompact2,
    PersonDetailed: () => PersonDetailed2,
    PersonWithAvatar: () => PersonWithAvatar2
  });
  init_define_import_meta_env();
  var React = __toESM(require_react_shim(), 1);

  // src/components/Table/Cells.stories.tsx
  var Cells_stories_exports = {};
  __export(Cells_stories_exports, {
    DetailPreviewCard: () => DetailPreviewCard,
    Person: () => Person,
    PersonCard: () => PersonCard,
    PersonCompact: () => PersonCompact,
    PersonDetailed: () => PersonDetailed,
    PersonWithAvatar: () => PersonWithAvatar,
    default: () => Cells_stories_default
  });
  init_define_import_meta_env();
  var import_test = __toESM(require_test());

  // ds-shim:ds:DetailPreview
  var ds_DetailPreview_exports = {};
  __export(ds_DetailPreview_exports, {
    default: () => ds_DetailPreview_default
  });
  init_define_import_meta_env();
  __reExport(ds_DetailPreview_exports, __toESM(require_ds_raw()));
  var g = window.PrintUI;
  var ds_DetailPreview_default = g["DetailPreview"] !== void 0 ? g["DetailPreview"] : g;

  // ds-shim:ds
  var ds_exports = {};
  __export(ds_exports, {
    default: () => ds_default
  });
  init_define_import_meta_env();
  __reExport(ds_exports, __toESM(require_ds_raw()));
  var g2 = window.PrintUI;
  var ds_default = "default" in g2 ? g2.default : g2;

  // src/components/Table/Cells.stories.tsx
  var import_jsx_runtime = __toESM(require_react_shim());
  var stack = {
    display: "flex",
    flexDirection: "column",
    gap: 24,
    maxWidth: 360
  };
  var meta = {
    title: "Data/TableCells",
    component: ds_exports.PersonCell,
    tags: ["autodocs"],
    args: {
      name: "Ana Costa",
      subtitle: "ana@print.com"
    },
    argTypes: {
      variant: {
        control: "select",
        options: ["default", "compact", "card"]
      }
    }
  };
  var Cells_stories_default = meta;
  var Person = {};
  var PersonCompact = {
    args: {
      variant: "compact"
    }
  };
  var PersonCard = {
    args: {
      variant: "card",
      subtitle: "Editora · Política"
    }
  };
  var PersonWithAvatar = {
    args: {
      name: "Bruno Lima",
      subtitle: "Repórter",
      avatarUrl: "https://i.pravatar.cc/80?u=bruno"
    }
  };
  var PersonDetailed = {
    render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: stack, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        ds_exports.PersonDetailedCell,
        {
          name: "Ana Costa",
          subtitle: "Editora",
          email: "ana@print.com",
          phone: "(11) 98888-1111",
          contactAction: {
            label: "Enviar mensagem",
            onClick: (0, import_test.fn)()
          }
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { style: { margin: 0, fontSize: 13, opacity: 0.7 }, children: "Passe o mouse sobre o nome para abrir o preview." })
    ] })
  };
  var DetailPreviewCard = {
    render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      ds_DetailPreview_exports.DetailPreview,
      {
        trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { cursor: "pointer", textDecoration: "underline" }, children: "Ver detalhes" }),
        side: "bottom",
        align: "start",
        children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { display: "flex", flexDirection: "column", gap: 8, padding: 4 }, children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.PersonCell, { name: "Carla Dias", subtitle: "Designer" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { style: { margin: 0, fontSize: 13 }, children: "Responsável pela identidade visual das capas semanais." })
        ] })
      }
    )
  };

  // .design-sync/.cache/previews/PersonCell.tsx
  function compose(S, key) {
    const meta2 = S.default ?? {};
    const st = S[key];
    const args = { ...meta2.args ?? {}, ...st && st.args ? st.args : {} };
    const at = { ...meta2.argTypes ?? {}, ...st && st.argTypes ? st.argTypes : {} };
    for (const k of Object.keys(args)) {
      const m = at[k] && at[k].mapping;
      if (m && typeof m === "object" && args[k] in m) args[k] = m[args[k]];
    }
    const title = typeof meta2.title === "string" ? meta2.title : "";
    const ctx = {
      args,
      name: key,
      title,
      kind: title,
      id: "",
      componentId: "",
      globals: {},
      viewMode: "story",
      parameters: (st && st.parameters) ?? meta2.parameters ?? {}
    };
    let render = null;
    if (st && typeof st.render === "function") render = () => st.render(args, ctx);
    else if (typeof st === "function") render = () => st(args, ctx);
    else if (typeof meta2.render === "function") render = () => meta2.render(args, ctx);
    else {
      const C = st && st.component || meta2.component;
      if (C) render = () => React.createElement(C, args);
    }
    if (!render) return () => null;
    const decorators = [].concat((st && st.decorators) ?? []).concat(meta2.decorators ?? []);
    return decorators.reduce((inner, dec) => () => {
      const out = dec(inner, ctx);
      return out === void 0 ? inner() : out;
    }, render);
  }
  var Person2 = (
    /* Person */
    compose(Cells_stories_exports, "Person")
  );
  var PersonCompact2 = (
    /* Person Compact */
    compose(Cells_stories_exports, "PersonCompact")
  );
  var PersonCard2 = (
    /* Person Card */
    compose(Cells_stories_exports, "PersonCard")
  );
  var PersonWithAvatar2 = (
    /* Person With Avatar */
    compose(Cells_stories_exports, "PersonWithAvatar")
  );
  var PersonDetailed2 = (
    /* Person Detailed */
    compose(Cells_stories_exports, "PersonDetailed")
  );
  var DetailPreviewCard2 = (
    /* Detail Preview Card */
    compose(Cells_stories_exports, "DetailPreviewCard")
  );
  return __toCommonJS(PersonCell_exports);
})();
