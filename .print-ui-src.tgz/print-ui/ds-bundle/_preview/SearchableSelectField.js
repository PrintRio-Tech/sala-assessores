"use strict";
var __dsPreview = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx2(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx2;
      module.exports.jsxs = jsxs;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs : jsx2)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // ds-raw:__ds_raw__
  var require_ds_raw = __commonJS({
    "ds-raw:__ds_raw__"(exports, module) {
      init_define_import_meta_env();
      module.exports = window.PrintUI;
    }
  });

  // .design-sync/.cache/previews/SearchableSelectField.tsx
  var SearchableSelectField_exports = {};
  __export(SearchableSelectField_exports, {
    Default: () => Default2,
    Disabled: () => Disabled2,
    Error: () => Error3,
    Filtered: () => Filtered2,
    Loading: () => Loading2,
    Required: () => Required2,
    WithDescription: () => WithDescription2,
    WithSelectedValue: () => WithSelectedValue2
  });
  init_define_import_meta_env();
  var React = __toESM(require_react_shim(), 1);

  // src/components/SearchableSelectField/SearchableSelectField.stories.tsx
  var SearchableSelectField_stories_exports = {};
  __export(SearchableSelectField_stories_exports, {
    Default: () => Default,
    Disabled: () => Disabled,
    Error: () => Error2,
    Filtered: () => Filtered,
    Loading: () => Loading,
    Required: () => Required,
    WithDescription: () => WithDescription,
    WithSelectedValue: () => WithSelectedValue,
    default: () => SearchableSelectField_stories_default
  });
  init_define_import_meta_env();
  var import_react = __toESM(require_react_shim());

  // ds-shim:ds:SearchableSelectField
  var ds_SearchableSelectField_exports = {};
  __export(ds_SearchableSelectField_exports, {
    default: () => ds_SearchableSelectField_default
  });
  init_define_import_meta_env();
  __reExport(ds_SearchableSelectField_exports, __toESM(require_ds_raw()));
  var g = window.PrintUI;
  var ds_SearchableSelectField_default = g["SearchableSelectField"] !== void 0 ? g["SearchableSelectField"] : g;

  // src/components/SearchableSelectField/SearchableSelectField.stories.tsx
  var import_jsx_runtime = __toESM(require_react_shim());
  var cityOptions = [
    { value: "sao-paulo", label: "São Paulo" },
    { value: "rio-de-janeiro", label: "Rio de Janeiro" },
    { value: "belo-horizonte", label: "Belo Horizonte" },
    { value: "curitiba", label: "Curitiba" },
    { value: "porto-alegre", label: "Porto Alegre" },
    { value: "salvador", label: "Salvador" },
    { value: "brasilia", label: "Brasília" },
    { value: "fortaleza", label: "Fortaleza" },
    { value: "recife", label: "Recife" },
    { value: "manaus", label: "Manaus" }
  ];
  var meta = {
    title: "Forms/SearchableSelectField",
    component: ds_SearchableSelectField_exports.SearchableSelectField,
    tags: ["autodocs"],
    args: {
      label: "Cidade",
      name: "city",
      options: cityOptions,
      value: "",
      onValueChange: () => void 0,
      placeholder: "Buscar cidade…",
      emptyMessage: "Nenhuma cidade encontrada.",
      required: false,
      disabled: false,
      loading: false
    },
    argTypes: {
      labelSize: {
        control: "select",
        options: ["md", "sm"]
      }
    },
    render: function Render(args) {
      const [value, setValue] = (0, import_react.useState)(args.value);
      return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        ds_SearchableSelectField_exports.SearchableSelectField,
        {
          ...args,
          value,
          onValueChange: setValue
        }
      );
    }
  };
  var SearchableSelectField_stories_default = meta;
  var Default = {};
  var WithSelectedValue = {
    args: { value: "curitiba" }
  };
  var Required = {
    args: { required: true }
  };
  var WithDescription = {
    args: {
      description: "Cidade de entrega do pedido."
    }
  };
  var Error2 = {
    args: {
      error: "Selecione uma cidade."
    }
  };
  var Loading = {
    args: {
      loading: true,
      options: []
    }
  };
  var Disabled = {
    args: {
      disabled: true,
      value: "sao-paulo"
    }
  };
  var Filtered = {
    render: function FilteredSearchableSelect() {
      const [value, setValue] = (0, import_react.useState)("");
      const [query, setQuery] = (0, import_react.useState)("");
      const options = (0, import_react.useMemo)(() => {
        const normalized = query.trim().toLowerCase();
        if (!normalized) return cityOptions;
        return cityOptions.filter(
          (option) => option.label.toLowerCase().includes(normalized)
        );
      }, [query]);
      return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        ds_SearchableSelectField_exports.SearchableSelectField,
        {
          label: "Cidade",
          name: "city",
          options,
          value,
          onValueChange: setValue,
          onQueryChange: setQuery,
          placeholder: "Digite para filtrar…"
        }
      );
    }
  };

  // .design-sync/.cache/previews/SearchableSelectField.tsx
  function compose(S, key) {
    const meta2 = S.default ?? {};
    const st = S[key];
    const args = { ...meta2.args ?? {}, ...st && st.args ? st.args : {} };
    const at = { ...meta2.argTypes ?? {}, ...st && st.argTypes ? st.argTypes : {} };
    for (const k of Object.keys(args)) {
      const m = at[k] && at[k].mapping;
      if (m && typeof m === "object" && args[k] in m) args[k] = m[args[k]];
    }
    const title = typeof meta2.title === "string" ? meta2.title : "";
    const ctx = {
      args,
      name: key,
      title,
      kind: title,
      id: "",
      componentId: "",
      globals: {},
      viewMode: "story",
      parameters: (st && st.parameters) ?? meta2.parameters ?? {}
    };
    let render = null;
    if (st && typeof st.render === "function") render = () => st.render(args, ctx);
    else if (typeof st === "function") render = () => st(args, ctx);
    else if (typeof meta2.render === "function") render = () => meta2.render(args, ctx);
    else {
      const C = st && st.component || meta2.component;
      if (C) render = () => React.createElement(C, args);
    }
    if (!render) return () => null;
    const decorators = [].concat((st && st.decorators) ?? []).concat(meta2.decorators ?? []);
    return decorators.reduce((inner, dec) => () => {
      const out = dec(inner, ctx);
      return out === void 0 ? inner() : out;
    }, render);
  }
  var Default2 = (
    /* Default */
    compose(SearchableSelectField_stories_exports, "Default")
  );
  var WithSelectedValue2 = (
    /* With Selected Value */
    compose(SearchableSelectField_stories_exports, "WithSelectedValue")
  );
  var Required2 = (
    /* Required */
    compose(SearchableSelectField_stories_exports, "Required")
  );
  var WithDescription2 = (
    /* With Description */
    compose(SearchableSelectField_stories_exports, "WithDescription")
  );
  var Error3 = (
    /* Error */
    compose(SearchableSelectField_stories_exports, "Error")
  );
  var Loading2 = (
    /* Loading */
    compose(SearchableSelectField_stories_exports, "Loading")
  );
  var Disabled2 = (
    /* Disabled */
    compose(SearchableSelectField_stories_exports, "Disabled")
  );
  var Filtered2 = (
    /* Filtered */
    compose(SearchableSelectField_stories_exports, "Filtered")
  );
  return __toCommonJS(SearchableSelectField_exports);
})();
