import * as React from 'react';

/**
 * CardSkeleton — from @printrio-tech/print-ui@0.5.10 (./src/components/Card/CardSkeleton.stories.tsx).
 */
export interface CardSkeletonProps {
  variant?: "primary" | "accent" | "soft" | "surface" | "elevated" | "inset";
  padding?: "sm" | "md" | "lg" | "none";
  /** Inclui bloco de mídia no topo. */
  withMedia?: boolean;
  className?: string;
  style?: CSSProperties;
  id?: string;
}

export declare const CardSkeleton: React.ComponentType<CardSkeletonProps>;
