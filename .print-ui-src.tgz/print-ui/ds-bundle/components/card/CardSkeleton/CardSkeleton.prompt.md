CardSkeleton from @printrio-tech/print-ui. Use via `window.PrintUI.CardSkeleton` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `CardSkeleton.html`): Default, With Media, Elevated.

## Props

```ts
interface CardSkeletonProps {
  variant?: "primary" | "accent" | "soft" | "surface" | "elevated" | "inset";
  padding?: "sm" | "md" | "lg" | "none";
  /** Inclui bloco de mídia no topo. */
  withMedia?: boolean;
  className?: string;
  style?: CSSProperties;
  id?: string;
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// With Media
export const WithMedia: Story = {
  args: { withMedia: true },
};

// Elevated
export const Elevated: Story = {
  args: { variant: 'elevated', withMedia: true },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### WithMedia

```jsx
/* With Media */ compose(S, "WithMedia")
```

### Elevated

```jsx
/* Elevated */ compose(S, "Elevated")
```
