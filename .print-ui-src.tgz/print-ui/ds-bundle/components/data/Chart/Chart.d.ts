import * as React from 'react';

/**
 * Chart — from @printrio-tech/print-ui@0.5.10 (./src/components/Chart/Chart.stories.tsx).
 */
export interface ChartProps {
  type: "line" | "bar" | "horizontal-bar";
  data: ChartDatum[];
  height?: number;
  /** Bar fill strategy. Defaults: `single` for `bar`, `auto` for `horizontal-bar`. Ignored for `line`. */
  colorMode?: "auto" | "single";
  /** Entrance motion. Honors `prefers-reduced-motion`. Default true. */
  animate?: boolean;
  loading?: boolean;
  className?: string;
  "aria-label"?: string;
}

export declare const Chart: React.ComponentType<ChartProps>;
