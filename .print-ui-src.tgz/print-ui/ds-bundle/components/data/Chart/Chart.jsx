// Re-export of @printrio-tech/print-ui@0.5.10 Chart. Implementation is in the root _ds_bundle.js (window.PrintUI).
Object.assign(window, { Chart: window.PrintUI.Chart });
