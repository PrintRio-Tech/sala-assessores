Chart from @printrio-tech/print-ui. Use via `window.PrintUI.Chart` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `Chart.html`): Line, Line (30 days), Line in wide card, Bar (single primary), Bar colorMode=auto, Horizontal bar (auto), Loading, Single Point.

## Props

```ts
interface ChartProps {
  type: "line" | "bar" | "horizontal-bar";
  data: ChartDatum[];
  height?: number;
  /** Bar fill strategy. Defaults: `single` for `bar`, `auto` for `horizontal-bar`. Ignored for `line`. */
  colorMode?: "auto" | "single";
  /** Entrance motion. Honors `prefers-reduced-motion`. Default true. */
  animate?: boolean;
  loading?: boolean;
  className?: string;
  "aria-label"?: string;
}
```

## Examples

```jsx
// Line
export const Line: Story = {
  args: {
    type: 'line',
    data: weekly,
    'aria-label': 'Tendência semanal',
  },
};

// Line (30 days)
export const LineMonth: Story = {
  name: 'Line (30 days)',
  args: {
    type: 'line',
    data: month,
    height: 220,
    'aria-label': 'Tendência do mês',
  },
};

// Line in wide card
export const LineWideCard: Story = {
  name: 'Line in wide card',
  decorators: [
    (Story) => (
      <div
        style={{
          maxWidth: 960,
          padding: 24,
          borderRadius: 16,
          background: 'var(--pf-surface-container-lowest, #fff)',
          boxShadow: '0 8px 30px rgba(0,0,0,0.06)',
        }}
      >
        <Story />
      </div>
    ),
  ],
  args: {
    type: 'line',
    data: month,
    height: 240,
    'aria-label': 'Série em card largo',
  },
};
```

### Line

```jsx
/* Line */ compose(S, "Line")
```

### LineMonth

```jsx
/* Line (30 days) */ compose(S, "LineMonth")
```

### LineWideCard

```jsx
/* Line in wide card */ compose(S, "LineWideCard")
```

### Bar

```jsx
/* Bar (single primary) */ compose(S, "Bar")
```

### BarCategorical

```jsx
/* Bar colorMode=auto */ compose(S, "BarCategorical")
```

### HorizontalBar

```jsx
/* Horizontal bar (auto) */ compose(S, "HorizontalBar")
```

### Loading

```jsx
/* Loading */ compose(S, "Loading")
```

### SinglePoint

```jsx
/* Single Point */ compose(S, "SinglePoint")
```
