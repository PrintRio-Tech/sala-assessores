import * as React from 'react';

/**
 * DataTable — from @printrio-tech/print-ui@0.5.10 (./src/components/Table/DataTable.stories.tsx).
 */
export interface DataTableProps<T> {
  columns: TableColumnDef<T>[];
  data: T[];
  getRowKey: (row: T) => string;
  striped?: boolean;
  sort?: TableSortState;
  onSort?: (columnId: string) => void;
  rowActions?: (row: T) => ReactNode;
  emptyState?: React.ReactNode;
  /** Quantas colunas de dados exibir no tablet (ações sempre visíveis). */
  tabletColumnLimit?: number;
  className?: string;
}

export declare const DataTable: React.ComponentType<DataTableProps>;
