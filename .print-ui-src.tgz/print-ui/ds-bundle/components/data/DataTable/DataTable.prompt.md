DataTable from @printrio-tech/print-ui. Use via `window.PrintUI.DataTable` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `DataTable.html`): Default, Striped, With Sorting, With Row Actions, Empty, Person Detailed.

## Props

```ts
interface DataTableProps {
  columns: TableColumnDef<T>[];
  data: T[];
  getRowKey: (row: T) => string;
  striped?: boolean;
  sort?: TableSortState;
  onSort?: (columnId: string) => void;
  rowActions?: (row: T) => ReactNode;
  emptyState?: React.ReactNode;
  /** Quantas colunas de dados exibir no tablet (ações sempre visíveis). */
  tabletColumnLimit?: number;
  className?: string;
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// Striped
export const Striped: Story = {
  args: { striped: true },
};

// With Sorting
export const WithSorting: Story = {
  render: (args) => {
    const [sort, setSort] = useState<TableSortState>({
      key: 'name',
      direction: 'asc',
    });

    return (
      <DataTable
        columns={columns}
        data={sortRows(employees, sort)}
        getRowKey={(row) => row.id}
        striped={args.striped}
        emptyState={args.emptyState}
        sort={sort}
        onSort={(columnId) => {
          setSort((current) => {
            if (current.key !== columnId) {
              return { key: columnId, direction: 'asc' };
            }

            if (current.direction === 'asc') {
              return { key: columnId, direction: 'desc' };
            }

            if (current.direction === 'desc') {
              return { key: columnId, direction: null };
            }

            return { key: columnId, direction: 'asc' };
          });
        }}
      />
    );
  },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Striped

```jsx
/* Striped */ compose(S, "Striped")
```

### WithSorting

```jsx
/* With Sorting */ compose(S, "WithSorting")
```

### WithRowActions

```jsx
/* With Row Actions */ compose(S, "WithRowActions")
```

### Empty

```jsx
/* Empty */ compose(S, "Empty")
```

### PersonDetailed

```jsx
/* Person Detailed */ compose(S, "PersonDetailed")
```
