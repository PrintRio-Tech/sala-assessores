import * as React from 'react';

/**
 * Heatmap — from @printrio-tech/print-ui@0.5.10 (./src/components/Heatmap/Heatmap.stories.tsx).
 */
export interface HeatmapProps {
  cells: HeatmapCell[];
  loading?: boolean;
  className?: string;
  "aria-label"?: string;
}

export declare const Heatmap: React.ComponentType<HeatmapProps>;
