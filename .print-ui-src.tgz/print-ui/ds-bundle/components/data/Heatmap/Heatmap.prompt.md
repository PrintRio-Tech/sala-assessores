Heatmap from @printrio-tech/print-ui. Use via `window.PrintUI.Heatmap` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `Heatmap.html`): Default, Loading, Sparse, Empty.

## Props

```ts
interface HeatmapProps {
  cells: HeatmapCell[];
  loading?: boolean;
  className?: string;
  "aria-label"?: string;
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// Loading
export const Loading: Story = {
  args: {
    loading: true,
  },
};

// Sparse
export const Sparse: Story = {
  args: {
    cells: [
      { weekday: 1, hour: 9, count: 12 },
      { weekday: 1, hour: 10, count: 18 },
      { weekday: 2, hour: 15, count: 7 },
      { weekday: 3, hour: 11, count: 22 },
      { weekday: 4, hour: 16, count: 9 },
      { weekday: 5, hour: 8, count: 14 },
      { weekday: 5, hour: 20, count: 5 },
    ],
    'aria-label': 'Picos de publicação',
  },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Loading

```jsx
/* Loading */ compose(S, "Loading")
```

### Sparse

```jsx
/* Sparse */ compose(S, "Sparse")
```

### Empty

```jsx
/* Empty */ compose(S, "Empty")
```
