import * as React from 'react';

/**
 * Pagination — from @printrio-tech/print-ui@0.5.10 (./src/components/Pagination/Pagination.stories.tsx).
 */
export interface PaginationProps {
  page: number;
  pageSize: number;
  totalItems: number;
  onPageChange: (page: number) => void;
  siblingCount?: number;
  className?: string;
  style?: CSSProperties;
  id?: string;
}

export declare const Pagination: React.ComponentType<PaginationProps>;
