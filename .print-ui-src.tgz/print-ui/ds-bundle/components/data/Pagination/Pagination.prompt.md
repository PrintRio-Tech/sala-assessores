Pagination from @printrio-tech/print-ui. Use via `window.PrintUI.Pagination` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `Pagination.html`): Default, Middle Page, Few Pages, Empty, Interactive.

## Props

```ts
interface PaginationProps {
  page: number;
  pageSize: number;
  totalItems: number;
  onPageChange: (page: number) => void;
  siblingCount?: number;
  className?: string;
  style?: CSSProperties;
  id?: string;
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// Middle Page
export const MiddlePage: Story = {
  args: {
    page: 5,
    totalItems: 95,
  },
};

// Few Pages
export const FewPages: Story = {
  args: {
    page: 1,
    pageSize: 10,
    totalItems: 25,
  },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### MiddlePage

```jsx
/* Middle Page */ compose(S, "MiddlePage")
```

### FewPages

```jsx
/* Few Pages */ compose(S, "FewPages")
```

### Empty

```jsx
/* Empty */ compose(S, "Empty")
```

### Interactive

```jsx
/* Interactive */ compose(S, "Interactive")
```
