import * as React from 'react';

/**
 * PersonCell — from @printrio-tech/print-ui@0.5.10 (./src/components/Table/Cells.stories.tsx).
 */
export interface PersonCellProps {
  name: string;
  subtitle?: string;
  avatarUrl?: string;
  compact?: boolean;
  variant?: "default" | "compact" | "card";
}

export declare const PersonCell: React.ComponentType<PersonCellProps>;
