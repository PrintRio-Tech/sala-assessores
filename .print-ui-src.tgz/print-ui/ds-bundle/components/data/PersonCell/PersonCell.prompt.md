PersonCell from @printrio-tech/print-ui. Use via `window.PrintUI.PersonCell` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `PersonCell.html`): Person, Person Compact, Person Card, Person With Avatar, Person Detailed, Detail Preview Card.

## Props

```ts
interface PersonCellProps {
  name: string;
  subtitle?: string;
  avatarUrl?: string;
  compact?: boolean;
  variant?: "default" | "compact" | "card";
}
```

## Examples

```jsx
// Person
export const Person: Story = {};

// Person Compact
export const PersonCompact: Story = {
  args: {
    variant: 'compact',
  },
};

// Person Card
export const PersonCard: Story = {
  args: {
    variant: 'card',
    subtitle: 'Editora · Política',
  },
};
```

### Person

```jsx
/* Person */ compose(S, "Person")
```

### PersonCompact

```jsx
/* Person Compact */ compose(S, "PersonCompact")
```

### PersonCard

```jsx
/* Person Card */ compose(S, "PersonCard")
```

### PersonWithAvatar

```jsx
/* Person With Avatar */ compose(S, "PersonWithAvatar")
```

### PersonDetailed

```jsx
/* Person Detailed */ compose(S, "PersonDetailed")
```

### DetailPreviewCard

```jsx
/* Detail Preview Card */ compose(S, "DetailPreviewCard")
```
