import * as React from 'react';

/**
 * SectionState — from @printrio-tech/print-ui@0.5.10 (./src/components/SectionState/SectionState.stories.tsx).
 */
export interface SectionStateProps {
  className?: string;
  minHeight?: string | number;
  status: "success" | "error" | "loading";
}

export declare const SectionState: React.ComponentType<SectionStateProps>;
