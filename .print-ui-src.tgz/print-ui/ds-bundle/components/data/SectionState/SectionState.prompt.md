SectionState from @printrio-tech/print-ui. Use via `window.PrintUI.SectionState` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `SectionState.html`): Loading, Loading Default Label, Error, Error Without Description, Success.

## Props

```ts
interface SectionStateProps {
  className?: string;
  minHeight?: string | number;
  status: "success" | "error" | "loading";
}
```

## Examples

```jsx
// Loading
export const Loading: Story = {
  args: {
    status: 'loading',
    loadingLabel: 'Carregando relatório…',
  },
};

// Loading Default Label
export const LoadingDefaultLabel: Story = {
  args: {
    status: 'loading',
  },
};

// Error
export const Error: Story = {
  args: {
    status: 'error',
    errorMessage: 'Não foi possível carregar o relatório.',
    errorDescription: 'Verifique sua conexão e tente novamente.',
    onRetry: fn(),
  },
};
```

### Loading

```jsx
/* Loading */ compose(S, "Loading")
```

### LoadingDefaultLabel

```jsx
/* Loading Default Label */ compose(S, "LoadingDefaultLabel")
```

### Error

```jsx
/* Error */ compose(S, "Error")
```

### ErrorWithoutDescription

```jsx
/* Error Without Description */ compose(S, "ErrorWithoutDescription")
```

### Success

```jsx
/* Success */ compose(S, "Success")
```
