import * as React from 'react';

/**
 * Table — from @printrio-tech/print-ui@0.5.10 (./src/components/Table/Table.stories.tsx).
 * @replaces table
 */
export interface TableProps {
  striped?: boolean;
  children: React.ReactNode;
  style?: CSSProperties;
  className?: string;
  id?: string;
}

export declare const Table: React.ComponentType<TableProps>;
