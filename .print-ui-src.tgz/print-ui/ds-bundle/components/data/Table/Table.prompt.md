Table from @printrio-tech/print-ui. Use via `window.PrintUI.Table` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `Table.html`): Default, Striped, Sortable, Empty.

## Props

```ts
interface TableProps {
  striped?: boolean;
  children: React.ReactNode;
  style?: CSSProperties;
  className?: string;
  id?: string;
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// Striped
export const Striped: Story = {
  args: {
    striped: true,
    children: (
      <>
        <TableHeader>
          <TableRow>
            <TableHead>Nome</TableHead>
            <TableHead align="right">Matérias</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.map((row, index) => (
            <TableRow key={row.id}>
              <TableCell>{row.name}</TableCell>
              <TableCell align="right">{12 + index * 4}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </>
    ),
  },
};

// Sortable
export const Sortable: Story = {
  render: (args) => {
    const [direction, setDirection] = useState<'asc' | 'desc' | null>('asc');

    return (
      <Table striped={args.striped}>
        <TableHeader>
          <TableRow>
            <TableHead
              sortable
              sortDirection={direction}
              onSort={() =>
                setDirection((current) =>
                  current === 'asc' ? 'desc' : 'asc',
                )
              }
            >
              Nome
            </TableHead>
            <TableHead>Função</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {[...rows]
            .sort((a, b) => {
              const cmp = a.name.localeCompare(b.name);
              return direction === 'desc' ? -cmp : cmp;
            })
            .map((row) => (
              <TableRow key={row.id}>
                <TableCell>{row.name}</TableCell>
                <TableCell>{row.role}</TableCell>
              </TableRow>
            ))}
        </TableBody>
      </Table>
    );
  },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Striped

```jsx
/* Striped */ compose(S, "Striped")
```

### Sortable

```jsx
/* Sortable */ compose(S, "Sortable")
```

### Empty

```jsx
/* Empty */ compose(S, "Empty")
```

## Related

`TableRowActions`, `TableSkeleton`
