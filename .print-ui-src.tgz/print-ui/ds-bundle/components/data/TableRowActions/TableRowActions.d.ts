import * as React from 'react';

/**
 * TableRowActions — from @printrio-tech/print-ui@0.5.10 (./src/components/Table/TableRowActions.stories.tsx).
 */
export interface TableRowActionsProps {
  actions: TableRowAction[];
  "aria-label"?: string;
}

export declare const TableRowActions: React.ComponentType<TableRowActionsProps>;
