TableRowActions from @printrio-tech/print-ui. Use via `window.PrintUI.TableRowActions` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `TableRowActions.html`): Default, View And Edit, Destructive Only, Without Icons.

## Props

```ts
interface TableRowActionsProps {
  actions: TableRowAction[];
  "aria-label"?: string;
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// View And Edit
export const ViewAndEdit: Story = {
  args: {
    actions: [
      { label: 'Ver', icon: 'view', onSelect: fn() },
      { label: 'Editar', icon: 'edit', onSelect: fn() },
    ],
  },
};

// Destructive Only
export const DestructiveOnly: Story = {
  args: {
    actions: [
      {
        label: 'Excluir',
        icon: 'delete',
        destructive: true,
        onSelect: fn(),
      },
    ],
  },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### ViewAndEdit

```jsx
/* View And Edit */ compose(S, "ViewAndEdit")
```

### DestructiveOnly

```jsx
/* Destructive Only */ compose(S, "DestructiveOnly")
```

### WithoutIcons

```jsx
/* Without Icons */ compose(S, "WithoutIcons")
```
