import * as React from 'react';

/**
 * Toaster — from @printrio-tech/print-ui@0.5.10 (./src/components/Toast/Toast.stories.tsx).
 */
export interface ToasterProps {
  children: React.ReactNode;
}

export declare const Toaster: React.ComponentType<ToasterProps>;
