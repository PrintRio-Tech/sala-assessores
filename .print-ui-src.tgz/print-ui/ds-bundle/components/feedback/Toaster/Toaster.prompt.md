Toaster from @printrio-tech/print-ui. Use via `window.PrintUI.Toaster` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `Toaster.html`): Variants.

## Props

```ts
interface ToasterProps {
  children: React.ReactNode;
}
```

## Examples

```jsx
// Variants
export const Variants: Story = {
  render: () => <ToastTriggers />,
};
```

### Variants

```jsx
/* Variants */ compose(S, "Variants")
```
