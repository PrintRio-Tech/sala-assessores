import * as React from 'react';

/**
 * Tooltip — from @printrio-tech/print-ui@0.5.10 (./src/components/Tooltip/Tooltip.stories.tsx).
 */
export interface TooltipProps {
  content: React.ReactNode;
  children: ReactElement<Record<string, unknown>, string | JSXElementConstructor<any>>;
  /** Posicionamento do tooltip em relação ao trigger (alias semântico: placement). */
  side?: "top" | "bottom" | "left" | "right";
  /** Alias de `side` para compatibilidade com APIs que usam `placement`. */
  placement?: "top" | "bottom" | "left" | "right";
  sideOffset?: number;
  delay?: number;
  closeDelay?: number;
  disabled?: boolean;
}

export declare const Tooltip: React.ComponentType<TooltipProps>;
