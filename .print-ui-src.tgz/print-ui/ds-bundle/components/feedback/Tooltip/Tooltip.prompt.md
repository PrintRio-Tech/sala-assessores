Tooltip from @printrio-tech/print-ui. Use via `window.PrintUI.Tooltip` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `Tooltip.html`): Top, Bottom, Left, Right.

## Props

```ts
interface TooltipProps {
  content: React.ReactNode;
  children: ReactElement<Record<string, unknown>, string | JSXElementConstructor<any>>;
  /** Posicionamento do tooltip em relação ao trigger (alias semântico: placement). */
  side?: "top" | "bottom" | "left" | "right";
  /** Alias de `side` para compatibilidade com APIs que usam `placement`. */
  placement?: "top" | "bottom" | "left" | "right";
  sideOffset?: number;
  delay?: number;
  closeDelay?: number;
  disabled?: boolean;
}
```

## Examples

```jsx
// Top
export const Top: Story = {
  args: { side: 'top' },
};

// Bottom
export const Bottom: Story = {
  args: { side: 'bottom' },
};

// Left
export const Left: Story = {
  args: { side: 'left' },
};
```

### Top

```jsx
/* Top */ compose(S, "Top")
```

### Bottom

```jsx
/* Bottom */ compose(S, "Bottom")
```

### Left

```jsx
/* Left */ compose(S, "Left")
```

### Right

```jsx
/* Right */ compose(S, "Right")
```
