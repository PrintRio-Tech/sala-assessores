import * as React from 'react';

/**
 * Checkbox — from @printrio-tech/print-ui@0.5.10 (./src/components/Checkbox/Checkbox.stories.tsx).
 * @replaces input[type=checkbox]
 */
export interface CheckboxProps {
  checked?: boolean;
  defaultChecked?: boolean;
  onCheckedChange?: (checked: boolean) => void;
  disabled?: boolean;
  label?: React.ReactNode;
  indeterminate?: boolean;
  id?: string;
  name?: string;
  className?: string;
}

export declare const Checkbox: React.ComponentType<CheckboxProps>;
