// Re-export of @printrio-tech/print-ui@0.5.10 Checkbox. Implementation is in the root _ds_bundle.js (window.PrintUI).
Object.assign(window, { Checkbox: window.PrintUI.Checkbox });
