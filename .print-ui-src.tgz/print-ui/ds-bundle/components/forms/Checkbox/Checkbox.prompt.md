Checkbox from @printrio-tech/print-ui. Use via `window.PrintUI.Checkbox` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `Checkbox.html`): Default, Checked, Disabled, Disabled Checked, Indeterminate, Without Label, Controlled.

## Props

```ts
interface CheckboxProps {
  checked?: boolean;
  defaultChecked?: boolean;
  onCheckedChange?: (checked: boolean) => void;
  disabled?: boolean;
  label?: React.ReactNode;
  indeterminate?: boolean;
  id?: string;
  name?: string;
  className?: string;
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// Checked
export const Checked: Story = {
  args: { defaultChecked: true },
};

// Disabled
export const Disabled: Story = {
  args: { disabled: true },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Checked

```jsx
/* Checked */ compose(S, "Checked")
```

### Disabled

```jsx
/* Disabled */ compose(S, "Disabled")
```

### DisabledChecked

```jsx
/* Disabled Checked */ compose(S, "DisabledChecked")
```

### Indeterminate

```jsx
/* Indeterminate */ compose(S, "Indeterminate")
```

### WithoutLabel

```jsx
/* Without Label */ compose(S, "WithoutLabel")
```

### Controlled

```jsx
/* Controlled */ compose(S, "Controlled")
```

## Related

`CheckboxGroup`
