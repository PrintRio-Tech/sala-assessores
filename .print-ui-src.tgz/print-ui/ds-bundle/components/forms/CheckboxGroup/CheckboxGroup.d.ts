import * as React from 'react';

/**
 * CheckboxGroup — from @printrio-tech/print-ui@0.5.10 (./src/components/Checkbox/CheckboxGroup.stories.tsx).
 */
export interface CheckboxGroupProps {
  legend: string;
  name: string;
  options: CheckboxGroupOption[];
  value?: string[];
  defaultValue?: string[];
  onValueChange?: (value: string[]) => void;
  disabled?: boolean;
  className?: string;
}

export declare const CheckboxGroup: React.ComponentType<CheckboxGroupProps>;
