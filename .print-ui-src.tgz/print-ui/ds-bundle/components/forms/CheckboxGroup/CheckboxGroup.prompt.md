CheckboxGroup from @printrio-tech/print-ui. Use via `window.PrintUI.CheckboxGroup` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `CheckboxGroup.html`): Default, Disabled, Controlled.

## Props

```ts
interface CheckboxGroupProps {
  legend: string;
  name: string;
  options: CheckboxGroupOption[];
  value?: string[];
  defaultValue?: string[];
  onValueChange?: (value: string[]) => void;
  disabled?: boolean;
  className?: string;
}
```

## Examples

```jsx
// Default
export const Default: Story = {
  args: { defaultValue: ['print'] },
};

// Disabled
export const Disabled: Story = {
  args: { disabled: true, defaultValue: ['print', 'social'] },
};

// Controlled
export const Controlled: Story = {
  render: function ControlledGroup(args) {
    const [value, setValue] = useState<string[]>(['social']);
    return (
      <CheckboxGroup {...args} value={value} onValueChange={setValue} />
    );
  },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Disabled

```jsx
/* Disabled */ compose(S, "Disabled")
```

### Controlled

```jsx
/* Controlled */ compose(S, "Controlled")
```
