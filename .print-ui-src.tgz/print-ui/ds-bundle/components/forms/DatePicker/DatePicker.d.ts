import * as React from 'react';

/**
 * DatePicker — from @printrio-tech/print-ui@0.5.10 (./src/components/DatePicker/DatePicker.stories.tsx).
 */
export interface DatePickerProps {
  label: string;
  labelHidden?: boolean;
  labelSize?: "sm" | "md";
  required?: boolean;
  description?: string;
  error?: string;
  name: string;
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  disabled?: boolean;
  min?: string;
  max?: string;
  size?: "sm" | "md";
  hideHint?: boolean;
  placeholder?: string;
}

export declare const DatePicker: React.ComponentType<DatePickerProps>;
