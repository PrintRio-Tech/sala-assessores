DatePicker from @printrio-tech/print-ui. Use via `window.PrintUI.DatePicker` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `DatePicker.html`): Default, With Default Value, Required, With Description, Error, Small, Disabled, With Min Max, Label Hidden, Controlled.

## Props

```ts
interface DatePickerProps {
  label: string;
  labelHidden?: boolean;
  labelSize?: "sm" | "md";
  required?: boolean;
  description?: string;
  error?: string;
  name: string;
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  disabled?: boolean;
  min?: string;
  max?: string;
  size?: "sm" | "md";
  hideHint?: boolean;
  placeholder?: string;
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// With Default Value
export const WithDefaultValue: Story = {
  args: { defaultValue: '2026-07-26' },
};

// Required
export const Required: Story = {
  args: { required: true },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### WithDefaultValue

```jsx
/* With Default Value */ compose(S, "WithDefaultValue")
```

### Required

```jsx
/* Required */ compose(S, "Required")
```

### WithDescription

```jsx
/* With Description */ compose(S, "WithDescription")
```

### Error

```jsx
/* Error */ compose(S, "Error")
```

### Small

```jsx
/* Small */ compose(S, "Small")
```

### Disabled

```jsx
/* Disabled */ compose(S, "Disabled")
```

### WithMinMax

```jsx
/* With Min Max */ compose(S, "WithMinMax")
```

### LabelHidden

```jsx
/* Label Hidden */ compose(S, "LabelHidden")
```

### Controlled

```jsx
/* Controlled */ compose(S, "Controlled")
```
