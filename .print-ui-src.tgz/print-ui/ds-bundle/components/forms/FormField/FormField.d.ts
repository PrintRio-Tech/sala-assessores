import * as React from 'react';

/**
 * FormField — from @printrio-tech/print-ui@0.5.10 (./src/components/FormField/FormField.stories.tsx).
 */
export interface FormFieldProps {
  label: string;
  labelHidden?: boolean;
  labelSize?: "sm" | "md";
  required?: boolean;
  description?: string;
  error?: string;
  children: React.ReactNode;
  htmlFor?: string;
  name?: string;
  disabled?: boolean;
  invalid?: boolean;
}

export declare const FormField: React.ComponentType<FormFieldProps>;
