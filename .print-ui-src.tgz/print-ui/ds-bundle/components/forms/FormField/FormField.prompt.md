FormField from @printrio-tech/print-ui. Use via `window.PrintUI.FormField` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `FormField.html`): Default, Required, With Description, Error, Small Label, Label Hidden, Disabled, With Text Input.

## Props

```ts
interface FormFieldProps {
  label: string;
  labelHidden?: boolean;
  labelSize?: "sm" | "md";
  required?: boolean;
  description?: string;
  error?: string;
  children: React.ReactNode;
  htmlFor?: string;
  name?: string;
  disabled?: boolean;
  invalid?: boolean;
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// Required
export const Required: Story = {
  args: { required: true },
};

// With Description
export const WithDescription: Story = {
  args: {
    description: 'Usamos este e-mail para enviar o recibo.',
  },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Required

```jsx
/* Required */ compose(S, "Required")
```

### WithDescription

```jsx
/* With Description */ compose(S, "WithDescription")
```

### Error

```jsx
/* Error */ compose(S, "Error")
```

### SmallLabel

```jsx
/* Small Label */ compose(S, "SmallLabel")
```

### LabelHidden

```jsx
/* Label Hidden */ compose(S, "LabelHidden")
```

### Disabled

```jsx
/* Disabled */ compose(S, "Disabled")
```

### WithTextInput

```jsx
/* With Text Input */ compose(S, "WithTextInput")
```
