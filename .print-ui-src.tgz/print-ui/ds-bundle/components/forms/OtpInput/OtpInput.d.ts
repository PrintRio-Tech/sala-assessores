import * as React from 'react';

/**
 * OtpInput — from @printrio-tech/print-ui@0.5.10 (./src/components/OtpInput/OtpInput.stories.tsx).
 */
export interface OtpInputProps {
  label: string;
  required?: boolean;
  name: string;
  value: string;
  onChange: (value: string) => void;
  onComplete?: (value: string) => void;
  length?: number;
  error?: string;
  disabled?: boolean;
  autoFocus?: boolean;
}

export declare const OtpInput: React.ComponentType<OtpInputProps>;
