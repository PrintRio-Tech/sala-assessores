OtpInput from @printrio-tech/print-ui. Use via `window.PrintUI.OtpInput` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `OtpInput.html`): Default, Required, Filled, Four Digits, Error, Disabled, Auto Focus.

## Props

```ts
interface OtpInputProps {
  label: string;
  required?: boolean;
  name: string;
  value: string;
  onChange: (value: string) => void;
  onComplete?: (value: string) => void;
  length?: number;
  error?: string;
  disabled?: boolean;
  autoFocus?: boolean;
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// Required
export const Required: Story = {
  args: { required: true },
};

// Filled
export const Filled: Story = {
  args: { value: '482910' },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Required

```jsx
/* Required */ compose(S, "Required")
```

### Filled

```jsx
/* Filled */ compose(S, "Filled")
```

### FourDigits

```jsx
/* Four Digits */ compose(S, "FourDigits")
```

### Error

```jsx
/* Error */ compose(S, "Error")
```

### Disabled

```jsx
/* Disabled */ compose(S, "Disabled")
```

### AutoFocus

```jsx
/* Auto Focus */ compose(S, "AutoFocus")
```
