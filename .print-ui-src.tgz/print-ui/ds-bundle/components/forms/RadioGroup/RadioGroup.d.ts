import * as React from 'react';

/**
 * RadioGroup — from @printrio-tech/print-ui@0.5.10 (./src/components/RadioGroup/RadioGroup.stories.tsx).
 */
export interface RadioGroupProps {
  legend: string;
  name?: string;
  options: RadioGroupOption[];
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  disabled?: boolean;
  orientation?: "horizontal" | "vertical";
  className?: string;
}

export declare const RadioGroup: React.ComponentType<RadioGroupProps>;
