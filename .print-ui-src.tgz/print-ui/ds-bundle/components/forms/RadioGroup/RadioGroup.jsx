// Re-export of @printrio-tech/print-ui@0.5.10 RadioGroup. Implementation is in the root _ds_bundle.js (window.PrintUI).
Object.assign(window, { RadioGroup: window.PrintUI.RadioGroup });
