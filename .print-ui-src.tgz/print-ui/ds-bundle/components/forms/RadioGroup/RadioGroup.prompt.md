RadioGroup from @printrio-tech/print-ui. Use via `window.PrintUI.RadioGroup` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `RadioGroup.html`): Default, Horizontal, Disabled, Controlled.

## Props

```ts
interface RadioGroupProps {
  legend: string;
  name?: string;
  options: RadioGroupOption[];
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  disabled?: boolean;
  orientation?: "horizontal" | "vertical";
  className?: string;
}
```

## Examples

```jsx
// Default
export const Default: Story = {
  args: { defaultValue: 'email' },
};

// Horizontal
export const Horizontal: Story = {
  args: { orientation: 'horizontal', defaultValue: 'sms' },
};

// Disabled
export const Disabled: Story = {
  args: { disabled: true, defaultValue: 'email' },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Horizontal

```jsx
/* Horizontal */ compose(S, "Horizontal")
```

### Disabled

```jsx
/* Disabled */ compose(S, "Disabled")
```

### Controlled

```jsx
/* Controlled */ compose(S, "Controlled")
```
