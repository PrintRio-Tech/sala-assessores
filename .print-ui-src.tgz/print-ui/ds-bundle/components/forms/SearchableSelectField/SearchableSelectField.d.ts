import * as React from 'react';

/**
 * SearchableSelectField — from @printrio-tech/print-ui@0.5.10 (./src/components/SearchableSelectField/SearchableSelectField.stories.tsx).
 */
export interface SearchableSelectFieldProps {
  label: string;
  labelHidden?: boolean;
  labelSize?: "sm" | "md";
  required?: boolean;
  description?: string;
  error?: string;
  name: string;
  options: SearchableSelectOption[];
  value: string;
  onValueChange: (value: string) => void;
  onQueryChange?: (query: string) => void;
  loading?: boolean;
  placeholder?: string;
  emptyMessage?: string;
  disabled?: boolean;
  selectedLabel?: string;
  footerSlot?: React.ReactNode;
  emptyValue?: string;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}

export declare const SearchableSelectField: React.ComponentType<SearchableSelectFieldProps>;
