SearchableSelectField from @printrio-tech/print-ui. Use via `window.PrintUI.SearchableSelectField` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `SearchableSelectField.html`): Default, With Selected Value, Required, With Description, Error, Loading, Disabled, Filtered.

## Props

```ts
interface SearchableSelectFieldProps {
  label: string;
  labelHidden?: boolean;
  labelSize?: "sm" | "md";
  required?: boolean;
  description?: string;
  error?: string;
  name: string;
  options: SearchableSelectOption[];
  value: string;
  onValueChange: (value: string) => void;
  onQueryChange?: (query: string) => void;
  loading?: boolean;
  placeholder?: string;
  emptyMessage?: string;
  disabled?: boolean;
  selectedLabel?: string;
  footerSlot?: React.ReactNode;
  emptyValue?: string;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// With Selected Value
export const WithSelectedValue: Story = {
  args: { value: 'curitiba' },
};

// Required
export const Required: Story = {
  args: { required: true },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### WithSelectedValue

```jsx
/* With Selected Value */ compose(S, "WithSelectedValue")
```

### Required

```jsx
/* Required */ compose(S, "Required")
```

### WithDescription

```jsx
/* With Description */ compose(S, "WithDescription")
```

### Error

```jsx
/* Error */ compose(S, "Error")
```

### Loading

```jsx
/* Loading */ compose(S, "Loading")
```

### Disabled

```jsx
/* Disabled */ compose(S, "Disabled")
```

### Filtered

```jsx
/* Filtered */ compose(S, "Filtered")
```
