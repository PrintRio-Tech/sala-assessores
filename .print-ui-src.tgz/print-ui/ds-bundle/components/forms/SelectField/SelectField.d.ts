import * as React from 'react';

/**
 * SelectField — from @printrio-tech/print-ui@0.5.10 (./src/components/SelectField/SelectField.stories.tsx).
 */
export interface SelectFieldProps {
  label: string;
  labelHidden?: boolean;
  labelSize?: "sm" | "md";
  required?: boolean;
  description?: string;
  error?: string;
  name: string;
  options: SelectOption[];
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  placeholder?: string;
  disabled?: boolean;
  size?: "sm" | "md";
  /** Render popup inside the DOM tree (for scrollable drawers/modals). */
  contained?: boolean;
}

export declare const SelectField: React.ComponentType<SelectFieldProps>;
