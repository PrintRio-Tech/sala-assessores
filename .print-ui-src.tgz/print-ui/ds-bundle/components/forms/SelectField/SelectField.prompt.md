SelectField from @printrio-tech/print-ui. Use via `window.PrintUI.SelectField` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `SelectField.html`): Default, With Default Value, Required, With Description, Error, Small, Disabled, Controlled.

## Props

```ts
interface SelectFieldProps {
  label: string;
  labelHidden?: boolean;
  labelSize?: "sm" | "md";
  required?: boolean;
  description?: string;
  error?: string;
  name: string;
  options: SelectOption[];
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  placeholder?: string;
  disabled?: boolean;
  size?: "sm" | "md";
  /** Render popup inside the DOM tree (for scrollable drawers/modals). */
  contained?: boolean;
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// With Default Value
export const WithDefaultValue: Story = {
  args: { defaultValue: 'sp' },
};

// Required
export const Required: Story = {
  args: { required: true },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### WithDefaultValue

```jsx
/* With Default Value */ compose(S, "WithDefaultValue")
```

### Required

```jsx
/* Required */ compose(S, "Required")
```

### WithDescription

```jsx
/* With Description */ compose(S, "WithDescription")
```

### Error

```jsx
/* Error */ compose(S, "Error")
```

### Small

```jsx
/* Small */ compose(S, "Small")
```

### Disabled

```jsx
/* Disabled */ compose(S, "Disabled")
```

### Controlled

```jsx
/* Controlled */ compose(S, "Controlled")
```
