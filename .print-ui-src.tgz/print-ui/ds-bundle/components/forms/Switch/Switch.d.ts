import * as React from 'react';

/**
 * Switch — from @printrio-tech/print-ui@0.5.10 (./src/components/Switch/Switch.stories.tsx).
 */
export interface SwitchProps {
  checked?: boolean;
  defaultChecked?: boolean;
  onCheckedChange?: (checked: boolean) => void;
  disabled?: boolean;
  required?: boolean;
  label?: React.ReactNode;
  id?: string;
  name?: string;
  className?: string;
}

export declare const Switch: React.ComponentType<SwitchProps>;
