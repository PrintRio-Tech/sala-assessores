Switch from @printrio-tech/print-ui. Use via `window.PrintUI.Switch` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `Switch.html`): Default, Checked, Disabled, Disabled Checked, Required, Without Label, Controlled.

## Props

```ts
interface SwitchProps {
  checked?: boolean;
  defaultChecked?: boolean;
  onCheckedChange?: (checked: boolean) => void;
  disabled?: boolean;
  required?: boolean;
  label?: React.ReactNode;
  id?: string;
  name?: string;
  className?: string;
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// Checked
export const Checked: Story = {
  args: { defaultChecked: true },
};

// Disabled
export const Disabled: Story = {
  args: { disabled: true },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Checked

```jsx
/* Checked */ compose(S, "Checked")
```

### Disabled

```jsx
/* Disabled */ compose(S, "Disabled")
```

### DisabledChecked

```jsx
/* Disabled Checked */ compose(S, "DisabledChecked")
```

### Required

```jsx
/* Required */ compose(S, "Required")
```

### WithoutLabel

```jsx
/* Without Label */ compose(S, "WithoutLabel")
```

### Controlled

```jsx
/* Controlled */ compose(S, "Controlled")
```
