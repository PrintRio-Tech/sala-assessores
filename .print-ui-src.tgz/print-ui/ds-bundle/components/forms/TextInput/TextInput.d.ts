import * as React from 'react';

/**
 * TextInput — from @printrio-tech/print-ui@0.5.10 (./src/components/TextInput/TextInput.stories.tsx).
 * @replaces input
 */
export interface TextInputProps {
  label: string;
  labelHidden?: boolean;
  labelSize?: "sm" | "md";
  required?: boolean;
  description?: string;
  error?: string;
  name: string;
  size?: "sm" | "md";
  style?: CSSProperties;
  className?: string;
  id?: string;
  children?: React.ReactNode;
}

export declare const TextInput: React.ComponentType<TextInputProps>;
