// Re-export of @printrio-tech/print-ui@0.5.10 TextInput. Implementation is in the root _ds_bundle.js (window.PrintUI).
Object.assign(window, { TextInput: window.PrintUI.TextInput });
