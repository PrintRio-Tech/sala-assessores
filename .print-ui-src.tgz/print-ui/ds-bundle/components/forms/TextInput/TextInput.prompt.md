TextInput from @printrio-tech/print-ui. Use via `window.PrintUI.TextInput` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `TextInput.html`): Default, Required, With Description, Error, Small, Disabled, Password, Label Hidden.

## Props

```ts
interface TextInputProps {
  label: string;
  labelHidden?: boolean;
  labelSize?: "sm" | "md";
  required?: boolean;
  description?: string;
  error?: string;
  name: string;
  size?: "sm" | "md";
  style?: CSSProperties;
  className?: string;
  id?: string;
  children?: React.ReactNode;
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// Required
export const Required: Story = {
  args: { required: true },
};

// With Description
export const WithDescription: Story = {
  args: {
    description: 'Como aparece no comprovante.',
  },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Required

```jsx
/* Required */ compose(S, "Required")
```

### WithDescription

```jsx
/* With Description */ compose(S, "WithDescription")
```

### Error

```jsx
/* Error */ compose(S, "Error")
```

### Small

```jsx
/* Small */ compose(S, "Small")
```

### Disabled

```jsx
/* Disabled */ compose(S, "Disabled")
```

### Password

```jsx
/* Password */ compose(S, "Password")
```

### LabelHidden

```jsx
/* Label Hidden */ compose(S, "LabelHidden")
```
