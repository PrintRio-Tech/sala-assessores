import * as React from 'react';

/**
 * Textarea — from @printrio-tech/print-ui@0.5.10 (./src/components/Textarea/Textarea.stories.tsx).
 * @replaces textarea
 */
export interface TextareaProps {
  label: string;
  required?: boolean;
  description?: string;
  error?: string;
  name?: string;
  style?: CSSProperties;
  /** Allows getting a ref to the component instance. Once the component unmounts, React will set `ref.current` to `null` (or  */
  ref?: React.Ref;
  className?: string;
  id?: string;
  children?: React.ReactNode;
}

export declare const Textarea: React.ComponentType<TextareaProps>;
