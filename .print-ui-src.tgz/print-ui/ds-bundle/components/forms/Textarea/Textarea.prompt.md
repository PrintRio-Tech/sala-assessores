Textarea from @printrio-tech/print-ui. Use via `window.PrintUI.Textarea` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `Textarea.html`): Default, Required, With Description, Error, Disabled.

## Props

```ts
interface TextareaProps {
  label: string;
  required?: boolean;
  description?: string;
  error?: string;
  name?: string;
  style?: CSSProperties;
  /** Allows getting a ref to the component instance. Once the component unmounts, React will set `ref.current` to `null` (or  */
  ref?: React.Ref;
  className?: string;
  id?: string;
  children?: React.ReactNode;
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// Required
export const Required: Story = {
  args: { required: true },
};

// With Description
export const WithDescription: Story = {
  args: {
    description: 'Aparece no relatório e no e-mail de confirmação.',
  },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Required

```jsx
/* Required */ compose(S, "Required")
```

### WithDescription

```jsx
/* With Description */ compose(S, "WithDescription")
```

### Error

```jsx
/* Error */ compose(S, "Error")
```

### Disabled

```jsx
/* Disabled */ compose(S, "Disabled")
```
