import * as React from 'react';

/**
 * TimeInput — from @printrio-tech/print-ui@0.5.10 (./src/components/TimeInput/TimeInput.stories.tsx).
 */
export interface TimeInputProps {
  label: string;
  labelSize?: "sm" | "md";
  required?: boolean;
  name?: string;
  value?: string;
  onValueChange?: (value: string) => void;
  disabled?: boolean;
  error?: string;
  size?: "sm" | "md";
  placeholder?: string;
}

export declare const TimeInput: React.ComponentType<TimeInputProps>;
