TimeInput from @printrio-tech/print-ui. Use via `window.PrintUI.TimeInput` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `TimeInput.html`): Default, Small, Error, Disabled.

## Props

```ts
interface TimeInputProps {
  label: string;
  labelSize?: "sm" | "md";
  required?: boolean;
  name?: string;
  value?: string;
  onValueChange?: (value: string) => void;
  disabled?: boolean;
  error?: string;
  size?: "sm" | "md";
  placeholder?: string;
}
```

## Examples

```jsx
// Default
export const Default: Story = {
  render: (args) => <Controlled {...args} />,
};

// Small
export const Small: Story = {
  args: { size: 'sm', labelSize: 'sm' },
  render: (args) => <Controlled {...args} />,
};

// Error
export const Error: Story = {
  args: { error: 'Horário inválido.', value: '25:00' },
  render: (args) => <Controlled {...args} />,
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Small

```jsx
/* Small */ compose(S, "Small")
```

### Error

```jsx
/* Error */ compose(S, "Error")
```

### Disabled

```jsx
/* Disabled */ compose(S, "Disabled")
```
