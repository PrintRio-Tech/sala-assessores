import * as React from 'react';

/**
 * ActionTile — from @printrio-tech/print-ui@0.5.10 (./src/components/ActionTile/ActionTile.stories.tsx).
 */
export interface ActionTileProps {
  title: string;
  eyebrow: string;
  icon: React.ReactNode;
  variant?: "primary" | "outline" | "muted";
  href?: string;
  onClick?: MouseEventHandler<HTMLAnchorElement | HTMLButtonElement>;
  disabled?: boolean;
  className?: string;
  "aria-label"?: string;
}

export declare const ActionTile: React.ComponentType<ActionTileProps>;
