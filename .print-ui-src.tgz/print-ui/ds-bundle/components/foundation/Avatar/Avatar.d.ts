import * as React from 'react';

/**
 * Avatar — from @printrio-tech/print-ui@0.5.10 (./src/components/Avatar/Avatar.stories.tsx).
 */
export interface AvatarProps {
  style?: CSSProperties;
  className?: string;
  id?: string;
  /** Nome completo — gera iniciais quando `initials` / `src` ausentes. */
  name?: string;
  /** Iniciais explícitas (sobrescreve as geradas a partir de `name`). */
  initials?: string;
  src?: string;
  alt?: string;
  size?: "sm" | "md" | "lg";
  children?: React.ReactNode;
}

export declare const Avatar: React.ComponentType<AvatarProps>;
