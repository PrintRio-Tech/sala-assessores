Avatar from @printrio-tech/print-ui. Use via `window.PrintUI.Avatar` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `Avatar.html`): Default, Small, Medium, Large, With Initials, With Image, Sizes.

## Props

```ts
interface AvatarProps {
  style?: CSSProperties;
  className?: string;
  id?: string;
  /** Nome completo — gera iniciais quando `initials` / `src` ausentes. */
  name?: string;
  /** Iniciais explícitas (sobrescreve as geradas a partir de `name`). */
  initials?: string;
  src?: string;
  alt?: string;
  size?: "sm" | "md" | "lg";
  children?: React.ReactNode;
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// Small
export const Small: Story = {
  args: { size: 'sm', name: 'Ana Silva' },
};

// Medium
export const Medium: Story = {
  args: { size: 'md', name: 'Ana Silva' },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Small

```jsx
/* Small */ compose(S, "Small")
```

### Medium

```jsx
/* Medium */ compose(S, "Medium")
```

### Large

```jsx
/* Large */ compose(S, "Large")
```

### WithInitials

```jsx
/* With Initials */ compose(S, "WithInitials")
```

### WithImage

```jsx
/* With Image */ compose(S, "WithImage")
```

### Sizes

```jsx
/* Sizes */ compose(S, "Sizes")
```
