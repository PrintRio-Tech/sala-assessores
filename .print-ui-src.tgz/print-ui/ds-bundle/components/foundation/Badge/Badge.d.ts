import * as React from 'react';

/**
 * Badge — from @printrio-tech/print-ui@0.5.10 (./src/components/Badge/Badge.stories.tsx).
 */
export interface BadgeProps {
  children: React.ReactNode;
  tone?: "primary" | "outline" | "neutral" | "success" | "warning" | "danger" | "accent" | "soft" | "secondary";
  size?: "sm" | "md";
  className?: string;
}

export declare const Badge: React.ComponentType<BadgeProps>;
