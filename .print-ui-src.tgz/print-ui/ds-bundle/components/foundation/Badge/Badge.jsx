// Re-export of @printrio-tech/print-ui@0.5.10 Badge. Implementation is in the root _ds_bundle.js (window.PrintUI).
Object.assign(window, { Badge: window.PrintUI.Badge });
