Badge from @printrio-tech/print-ui. Use via `window.PrintUI.Badge` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `Badge.html`): Default, Neutral, Soft, Secondary, Outline, Success, Warning, Danger, Accent, Primary, Small, Forms → UI map, All Tones, Sizes.

## Props

```ts
interface BadgeProps {
  children: React.ReactNode;
  tone?: "primary" | "outline" | "neutral" | "success" | "warning" | "danger" | "accent" | "soft" | "secondary";
  size?: "sm" | "md";
  className?: string;
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// Neutral
export const Neutral: Story = {
  args: { tone: 'neutral', children: 'Neutro' },
};

// Soft
export const Soft: Story = {
  args: { tone: 'soft', children: 'Soft (forms primary)' },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Neutral

```jsx
/* Neutral */ compose(S, "Neutral")
```

### Soft

```jsx
/* Soft */ compose(S, "Soft")
```

### Secondary

```jsx
/* Secondary */ compose(S, "Secondary")
```

### Outline

```jsx
/* Outline */ compose(S, "Outline")
```

### Success

```jsx
/* Success */ compose(S, "Success")
```

### Warning

```jsx
/* Warning */ compose(S, "Warning")
```

### Danger

```jsx
/* Danger */ compose(S, "Danger")
```

### Accent

```jsx
/* Accent */ compose(S, "Accent")
```

### Primary

```jsx
/* Primary */ compose(S, "Primary")
```

### Small

```jsx
/* Small */ compose(S, "Small")
```

### FormsMigrationMap

```jsx
/* Forms → UI map */ compose(S, "FormsMigrationMap")
```

### AllTones

```jsx
/* All Tones */ compose(S, "AllTones")
```

### Sizes

```jsx
/* Sizes */ compose(S, "Sizes")
```
