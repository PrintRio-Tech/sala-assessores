import * as React from 'react';

/**
 * Button — from @printrio-tech/print-ui@0.5.10 (./src/components/Button/Button.stories.tsx).
 * @replaces button
 */
export interface ButtonProps {
  nativeButton?: boolean;
  /** Whether the button should ignore user interaction. */
  disabled?: boolean;
  /** Whether the button should be focusable when disabled. */
  focusableWhenDisabled?: boolean;
  style?: CSSProperties | (CSSProperties & ((state: ButtonState) => React.CSSProperties | undefined));
  /** CSS class applied to the element, or a function that returns a class based on the component’s state. */
  className?: string | ((state: ButtonState) => string | undefined);
  id?: string;
  children?: React.ReactNode;
  /** Allows you to replace the component’s HTML element with a different tag, or compose it with another component. Accepts a */
  render?: ReactElement<Record<string, unknown>, string | JSXElementConstructor<any>> | ComponentRenderFn<HTMLProps<any>, ButtonState>;
  /** Allows getting a ref to the component instance. Once the component unmounts, React will set `ref.current` to `null` (or  */
  ref?: React.Ref;
  variant?: "primary" | "outline" | "danger" | "secondary" | "ghost";
  size?: "sm" | "md" | "lg";
  iconOnly?: boolean;
}

export declare const Button: React.ComponentType<ButtonProps>;
