// Re-export of @printrio-tech/print-ui@0.5.10 Button. Implementation is in the root _ds_bundle.js (window.PrintUI).
Object.assign(window, { Button: window.PrintUI.Button });
