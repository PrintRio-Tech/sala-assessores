Button from @printrio-tech/print-ui. Use via `window.PrintUI.Button` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `Button.html`): Default, Secondary, Outline, Ghost, Danger, Small, Large, Disabled, Icon Only.

## Props

```ts
interface ButtonProps {
  nativeButton?: boolean;
  /** Whether the button should ignore user interaction. */
  disabled?: boolean;
  /** Whether the button should be focusable when disabled. */
  focusableWhenDisabled?: boolean;
  style?: CSSProperties | (CSSProperties & ((state: ButtonState) => React.CSSProperties | undefined));
  /** CSS class applied to the element, or a function that returns a class based on the component’s state. */
  className?: string | ((state: ButtonState) => string | undefined);
  id?: string;
  children?: React.ReactNode;
  /** Allows you to replace the component’s HTML element with a different tag, or compose it with another component. Accepts a */
  render?: ReactElement<Record<string, unknown>, string | JSXElementConstructor<any>> | ComponentRenderFn<HTMLProps<any>, ButtonState>;
  /** Allows getting a ref to the component instance. Once the component unmounts, React will set `ref.current` to `null` (or  */
  ref?: React.Ref;
  variant?: "primary" | "outline" | "danger" | "secondary" | "ghost";
  size?: "sm" | "md" | "lg";
  iconOnly?: boolean;
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// Secondary
export const Secondary: Story = {
  args: { variant: 'secondary' },
};

// Outline
export const Outline: Story = {
  args: { variant: 'outline' },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Secondary

```jsx
/* Secondary */ compose(S, "Secondary")
```

### Outline

```jsx
/* Outline */ compose(S, "Outline")
```

### Ghost

```jsx
/* Ghost */ compose(S, "Ghost")
```

### Danger

```jsx
/* Danger */ compose(S, "Danger")
```

### Small

```jsx
/* Small */ compose(S, "Small")
```

### Large

```jsx
/* Large */ compose(S, "Large")
```

### Disabled

```jsx
/* Disabled */ compose(S, "Disabled")
```

### IconOnly

```jsx
/* Icon Only */ compose(S, "IconOnly")
```
