import * as React from 'react';

/**
 * Card — from @printrio-tech/print-ui@0.5.10 (./src/components/Card/Card.stories.tsx).
 */
export interface CardProps {
  variant?: "primary" | "accent" | "soft" | "surface" | "elevated" | "inset";
  padding?: "sm" | "md" | "lg" | "none";
  interactive?: boolean;
  className?: string;
  children?: React.ReactNode;
  style?: CSSProperties;
  id?: string;
}

export declare const Card: React.ComponentType<CardProps>;
