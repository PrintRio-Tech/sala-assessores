Card from @printrio-tech/print-ui. Use via `window.PrintUI.Card` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `Card.html`): Default, Surface, Elevated, Soft, Inset, Primary, Accent, Padding None, Padding Sm, Padding Lg, Interactive, All Variants.

## Props

```ts
interface CardProps {
  variant?: "primary" | "accent" | "soft" | "surface" | "elevated" | "inset";
  padding?: "sm" | "md" | "lg" | "none";
  interactive?: boolean;
  className?: string;
  children?: React.ReactNode;
  style?: CSSProperties;
  id?: string;
}
```

## Examples

```jsx
// Default
export const Default: Story = {
  args: {
    children: <SampleContent title="Surface" />,
  },
};

// Surface
export const Surface: Story = {
  args: {
    variant: 'surface',
    children: <SampleContent title="Surface" />,
  },
};

// Elevated
export const Elevated: Story = {
  args: {
    variant: 'elevated',
    children: <SampleContent title="Elevated" />,
  },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Surface

```jsx
/* Surface */ compose(S, "Surface")
```

### Elevated

```jsx
/* Elevated */ compose(S, "Elevated")
```

### Soft

```jsx
/* Soft */ compose(S, "Soft")
```

### Inset

```jsx
/* Inset */ compose(S, "Inset")
```

### Primary

```jsx
/* Primary */ compose(S, "Primary")
```

### Accent

```jsx
/* Accent */ compose(S, "Accent")
```

### PaddingNone

```jsx
/* Padding None */ compose(S, "PaddingNone")
```

### PaddingSm

```jsx
/* Padding Sm */ compose(S, "PaddingSm")
```

### PaddingLg

```jsx
/* Padding Lg */ compose(S, "PaddingLg")
```

### Interactive

```jsx
/* Interactive */ compose(S, "Interactive")
```

### AllVariants

```jsx
/* All Variants */ compose(S, "AllVariants")
```

## Related

`CardSkeleton`
