import * as React from 'react';

/**
 * EmptyState — from @printrio-tech/print-ui@0.5.10 (./src/components/EmptyState/EmptyState.stories.tsx).
 */
export interface EmptyStateProps {
  variant: "empty" | "filtered" | "error";
  title: string;
  description: string;
  action?: EmptyStateAction;
  mark?: React.ReactNode;
  className?: string;
}

export declare const EmptyState: React.ComponentType<EmptyStateProps>;
