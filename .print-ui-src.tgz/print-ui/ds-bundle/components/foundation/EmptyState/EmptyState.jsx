// Re-export of @printrio-tech/print-ui@0.5.10 EmptyState. Implementation is in the root _ds_bundle.js (window.PrintUI).
Object.assign(window, { EmptyState: window.PrintUI.EmptyState });
