EmptyState from @printrio-tech/print-ui. Use via `window.PrintUI.EmptyState` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `EmptyState.html`): Default, Empty, Filtered, Error, Without Action.

## Props

```ts
interface EmptyStateProps {
  variant: "empty" | "filtered" | "error";
  title: string;
  description: string;
  action?: EmptyStateAction;
  mark?: React.ReactNode;
  className?: string;
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// Empty
export const Empty: Story = {
  args: {
    variant: 'empty',
    title: 'Nenhum clipping',
    description: 'Adicione um clipping para começar a acompanhar a cobertura.',
    action: {
      label: 'Novo clipping',
      onClick: fn(),
    },
  },
};

// Filtered
export const Filtered: Story = {
  args: {
    variant: 'filtered',
    title: 'Nenhum resultado',
    description: 'Ajuste os filtros ou limpe a busca para ver mais itens.',
    action: {
      label: 'Limpar filtros',
      onClick: fn(),
    },
  },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Empty

```jsx
/* Empty */ compose(S, "Empty")
```

### Filtered

```jsx
/* Filtered */ compose(S, "Filtered")
```

### Error

```jsx
/* Error */ compose(S, "Error")
```

### WithoutAction

```jsx
/* Without Action */ compose(S, "WithoutAction")
```
