import * as React from 'react';

/**
 * Heading — from @printrio-tech/print-ui@0.5.10 (./src/components/Heading/Heading.stories.tsx).
 */
export interface HeadingProps<T extends ElementType = 'h1'> {
  level?: 1 | 2 | 3 | 4 | 5 | 6;
  variant?: "md" | "lg" | "xl";
  as?: T;
}

export declare const Heading: React.ComponentType<HeadingProps>;
