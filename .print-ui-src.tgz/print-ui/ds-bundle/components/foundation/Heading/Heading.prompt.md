Heading from @printrio-tech/print-ui. Use via `window.PrintUI.Heading` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `Heading.html`): Default, Levels, Variants.

## Props

```ts
interface HeadingProps {
  level?: 1 | 2 | 3 | 4 | 5 | 6;
  variant?: "md" | "lg" | "xl";
  as?: T;
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// Levels
export const Levels: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <Heading level={1}>Heading level 1</Heading>
      <Heading level={2}>Heading level 2</Heading>
      <Heading level={3}>Heading level 3</Heading>
      <Heading level={4}>Heading level 4</Heading>
      <Heading level={5}>Heading level 5</Heading>
      <Heading level={6}>Heading level 6</Heading>
    </div>
  ),
};

// Variants
export const Variants: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <Heading variant="xl">Variant xl</Heading>
      <Heading variant="lg">Variant lg</Heading>
      <Heading variant="md">Variant md</Heading>
    </div>
  ),
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Levels

```jsx
/* Levels */ compose(S, "Levels")
```

### Variants

```jsx
/* Variants */ compose(S, "Variants")
```
