import * as React from 'react';

/**
 * Icon — from @printrio-tech/print-ui@0.5.10 (./src/components/Icon/Icon.stories.tsx).
 */
export interface IconProps {
  src: string;
  className?: string;
  size?: number;
  width?: number;
  height?: number;
  label?: string;
}

export declare const Icon: React.ComponentType<IconProps>;
