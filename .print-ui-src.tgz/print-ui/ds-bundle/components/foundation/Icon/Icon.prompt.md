Icon from @printrio-tech/print-ui. Use via `window.PrintUI.Icon` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

# Contrato de ícones — D-ICON-04=A

**Decisão:** apps consumidoras servem os SVGs em `public/icons/` espelhando o catálogo do pacote.

Referência: `docs/product/sdd/plataforma-adm-ds-consolidation.md` (D-ICON-04).

## Como funciona

1. `@print/ui` exporta `ICONS` (paths `/icons/...`) e o componente `Icon` (CSS mask).
2. O pacote inclui os arquivos fonte em `dist/icons/` (publicados no npm, D-NPM-01=B).
3. Cada app copia (ou sincroniza) esses SVGs para o próprio `public/icons/` para que o servidor estático sirva em runtime.

`Icon` usa `mask-image: url("/icons/...")` — o browser resolve contra a raiz do app, **não** contra `node_modules`.

## Catálogo mínimo (28 SVGs)

| Grupo | Qtd | Chaves `ICONS` |
|-------|-----|----------------|
| `nav` | 6 | `home`, `journalists`, `reports`, `activities`, `clippings`, `releases` |
| `home` | 5 | `article`, `chart`, `release`, `addCircle`, `arrowForward` |
| `ui` | 8 | `chevronLeft`, `chevronRight`, `chevronDown`, `check`, `menu`, `search`, `filter`, `download` |
| `toast` | 5 | `success`, `error`, `warning`, `info`, `default` |
| `table` | 3 | `view`, `edit`, `delete` |
| `datePicker` | 1 | `calendar` |

Ícones extras no catálogo completo (`nav.playground`, `home.location`, `datePicker.clock`) permanecem opcionais.

## Setup no app consumidor

```bash
# A partir da raiz do app (ex.: print-adm)
cp -R node_modules/@print/ui/dist/icons public/icons
```

Ou use o script do pacote:

```bash
bash node_modules/@print/ui/dist/scripts/sync-icons.sh
# ou via export:
bash node_modules/@print/ui/scripts/sync-icons.sh /caminho/do/app
```

## Uso

```tsx
import { Icon, ICONS } from '@print/ui';

<Icon src={ICONS.nav.home} size={20} label="Início" />
```

## O que **não** fazer

- **Não** embutir SVGs como data URLs no `ICONS` — quebra `mask-image` em alguns browsers.
- **Não** manter `icons.ts` local duplicado — importe `ICONS` de `@print/ui`.
- **Não** alterar paths do catálogo sem bump de versão (breaking change).

## Props

```ts
interface IconProps {
  src: string;
  className?: string;
  size?: number;
  width?: number;
  height?: number;
  label?: string;
}
```
