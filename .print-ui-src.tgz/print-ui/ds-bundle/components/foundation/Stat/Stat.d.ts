import * as React from 'react';

/**
 * Stat — from @printrio-tech/print-ui@0.5.10 (./src/components/Stat/Stat.stories.tsx).
 */
export interface StatProps {
  style?: CSSProperties;
  className?: string;
  id?: string;
  children?: React.ReactNode;
  value: string;
  label: string;
  emphasis?: "primary" | "default";
  loading?: boolean;
}

export declare const Stat: React.ComponentType<StatProps>;
