Stat from @printrio-tech/print-ui. Use via `window.PrintUI.Stat` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `Stat.html`): Default, Primary emphasis, Loading, Group.

## Props

```ts
interface StatProps {
  style?: CSSProperties;
  className?: string;
  id?: string;
  children?: React.ReactNode;
  value: string;
  label: string;
  emphasis?: "primary" | "default";
  loading?: boolean;
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// Primary emphasis
export const Primary: Story = {
  name: 'Primary emphasis',
  args: {
    emphasis: 'primary',
    value: '98%',
    label: 'Taxa de entrega',
  },
};

// Loading
export const Loading: Story = {
  args: {
    loading: true,
    label: 'Clippings',
  },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Primary

```jsx
/* Primary emphasis */ compose(S, "Primary")
```

### Loading

```jsx
/* Loading */ compose(S, "Loading")
```

### Group

```jsx
/* Group */ compose(S, "Group")
```
