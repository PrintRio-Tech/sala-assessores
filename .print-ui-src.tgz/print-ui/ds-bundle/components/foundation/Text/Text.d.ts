import * as React from 'react';

/**
 * Text — from @printrio-tech/print-ui@0.5.10 (./src/components/Text/Text.stories.tsx).
 */
export interface TextProps<T extends ElementType = 'p'> {
  as?: T;
  variant?: "bodyLg" | "bodyMd" | "labelMd" | "labelSm";
  tone?: "primary" | "muted" | "error" | "default";
  wrap?: "normal" | "balance" | "pretty";
  tabular?: boolean;
}

export declare const Text: React.ComponentType<TextProps>;
