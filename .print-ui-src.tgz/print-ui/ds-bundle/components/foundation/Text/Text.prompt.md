Text from @printrio-tech/print-ui. Use via `window.PrintUI.Text` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `Text.html`): Default, Variants, Tones, Tabular, Wrap Balance.

## Props

```ts
interface TextProps {
  as?: T;
  variant?: "bodyLg" | "bodyMd" | "labelMd" | "labelSm";
  tone?: "primary" | "muted" | "error" | "default";
  wrap?: "normal" | "balance" | "pretty";
  tabular?: boolean;
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// Variants
export const Variants: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <Text variant="bodyLg">bodyLg — parágrafo destacado</Text>
      <Text variant="bodyMd">bodyMd — parágrafo padrão</Text>
      <Text variant="labelMd">labelMd — rótulo médio</Text>
      <Text variant="labelSm">labelSm — rótulo pequeno</Text>
    </div>
  ),
};

// Tones
export const Tones: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <Text tone="default">tone default</Text>
      <Text tone="muted">tone muted</Text>
      <Text tone="error">tone error</Text>
      <Text tone="primary">tone primary</Text>
    </div>
  ),
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Variants

```jsx
/* Variants */ compose(S, "Variants")
```

### Tones

```jsx
/* Tones */ compose(S, "Tones")
```

### Tabular

```jsx
/* Tabular */ compose(S, "Tabular")
```

### WrapBalance

```jsx
/* Wrap Balance */ compose(S, "WrapBalance")
```

## Related

`TextInput`
