import * as React from 'react';

/**
 * Accordion — from @printrio-tech/print-ui@0.5.10 (./src/components/Accordion/Accordion.stories.tsx).
 */
export interface AccordionProps {
  id?: string;
  title: string;
  description?: string;
  expanded: boolean;
  onExpandedChange: (expanded: boolean) => void;
  actions?: React.ReactNode;
  children: React.ReactNode;
}

export declare const Accordion: React.ComponentType<AccordionProps>;
