Accordion from @printrio-tech/print-ui. Use via `window.PrintUI.Accordion` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `Accordion.html`): Default, Expanded, With Actions.

## Props

```ts
interface AccordionProps {
  id?: string;
  title: string;
  description?: string;
  expanded: boolean;
  onExpandedChange: (expanded: boolean) => void;
  actions?: React.ReactNode;
  children: React.ReactNode;
}
```

## Examples

```jsx
// Default
export const Default: Story = {
  args: {
    title: 'Seção',
    expanded: false,
    onExpandedChange: () => undefined,
    children: 'Conteúdo',
  },
  render: () => <ControlledDemo />,
};

// Expanded
export const Expanded: Story = {
  args: {
    title: 'Seção',
    expanded: true,
    onExpandedChange: () => undefined,
    children: 'Conteúdo',
  },
  render: () => <ControlledDemo initialExpanded />,
};

// With Actions
export const WithActions: Story = {
  args: {
    title: 'Seção',
    expanded: false,
    onExpandedChange: () => undefined,
    children: 'Conteúdo',
  },
  render: () => <ControlledDemo withActions />,
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Expanded

```jsx
/* Expanded */ compose(S, "Expanded")
```

### WithActions

```jsx
/* With Actions */ compose(S, "WithActions")
```
