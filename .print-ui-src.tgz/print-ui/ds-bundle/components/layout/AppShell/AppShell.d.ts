import * as React from 'react';

/**
 * AppShell — from @printrio-tech/print-ui@0.5.10 (./src/components/AppShell/AppShell.stories.tsx).
 */
export interface AppShellProps {
  logo?: React.ReactNode;
  logoCollapsed?: React.ReactNode;
  /** Logo no header mobile (fundo claro). Default: `logo`. */
  mobileLogo?: React.ReactNode;
  navItems: AppNavItem[];
  /** Conteúdo extra no rodapé da sidebar (ex.: usuário / logout). */
  footerSlot?: React.ReactNode;
  userSlot?: React.ReactNode;
  children?: React.ReactNode;
  collapsed?: boolean;
  onCollapsedChange?: (collapsed: boolean) => void;
  mobileOpen?: boolean;
  onMobileOpenChange?: (open: boolean) => void;
  /** Main content width. `fluid` matches print-forms DashboardLayout (default). `contained` keeps max-width + centered column */
  contentWidth?: "fluid" | "contained";
  className?: string;
}

export declare const AppShell: React.ComponentType<AppShellProps>;
