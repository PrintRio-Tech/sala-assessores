// Re-export of @printrio-tech/print-ui@0.5.10 AppShell. Implementation is in the root _ds_bundle.js (window.PrintUI).
Object.assign(window, { AppShell: window.PrintUI.AppShell });
