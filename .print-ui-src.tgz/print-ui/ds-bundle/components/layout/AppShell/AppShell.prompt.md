AppShell from @printrio-tech/print-ui. Use via `window.PrintUI.AppShell` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `AppShell.html`): Default, Contained.

## Props

```ts
interface AppShellProps {
  logo?: React.ReactNode;
  logoCollapsed?: React.ReactNode;
  /** Logo no header mobile (fundo claro). Default: `logo`. */
  mobileLogo?: React.ReactNode;
  navItems: AppNavItem[];
  /** Conteúdo extra no rodapé da sidebar (ex.: usuário / logout). */
  footerSlot?: React.ReactNode;
  userSlot?: React.ReactNode;
  children?: React.ReactNode;
  collapsed?: boolean;
  onCollapsedChange?: (collapsed: boolean) => void;
  mobileOpen?: boolean;
  onMobileOpenChange?: (open: boolean) => void;
  /** Main content width. `fluid` matches print-forms DashboardLayout (default). `contained` keeps max-width + centered column */
  contentWidth?: "fluid" | "contained";
  className?: string;
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// Contained
export const Contained: Story = {
  args: {
    contentWidth: 'contained',
    children: (
      <div>
        <h1 style={{ margin: '0 0 8px', fontSize: 20 }}>Contained</h1>
        <p style={{ margin: 0 }}>
          Coluna centrada com max-width (legado / Storybook).
        </p>
      </div>
    ),
  },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Contained

```jsx
/* Contained */ compose(S, "Contained")
```
