import * as React from 'react';

/**
 * Tabs — from @printrio-tech/print-ui@0.5.10 (./src/components/Tabs/Tabs.stories.tsx).
 */
export interface TabsProps {
  style?: CSSProperties | (CSSProperties & ((state: TabsRootState) => React.CSSProperties | undefined));
  /** The default value. Use when the component is not controlled. When the value is `null`, no Tab will be active. */
  defaultValue?: any;
  /** CSS class applied to the element, or a function that returns a class based on the component’s state. */
  className?: string | (((state: TabsRootState) => string | undefined) & string);
  id?: string;
  children?: React.ReactNode;
  /** The value of the currently active `Tab`. Use when the component is controlled. When the value is `null`, no Tab will be  */
  value?: any;
  /** Allows you to replace the component’s HTML element with a different tag, or compose it with another component. Accepts a */
  render?: ReactElement<Record<string, unknown>, string | JSXElementConstructor<any>> | ComponentRenderFn<HTMLProps<any>, TabsRootState>;
  /** The component orientation (layout flow direction). */
  orientation?: "horizontal" | "vertical";
  /** `underline` (default) com indicator; `segmented` espelha ReportsSectionTabs. */
  variant?: "underline" | "segmented";
}

export declare const Tabs: React.ComponentType<TabsProps>;
