Tabs from @printrio-tech/print-ui. Use via `window.PrintUI.Tabs` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `Tabs.html`): Default, Underline, Segmented.

## Props

```ts
interface TabsProps {
  style?: CSSProperties | (CSSProperties & ((state: TabsRootState) => React.CSSProperties | undefined));
  /** The default value. Use when the component is not controlled. When the value is `null`, no Tab will be active. */
  defaultValue?: any;
  /** CSS class applied to the element, or a function that returns a class based on the component’s state. */
  className?: string | (((state: TabsRootState) => string | undefined) & string);
  id?: string;
  children?: React.ReactNode;
  /** The value of the currently active `Tab`. Use when the component is controlled. When the value is `null`, no Tab will be  */
  value?: any;
  /** Allows you to replace the component’s HTML element with a different tag, or compose it with another component. Accepts a */
  render?: ReactElement<Record<string, unknown>, string | JSXElementConstructor<any>> | ComponentRenderFn<HTMLProps<any>, TabsRootState>;
  /** The component orientation (layout flow direction). */
  orientation?: "horizontal" | "vertical";
  /** `underline` (default) com indicator; `segmented` espelha ReportsSectionTabs. */
  variant?: "underline" | "segmented";
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// Underline
export const Underline: Story = {
  args: { variant: 'underline' },
};

// Segmented
export const Segmented: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'Controle segmentado (padrão ReportsSectionTabs): tablist padded, surface-container-low, tab ativa surface-bright + shadow-ambient, sem indicator.',
      },
    },
  },
  args: { variant: 'segmented' },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Underline

```jsx
/* Underline */ compose(S, "Underline")
```

### Segmented

```jsx
/* Segmented */ compose(S, "Segmented")
```
