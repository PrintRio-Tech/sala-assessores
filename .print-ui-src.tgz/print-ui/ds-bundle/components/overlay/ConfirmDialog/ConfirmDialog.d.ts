import * as React from 'react';

/**
 * ConfirmDialog — from @printrio-tech/print-ui@0.5.10 (./src/components/ConfirmDialog/ConfirmDialog.stories.tsx).
 */
export interface ConfirmDialogProps {
  /** Elemento gatilho (modo não controlado). Omita quando usar `open` / `onOpenChange`. */
  children?: ReactElement<Record<string, unknown>, string | JSXElementConstructor<any>>;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  title: string;
  description?: string;
  body?: React.ReactNode;
  confirmLabel?: string;
  cancelLabel?: string;
  loadingLabel?: string;
  destructive?: boolean;
  /** Bloqueia fechamento e desabilita ações enquanto a confirmação está em andamento. */
  loading?: boolean;
  onConfirm?: () => void | Promise<void>;
}

export declare const ConfirmDialog: React.ComponentType<ConfirmDialogProps>;
