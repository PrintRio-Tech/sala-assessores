// Re-export of @printrio-tech/print-ui@0.5.10 ConfirmDialog. Implementation is in the root _ds_bundle.js (window.PrintUI).
Object.assign(window, { ConfirmDialog: window.PrintUI.ConfirmDialog });
