ConfirmDialog from @printrio-tech/print-ui. Use via `window.PrintUI.ConfirmDialog` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `ConfirmDialog.html`): Default, Trigger (como Modal forms), Destructive, With Body, Loading.

## Props

```ts
interface ConfirmDialogProps {
  /** Elemento gatilho (modo não controlado). Omita quando usar `open` / `onOpenChange`. */
  children?: ReactElement<Record<string, unknown>, string | JSXElementConstructor<any>>;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  title: string;
  description?: string;
  body?: React.ReactNode;
  confirmLabel?: string;
  cancelLabel?: string;
  loadingLabel?: string;
  destructive?: boolean;
  /** Bloqueia fechamento e desabilita ações enquanto a confirmação está em andamento. */
  loading?: boolean;
  onConfirm?: () => void | Promise<void>;
}
```

## Examples

```jsx
// Default
export const Default: Story = {
  render: function Render(args) {
    const [open, setOpen] = useState(false);

    return (
      <>
        <Button type="button" onClick={() => setOpen(true)}>
          Abrir diálogo
        </Button>
        <ConfirmDialog
          {...args}
          open={open}
          onOpenChange={setOpen}
          onConfirm={() => setOpen(false)}
        />
      </>
    );
  },
};

// Trigger (como Modal forms)
export const WithTrigger: Story = {
  name: 'Trigger (como Modal forms)',
  render: function Render(args) {
    return (
      <ConfirmDialog
        {...args}
        title="Publicar release?"
        description="O conteúdo ficará visível para a equipe."
        onConfirm={() => undefined}
      >
        <Button type="button">Abrir via trigger</Button>
      </ConfirmDialog>
    );
  },
};

// Destructive
export const Destructive: Story = {
  args: {
    title: 'Excluir item?',
    description: 'Esta ação não pode ser desfeita.',
    confirmLabel: 'Excluir',
    destructive: true,
  },
  render: function Render(args) {
    const [open, setOpen] = useState(false);

    return (
      <>
        <Button type="button" variant="danger" onClick={() => setOpen(true)}>
          Excluir
        </Button>
        <ConfirmDialog
          {...args}
          open={open}
          onOpenChange={setOpen}
          onConfirm={() => setOpen(false)}
        />
      </>
    );
  },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### WithTrigger

```jsx
/* Trigger (como Modal forms) */ compose(S, "WithTrigger")
```

### Destructive

```jsx
/* Destructive */ compose(S, "Destructive")
```

### WithBody

```jsx
/* With Body */ compose(S, "WithBody")
```

### Loading

```jsx
/* Loading */ compose(S, "Loading")
```
