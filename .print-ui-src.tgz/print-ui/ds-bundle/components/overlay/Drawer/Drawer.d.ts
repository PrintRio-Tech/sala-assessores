import * as React from 'react';

/**
 * Drawer — from @printrio-tech/print-ui@0.5.10 (./src/components/Drawer/Drawer.stories.tsx).
 */
export interface DrawerProps {
  children: ReactElement<Record<string, unknown>, string | JSXElementConstructor<any>>;
  title: string;
  description?: string;
  body?: React.ReactNode;
  confirmLabel?: string;
  cancelLabel?: string;
  onConfirm?: () => void;
  size?: "md" | "lg" | "xl";
}

export declare const Drawer: React.ComponentType<DrawerProps>;
