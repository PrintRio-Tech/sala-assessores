// Re-export of @printrio-tech/print-ui@0.5.10 Drawer. Implementation is in the root _ds_bundle.js (window.PrintUI).
Object.assign(window, { Drawer: window.PrintUI.Drawer });
