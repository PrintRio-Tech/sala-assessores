Drawer from @printrio-tech/print-ui. Use via `window.PrintUI.Drawer` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `Drawer.html`): Default, Large, DrawerShell.

## Props

```ts
interface DrawerProps {
  children: ReactElement<Record<string, unknown>, string | JSXElementConstructor<any>>;
  title: string;
  description?: string;
  body?: React.ReactNode;
  confirmLabel?: string;
  cancelLabel?: string;
  onConfirm?: () => void;
  size?: "md" | "lg" | "xl";
}
```

## Examples

```jsx
// Default
export const Default: Story = {
  render: (args) => <Drawer {...args} />,
};

// Large
export const Large: Story = {
  args: {
    size: 'lg',
    title: 'Drawer grande',
    children: <Button type="button">Abrir drawer lg</Button>,
  },
  render: (args) => <Drawer {...args} />,
};

// DrawerShell
export const Shell: Story = {
  name: 'DrawerShell',
  parameters: {
    docs: {
      description: {
        story:
          'Shell controlado com footer customizado — base usada por fluxos como DrawerSteps.',
      },
    },
  },
  render: function Render() {
    const [open, setOpen] = useState(false);

    return (
      <>
        <Button type="button" onClick={() => setOpen(true)}>
          Abrir DrawerShell
        </Button>
        <DrawerShell
          open={open}
          onOpenChange={setOpen}
          title="Editar perfil"
          description="Atualize os dados do usuário."
          size="lg"
          footer={
            <>
              <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
                Cancelar
              </Button>
              <Button type="button" variant="primary" onClick={() => setOpen(false)}>
                Salvar
              </Button>
            </>
          }
        >
          <label style={{ display: 'grid', gap: 4 }}>
            Nome
            <input defaultValue="Maria Silva" />
          </label>
        </DrawerShell>
// …
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Large

```jsx
/* Large */ compose(S, "Large")
```

### Shell

```jsx
/* DrawerShell */ compose(S, "Shell")
```

## Related

`DrawerSteps`
