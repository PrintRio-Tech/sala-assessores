import * as React from 'react';

/**
 * DrawerSteps — from @printrio-tech/print-ui@0.5.10 (./src/components/Drawer/DrawerSteps.stories.tsx).
 */
export interface DrawerStepsProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  flowTitle: string;
  steps: DrawerStep[];
  currentStepIndex: number;
  onStepChange: (index: number) => void;
  /** Conclusão que fecha o drawer (ex.: "Salvar e fechar"). Sempre presente; no modo dual vira ação secundária (outline). */
  onComplete: () => void | Promise<void>;
  completeLabel: string;
  /** Conclusão que mantém o drawer aberto (multi-create). Quando definido com `completeStayOpenLabel`, a última etapa mostra  */
  onCompleteStayOpen?: () => void | Promise<void>;
  completeStayOpenLabel?: string;
  isCompleting?: boolean;
  onRequestClose: () => void;
  size?: "md" | "lg" | "xl";
  backLabel?: string;
  advanceLabel?: string;
  closeLabel?: string;
}

export declare const DrawerSteps: React.ComponentType<DrawerStepsProps>;
