// Re-export of @printrio-tech/print-ui@0.5.10 DrawerSteps. Implementation is in the root _ds_bundle.js (window.PrintUI).
Object.assign(window, { DrawerSteps: window.PrintUI.DrawerSteps });
