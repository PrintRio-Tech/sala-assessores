DrawerSteps from @printrio-tech/print-ui. Use via `window.PrintUI.DrawerSteps` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

# DrawerSteps

Painel lateral multi-etapas que encapsula `DrawerShell` com progresso, gate de validação e
navegação voltar/avançar. A persistência dos dados de cada etapa fica no consumidor (state acima
do componente, ex.: `react-hook-form`).

## Uso básico

```tsx
import { useMemo, useState } from 'react';
import { DrawerSteps, type DrawerStep } from '@print/ui';

function ProvisionAccessDrawer() {
  const [open, setOpen] = useState(false);
  const [stepIndex, setStepIndex] = useState(0);
  const [personId, setPersonId] = useState<string | null>(null);
  const [email, setEmail] = useState('');

  const steps = useMemo<DrawerStep[]>(
    () => [
      {
        id: 'person',
        label: 'Buscar pessoa',
        isValid: personId !== null,
        content: (
          <PersonSearchStep value={personId} onChange={setPersonId} />
        ),
      },
      {
        id: 'access',
        label: 'Atribuir acesso',
        isValid: email.includes('@'),
        content: (
          <AccessFormStep email={email} onEmailChange={setEmail} />
        ),
      },
    ],
    [personId, email],
  );

  return (
    <DrawerSteps
      open={open}
      onOpenChange={setOpen}
      flowTitle="Conceder acesso"
      steps={steps}
      currentStepIndex={stepIndex}
      onStepChange={setStepIndex}
      completeLabel="Conceder acesso"
      onComplete={async () => {
        await grantAccess({ personId, email });
      }}
      onRequestClose={() => setOpen(false)}
    />
  );
}
```

## Fechar com dados não salvos + ConfirmDialog (T-3.1)

`DrawerSteps` **não** acopla `ConfirmDialog` internamente. Em qualquer tentativa de fechar (Esc,
backdrop, botão ×), chama `onRequestClose` e mantém `open` até o consumidor decidir.

```tsx
import { useState } from 'react';
import { ConfirmDialog, DrawerSteps } from '@print/ui';

function ProvisionAccessDrawer() {
  const [open, setOpen] = useState(false);
  const [confirmDiscardOpen, setConfirmDiscardOpen] = useState(false);
  const hasUnsavedChanges = /* derivado do formulário */;

  const handleRequestClose = () => {
    if (hasUnsavedChanges) {
      setConfirmDiscardOpen(true);
      return;
    }

    setOpen(false);
  };

  return (
    <>
      <DrawerSteps
        open={open}
        onOpenChange={setOpen}
        flowTitle="Conceder acesso"
        steps={steps}
        currentStepIndex={stepIndex}
        onStepChange={setStepIndex}
        completeLabel="Conceder acesso"
        onComplete={handleGrantAccess}
        onRequestClose={handleRequestClose}
      />

      <ConfirmDialog
        open={confirmDiscardOpen}
        onOpenChange={setConfirmDiscardOpen}
        title="Descartar progresso?"
        description="As informações preenchidas neste fluxo serão perdidas."
        confirmLabel="Descartar"
        cancelLabel="Continuar editando"
        onConfirm={() => {
          setConfirmDiscardOpen(false);
          setOpen(false);
        }}
      />
    </>
  );
}
```

## Comportamento

| Situação | Resultado |
| -------- | --------- |
| Etapa inválida | Botão Avançar/Concluir desabilitado (`aria-describedby` com dica) |
| Primeira etapa | Sem botão Voltar |
| Última etapa | `completeLabel` substitui Avançar; fecha após `onComplete` bem-sucedido |
| Multi-create | Ver footer dual abaixo |
| `isCompleting` | Loading na conclusão; navegação bloqueada |
| Troca de etapa | Foco move para o título composto (`${flowTitle} — ${label}`) |
| Mobile | Indicador compacto "Etapa N de M" |
| Desktop | Lista de rótulos das etapas no header |

## Footer dual (multi-create)

Quando `onCompleteStayOpen` **e** `completeStayOpenLabel` estão definidos, a última etapa
mostra duas ações de conclusão:

| Botão | Props | Comportamento |
| ----- | ----- | ------------- |
| Primary | `completeStayOpenLabel` + `onCompleteStayOpen` | Salva e **não** fecha (ex.: "Salvar e adicionar outro") |
| Outline | `completeLabel` + `onComplete` | Salva e **fecha** (ex.: "Salvar e fechar") |

```tsx
<DrawerSteps
  open={open}
  onOpenChange={setOpen}
  flowTitle="Novo escritório"
  steps={steps}
  currentStepIndex={step}
  onStepChange={setStep}
  completeLabel="Salvar e fechar"
  onComplete={async () => {
    await createOffice();
  }}
  completeStayOpenLabel="Salvar e adicionar outro"
  onCompleteStayOpen={async () => {
    await createOffice();
    resetForm(); // consumidor reseta campos / volta à etapa 0
  }}
  onRequestClose={handleRequestClose}
/>
```

Sem o par stay-open, o comportamento continua single-button (`completeLabel` → fecha).

## API

| Prop | Tipo | Notas |
| ---- | ---- | ----- |
| `onComplete` | `() => void \| Promise<void>` | Fecha o drawer após sucesso |
| `completeLabel` | `string` | Label da ação que fecha |
| `onCompleteStayOpen?` | `() => void \| Promise<void>` | Opcional; não fecha |
| `completeStayOpenLabel?` | `string` | Obrigatório junto com `onCompleteStayOpen` |

Tipos: `DrawerStep`, `DrawerStepsProps` em `@print/ui`.
