import * as React from 'react';

/**
 * TableSkeleton — from @printrio-tech/print-ui@0.5.10 (./src/components/Table/TableSkeleton.stories.tsx).
 */
export interface TableSkeletonProps {
  rows?: number;
  columns?: number;
  className?: string;
  style?: CSSProperties;
  id?: string;
}

export declare const TableSkeleton: React.ComponentType<TableSkeletonProps>;
