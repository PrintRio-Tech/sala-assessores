TableSkeleton from @printrio-tech/print-ui. Use via `window.PrintUI.TableSkeleton` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TooltipProvider>` (full provider chain in README.md — components read theme/i18n from that context).

Variants (see `TableSkeleton.html`): Default, Compact, Wide.

## Props

```ts
interface TableSkeletonProps {
  rows?: number;
  columns?: number;
  className?: string;
  style?: CSSProperties;
  id?: string;
}
```

## Examples

```jsx
// Default
export const Default: Story = {};

// Compact
export const Compact: Story = {
  args: { rows: 3, columns: 3 },
};

// Wide
export const Wide: Story = {
  args: { rows: 6, columns: 6 },
};
```

### Default

```jsx
/* Default */ compose(S, "Default")
```

### Compact

```jsx
/* Compact */ compose(S, "Compact")
```

### Wide

```jsx
/* Wide */ compose(S, "Wide")
```
