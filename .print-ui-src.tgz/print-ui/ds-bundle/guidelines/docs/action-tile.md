# ActionTile

Tile de CTA grande (home / painéis de ações rápidas). Portado do `QuickActionTile` do print-forms.

## Uso

```tsx
import { ActionTile, Icon, ICONS } from '@print/ui';

<ActionTile
  variant="primary"
  eyebrow="Criar"
  title="Novo clipping"
  icon={<Icon src={ICONS.home.addCircle} size={28} />}
  href="/clippings/new"
/>
```

## Props

| Prop | Tipo | Default |
|------|------|---------|
| `title` | `string` | — |
| `eyebrow` | `string` | — |
| `icon` | `ReactNode` | — |
| `variant` | `'primary' \| 'outline' \| 'muted'` | `'outline'` |
| `href` | `string?` | — → renderiza `<a>` |
| `onClick` | `MouseEventHandler?` | — → `<button>` se sem `href` |
| `disabled` | `boolean` | `false` |
| `className` | `string?` | — |
| `aria-label` | `string?` | `` `${eyebrow}: ${title}` `` |

`primary` inclui decor e seta no hover/focus. Sem dependência de react-router — use `href` ou wrappe com o `Link` do app.
