# Publishing — @printrio-tech/print-ui

## Contratos

| Item | Valor |
|------|--------|
| Repo | `https://github.com/PrintRio-Tech/print-ui` |
| Remote local | `origin` → `https://github.com/PrintRio-Tech/print-ui.git` |
| Package (registry) | `@printrio-tech/print-ui` |
| Alias consumidor | `@print/ui` → `npm:@printrio-tech/print-ui@^x` |
| Registry | `https://npm.pkg.github.com` |
| Scope `.npmrc` | `@printrio-tech:registry=https://npm.pkg.github.com` |

O login da org no GitHub é `PrintRio-Tech`; o **npm scope é lowercase**: `@printrio-tech`.

## Ordem CI: publish → verify

**Escolha:** um único workflow [`.github/workflows/publish.yml`](../.github/workflows/publish.yml) com dois jobs:

1. `publish` — build + `bun publish`
2. `verify` — `needs: publish`, instala via alias `@print/ui` com retries (poll até o registry resolver)

Não dispare Verify em paralelo no mesmo `push` de tag. Isso causa race: o install tenta a versão antes dela existir.

O workflow `verify-registry-install.yml` ficou só para `workflow_dispatch` (smoke manual).

## Checklist pré-tag

1. `git remote -v` aponta para `PrintRio-Tech/print-ui` (não conta pessoal).
2. `package.json` → `"name": "@printrio-tech/print-ui"` e `repository.url` da org.
3. Version em `package.json` alinhada à tag (CI também sincroniza pela tag).
4. Workflows e `.npmrc.example` usam `@printrio-tech`, não scope antigo.
5. Fixture consumidor (`scripts/fixtures/print-adm-package.json`) com alias correto.
6. Commit na `master` já no remote da org.
7. `git tag vX.Y.Z && git push origin vX.Y.Z`
8. Observar o run até **publish e verify** = `success` (`gh run watch`).

## Consumidor (print-adm)

```json
"@print/ui": "npm:@printrio-tech/print-ui@^0.5.10"
```

```ini
@printrio-tech:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NPM_TOKEN}
always-auth=true
```

Token do consumidor precisa de `read:packages` na org PrintRio-Tech.

## Erros históricos (não repetir)

| Sintoma | Causa | Correção |
|---------|--------|----------|
| `No version matching …@X.Y.Z` no Verify | Verify rodava em paralelo ao Publish no mesmo push de tag | `needs: publish` + retries |
| Publish no package pessoal `@noeloliveira1982/…` | Repo/package ainda no user; remote e `package.json` name antigos | Org `PrintRio-Tech`, name `@printrio-tech/print-ui`, remote correto |
| Install local/CI 401/404 no registry | `.npmrc` com scope errado ou token sem acesso à org | Scope `@printrio-tech` + `read:packages` na org |

## Comandos úteis

```bash
git remote -v
gh repo view --json nameWithOwner,url
gh run list --workflow=publish.yml --limit 5
gh run watch
```
