#!/usr/bin/env bash
# Copia SCSS, ícones e scripts auxiliares para dist/ (D-NPM-01=B — publish dist-only).
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

cp -R src/tokens dist/tokens
# Testes não fazem parte do pacote publicado.
find dist/tokens -type f \( -name '*.test.ts' -o -name '*.test.tsx' \) -delete
cp -R src/mixins dist/mixins
find dist/mixins -type f \( -name '*.test.ts' -o -name '*.test.tsx' \) -delete
cp -R src/fonts dist/fonts
cp src/theme/*.scss dist/theme/

mkdir -p dist/scripts dist/docs
cp scripts/sync-icons.sh dist/scripts/sync-icons.sh
chmod +x dist/scripts/sync-icons.sh
cp docs/icons.md dist/docs/icons.md
