#!/usr/bin/env bash
# D-ICON-04=A — copia public/icons do pacote para o app consumidor.
set -euo pipefail

APP_ROOT="${1:-.}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ "$SCRIPT_DIR" == */dist/scripts ]]; then
  SRC="$SCRIPT_DIR/../icons"
else
  PKG_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
  if [[ -d "$PKG_ROOT/dist/icons" ]]; then
    SRC="$PKG_ROOT/dist/icons"
  elif [[ -d "$PKG_ROOT/public/icons" ]]; then
    SRC="$PKG_ROOT/public/icons"
  else
    SRC=""
  fi
fi

DEST="$(cd "$APP_ROOT" && pwd)/public/icons"

if [[ -z "${SRC:-}" || ! -d "$SRC" ]]; then
  echo "sync-icons: catálogo não encontrado (esperado dist/icons ou public/icons)" >&2
  exit 1
fi

mkdir -p "$DEST"
cp -R "$SRC/." "$DEST/"
echo "sync-icons: $DEST atualizado ($(find "$DEST" -name '*.svg' | wc -l | tr -d ' ') SVGs)"
