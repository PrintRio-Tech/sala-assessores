/**
 * Catálogo de ícones SVG do design system.
 *
 * Contrato D-ICON-04=A: apps consumidoras copiam `public/icons/` do pacote
 * para o próprio `public/icons/` (servidos em `/icons/*` em runtime).
 * Ver `docs/icons.md`.
 */
export const ICONS = {
  nav: {
    home: '/icons/nav/home.svg',
    activities: '/icons/nav/activities.svg',
    journalists: '/icons/nav/journalists.svg',
    releases: '/icons/nav/releases.svg',
    clippings: '/icons/nav/clippings.svg',
    reports: '/icons/nav/reports.svg',
    playground: '/icons/nav/playground.svg',
  },
  home: {
    location: '/icons/home/location.svg',
    arrowForward: '/icons/home/arrow-forward.svg',
    addCircle: '/icons/home/add-circle.svg',
    article: '/icons/home/article.svg',
    release: '/icons/home/release.svg',
    chart: '/icons/home/chart.svg',
  },
  ui: {
    menu: '/icons/ui/menu.svg',
    search: '/icons/ui/search.svg',
    download: '/icons/ui/download.svg',
    chevronLeft: '/icons/ui/chevron-left.svg',
    chevronRight: '/icons/ui/chevron-right.svg',
    chevronDown: '/icons/ui/chevron-down.svg',
    filter: '/icons/ui/filter.svg',
    check: '/icons/ui/check.svg',
  },
  toast: {
    success: '/icons/toast/success.svg',
    error: '/icons/toast/error.svg',
    warning: '/icons/toast/warning.svg',
    info: '/icons/toast/info.svg',
    default: '/icons/toast/default.svg',
  },
  table: {
    view: '/icons/table/view.svg',
    edit: '/icons/table/edit.svg',
    delete: '/icons/table/delete.svg',
  },
  datePicker: {
    calendar: '/icons/date-picker/calendar.svg',
    clock: '/icons/date-picker/clock.svg',
  },
} as const;
