import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';

import { Button } from '../Button/Button';
import { Text } from '../Text/Text';
import { Accordion } from './Accordion';

const meta = {
  title: 'Layout/Accordion',
  component: Accordion,
  tags: ['autodocs'],
} satisfies Meta<typeof Accordion>;

export default meta;
type Story = StoryObj<typeof meta>;

function ControlledDemo({
  initialExpanded = false,
  withActions = false,
}: {
  initialExpanded?: boolean;
  withActions?: boolean;
}) {
  const [expanded, setExpanded] = useState(initialExpanded);

  return (
    <Accordion
      title="Adicionar inserção"
      description="Opcional — detalhes da publicação."
      expanded={expanded}
      onExpandedChange={setExpanded}
      actions={
        withActions ? (
          <Button type="button" variant="ghost" size="sm">
            Remover
          </Button>
        ) : undefined
      }
    >
      <Text variant="bodyMd">
        Conteúdo da seção: campos de clipping, veículos e observações.
      </Text>
    </Accordion>
  );
}

export const Default: Story = {
  args: {
    title: 'Seção',
    expanded: false,
    onExpandedChange: () => undefined,
    children: 'Conteúdo',
  },
  render: () => <ControlledDemo />,
};

export const Expanded: Story = {
  args: {
    title: 'Seção',
    expanded: true,
    onExpandedChange: () => undefined,
    children: 'Conteúdo',
  },
  render: () => <ControlledDemo initialExpanded />,
};

export const WithActions: Story = {
  args: {
    title: 'Seção',
    expanded: false,
    onExpandedChange: () => undefined,
    children: 'Conteúdo',
  },
  render: () => <ControlledDemo withActions />,
};
