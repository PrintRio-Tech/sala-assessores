import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';

import { Accordion } from './Accordion';

describe('Accordion', () => {
  it('exibe título e descrição', () => {
    render(
      <Accordion
        title="Adicionar inserção"
        description="Opcional."
        expanded={false}
        onExpandedChange={vi.fn()}
      >
        Conteúdo
      </Accordion>,
    );

    expect(screen.getByText('Adicionar inserção')).toBeInTheDocument();
    expect(screen.getByText('Opcional.')).toBeInTheDocument();
  });

  it('alterna via chevron e notifica onExpandedChange', () => {
    const onExpandedChange = vi.fn();

    render(
      <Accordion
        title="Seção"
        expanded={false}
        onExpandedChange={onExpandedChange}
      >
        Conteúdo
      </Accordion>,
    );

    const trigger = screen.getByRole('button', { name: 'Expandir seção' });
    expect(trigger).toHaveAttribute('aria-expanded', 'false');

    fireEvent.click(trigger);
    expect(onExpandedChange).toHaveBeenCalledWith(true);
  });

  it('marca painel recolhido com aria-hidden e inert (sem hidden)', () => {
    render(
      <Accordion title="Seção" expanded={false} onExpandedChange={vi.fn()}>
        Conteúdo oculto
      </Accordion>,
    );

    const panel = screen.getByText('Conteúdo oculto').closest('[role="region"]');
    expect(panel).toHaveAttribute('aria-hidden', 'true');
    expect(panel).toHaveAttribute('inert');
    expect(panel).not.toHaveAttribute('hidden');
  });

  it('libera painel quando expandido', () => {
    render(
      <Accordion title="Seção" expanded onExpandedChange={vi.fn()}>
        Conteúdo visível
      </Accordion>,
    );

    const panel = screen.getByText('Conteúdo visível').closest('[role="region"]');
    expect(panel).toHaveAttribute('aria-hidden', 'false');
    expect(panel).not.toHaveAttribute('inert');
  });
});
