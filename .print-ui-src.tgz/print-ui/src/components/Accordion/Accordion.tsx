import { useId, type ReactNode } from 'react';

import { ICONS } from '../../assets/icons';
import { Icon } from '../Icon';
import { Text } from '../Text/Text';

import styles from './styles.module.scss';

export type AccordionProps = {
  id?: string;
  title: string;
  description?: string;
  expanded: boolean;
  onExpandedChange: (expanded: boolean) => void;
  actions?: ReactNode;
  children: ReactNode;
};

export function Accordion({
  id,
  title,
  description,
  expanded,
  onExpandedChange,
  actions,
  children,
}: AccordionProps) {
  const generatedId = useId();
  const accordionId = id ?? generatedId;
  const panelId = `${accordionId}-panel`;
  const triggerId = `${accordionId}-trigger`;

  return (
    <section className={styles.root}>
      <div className={styles.header}>
        <button
          id={triggerId}
          type="button"
          className={styles.trigger}
          aria-expanded={expanded}
          aria-controls={panelId}
          onClick={() => onExpandedChange(!expanded)}
        >
          <span className={styles.triggerContent}>
            <Text as="span" variant="labelMd" className={styles.title}>
              {title}
            </Text>
            {description ? (
              <Text as="span" variant="bodyMd" tone="muted">
                {description}
              </Text>
            ) : null}
          </span>
        </button>
        <div className={styles.aside}>
          <button
            type="button"
            className={styles.chevronButton}
            aria-expanded={expanded}
            aria-controls={panelId}
            aria-label={expanded ? 'Recolher seção' : 'Expandir seção'}
            onClick={() => onExpandedChange(!expanded)}
          >
            <Icon
              src={ICONS.ui.chevronDown}
              size={16}
              className={[
                styles.chevron,
                expanded ? styles.chevronExpanded : '',
              ]
                .filter(Boolean)
                .join(' ')}
            />
          </button>
          {actions ? <div className={styles.actions}>{actions}</div> : null}
        </div>
      </div>
      <div
        id={panelId}
        role="region"
        aria-labelledby={triggerId}
        className={[styles.panel, expanded ? styles.panelExpanded : '']
          .filter(Boolean)
          .join(' ')}
        aria-hidden={!expanded}
        // `hidden` aborta a transição grid; inert bloqueia foco quando recolhido
        inert={!expanded ? true : undefined}
      >
        <div className={styles.panelInner}>{children}</div>
      </div>
    </section>
  );
}
