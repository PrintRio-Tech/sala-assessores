import type { Meta, StoryObj } from '@storybook/react-vite';

import { Button } from '../Button/Button';
import { ActionGroup } from './ActionGroup';

const meta = {
  title: 'Components/ActionGroup',
  component: ActionGroup,
  parameters: { layout: 'padded' },
} satisfies Meta<typeof ActionGroup>;

export default meta;
type Story = StoryObj<typeof meta>;

export const ToolbarEnd: Story = {
  render: () => (
    <ActionGroup>
      <Button type="button" variant="outline">
        Suspender
      </Button>
      <Button type="button" variant="primary">
        Editar
      </Button>
    </ActionGroup>
  ),
};
