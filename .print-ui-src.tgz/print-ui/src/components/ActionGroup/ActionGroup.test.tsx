import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { ActionGroup } from './ActionGroup';

describe('ActionGroup', () => {
  it('agrupa ações com role=group e alinhamento end por padrão', () => {
    render(
      <ActionGroup data-testid="actions">
        <button type="button">Editar</button>
      </ActionGroup>,
    );

    const group = screen.getByRole('group');
    expect(group.className).toMatch(/alignEnd/);
    expect(screen.getByRole('button', { name: 'Editar' })).toBeInTheDocument();
  });

  it('suporta align start e between', () => {
    const { rerender } = render(
      <ActionGroup align="start" data-testid="actions">
        <button type="button">A</button>
      </ActionGroup>,
    );
    expect(screen.getByTestId('actions').className).toMatch(/alignStart/);

    rerender(
      <ActionGroup align="between" data-testid="actions">
        <button type="button">A</button>
      </ActionGroup>,
    );
    expect(screen.getByTestId('actions').className).toMatch(/alignBetween/);
  });
});
