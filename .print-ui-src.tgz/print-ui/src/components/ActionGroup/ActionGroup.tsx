import type { ComponentPropsWithoutRef, ReactNode } from 'react';

import styles from './styles.module.scss';

export type ActionGroupAlign = 'start' | 'end' | 'between';

export type ActionGroupProps = ComponentPropsWithoutRef<'div'> & {
  align?: ActionGroupAlign;
  children?: ReactNode;
};

const alignClass: Record<ActionGroupAlign, string> = {
  start: styles.alignStart,
  end: styles.alignEnd,
  between: styles.alignBetween,
};

/** Toolbar externa de ações — layout flex, sem chrome de card. */
export function ActionGroup({
  align = 'end',
  className,
  children,
  ...props
}: ActionGroupProps) {
  const classes = [styles.group, alignClass[align], className]
    .filter(Boolean)
    .join(' ');

  return (
    <div role="group" className={classes} {...props}>
      {children}
    </div>
  );
}
