import type { Meta, StoryObj } from '@storybook/react-vite';

import { ICONS } from '../../assets/icons';
import { Icon } from '../Icon';

import { ActionTile } from './ActionTile';

const meta = {
  title: 'Foundation/ActionTile',
  component: ActionTile,
  tags: ['autodocs'],
  args: {
    title: 'Novo clipping',
    eyebrow: 'Ação rápida',
    icon: <Icon src={ICONS.home.addCircle} size={28} />,
    variant: 'primary',
  },
  argTypes: {
    variant: {
      control: 'select',
      options: ['primary', 'outline', 'muted'],
    },
  },
  decorators: [
    (Story) => (
      <div style={{ maxWidth: 280 }}>
        <Story />
      </div>
    ),
  ],
} satisfies Meta<typeof ActionTile>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Primary: Story = {};

export const Outline: Story = {
  args: {
    variant: 'outline',
    title: 'Ver releases',
    eyebrow: 'Conteúdo',
    icon: <Icon src={ICONS.home.release} size={28} />,
  },
};

export const Muted: Story = {
  args: {
    variant: 'muted',
    title: 'Relatórios',
    eyebrow: 'Análise',
    icon: <Icon src={ICONS.home.chart} size={28} />,
  },
};

export const AsLink: Story = {
  args: {
    href: '#',
    title: 'Abrir artigo',
    eyebrow: 'Leitura',
    icon: <Icon src={ICONS.home.article} size={28} />,
    variant: 'outline',
  },
};

export const Disabled: Story = {
  args: {
    disabled: true,
    variant: 'muted',
  },
};

export const Grid: Story = {
  render: () => (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(2, minmax(0, 1fr))',
        gap: 16,
        maxWidth: 560,
      }}
    >
      <ActionTile
        variant="primary"
        eyebrow="Criar"
        title="Novo clipping"
        icon={<Icon src={ICONS.home.addCircle} size={28} />}
        href="#"
      />
      <ActionTile
        variant="outline"
        eyebrow="Conteúdo"
        title="Ver releases"
        icon={<Icon src={ICONS.home.release} size={28} />}
        href="#"
      />
      <ActionTile
        variant="muted"
        eyebrow="Análise"
        title="Relatórios"
        icon={<Icon src={ICONS.home.chart} size={28} />}
        href="#"
      />
      <ActionTile
        variant="muted"
        eyebrow="Leitura"
        title="Artigos"
        icon={<Icon src={ICONS.home.article} size={28} />}
        href="#"
      />
    </div>
  ),
};
