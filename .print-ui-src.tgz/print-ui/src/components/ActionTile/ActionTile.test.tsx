import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it, vi } from 'vitest';

import { ActionTile } from './ActionTile';

describe('ActionTile', () => {
  it('renderiza eyebrow e título', () => {
    render(
      <ActionTile
        title="Novo clipping"
        eyebrow="Criar"
        icon={<span data-testid="icon" />}
        variant="primary"
      />,
    );

    expect(screen.getByText('Criar')).toBeInTheDocument();
    expect(screen.getByText('Novo clipping')).toBeInTheDocument();
    expect(screen.getByTestId('icon')).toBeInTheDocument();
  });

  it('usa <a> quando href está definido', () => {
    render(
      <ActionTile
        title="Ver releases"
        eyebrow="Conteúdo"
        icon={<span />}
        href="/releases"
        variant="outline"
      />,
    );

    const link = screen.getByRole('link', { name: 'Conteúdo: Ver releases' });
    expect(link).toHaveAttribute('href', '/releases');
  });

  it('usa <button> e dispara onClick sem href', async () => {
    const user = userEvent.setup();
    const onClick = vi.fn();

    render(
      <ActionTile
        title="Relatórios"
        eyebrow="Análise"
        icon={<span />}
        variant="muted"
        onClick={onClick}
      />,
    );

    await user.click(screen.getByRole('button', { name: 'Análise: Relatórios' }));
    expect(onClick).toHaveBeenCalledOnce();
  });

  it('respeita disabled', () => {
    render(
      <ActionTile
        title="Bloqueado"
        eyebrow="Ação"
        icon={<span />}
        disabled
      />,
    );

    expect(screen.getByRole('button', { name: 'Ação: Bloqueado' })).toBeDisabled();
  });
});
