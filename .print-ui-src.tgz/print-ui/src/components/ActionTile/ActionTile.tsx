import type { MouseEventHandler, ReactNode } from 'react';

import { ICONS } from '../../assets/icons';
import { Heading } from '../Heading/Heading';
import { Icon } from '../Icon';
import { Text } from '../Text/Text';

import styles from './styles.module.scss';

export type ActionTileVariant = 'primary' | 'outline' | 'muted';

export type ActionTileProps = {
  title: string;
  eyebrow: string;
  icon: ReactNode;
  variant?: ActionTileVariant;
  href?: string;
  onClick?: MouseEventHandler<HTMLAnchorElement | HTMLButtonElement>;
  disabled?: boolean;
  className?: string;
  'aria-label'?: string;
};

const variantClass: Record<ActionTileVariant, string> = {
  primary: styles.primary,
  outline: styles.outline,
  muted: styles.muted,
};

export function ActionTile({
  title,
  eyebrow,
  icon,
  variant = 'outline',
  href,
  onClick,
  disabled = false,
  className,
  'aria-label': ariaLabel,
}: ActionTileProps) {
  const classes = [
    styles.tile,
    variantClass[variant],
    disabled ? styles.disabled : undefined,
    className,
  ]
    .filter(Boolean)
    .join(' ');

  const iconWrapClass =
    variant === 'primary' ? styles.iconPrimary : styles.iconSecondary;

  const content = (
    <>
      {variant === 'primary' ? (
        <span className={styles.decor} aria-hidden="true" />
      ) : null}
      <span className={[styles.iconWrap, iconWrapClass].join(' ')}>{icon}</span>
      <div className={styles.copy}>
        <Text
          as="span"
          variant="labelMd"
          className={
            variant === 'primary'
              ? styles.eyebrow
              : [styles.eyebrow, styles.eyebrowMuted].join(' ')
          }
        >
          {eyebrow}
        </Text>
        <Heading level={3} className={styles.title}>
          {title}
        </Heading>
      </div>
      {variant === 'primary' ? (
        <span className={styles.arrow} aria-hidden="true">
          <Icon src={ICONS.home.arrowForward} size={20} />
        </span>
      ) : null}
    </>
  );

  const accessibleName = ariaLabel ?? `${eyebrow}: ${title}`;

  if (href && !disabled) {
    return (
      <a
        href={href}
        className={classes}
        onClick={onClick as MouseEventHandler<HTMLAnchorElement> | undefined}
        aria-label={accessibleName}
      >
        {content}
      </a>
    );
  }

  return (
    <button
      type="button"
      className={classes}
      onClick={onClick as MouseEventHandler<HTMLButtonElement> | undefined}
      disabled={disabled}
      aria-label={accessibleName}
    >
      {content}
    </button>
  );
}
