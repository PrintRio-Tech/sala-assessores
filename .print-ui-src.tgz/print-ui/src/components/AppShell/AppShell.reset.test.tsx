import { fireEvent, render, screen, within } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import { readFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

import { AppShell } from './AppShell';

const here = dirname(fileURLToPath(import.meta.url));
const layoutTokens = readFileSync(
  join(here, '..', '..', 'tokens', '_layout.scss'),
  'utf8',
);

const navItems = [
  { id: 'home', label: 'Home', active: true, onClick: () => undefined },
  { id: 'users', label: 'Usuários', onClick: () => undefined },
];

describe('AppShell visual-reset canônico', () => {
  it('token sidebar = 236px (14.75rem) e header mobile = 64px', () => {
    expect(layoutTokens).toMatch(/\$sidebar-width:\s*14\.75rem/);
    expect(layoutTokens).toMatch(/\$header-height-mobile:\s*4rem/);
    expect(layoutTokens).not.toMatch(/\$sidebar-width:\s*16rem/);
    expect(layoutTokens).not.toMatch(/\$header-height-mobile:\s*3rem/);
  });

  it('topbar CSS: border-box + height 64px (padding interno; safe-area só no padding-top)', () => {
    const scss = readFileSync(join(here, 'styles.module.scss'), 'utf8');
    const topbar =
      scss.match(/\.topbar\s*\{[\s\S]*?(?=\n\.topbarBrand)/)?.[0] ?? '';
    expect(topbar).toMatch(/box-sizing:\s*border-box/);
    expect(topbar).toMatch(
      /height:\s*calc\(#\{\$header-height\} \+ env\(safe-area-inset-top/,
    );
    expect(topbar).toMatch(
      /padding-top:\s*env\(safe-area-inset-top/,
    );
    expect(topbar).toMatch(/padding-block:\s*0/);
    expect(topbar).not.toMatch(/padding-block:\s*\$space-2/);
  });

  it('renderiza topbar com slots de busca e ações (desktop+mobile)', () => {
    render(
      <AppShell
        logo={<span>Print</span>}
        navItems={navItems}
        topbarSearchSlot={<input aria-label="Buscar" />}
        topbarActionsSlot={<button type="button">Ajuda</button>}
      >
        <p>Conteúdo</p>
      </AppShell>,
    );

    const topbars = screen.getAllByRole('banner');
    expect(topbars.length).toBeGreaterThanOrEqual(1);
    expect(screen.getByLabelText('Buscar')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Ajuda' })).toBeInTheDocument();
  });

  it('expõe bottom-nav mobile derivado de navItems', () => {
    const onUsers = vi.fn();
    const { container } = render(
      <AppShell
        navItems={[
          { id: 'home', label: 'Home', active: true, onClick: () => undefined },
          { id: 'users', label: 'Usuários', onClick: onUsers },
        ]}
      >
        <p>Página</p>
      </AppShell>,
    );

    // jsdom não aplica @media mobile — bottom-nav fica display:none; assert via DOM.
    const bottom = container.querySelector(
      'nav[aria-label="Navegação inferior"]',
    );
    expect(bottom).toBeTruthy();
    const home = within(bottom as HTMLElement).getByText('Home');
    expect(home.closest('button')).toHaveAttribute('aria-current', 'page');
    fireEvent.click(within(bottom as HTMLElement).getByText('Usuários'));
    expect(onUsers).toHaveBeenCalled();
  });

  it('collapsible=false: sem botão de recolher e sem estado collapsed', () => {
    render(
      <AppShell
        logo={<span>Print</span>}
        navItems={navItems}
        collapsible={false}
        collapsed
      >
        <p>Fixo</p>
      </AppShell>,
    );

    expect(
      screen.queryByRole('button', { name: /Recolher menu|Expandir menu/ }),
    ).not.toBeInTheDocument();
    expect(
      document.querySelector('[data-collapsed="true"]'),
    ).toBeNull();
    expect(
      document.querySelector('aside[data-collapsed="false"]'),
    ).toBeTruthy();
  });

  it('collapsible default true mantém botão de recolher', () => {
    render(
      <AppShell logo={<span>Print</span>} navItems={navItems}>
        <p>Compat</p>
      </AppShell>,
    );

    expect(
      screen.getByRole('button', { name: 'Recolher menu' }),
    ).toBeInTheDocument();
  });

  it('sidebar CSS usa $primary / $on-primary (branding oficial)', () => {
    const scss = readFileSync(join(here, 'styles.module.scss'), 'utf8');
    const sidebar =
      scss.match(/\.sidebar\s*\{[\s\S]*?(?=\n\.sidebarCollapsed)/)?.[0] ?? '';
    expect(sidebar).toMatch(/background-color:\s*\$primary/);
    expect(sidebar).toMatch(/color:\s*\$on-primary/);
    expect(scss).not.toMatch(/\$on-shell/);
  });

  it('chrome default é brand; inverse usa tokens inverse-* existentes', () => {
    const scss = readFileSync(join(here, 'styles.module.scss'), 'utf8');
    const source = readFileSync(join(here, 'AppShell.tsx'), 'utf8');

    expect(source).toMatch(/export type AppShellChrome = 'brand' \| 'inverse'/);
    expect(source).toMatch(/chrome = 'brand'/);

    const inverse =
      scss.match(/\.shellInverse\s*\{[\s\S]*?(?=\n\.navIcon)/)?.[0] ?? '';
    expect(inverse).toMatch(/background-color:\s*\$inverse-surface/);
    expect(inverse).toMatch(/color:\s*\$inverse-on-surface/);
    expect(inverse).toMatch(/\.sidebar \.navLinkActive/);
    expect(inverse).toMatch(/background-color:\s*\$surface-bright/);
    expect(scss).not.toMatch(/\$on-shell/);
    expect(scss).not.toMatch(/\$shell(?!-)/);
  });

  it('chrome="inverse" marca data-chrome e não quebra slots', () => {
    render(
      <AppShell
        chrome="inverse"
        collapsible={false}
        logo={<span>Print ADM</span>}
        navItems={navItems}
        topbarSearchSlot={<input aria-label="Buscar" />}
        footerSlot={<span>Ambiente</span>}
      >
        <p>Home</p>
      </AppShell>,
    );

    expect(document.querySelector('[data-chrome="inverse"]')).toBeTruthy();
    expect(screen.getByLabelText('Buscar')).toBeInTheDocument();
    expect(screen.getByText('Ambiente')).toBeInTheDocument();
    expect(
      screen.queryByRole('button', { name: /Recolher menu|Expandir menu/ }),
    ).not.toBeInTheDocument();
  });

  it('chrome omitido permanece brand (compat)', () => {
    const { container } = render(
      <AppShell logo={<span>Print</span>} navItems={navItems}>
        <p>Compat</p>
      </AppShell>,
    );

    expect(container.querySelector('[data-chrome="brand"]')).toBeTruthy();
    expect(container.querySelector('[data-chrome="inverse"]')).toBeNull();
  });

  it('nav brand é compacta: min-height $space-5, padding $space-1 $space-2, pill $radius-full', () => {
    const scss = readFileSync(join(here, 'styles.module.scss'), 'utf8');
    const navLink =
      scss.match(/\.navLink\s*\{[\s\S]*?(?=\n\.navLinkActive)/)?.[0] ?? '';

    expect(navLink).toMatch(/min-height:\s*\$space-5/);
    expect(navLink).toMatch(/padding:\s*\$space-1 \$space-2/);
    expect(navLink).toMatch(/border-radius:\s*\$radius-full/);
    expect(navLink).not.toMatch(/min-height:\s*\$space-6/);
    expect(navLink).not.toMatch(/padding:\s*\$space-2 \$space-3/);
  });

  it('item ativo brand é pill clara ($surface-bright + $primary), sem overlay lavado nem $inverse-surface', () => {
    const scss = readFileSync(join(here, 'styles.module.scss'), 'utf8');
    const active =
      scss.match(/\.navLinkActive\s*\{[\s\S]*?\n\}/)?.[0] ?? '';

    expect(active).toMatch(/background-color:\s*\$surface-bright/);
    expect(active).toMatch(/color:\s*\$primary/);
    expect(active).not.toMatch(/rgba\(\$on-primary,/);
    expect(active).not.toMatch(/\$inverse-surface/);
    expect(active).not.toMatch(/\$grafite/);
  });

  it('topbarSearch: desktop flex 1 left-aligned com teto $breakpoint-sm; mobile auto (ícone-only)', () => {
    const scss = readFileSync(join(here, 'styles.module.scss'), 'utf8');
    const topbar =
      scss.match(/\.topbar\s*\{[\s\S]*?(?=\n\.topbarBrand)/)?.[0] ?? '';
    const search =
      scss.match(/\.topbarSearch\s*\{[\s\S]*?(?=\n\.topbarSearchSpacer)/)?.[0] ??
      '';
    const actions =
      scss.match(/\.topbarActions\s*\{[\s\S]*?(?=\n\.mobileLogo)/)?.[0] ?? '';

    expect(topbar).toMatch(/display:\s*flex/);
    expect(topbar).not.toMatch(/display:\s*grid/);
    expect(topbar).not.toMatch(/grid-template-columns/);
    expect(search).toMatch(/flex:\s*1/);
    expect(search).toMatch(/min-width:\s*0/);
    expect(search).toMatch(/max-width:\s*\$breakpoint-sm/);
    expect(search).not.toMatch(/max-width:\s*28rem/);
    expect(search).not.toMatch(/grid-column/);
    expect(search).toMatch(/flex:\s*0 0 auto/);
    expect(search).toMatch(/width:\s*auto/);
    expect(actions).toMatch(/margin-inline-start:\s*auto/);
    expect(scss).not.toMatch(/\.topbarSearch\s*\{[\s\S]*?max-width:\s*28rem/);
  });
});
