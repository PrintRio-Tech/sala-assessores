import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';

import { ICONS } from '../../assets/icons';
import { Avatar } from '../Avatar/Avatar';
import { Icon } from '../Icon';
import { SearchableSelectField } from '../SearchableSelectField/SearchableSelectField';
import { Text } from '../Text/Text';
import { TextInput } from '../TextInput/TextInput';
import { AppShell, type AppNavItem, type AppShellChrome } from './AppShell';

const navItems: AppNavItem[] = [
  {
    id: 'home',
    label: 'Início',
    icon: <Icon src={ICONS.nav.home} size={20} />,
    active: true,
    onClick: () => undefined,
  },
  {
    id: 'activities',
    label: 'Atividades',
    icon: <Icon src={ICONS.nav.activities} size={20} />,
    onClick: () => undefined,
  },
  {
    id: 'releases',
    label: 'Releases',
    icon: <Icon src={ICONS.nav.releases} size={20} />,
    onClick: () => undefined,
  },
  {
    id: 'reports',
    label: 'Relatórios',
    icon: <Icon src={ICONS.nav.reports} size={20} />,
    onClick: () => undefined,
  },
];

const ENVIRONMENT_OPTIONS = [
  { value: 'acme', label: 'Acme Comunicação' },
  { value: 'beta', label: 'Beta Press' },
  { value: 'gamma', label: 'Gamma Media' },
];

const meta = {
  title: 'Layout/AppShell',
  component: AppShell,
  tags: ['autodocs'],
  parameters: {
    layout: 'fullscreen',
  },
  args: {
    logo: <span>Print</span>,
    logoCollapsed: <span>P</span>,
    navItems,
    footerSlot: <span>Ana</span>,
    contentWidth: 'fluid',
    chrome: 'brand',
    topbarSearchSlot: (
      <TextInput
        name="q"
        label="Buscar cliente ou usuário"
        labelHidden
        type="search"
        placeholder="Buscar cliente ou usuário"
        leadingIcon={<Icon src={ICONS.ui.search} size={16} />}
      />
    ),
    topbarActionsSlot: <Avatar name="Noel Silva" size="sm" />,
    children: (
      <div>
        <h1 style={{ margin: '0 0 8px', fontSize: 20 }}>Dashboard</h1>
        <p style={{ margin: 0 }}>
          Conteúdo fluid — ocupa a largura do workspace (padrão forms).
        </p>
      </div>
    ),
  },
  argTypes: {
    contentWidth: {
      control: 'select',
      options: ['fluid', 'contained'],
    },
    chrome: {
      control: 'select',
      options: ['brand', 'inverse'] satisfies AppShellChrome[],
    },
  },
} satisfies Meta<typeof AppShell>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const Contained: Story = {
  args: {
    contentWidth: 'contained',
    children: (
      <div>
        <h1 style={{ margin: '0 0 8px', fontSize: 20 }}>Contained</h1>
        <p style={{ margin: 0 }}>
          Coluna centrada com max-width (legado / Storybook).
        </p>
      </div>
    ),
  },
};

/** Shell neutro/escuro — `$inverse-surface` / `$inverse-on-surface`. Default `brand` intacto. */
export const Inverse: Story = {
  args: {
    chrome: 'inverse',
    collapsible: false,
    topbarSearchSlot: (
      <input aria-label="Buscar" placeholder="Buscar…" style={{ width: '100%' }} />
    ),
    topbarActionsSlot: <Avatar name="Noel Silva" size="sm" />,
    footerSlot: <span>Ambiente de protótipo</span>,
    children: (
      <div>
        <h1 style={{ margin: '0 0 8px', fontSize: 20 }}>Inverse chrome</h1>
        <p style={{ margin: 0 }}>
          Sidebar grafite, item ativo em pill clara, topbar 64px.
        </p>
      </div>
    ),
  },
};

/** Composição Slack-like: slot + SearchableSelectField (+ footerSlot do select). Sem EnvironmentSwitcher. */
export const WithEnvironmentSlot: Story = {
  render: function WithEnvironmentSlotStory(args) {
    const [environment, setEnvironment] = useState('acme');
    const [collapsed, setCollapsed] = useState(false);
    const selected =
      ENVIRONMENT_OPTIONS.find((option) => option.value === environment) ??
      ENVIRONMENT_OPTIONS[0];

    return (
      <AppShell
        {...args}
        collapsed={collapsed}
        onCollapsedChange={setCollapsed}
        sidebarTopSlot={({ collapsed: isCollapsed }) =>
          isCollapsed ? (
            <button
              type="button"
              aria-label={`Ambiente: ${selected.label}`}
              style={{
                display: 'inline-flex',
                margin: '0 auto',
                padding: 0,
                border: 0,
                background: 'transparent',
                cursor: 'pointer',
                color: 'inherit',
              }}
            >
              <Avatar name={selected.label} size="sm" />
            </button>
          ) : (
            <div style={{ display: 'grid', gap: 8 }}>
              <Text as="span" variant="labelSm" style={{ opacity: 0.72 }}>
                Ambiente
              </Text>
              <SearchableSelectField
                label="Ambiente"
                labelHidden
                tone="onPrimary"
                size="sm"
                name="environment"
                options={ENVIRONMENT_OPTIONS}
                value={environment}
                onValueChange={setEnvironment}
                placeholder="Buscar ambiente…"
                footerSlot={
                  <a
                    href="/clientes"
                    style={{
                      display: 'block',
                      padding: '8px 12px',
                      color: 'inherit',
                      textDecoration: 'underline',
                      fontSize: 13,
                    }}
                  >
                    Gerenciar ambientes
                  </a>
                }
              />
            </div>
          )
        }
      />
    );
  },
};
