import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';

import { AppShell } from './AppShell';

describe('AppShell', () => {
  it('renderiza sidebar com logo, navegação e conteúdo', () => {
    render(
      <AppShell
        logo={<span>Print</span>}
        navItems={[
          { id: 'dash', label: 'Dashboard', active: true, onClick: () => undefined },
          { id: 'cli', label: 'Clientes', onClick: () => undefined },
        ]}
        footerSlot={<span>Ana</span>}
      >
        <p>Conteúdo principal</p>
      </AppShell>,
    );

    expect(screen.getAllByText('Print').length).toBeGreaterThan(0);
    expect(
      screen.getByRole('navigation', { name: 'Navegação principal' }),
    ).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Dashboard' })).toHaveAttribute(
      'aria-current',
      'page',
    );
    expect(screen.getByText('Ana')).toBeInTheDocument();
    expect(screen.getByText('Conteúdo principal')).toBeInTheDocument();
  });

  it('expõe skip link para #main-content (WIG)', () => {
    render(
      <AppShell
        navItems={[{ id: 'dash', label: 'Dashboard', onClick: () => undefined }]}
      >
        <p>Página</p>
      </AppShell>,
    );

    const skip = screen.getByRole('link', { name: 'Ir para o conteúdo principal' });
    expect(skip).toHaveAttribute('href', '#main-content');
    expect(document.getElementById('main-content')).toBeTruthy();
  });

  it('alterna menu mobile via onMobileOpenChange', () => {
    // Overlay hamburger removido — bottom-nav canônica. Props mobileOpen*
    // permanecem por compat e não controlam UI.
    const onMobileOpenChange = vi.fn();

    render(
      <AppShell
        navItems={[{ id: 'dash', label: 'Dashboard', onClick: () => undefined }]}
        mobileOpen={false}
        onMobileOpenChange={onMobileOpenChange}
      />,
    );

    expect(
      screen.queryByRole('button', { name: 'Abrir menu' }),
    ).not.toBeInTheDocument();
    expect(onMobileOpenChange).not.toHaveBeenCalled();
    expect(
      document.querySelector('nav[aria-label="Navegação inferior"]'),
    ).toBeTruthy();
  });

  it('alterna collapse da sidebar', () => {
    const onCollapsedChange = vi.fn();

    render(
      <AppShell
        navItems={[{ id: 'dash', label: 'Dashboard', onClick: () => undefined }]}
        collapsed={false}
        onCollapsedChange={onCollapsedChange}
      />,
    );

    fireEvent.click(screen.getByRole('button', { name: 'Recolher menu' }));
    expect(onCollapsedChange).toHaveBeenCalledWith(true);
  });

  it('contentWidth=contained aplica classe de coluna centrada', () => {
    render(
      <AppShell
        navItems={[{ id: 'dash', label: 'Dashboard', onClick: () => undefined }]}
        contentWidth="contained"
      >
        <p>Narrow</p>
      </AppShell>,
    );

    const main = document.getElementById('main-content');
    expect(main?.className).toMatch(/mainContained/);
  });

  it('contentWidth fluid (default) não aplica contained', () => {
    render(
      <AppShell
        navItems={[{ id: 'dash', label: 'Dashboard', onClick: () => undefined }]}
      >
        <p>Wide</p>
      </AppShell>,
    );

    const main = document.getElementById('main-content');
    expect(main?.className).not.toMatch(/mainContained/);
  });

  it('renderiza sidebarTopSlot entre brand e nav na sidebar', () => {
    render(
      <AppShell
        logo={<span>Print</span>}
        navItems={[{ id: 'dash', label: 'Dashboard', onClick: () => undefined }]}
        sidebarTopSlot={<span>Ambiente Acme</span>}
      />,
    );

    expect(screen.getByText('Ambiente Acme')).toBeInTheDocument();
  });

  it('sidebarTopSlot recebe collapsed e permanece visível quando recolhido', () => {
    render(
      <AppShell
        logo={<span>Print</span>}
        logoCollapsed={<span>P</span>}
        navItems={[{ id: 'dash', label: 'Dashboard', onClick: () => undefined }]}
        collapsed
        sidebarTopSlot={({ collapsed }) => (
          <span>{collapsed ? 'AC' : 'Ambiente Acme'}</span>
        )}
        footerSlot={<span>Ana</span>}
      />,
    );

    expect(screen.getByText('AC')).toBeInTheDocument();
    expect(screen.queryByText('Ambiente Acme')).not.toBeInTheDocument();
    expect(screen.getByText('Ana')).toBeInTheDocument();
    expect(
      document.querySelector('[data-collapsed="true"]'),
    ).toBeTruthy();
  });

  it('não renderiza menu overlay hamburger (bottom-nav canônica)', () => {
    render(
      <AppShell
        logo={<span>Print</span>}
        navItems={[
          { id: 'dash', label: 'Dashboard', onClick: () => undefined },
        ]}
        mobileOpen
        sidebarTopSlot={<span>Ambiente Acme</span>}
      />,
    );

    expect(
      document.querySelector('nav[aria-label="Menu principal"]'),
    ).toBeNull();
    expect(
      document.querySelector('nav[aria-label="Navegação inferior"]'),
    ).toBeTruthy();
  });
});

