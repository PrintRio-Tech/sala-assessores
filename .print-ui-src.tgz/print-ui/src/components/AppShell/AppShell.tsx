import {
  useCallback,
  useState,
  type ReactNode,
} from 'react';

import { ICONS } from '../../assets/icons';
import { Icon } from '../Icon';
import { Tooltip, TooltipProvider } from '../Tooltip/Tooltip';

import styles from './styles.module.scss';

export type AppNavItem = {
  id: string;
  label: string;
  href?: string;
  icon?: ReactNode;
  active?: boolean;
  onClick?: () => void;
};

export type AppNavProps = {
  items: AppNavItem[];
  collapsed?: boolean;
  className?: string;
  'aria-label'?: string;
};

function NavItemContent({
  item,
  collapsed,
}: {
  item: AppNavItem;
  collapsed?: boolean;
}) {
  return (
    <>
      {item.icon != null ? (
        <span className={styles.navIcon} aria-hidden="true">
          {item.icon}
        </span>
      ) : null}
      <span className={styles.navLabel}>{item.label}</span>
      {collapsed ? <span className={styles.srOnly}>{item.label}</span> : null}
    </>
  );
}

export function AppNav({
  items,
  collapsed = false,
  className,
  'aria-label': ariaLabel = 'Navegação principal',
}: AppNavProps) {
  const classes = [styles.nav, className].filter(Boolean).join(' ');

  return (
    <nav className={classes} aria-label={ariaLabel}>
      <ul className={styles.navList}>
        {items.map((item) => {
          const itemClasses = [
            styles.navLink,
            item.active ? styles.navLinkActive : undefined,
          ]
            .filter(Boolean)
            .join(' ');

          const control = item.href ? (
            <a
              className={itemClasses}
              href={item.href}
              aria-current={item.active ? 'page' : undefined}
              aria-label={collapsed ? item.label : undefined}
              onClick={item.onClick}
            >
              <NavItemContent item={item} collapsed={collapsed} />
            </a>
          ) : (
            <button
              type="button"
              className={itemClasses}
              aria-current={item.active ? 'page' : undefined}
              aria-label={collapsed ? item.label : undefined}
              onClick={item.onClick}
            >
              <NavItemContent item={item} collapsed={collapsed} />
            </button>
          );

          return (
            <li key={item.id} className={styles.navItem}>
              {collapsed ? (
                <Tooltip content={item.label} side="right" sideOffset={8}>
                  {control}
                </Tooltip>
              ) : (
                control
              )}
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

export type AppShellContentWidth = 'fluid' | 'contained';

/**
 * Chrome da sidebar/nav.
 * `brand` — `$primary` / `$on-primary` (default, compat Forms).
 * `inverse` — `$inverse-surface` / `$inverse-on-surface` (shell neutro/escuro).
 */
export type AppShellChrome = 'brand' | 'inverse';

export type AppShellSidebarTopSlotContext = {
  collapsed: boolean;
};

export type AppShellSidebarTopSlot =
  | ReactNode
  | ((ctx: AppShellSidebarTopSlotContext) => ReactNode);

export type AppShellProps = {
  logo?: ReactNode;
  logoCollapsed?: ReactNode;
  /** Logo no header/topbar mobile (fundo claro). Default: `logo`. */
  mobileLogo?: ReactNode;
  navItems: AppNavItem[];
  /**
   * Conteúdo entre brand e nav (ex.: seletor de ambiente / cliente).
   * Renderizado na sidebar desktop (também quando `collapsed`).
   * Prefira função `({ collapsed })` para UI compacta (avatar/ícone) vs. combobox expandido.
   */
  sidebarTopSlot?: AppShellSidebarTopSlot;
  /**
   * Slot de busca na topbar neutra (desktop + mobile), ex.: campo “Buscar…”.
   */
  topbarSearchSlot?: ReactNode;
  /**
   * Ações à direita da topbar (ajuda, avatar, etc.) — desktop + mobile.
   */
  topbarActionsSlot?: ReactNode;
  /** Conteúdo extra no rodapé da sidebar (ex.: usuário / logout). */
  footerSlot?: ReactNode;
  /** @deprecated Use footerSlot — mantido para compat. */
  userSlot?: ReactNode;
  children?: ReactNode;
  /**
   * Quando `true` (default, compat), permite recolher a sidebar.
   * `false` = sidebar fixa (visual-reset ADM): sem botão nem estado collapsed.
   */
  collapsible?: boolean;
  collapsed?: boolean;
  onCollapsedChange?: (collapsed: boolean) => void;
  /**
   * @deprecated Menu overlay mobile foi substituído pela bottom-nav canônica.
   * Props mantidas para compat; não controlam UI.
   */
  mobileOpen?: boolean;
  /** @deprecated Ver `mobileOpen`. */
  onMobileOpenChange?: (open: boolean) => void;
  /**
   * Main content width. `fluid` matches print-forms DashboardLayout (default).
   * `contained` keeps max-width + centered column (legacy).
   */
  contentWidth?: AppShellContentWidth;
  /**
   * Aparência do chrome (sidebar). Default `brand` preserva o verde floresta.
   * `inverse` usa só tokens já existentes (`$inverse-surface` / `$inverse-on-surface`).
   */
  chrome?: AppShellChrome;
  className?: string;
};

function resolveSidebarTopSlot(
  slot: AppShellSidebarTopSlot | undefined,
  collapsed: boolean,
): ReactNode {
  if (slot == null) return null;
  if (typeof slot === 'function') return slot({ collapsed });
  return slot;
}

export function AppShell({
  logo,
  logoCollapsed,
  mobileLogo,
  navItems,
  sidebarTopSlot,
  topbarSearchSlot,
  topbarActionsSlot,
  footerSlot,
  userSlot,
  children,
  collapsible = true,
  collapsed: collapsedProp,
  onCollapsedChange,
  mobileOpen: _mobileOpenProp,
  onMobileOpenChange: _onMobileOpenChange,
  contentWidth = 'fluid',
  chrome = 'brand',
  className,
}: AppShellProps) {
  const [uncontrolledCollapsed, setUncontrolledCollapsed] = useState(false);

  const isCollapsedControlled = collapsedProp !== undefined;
  const collapsed = collapsible
    ? isCollapsedControlled
      ? collapsedProp
      : uncontrolledCollapsed
    : false;

  const setCollapsed = useCallback(
    (next: boolean) => {
      if (!collapsible) return;
      if (!isCollapsedControlled) setUncontrolledCollapsed(next);
      onCollapsedChange?.(next);
    },
    [collapsible, isCollapsedControlled, onCollapsedChange],
  );

  void _mobileOpenProp;
  void _onMobileOpenChange;

  const collapseLabel = collapsed ? 'Expandir menu' : 'Recolher menu';
  const footer = footerSlot ?? userSlot;
  const brandLogo = collapsed && logoCollapsed != null ? logoCollapsed : logo;
  const topSlot = resolveSidebarTopSlot(sidebarTopSlot, collapsed);

  const shellClasses = [
    styles.shell,
    chrome === 'inverse' ? styles.shellInverse : undefined,
    collapsed ? styles.shellCollapsed : undefined,
    className,
  ]
    .filter(Boolean)
    .join(' ');

  const collapseButton = collapsible ? (
    <button
      type="button"
      className={styles.collapseButton}
      aria-label={collapseLabel}
      aria-expanded={!collapsed}
      onClick={() => setCollapsed(!collapsed)}
    >
      <Icon
        src={ICONS.ui.chevronLeft}
        size={20}
        className={[
          styles.collapseIcon,
          collapsed ? styles.collapseIconFlipped : undefined,
        ]
          .filter(Boolean)
          .join(' ')}
      />
    </button>
  ) : null;

  const topbarInner = (
    <>
      <div className={styles.topbarBrand}>
        {mobileLogo != null || logo != null ? (
          <div className={styles.mobileLogo}>{mobileLogo ?? logo}</div>
        ) : null}
      </div>
      {topbarSearchSlot != null ? (
        <div className={styles.topbarSearch}>{topbarSearchSlot}</div>
      ) : (
        <div className={styles.topbarSearchSpacer} />
      )}
      {topbarActionsSlot != null ? (
        <div className={styles.topbarActions}>{topbarActionsSlot}</div>
      ) : null}
    </>
  );

  return (
    <div className={shellClasses} data-chrome={chrome}>
      <a href="#main-content" className={styles.skipLink}>
        Ir para o conteúdo principal
      </a>

      <aside
        className={[
          styles.sidebar,
          collapsed ? styles.sidebarCollapsed : undefined,
        ]
          .filter(Boolean)
          .join(' ')}
        aria-label="Menu lateral"
        data-collapsed={collapsed ? 'true' : 'false'}
      >
        <div className={styles.brand}>
          {brandLogo != null ? (
            <div className={styles.brandLogo}>{brandLogo}</div>
          ) : null}
        </div>

        {collapsed ? (
          <TooltipProvider delay={300}>
            {topSlot != null ? (
              <div className={styles.sidebarTopSlot} data-collapsed="true">
                {topSlot}
              </div>
            ) : null}
            <div className={styles.sidebarBody}>
              <AppNav items={navItems} collapsed />
            </div>
            <div className={styles.sidebarFooter}>
              {footer != null ? (
                <div className={styles.footerSlot}>{footer}</div>
              ) : null}
              {collapseButton != null ? (
                <Tooltip content={collapseLabel} side="right" sideOffset={8}>
                  {collapseButton}
                </Tooltip>
              ) : null}
            </div>
          </TooltipProvider>
        ) : (
          <>
            {topSlot != null ? (
              <div className={styles.sidebarTopSlot} data-collapsed="false">
                {topSlot}
              </div>
            ) : null}
            <div className={styles.sidebarBody}>
              <AppNav items={navItems} />
            </div>
            <div className={styles.sidebarFooter}>
              {footer != null ? (
                <div className={styles.footerSlot}>{footer}</div>
              ) : null}
              {collapseButton}
            </div>
          </>
        )}
      </aside>

      <div className={styles.workspace}>
        <header className={styles.topbar} aria-label="Barra superior">
          {topbarInner}
        </header>

        <div className={styles.scrollArea}>
          <main
            id="main-content"
            className={[
              styles.main,
              contentWidth === 'contained' ? styles.mainContained : undefined,
            ]
              .filter(Boolean)
              .join(' ')}
            tabIndex={-1}
          >
            {children}
          </main>
        </div>

        <AppNav
          items={navItems}
          className={styles.bottomNav}
          aria-label="Navegação inferior"
        />
      </div>
    </div>
  );
}
