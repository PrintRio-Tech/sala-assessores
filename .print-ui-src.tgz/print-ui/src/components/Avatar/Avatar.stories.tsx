import type { Meta, StoryObj } from '@storybook/react-vite';

import { Avatar } from './Avatar';

const meta = {
  title: 'Foundation/Avatar',
  component: Avatar,
  tags: ['autodocs'],
  args: {
    name: 'Ana Silva',
    size: 'md',
  },
  argTypes: {
    size: {
      control: 'select',
      options: ['sm', 'md', 'lg'],
    },
  },
} satisfies Meta<typeof Avatar>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const Small: Story = {
  args: { size: 'sm', name: 'Ana Silva' },
};

export const Medium: Story = {
  args: { size: 'md', name: 'Ana Silva' },
};

export const Large: Story = {
  args: { size: 'lg', name: 'Ana Silva' },
};

export const WithInitials: Story = {
  args: {
    initials: 'PF',
    name: undefined,
  },
};

export const WithImage: Story = {
  args: {
    name: 'Ana Silva',
    src: 'https://i.pravatar.cc/128?u=print-forms',
    alt: 'Ana Silva',
  },
};

export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
      <Avatar size="sm" name="Ana Silva" />
      <Avatar size="md" name="Ana Silva" />
      <Avatar size="lg" name="Ana Silva" />
    </div>
  ),
};
