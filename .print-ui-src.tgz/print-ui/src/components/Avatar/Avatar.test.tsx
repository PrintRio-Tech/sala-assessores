import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { Avatar } from './Avatar';

describe('Avatar', () => {
  it('gera iniciais a partir de name via getPersonInitials', () => {
    render(<Avatar name="Ana Silva" />);

    const avatar = screen.getByRole('img', { name: 'Ana Silva' });
    expect(avatar).toBeInTheDocument();
    expect(avatar).toHaveTextContent('AS');
  });

  it('prioriza initials explícitas sobre name', () => {
    render(<Avatar name="Ana Silva" initials="XY" />);
    expect(screen.getByRole('img', { name: 'Ana Silva' })).toHaveTextContent(
      'XY',
    );
  });

  it('renderiza imagem quando src está presente', () => {
    render(<Avatar name="Ana Silva" src="/avatar.png" alt="Foto de Ana" />);

    const img = screen.getByRole('img', { name: 'Foto de Ana' });
    expect(img.tagName).toBe('IMG');
    expect(img).toHaveAttribute('src', '/avatar.png');
  });
});
