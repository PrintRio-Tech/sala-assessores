import type { ComponentPropsWithoutRef, ReactNode } from 'react';

import { getPersonInitials } from '../Table/Cells/Person/types';

import styles from './styles.module.scss';

export type AvatarSize = 'sm' | 'md' | 'lg';

export type AvatarProps = Omit<ComponentPropsWithoutRef<'span'>, 'children'> & {
  /** Nome completo — gera iniciais quando `initials` / `src` ausentes. */
  name?: string;
  /** Iniciais explícitas (sobrescreve as geradas a partir de `name`). */
  initials?: string;
  src?: string;
  alt?: string;
  size?: AvatarSize;
  children?: ReactNode;
};

const sizeClass: Record<AvatarSize, string | undefined> = {
  sm: styles.sm,
  md: undefined,
  lg: styles.lg,
};

export function Avatar({
  name,
  initials: initialsProp,
  src,
  alt,
  size = 'md',
  className,
  children,
  ...props
}: AvatarProps) {
  const initials =
    initialsProp ?? (name ? getPersonInitials(name) : undefined) ?? '?';
  const label = alt ?? name ?? initials;
  const classes = [styles.avatar, sizeClass[size], className]
    .filter(Boolean)
    .join(' ');

  return (
    <span
      className={classes}
      role={src ? undefined : 'img'}
      aria-label={src ? undefined : label}
      {...props}
    >
      {src ? (
        <img className={styles.image} src={src} alt={alt ?? name ?? ''} />
      ) : (
        (children ?? initials)
      )}
    </span>
  );
}
