import type { Meta, StoryObj } from '@storybook/react-vite';

import { Badge } from './Badge';

const meta = {
  title: 'Foundation/Badge',
  component: Badge,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component: [
          'Chip de status/etiqueta. API canônica: `tone` + `size`.',
          '',
          '**Mapa forms `variant` → UI `tone`:**',
          '- `default` → `neutral`',
          '- `primary` (salvia container) → `soft`',
          '- `secondary` → `secondary`',
          '- `accent` → `accent`',
          '- `outline` → `outline`',
          '- `primary` no UI = solid (`$primary`); não existe no Badge do forms.',
        ].join('\n'),
      },
    },
  },
  args: {
    children: 'Badge',
    tone: 'neutral',
    size: 'md',
  },
  argTypes: {
    tone: {
      control: 'select',
      options: [
        'neutral',
        'success',
        'warning',
        'danger',
        'accent',
        'primary',
        'soft',
        'secondary',
        'outline',
      ],
    },
    size: {
      control: 'select',
      options: ['sm', 'md'],
    },
  },
} satisfies Meta<typeof Badge>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const Neutral: Story = {
  args: { tone: 'neutral', children: 'Neutro' },
};

export const Soft: Story = {
  args: { tone: 'soft', children: 'Soft (forms primary)' },
};

export const Secondary: Story = {
  args: { tone: 'secondary', children: 'Secundário' },
};

export const Outline: Story = {
  args: { tone: 'outline', children: 'Outline' },
};

export const Success: Story = {
  args: { tone: 'success', children: 'Sucesso' },
};

export const Warning: Story = {
  args: { tone: 'warning', children: 'Atenção' },
};

export const Danger: Story = {
  args: { tone: 'danger', children: 'Erro' },
};

export const Accent: Story = {
  args: { tone: 'accent', children: 'Destaque' },
};

export const Primary: Story = {
  args: { tone: 'primary', children: 'Primário solid' },
};

export const Small: Story = {
  args: { size: 'sm', children: 'Pequeno' },
};

export const FormsMigrationMap: Story = {
  name: 'Forms → UI map',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, alignItems: 'center' }}>
        <Badge tone="neutral">default → neutral</Badge>
        <Badge tone="soft">primary → soft</Badge>
        <Badge tone="secondary">secondary → secondary</Badge>
        <Badge tone="accent">accent → accent</Badge>
        <Badge tone="outline">outline → outline</Badge>
      </div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, alignItems: 'center' }}>
        <Badge tone="primary">UI-only primary (solid)</Badge>
        <Badge tone="success">success</Badge>
        <Badge tone="warning">warning</Badge>
        <Badge tone="danger">danger</Badge>
      </div>
    </div>
  ),
};

export const AllTones: Story = {
  render: () => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, alignItems: 'center' }}>
      <Badge tone="neutral">Neutral</Badge>
      <Badge tone="soft">Soft</Badge>
      <Badge tone="secondary">Secondary</Badge>
      <Badge tone="outline">Outline</Badge>
      <Badge tone="success">Success</Badge>
      <Badge tone="warning">Warning</Badge>
      <Badge tone="danger">Danger</Badge>
      <Badge tone="accent">Accent</Badge>
      <Badge tone="primary">Primary</Badge>
    </div>
  ),
};

export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
      <Badge size="sm">Small</Badge>
      <Badge size="md">Medium</Badge>
    </div>
  ),
};
