import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { Badge } from './Badge';

describe('Badge', () => {
  it('renderiza o conteúdo e aplica tone primary (solid)', () => {
    render(<Badge tone="primary">Ativo</Badge>);

    const badge = screen.getByText('Ativo');
    expect(badge).toBeInTheDocument();
    expect(badge.className).toMatch(/primary/);
  });

  it('aplica tones soft, secondary e outline', () => {
    const { rerender } = render(<Badge tone="soft">Soft</Badge>);
    expect(screen.getByText('Soft').className).toMatch(/soft/);

    rerender(<Badge tone="secondary">Sec</Badge>);
    expect(screen.getByText('Sec').className).toMatch(/secondary/);

    rerender(<Badge tone="outline">Out</Badge>);
    expect(screen.getByText('Out').className).toMatch(/outline/);
  });

  it('aplica tamanho sm', () => {
    render(<Badge size="sm">Novo</Badge>);

    expect(screen.getByText('Novo').className).toMatch(/sm/);
  });
});
