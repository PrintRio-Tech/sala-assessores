import type { ReactNode } from 'react';

import styles from './styles.module.scss';

export type BadgeTone =
  | 'neutral'
  | 'success'
  | 'warning'
  | 'danger'
  | 'accent'
  | 'primary'
  | 'soft'
  | 'secondary'
  | 'outline';

export type BadgeSize = 'sm' | 'md';

export type BadgeProps = {
  children: ReactNode;
  tone?: BadgeTone;
  size?: BadgeSize;
  className?: string;
};

const toneClass: Record<BadgeTone, string> = {
  neutral: styles.neutral,
  success: styles.success,
  warning: styles.warning,
  danger: styles.danger,
  accent: styles.accent,
  primary: styles.primary,
  soft: styles.soft,
  secondary: styles.secondary,
  outline: styles.outline,
};

const sizeClass: Record<BadgeSize, string | undefined> = {
  sm: styles.sm,
  md: undefined,
};

export function Badge({
  children,
  tone = 'neutral',
  size = 'md',
  className,
}: BadgeProps) {
  const classes = [
    styles.badge,
    toneClass[tone],
    sizeClass[size],
    className,
  ]
    .filter(Boolean)
    .join(' ');

  return <span className={classes}>{children}</span>;
}
