import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { Button } from './Button';

describe('Button', () => {
  it('renderiza e permanece focável (press feedback via CSS :active)', () => {
    render(<Button type="button">Salvar</Button>);

    const button = screen.getByRole('button', { name: 'Salvar' });
    expect(button).toBeEnabled();
    button.focus();
    expect(button).toHaveFocus();
  });

  it('respeita disabled', () => {
    render(
      <Button type="button" disabled>
        Bloqueado
      </Button>,
    );

    expect(screen.getByRole('button', { name: 'Bloqueado' })).toBeDisabled();
  });
});
