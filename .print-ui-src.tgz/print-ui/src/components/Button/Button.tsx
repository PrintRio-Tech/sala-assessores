import { Button as BaseButton } from '@base-ui-components/react/button';
import type { ComponentProps } from 'react';

import styles from './styles.module.scss';

type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
type ButtonSize = 'sm' | 'md' | 'lg';

export type ButtonProps = ComponentProps<typeof BaseButton> & {
  variant?: ButtonVariant;
  size?: ButtonSize;
  iconOnly?: boolean;
};

const variantClass: Record<ButtonVariant, string> = {
  primary: styles.primary,
  secondary: styles.secondary,
  outline: styles.outline,
  ghost: styles.ghost,
  danger: styles.danger,
};

const sizeClass: Record<ButtonSize, string | undefined> = {
  sm: styles.sm,
  md: undefined,
  lg: styles.lg,
};

export function Button({
  variant = 'primary',
  size = 'md',
  iconOnly = false,
  className,
  ...props
}: ButtonProps) {
  const classes = [
    styles.button,
    variantClass[variant],
    sizeClass[size],
    iconOnly ? styles.iconOnly : undefined,
    className,
  ]
    .filter(Boolean)
    .join(' ');

  return <BaseButton className={classes} {...props} />;
}
