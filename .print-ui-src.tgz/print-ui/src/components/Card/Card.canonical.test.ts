import { readFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

import { describe, expect, it } from 'vitest';

const here = dirname(fileURLToPath(import.meta.url));
const scss = readFileSync(join(here, 'styles.module.scss'), 'utf8');
const source = readFileSync(join(here, 'Card.tsx'), 'utf8');
const indexSource = readFileSync(join(here, '..', 'index.ts'), 'utf8');

describe('Card gramática canônica (visual reset)', () => {
  it('default usa radius moderado ($radius-md 12px), nunca xl nem 0', () => {
    const cardBlock = scss.match(/\.card\s*\{[\s\S]*?\n\}/)?.[0] ?? '';
    expect(cardBlock).toMatch(/border-radius:\s*\$radius-md/);
    expect(cardBlock).not.toMatch(/\$radius-xl/);
    expect(cardBlock).not.toMatch(/border-radius:\s*0/);
    expect(scss).not.toMatch(/\.surfaceFlat/);
  });

  it('paddingSm = 16px ($space-2) em desktop e mobile', () => {
    const pad = scss.match(/\.paddingSm\s*\{[\s\S]*?\n\}/)?.[0] ?? '';
    expect(pad).toMatch(/padding:\s*\$space-2/);
    expect(pad).not.toMatch(/\$space-3/);
  });

  it('não expõe prop surface / CardSurface (opt-in removido)', () => {
    expect(source).not.toMatch(/CardSurface/);
    expect(source).not.toMatch(/surface\?:/);
    expect(source).not.toMatch(/surface\s*=/);
    expect(indexSource).not.toMatch(/CardSurface/);
  });

  it('borda subtle e sem shadow pesada no chrome base', () => {
    const cardBlock = scss.match(/\.card\s*\{[\s\S]*?\n\}/)?.[0] ?? '';
    expect(cardBlock).toMatch(/\$border-subtle|border:\s*1px/);
    expect(cardBlock).not.toMatch(/box-shadow:/);
  });

  it('highlight é featured real (sage + outline); soft continua translúcido', () => {
    const highlight = scss.match(/\.highlight\s*\{[\s\S]*?\n\}/)?.[0] ?? '';
    const soft = scss.match(/\.soft\s*\{[\s\S]*?\n\}/)?.[0] ?? '';

    expect(highlight).toMatch(/\$primary-container|\$outline/);
    expect(highlight).toMatch(/color:\s*\$on-surface/);
    expect(highlight).not.toMatch(/\$surface-container-lowest/);

    expect(soft).toMatch(/rgba\(\$surface-container-lowest/);
    expect(source).toMatch(/'highlight'/);
  });

  it('action é CTA escuro $primary/$on-primary; primary permanece container oliva', () => {
    const action = scss.match(/^\.action\s*\{[\s\S]*?\n\}/m)?.[0] ?? '';
    const primary = scss.match(/^\.primary\s*\{[\s\S]*?\n\}/m)?.[0] ?? '';

    expect(action).toMatch(/background-color:\s*\$primary;/);
    expect(action).toMatch(/color:\s*\$on-primary;/);
    expect(action).toMatch(/--pf-on-surface:\s*#\{\$on-primary\}/);
    expect(action).toMatch(/:is\(h1,\s*h2,\s*h3/);
    expect(action).not.toMatch(/:where\(/);
    expect(action).not.toMatch(/\$primary-container/);

    expect(primary).toMatch(/background-color:\s*\$primary-container/);
    expect(primary).toMatch(/color:\s*\$on-primary-container/);

    expect(source).toMatch(/'action'/);
    expect(source).toMatch(/action:\s*styles\.action/);
  });
});
