import type { Meta, StoryObj } from '@storybook/react-vite';
import { fn } from 'storybook/test';
import type { ReactNode } from 'react';

import { Heading } from '../Heading/Heading';
import { Text } from '../Text/Text';
import { Card, type CardPadding, type CardVariant } from './Card';

/** Args de story — evita `never` da união polimórfica de CardProps. */
type CardStoryArgs = {
  variant?: CardVariant;
  padding?: CardPadding;
  interactive?: boolean;
  children?: ReactNode;
  onClick?: () => void;
  href?: string;
};

const meta = {
  title: 'Foundation/Card',
  component: Card,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Superfície de conteúdo. Largura intrínseca (sem `width: 100%`) — o layout do consumidor controla. Chrome clean por default (`$radius-md`, borda subtle, sem shadow). `primary` = KPI/destaque invertido oliva (`$primary-container`). `action` = CTA/destaque de ação, verde floresta `$primary` + `$on-primary` (Heading e Text default herdam; `tone="muted"` permanece variant). `accent` = banner secundário (texto marrom). `highlight` = entidade em destaque num conjunto (texto `$on-surface`). `soft` é painel translúcido, não featured. Não usar `primary` como CTA full-bleed — use `action`.',
      },
    },
  },
  decorators: [
    (Story) => (
      <div style={{ maxWidth: 360 }}>
        <Story />
      </div>
    ),
  ],
  args: {
    children: 'Conteúdo do card',
    variant: 'surface',
    padding: 'md',
    interactive: false,
  },
  argTypes: {
    variant: {
      control: 'select',
      options: [
        'surface',
        'elevated',
        'soft',
        'inset',
        'primary',
        'action',
        'accent',
        'highlight',
      ],
    },
    padding: {
      control: 'select',
      options: ['none', 'sm', 'md', 'lg'],
    },
    interactive: { control: 'boolean' },
  },
} satisfies Meta<CardStoryArgs>;

export default meta;
type Story = StoryObj<typeof meta>;

function SampleContent({ title = 'Card' }: { title?: string }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <Text as="strong" variant="labelMd">
        {title}
      </Text>
      <Text tone="muted" variant="bodyMd">
        Conteúdo de exemplo para visualizar o card.
      </Text>
    </div>
  );
}

/** CTA sobre `$primary` — texto herda `$on-primary` (sem hex no consumidor). */
function ActionCtaContent() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <Heading level={3} variant="sm">
        Nova demanda
      </Heading>
      <Text variant="bodyMd">
        Registre o pedido recebido e organize os próximos passos.
      </Text>
    </div>
  );
}

/** Conteúdo legível sobre `$primary-container` — padrão ReportKpiCard. */
function PrimaryKpiContent() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <span
        style={{
          color: 'rgba(255, 255, 255, 0.75)',
          fontSize: 12,
          fontWeight: 500,
          letterSpacing: '0.04em',
          textTransform: 'uppercase',
        }}
      >
        Inserções na imprensa
      </span>
      <span
        style={{
          color: '#ffffff',
          fontSize: 28,
          fontWeight: 600,
          lineHeight: 1.1,
          fontVariantNumeric: 'tabular-nums',
        }}
      >
        1.248
      </span>
      <span style={{ color: '#f0ebe4', fontSize: 13 }}>
        +12% vs. período anterior
      </span>
    </div>
  );
}

/** Conteúdo legível sobre `$accent-gold` — marrom `#4b3d19`. */
function AccentBannerContent() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <Text as="strong" variant="labelMd" style={{ color: '#4b3d19' }}>
        Relatório semanal
      </Text>
      <Text variant="bodyMd" style={{ color: '#4b3d19' }}>
        Resumo das menções e releases publicados nesta semana.
      </Text>
    </div>
  );
}

export const Default: Story = {
  args: {
    children: <SampleContent title="Surface" />,
  },
};

export const Surface: Story = {
  args: {
    variant: 'surface',
    children: <SampleContent title="Surface" />,
  },
};

export const Elevated: Story = {
  args: {
    variant: 'elevated',
    children: <SampleContent title="Elevated" />,
  },
};

export const Soft: Story = {
  args: {
    variant: 'soft',
    children: <SampleContent title="Soft" />,
  },
};

export const Inset: Story = {
  args: {
    variant: 'inset',
    children: <SampleContent title="Inset" />,
  },
};

export const Primary: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'Uso: KPI / destaque numérico. Preferir texto branco ou off-white (`#f0ebe4`) sobre o container — contraste do `$on-primary-container` sozinho pode ser insuficiente para body pequeno.',
      },
    },
  },
  args: {
    variant: 'primary',
    children: <PrimaryKpiContent />,
  },
};

export const Action: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'CTA / destaque de ação. Superfície `$primary` (#2C412A) e texto `$on-primary`. Título: `Heading level={3} variant="sm"` (20px / linha 1.2). Dimensão do tile (ex.: 390×160) e ícone 24px ficam no layout do consumidor.',
      },
    },
  },
  args: {
    variant: 'action',
    padding: 'lg',
    children: <ActionCtaContent />,
  },
};

export const Accent: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'Uso: banner secundário com copy. Par ouro + marrom (`$on-tertiary-container` / `#4b3d19`) — melhor legibilidade para texto corrido.',
      },
    },
  },
  args: {
    variant: 'accent',
    children: <AccentBannerContent />,
  },
};

/** Entidade em destaque num conjunto — sage wash + `$outline`. Texto `$on-surface`. */
export const Highlight: Story = {
  args: {
    variant: 'highlight',
    padding: 'sm',
    interactive: true,
    href: '#',
    children: <SampleContent title="Highlight" />,
  },
};

export const PaddingNone: Story = {
  args: {
    padding: 'none',
    children: <SampleContent title="Padding none" />,
  },
};

export const PaddingSm: Story = {
  args: {
    padding: 'sm',
    children: <SampleContent title="Padding sm" />,
  },
};

export const PaddingLg: Story = {
  args: {
    padding: 'lg',
    children: <SampleContent title="Padding lg" />,
  },
};

export const Interactive: Story = {
  args: {
    interactive: true,
    onClick: fn(),
    children: <SampleContent title="Interactive" />,
  },
};

export const AllVariants: Story = {
  decorators: [
    (Story) => (
      <div style={{ maxWidth: 720 }}>
        <Story />
      </div>
    ),
  ],
  render: () => (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
        gap: 16,
      }}
    >
      {(
        ['surface', 'elevated', 'soft', 'inset', 'primary', 'action', 'accent', 'highlight'] as const
      ).map((variant) => (
        <Card key={variant} variant={variant}>
          {variant === 'primary' ? (
            <PrimaryKpiContent />
          ) : variant === 'action' ? (
            <ActionCtaContent />
          ) : variant === 'accent' ? (
            <AccentBannerContent />
          ) : (
            <SampleContent title={variant} />
          )}
        </Card>
      ))}
    </div>
  ),
};
