import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';

import { Card } from './Card';

describe('Card', () => {
  it('renderiza conteúdo em div não interativo por padrão', () => {
    render(<Card data-testid="card">Conteúdo</Card>);

    const card = screen.getByTestId('card');
    expect(card.tagName).toBe('DIV');
    expect(card).toHaveTextContent('Conteúdo');
    expect(card).not.toHaveAttribute('role', 'button');
  });

  it('suporta variantes surface e elevated', () => {
    const { rerender } = render(
      <Card variant="surface" data-testid="card">
        Surface
      </Card>,
    );

    expect(screen.getByTestId('card').className).toMatch(/surface/);

    rerender(
      <Card variant="elevated" data-testid="card">
        Elevated
      </Card>,
    );

    expect(screen.getByTestId('card').className).toMatch(/elevated/);
  });

  it('suporta variant action (CTA floresta) distinta de primary (KPI oliva)', () => {
    const { rerender } = render(
      <Card variant="action" data-testid="card">
        Nova demanda
      </Card>,
    );

    const action = screen.getByTestId('card');
    expect(action.className).toMatch(/action/);
    expect(action.className).not.toMatch(/primary/);
    const actionBg = getComputedStyle(action).backgroundColor;
    const actionColor = getComputedStyle(action).color;
    expect(actionBg).toBe('rgb(44, 65, 42)');
    expect(actionColor).toBe('rgb(255, 255, 255)');

    rerender(
      <Card variant="primary" data-testid="card">
        KPI
      </Card>,
    );

    const primary = screen.getByTestId('card');
    expect(primary.className).toMatch(/primary/);
    expect(primary.className).not.toMatch(/action/);
    expect(getComputedStyle(primary).backgroundColor).not.toBe(actionBg);
  });

  it('suporta variant highlight (featured) distinta de soft', () => {
    const { rerender } = render(
      <Card variant="highlight" data-testid="card">
        Destaque
      </Card>,
    );

    expect(screen.getByTestId('card').className).toMatch(/highlight/);

    rerender(
      <Card variant="soft" data-testid="card">
        Soft
      </Card>,
    );

    expect(screen.getByTestId('card').className).toMatch(/soft/);
    expect(screen.getByTestId('card').className).not.toMatch(/highlight/);
  });

  it('suporta paddings none, sm, md e lg', () => {
    const paddings = ['none', 'sm', 'md', 'lg'] as const;

    paddings.forEach((padding) => {
      const { unmount } = render(
        <Card padding={padding} data-testid={`card-${padding}`}>
          {padding}
        </Card>,
      );

      expect(screen.getByTestId(`card-${padding}`).className).toMatch(
        new RegExp(`padding${padding === 'none' ? 'None' : padding.charAt(0).toUpperCase() + padding.slice(1)}`),
      );
      unmount();
    });
  });

  it('renderiza link semântico quando recebe href', () => {
    render(
      <Card href="/relatorios" data-testid="card">
        Atalho
      </Card>,
    );

    const card = screen.getByRole('link', { name: 'Atalho' });
    expect(card).toHaveAttribute('href', '/relatorios');
    expect(card.className).toMatch(/interactive/);
  });

  it('renderiza botão semântico quando recebe onClick', () => {
    const handleClick = vi.fn();

    render(
      <Card onClick={handleClick} data-testid="card">
        Ação
      </Card>,
    );

    const card = screen.getByRole('button', { name: 'Ação' });
    expect(card.tagName).toBe('BUTTON');
    expect(card).toHaveAttribute('type', 'button');

    fireEvent.click(card);
    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  it('é focável quando renderizado como botão nativo', () => {
    render(
      <Card onClick={vi.fn()} data-testid="card">
        Ação
      </Card>,
    );

    const card = screen.getByRole('button', { name: 'Ação' });
    card.focus();

    expect(card).toHaveFocus();
    expect(card).toBeInstanceOf(HTMLButtonElement);
  });

  it('aplica classe interativa sem role de botão quando usado só como contêiner visual', () => {
    render(
      <Card interactive data-testid="card">
        Painel
      </Card>,
    );

    const card = screen.getByTestId('card');
    expect(card.className).toMatch(/interactive/);
    expect(card).not.toHaveAttribute('role', 'button');
  });
});
