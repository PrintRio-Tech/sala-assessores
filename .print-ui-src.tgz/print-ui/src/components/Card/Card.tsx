import type { ComponentPropsWithoutRef, ReactNode } from 'react';

import styles from './styles.module.scss';

export type CardVariant =
  | 'surface'
  | 'elevated'
  | 'soft'
  | 'inset'
  | 'primary'
  | 'accent'
  | 'highlight'
  | 'action';

export type CardPadding = 'none' | 'sm' | 'md' | 'lg';

type CardOwnProps = {
  variant?: CardVariant;
  padding?: CardPadding;
  interactive?: boolean;
  className?: string;
  children?: ReactNode;
};

export type CardProps =
  | (CardOwnProps & ComponentPropsWithoutRef<'div'>)
  | (CardOwnProps & ComponentPropsWithoutRef<'a'> & { href: string })
  | (CardOwnProps &
      ComponentPropsWithoutRef<'button'> & {
        href?: never;
        onClick: NonNullable<ComponentPropsWithoutRef<'button'>['onClick']>;
      });

const variantClass: Record<CardVariant, string> = {
  surface: styles.surface,
  elevated: styles.elevated,
  soft: styles.soft,
  inset: styles.inset,
  primary: styles.primary,
  accent: styles.accent,
  highlight: styles.highlight,
  action: styles.action,
};

const paddingClass: Record<CardPadding, string> = {
  none: styles.paddingNone,
  sm: styles.paddingSm,
  md: styles.paddingMd,
  lg: styles.paddingLg,
};

function buildCardClasses({
  variant,
  padding,
  interactive,
  className,
}: {
  variant: CardVariant;
  padding: CardPadding;
  interactive: boolean;
  className?: string;
}) {
  return [
    styles.card,
    variantClass[variant],
    paddingClass[padding],
    interactive ? styles.interactive : undefined,
    className,
  ]
    .filter(Boolean)
    .join(' ');
}

export function Card({
  variant = 'surface',
  padding = 'md',
  interactive = false,
  className,
  children,
  ...rest
}: CardProps) {
  const href = 'href' in rest ? rest.href : undefined;
  const onClick = 'onClick' in rest ? rest.onClick : undefined;
  const showInteractive = interactive || Boolean(href) || typeof onClick === 'function';
  const classes = buildCardClasses({
    variant,
    padding,
    interactive: showInteractive,
    className,
  });

  if (typeof href === 'string' && href.length > 0) {
    const { href: linkHref, ...anchorRest } = rest as ComponentPropsWithoutRef<'a'>;

    return (
      <a href={linkHref} className={classes} {...anchorRest}>
        {children}
      </a>
    );
  }

  if (typeof onClick === 'function') {
    const {
      onClick: handleClick,
      type = 'button',
      ...buttonRest
    } = rest as ComponentPropsWithoutRef<'button'>;

    return (
      <button type={type} onClick={handleClick} className={classes} {...buttonRest}>
        {children}
      </button>
    );
  }

  return (
    <div className={classes} {...(rest as ComponentPropsWithoutRef<'div'>)}>
      {children}
    </div>
  );
}
