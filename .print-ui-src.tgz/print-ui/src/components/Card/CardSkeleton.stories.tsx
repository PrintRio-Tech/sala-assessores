import type { Meta, StoryObj } from '@storybook/react-vite';

import { CardSkeleton } from './CardSkeleton';

const meta = {
  title: 'Foundation/Card/CardSkeleton',
  component: CardSkeleton,
  tags: ['autodocs'],
  decorators: [
    (Story) => (
      <div style={{ maxWidth: 360 }}>
        <Story />
      </div>
    ),
  ],
  args: {
    variant: 'surface',
    padding: 'md',
    withMedia: false,
  },
  argTypes: {
    variant: {
      control: 'select',
      options: ['surface', 'elevated', 'soft', 'inset', 'primary', 'accent'],
    },
    padding: {
      control: 'select',
      options: ['none', 'sm', 'md', 'lg'],
    },
  },
} satisfies Meta<typeof CardSkeleton>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const WithMedia: Story = {
  args: { withMedia: true },
};

export const Elevated: Story = {
  args: { variant: 'elevated', withMedia: true },
};
