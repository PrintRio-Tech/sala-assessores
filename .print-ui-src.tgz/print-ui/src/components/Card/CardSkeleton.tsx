import type { ComponentPropsWithoutRef } from 'react';

import { BoneBlock, BoneLine, BoneRoot } from '../Skeleton/bones';
import { Card, type CardPadding, type CardVariant } from './Card';

import styles from './CardSkeleton.module.scss';

export type CardSkeletonProps = {
  variant?: CardVariant;
  padding?: CardPadding;
  /** Inclui bloco de mídia no topo. */
  withMedia?: boolean;
  className?: string;
} & Omit<ComponentPropsWithoutRef<'div'>, 'children'>;

export function CardSkeleton({
  variant = 'surface',
  padding = 'md',
  withMedia = false,
  className,
  ...props
}: CardSkeletonProps) {
  return (
    <Card
      variant={variant}
      padding={padding}
      className={[styles.root, className].filter(Boolean).join(' ')}
      aria-busy="true"
      aria-label="Carregando"
      {...props}
    >
      <BoneRoot className={styles.stack}>
        {withMedia ? <BoneBlock className={styles.media} height={120} /> : null}
        <BoneLine width="55%" />
        <BoneLine width="100%" />
        <BoneLine width="72%" />
      </BoneRoot>
    </Card>
  );
}
