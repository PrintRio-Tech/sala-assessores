import type { Meta, StoryObj } from '@storybook/react-vite';

import { Chart, type ChartDatum } from './Chart';

const weekly: ChartDatum[] = [
  { label: 'Seg', value: 12 },
  { label: 'Ter', value: 18 },
  { label: 'Qua', value: 9 },
  { label: 'Qui', value: 22 },
  { label: 'Sex', value: 15 },
  { label: 'Sáb', value: 7 },
  { label: 'Dom', value: 4 },
];

const month: ChartDatum[] = Array.from({ length: 30 }, (_, i) => ({
  label: `${i + 1}`,
  value: Math.round(8 + 10 * Math.sin(i / 3.2) + (i % 5) * 1.4),
}));

const categories: ChartDatum[] = [
  { label: 'Política', value: 42 },
  { label: 'Esporte', value: 28 },
  { label: 'Cultura', value: 19 },
  { label: 'Economia', value: 31 },
];

const meta = {
  title: 'Data/Chart',
  component: Chart,
  tags: ['autodocs'],
  args: {
    type: 'line',
    data: weekly,
    height: 200,
    animate: true,
    loading: false,
    'aria-label': 'Matérias por dia',
  },
  argTypes: {
    type: {
      control: 'select',
      options: ['line', 'bar', 'horizontal-bar', 'donut'],
    },
    colorMode: {
      control: 'select',
      options: ['single', 'auto'],
    },
    animate: { control: 'boolean' },
    height: { control: { type: 'number', min: 120, max: 400, step: 10 } },
    loading: { control: 'boolean' },
  },
  decorators: [
    (Story) => (
      <div style={{ maxWidth: 720, padding: 16 }}>
        <Story />
      </div>
    ),
  ],
} satisfies Meta<typeof Chart>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Line: Story = {
  args: {
    type: 'line',
    data: weekly,
    'aria-label': 'Tendência semanal',
  },
};

export const LineMonth: Story = {
  name: 'Line (30 days)',
  args: {
    type: 'line',
    data: month,
    height: 220,
    'aria-label': 'Tendência do mês',
  },
};

export const LineWideCard: Story = {
  name: 'Line in wide card',
  decorators: [
    (Story) => (
      <div
        style={{
          maxWidth: 960,
          padding: 24,
          borderRadius: 16,
          background: 'var(--pf-surface-container-lowest, #fff)',
          boxShadow: '0 8px 30px rgba(0,0,0,0.06)',
        }}
      >
        <Story />
      </div>
    ),
  ],
  args: {
    type: 'line',
    data: month,
    height: 240,
    'aria-label': 'Série em card largo',
  },
};

export const Bar: Story = {
  name: 'Bar (single primary)',
  args: {
    type: 'bar',
    data: weekly,
    'aria-label': 'Matérias por dia',
  },
};

export const BarCategorical: Story = {
  name: 'Bar colorMode=auto',
  args: {
    type: 'bar',
    data: weekly,
    colorMode: 'auto',
    'aria-label': 'Matérias por dia (categórico)',
  },
};

export const HorizontalBar: Story = {
  name: 'Horizontal bar (auto)',
  args: {
    type: 'horizontal-bar',
    data: categories,
    height: 220,
    'aria-label': 'Matérias por categoria',
  },
};

export const Donut: Story = {
  name: 'Donut (canais)',
  args: {
    type: 'donut',
    data: [
      { label: 'Imprensa', value: 40 },
      { label: 'Social', value: 25 },
      { label: 'Rádio', value: 15 },
      { label: 'TV', value: 20 },
    ],
    height: 220,
    'aria-label': 'Canais de distribuição',
  },
};

export const DonutWithZero: Story = {
  name: 'Donut com zero',
  args: {
    type: 'donut',
    data: [
      { label: 'Ativo', value: 70 },
      { label: 'Pausado', value: 0 },
      { label: 'Arquivado', value: 30 },
    ],
    height: 200,
    'aria-label': 'Status com zero',
  },
};

export const DonutEmpty: Story = {
  name: 'Donut vazio',
  args: {
    type: 'donut',
    data: [],
    height: 180,
    'aria-label': 'Sem série',
  },
};

export const Loading: Story = {
  args: {
    loading: true,
    'aria-label': 'Carregando gráfico',
  },
};

export const SinglePoint: Story = {
  args: {
    type: 'line',
    data: [{ label: 'Hoje', value: 14 }],
    'aria-label': 'Publicações de hoje',
  },
};
