import { render, screen, within } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { Chart } from './Chart';

const sample = [
  { label: 'Seg', value: 12 },
  { label: 'Ter', value: 18 },
  { label: 'Qua', value: 9 },
];

const month = Array.from({ length: 30 }, (_, i) => ({
  label: `${i + 1}`,
  value: i + 1,
}));

describe('Chart', () => {
  it('expõe role img com aria-label', () => {
    render(
      <Chart type="bar" data={sample} aria-label="Matérias por dia" />,
    );

    expect(
      screen.getByRole('img', { name: 'Matérias por dia' }),
    ).toBeInTheDocument();
  });

  it('marca aria-busy quando loading', () => {
    render(<Chart type="line" data={sample} loading aria-label="Carregando" />);

    expect(screen.getByRole('img', { name: 'Carregando' })).toHaveAttribute(
      'aria-busy',
      'true',
    );
  });

  it('line com muitos pontos amostra labels do eixo (não todos)', () => {
    const { container } = render(
      <Chart type="line" data={month} aria-label="Mês" />,
    );

    const labels = container.querySelectorAll('svg text');
    // Sampled: first + last + ~4 inner ≈ ≤6 text nodes for axis
    expect(labels.length).toBeLessThanOrEqual(8);
    expect(labels.length).toBeGreaterThanOrEqual(2);
    expect(labels.length).toBeLessThan(month.length);
  });

  it('line renderiza área sob a curva e stroke', () => {
    const { container } = render(
      <Chart type="line" data={sample} aria-label="Semana" />,
    );

    const paths = container.querySelectorAll('path');
    expect(paths.length).toBeGreaterThanOrEqual(2);
    const filled = [...paths].some((p) => (p.getAttribute('fill') ?? 'none') !== 'none');
    const stroked = [...paths].some(
      (p) => p.getAttribute('stroke') && p.getAttribute('fill') === 'none',
    );
    expect(filled).toBe(true);
    expect(stroked).toBe(true);
  });

  it('bar usa fill único primary por padrão', () => {
    const { container } = render(
      <Chart type="bar" data={sample} aria-label="Série" />,
    );

    const fills = [...container.querySelectorAll('rect')].map((r) =>
      r.getAttribute('fill'),
    );
    expect(fills.length).toBe(sample.length);
    expect(new Set(fills)).toEqual(new Set(['var(--pf-primary)']));
  });

  it('bar colorMode=auto cicla a paleta', () => {
    const { container } = render(
      <Chart type="bar" data={sample} colorMode="auto" aria-label="Categorias" />,
    );

    const fills = new Set(
      [...container.querySelectorAll('rect')].map((r) => r.getAttribute('fill')),
    );
    expect(fills.size).toBeGreaterThan(1);
  });

  it('animate=false não aplica classes de entrada nas barras', () => {
    const { container } = render(
      <Chart type="bar" data={sample} animate={false} aria-label="Estático" />,
    );

    const rects = [...container.querySelectorAll('rect')];
    expect(rects.every((r) => !r.className.baseVal.includes('barGrow'))).toBe(
      true,
    );
  });

  describe('donut', () => {
    const channels = [
      { label: 'Imprensa', value: 40 },
      { label: 'Social', value: 25 },
      { label: 'Rádio', value: 15 },
      { label: 'TV', value: 20 },
    ];

    it('expõe role img, aria-label e legenda textual acessível', () => {
      render(
        <Chart type="donut" data={channels} aria-label="Canais de distribuição" />,
      );

      expect(
        screen.getByRole('img', { name: 'Canais de distribuição' }),
      ).toBeInTheDocument();

      const legend = screen.getByRole('list', { name: /legenda/i });
      expect(legend).toBeInTheDocument();
      expect(within(legend).getByText(/Imprensa/)).toBeInTheDocument();
      expect(within(legend).getByText(/Social/)).toBeInTheDocument();
    });

    it('legenda não é descendente de role=img (ARIA presentational)', () => {
      render(
        <Chart type="donut" data={channels} aria-label="Canais estrutural" />,
      );

      const graphic = screen.getByRole('img', { name: 'Canais estrutural' });
      const legend = screen.getByRole('list', { name: /legenda/i });
      expect(graphic.contains(legend)).toBe(false);
      expect(legend.closest('[role="img"]')).toBeNull();

      const group = screen.getByRole('group', { name: 'Canais estrutural' });
      expect(group.contains(graphic)).toBe(true);
      expect(group.contains(legend)).toBe(true);
    });

    it('renderiza segmentos SVG proporcionais (paths) com paleta distinguível', () => {
      const { container } = render(
        <Chart type="donut" data={channels} aria-label="Canais" />,
      );

      const slices = container.querySelectorAll('[data-chart-slice]');
      expect(slices.length).toBe(channels.length);
      const fills = new Set(
        [...slices].map((s) => s.getAttribute('fill') || s.getAttribute('stroke')),
      );
      expect(fills.size).toBeGreaterThan(1);
    });

    it('inclui fatias de valor zero na legenda sem path angular', () => {
      const withZero = [
        { label: 'A', value: 10 },
        { label: 'B', value: 0 },
        { label: 'C', value: 5 },
      ];
      const { container } = render(
        <Chart type="donut" data={withZero} aria-label="Com zero" />,
      );

      expect(within(screen.getByRole('list', { name: /legenda/i })).getByText(/B/)).toBeInTheDocument();
      const slices = container.querySelectorAll('[data-chart-slice]');
      // Só fatias com valor > 0 geram arco
      expect(slices.length).toBe(2);
    });

    it('empty / todos zero: estado vazio coerente sem overflow', () => {
      const { rerender } = render(
        <Chart type="donut" data={[]} aria-label="Vazio" />,
      );
      expect(screen.getByRole('img', { name: 'Vazio' })).toBeInTheDocument();
      expect(screen.getByText(/sem dados/i)).toBeInTheDocument();

      rerender(
        <Chart
          type="donut"
          data={[
            { label: 'A', value: 0 },
            { label: 'B', value: 0 },
          ]}
          aria-label="Zeros"
        />,
      );
      expect(screen.getByRole('img', { name: 'Zeros' })).toBeInTheDocument();
      expect(screen.getByText(/sem dados/i)).toBeInTheDocument();
    });

    it('loading marca aria-busy', () => {
      render(
        <Chart
          type="donut"
          data={channels}
          loading
          aria-label="Donut loading"
        />,
      );
      expect(screen.getByRole('img', { name: 'Donut loading' })).toHaveAttribute(
        'aria-busy',
        'true',
      );
    });

    it('animate=false não aplica classes de entrada no donut', () => {
      const { container } = render(
        <Chart
          type="donut"
          data={channels}
          animate={false}
          aria-label="Donut estático"
        />,
      );
      const slices = [...container.querySelectorAll('[data-chart-slice]')];
      expect(
        slices.every((s) => !String(s.className.baseVal || s.className).includes('donutReveal')),
      ).toBe(true);
    });
  });
});
