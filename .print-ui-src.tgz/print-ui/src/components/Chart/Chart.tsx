import {
  useId,
  useLayoutEffect,
  useRef,
  type CSSProperties,
} from 'react';

import { BoneBlock } from '../Skeleton/bones';

import styles from './styles.module.scss';

export type ChartDatum = {
  label: string;
  value: number;
};

export type ChartType = 'line' | 'bar' | 'horizontal-bar' | 'donut';

/** `single` = one primary fill (time series). `auto` = categorical palette. */
export type ChartColorMode = 'auto' | 'single';

export type ChartProps = {
  type: ChartType;
  data: ChartDatum[];
  height?: number;
  /**
   * Bar/donut fill strategy. Defaults: `single` for `bar`/`line`, `auto` for
   * `horizontal-bar` and `donut`. Ignored for `line`.
   */
  colorMode?: ChartColorMode;
  /** Entrance motion. Honors `prefers-reduced-motion`. Default true. */
  animate?: boolean;
  loading?: boolean;
  className?: string;
  'aria-label'?: string;
};

const PRIMARY = 'var(--pf-primary)';
const TERTIARY = 'var(--pf-tertiary)';
const GOLD = 'var(--pf-accent-gold)';
const SECONDARY = 'var(--pf-secondary)';
const ERROR = 'var(--pf-error)';

const BAR_COLORS = [PRIMARY, TERTIARY, GOLD, SECONDARY, ERROR] as const;


function barFill(index: number, colorMode: ChartColorMode): string {
  return colorMode === 'single' ? PRIMARY : BAR_COLORS[index % BAR_COLORS.length];
}

/** Logical SVG width — scales with container via width=100%. */
const VB_WIDTH = 640;

function maxValue(data: ChartDatum[]): number {
  return Math.max(1, ...data.map((d) => d.value));
}

/** Sample axis labels: first + last + evenly spaced (cap ~6). */
function labelIndices(length: number, maxLabels = 6): Set<number> {
  if (length <= 0) return new Set();
  if (length <= maxLabels) {
    return new Set(Array.from({ length }, (_, i) => i));
  }
  const indices = new Set<number>([0, length - 1]);
  const inner = maxLabels - 2;
  for (let k = 1; k <= inner; k++) {
    indices.add(Math.round((k * (length - 1)) / (inner + 1)));
  }
  return indices;
}

function prefersReducedMotion(): boolean {
  return (
    typeof window !== 'undefined' &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches
  );
}

function staggerMs(index: number): string {
  return `${Math.min(index * 24, 120)}ms`;
}

type Point = { x: number; y: number; label: string; value: number };

function buildPoints(
  data: ChartDatum[],
  pad: { top: number; right: number; bottom: number; left: number },
  height: number,
  width: number,
): Point[] {
  const innerW = width - pad.left - pad.right;
  const innerH = height - pad.top - pad.bottom;
  const max = maxValue(data);

  return data.map((d, i) => {
    const x =
      data.length === 1
        ? pad.left + innerW / 2
        : pad.left + (i / (data.length - 1)) * innerW;
    const y = pad.top + innerH - (d.value / max) * innerH;
    return { x, y, label: d.label, value: d.value };
  });
}

function LineChart({
  data,
  height,
  animate,
}: {
  data: ChartDatum[];
  height: number;
  animate: boolean;
}) {
  const gradId = useId().replace(/:/g, '');
  const lineRef = useRef<SVGPathElement>(null);
  const pad = { top: 16, right: 16, bottom: 28, left: 16 };
  const innerH = height - pad.top - pad.bottom;
  const baselineY = pad.top + innerH;
  const midY = pad.top + innerH / 2;
  const points = buildPoints(data, pad, height, VB_WIDTH);
  const shownLabels = labelIndices(data.length);
  const shouldAnimate = animate && !prefersReducedMotion();

  const linePath = points
    .map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`)
    .join(' ');

  const areaPath =
    points.length === 0
      ? ''
      : [
          `M ${points[0].x.toFixed(1)} ${baselineY.toFixed(1)}`,
          ...points.map((p) => `L ${p.x.toFixed(1)} ${p.y.toFixed(1)}`),
          `L ${points[points.length - 1].x.toFixed(1)} ${baselineY.toFixed(1)}`,
          'Z',
        ].join(' ');

  useLayoutEffect(() => {
    const el = lineRef.current;
    if (!el || !linePath) return;

    if (!shouldAnimate || typeof el.getTotalLength !== 'function') {
      el.style.strokeDasharray = '';
      el.style.strokeDashoffset = '';
      return;
    }

    const length = el.getTotalLength();
    el.style.transition = 'none';
    el.style.strokeDasharray = `${length}`;
    el.style.strokeDashoffset = `${length}`;
    // Force layout so the browser commits the "hidden" state before reveal.
    el.getBoundingClientRect();
    el.style.transition = '';
    el.style.strokeDashoffset = '0';
  }, [linePath, shouldAnimate]);

  return (
    <svg
      className={styles.svg}
      viewBox={`0 0 ${VB_WIDTH} ${height}`}
      width="100%"
      height={height}
      preserveAspectRatio="none"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={`area-${gradId}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={PRIMARY} stopOpacity="0.22" />
          <stop offset="100%" stopColor={PRIMARY} stopOpacity="0.02" />
        </linearGradient>
      </defs>

      <line
        x1={pad.left}
        y1={midY}
        x2={VB_WIDTH - pad.right}
        y2={midY}
        className={styles.gridLine}
      />
      <line
        x1={pad.left}
        y1={baselineY}
        x2={VB_WIDTH - pad.right}
        y2={baselineY}
        className={styles.baseline}
      />

      {areaPath ? (
        <path
          d={areaPath}
          fill={`url(#area-${gradId})`}
          stroke="none"
          className={shouldAnimate ? styles.areaReveal : undefined}
        />
      ) : null}

      {linePath ? (
        <path
          ref={lineRef}
          d={linePath}
          fill="none"
          stroke={PRIMARY}
          strokeWidth="2.5"
          strokeLinejoin="round"
          strokeLinecap="round"
          vectorEffect="non-scaling-stroke"
          className={shouldAnimate ? styles.lineReveal : undefined}
        />
      ) : null}

      {points.map((p) => (
        <circle
          key={p.label}
          cx={p.x}
          cy={p.y}
          r="8"
          fill="transparent"
          className={styles.hitTarget}
        >
          <title>
            {p.label}: {p.value}
          </title>
        </circle>
      ))}

      {points.map((p, i) =>
        shownLabels.has(i) ? (
          <text
            key={`label-${p.label}`}
            x={p.x}
            y={height - 8}
            textAnchor="middle"
            className={styles.axisLabel}
          >
            {p.label}
          </text>
        ) : null,
      )}
    </svg>
  );
}

function BarChart({
  data,
  height,
  colorMode,
  animate,
}: {
  data: ChartDatum[];
  height: number;
  colorMode: ChartColorMode;
  animate: boolean;
}) {
  const pad = { top: 12, right: 12, bottom: 28, left: 12 };
  const innerW = VB_WIDTH - pad.left - pad.right;
  const innerH = height - pad.top - pad.bottom;
  const max = maxValue(data);
  const gap = Math.max(6, Math.min(14, innerW / (data.length * 6)));
  const barW = Math.max(10, (innerW - gap * Math.max(data.length - 1, 0)) / data.length);
  const shownLabels = labelIndices(data.length, data.length <= 10 ? 10 : 6);
  const baselineY = pad.top + innerH;
  const shouldAnimate = animate && !prefersReducedMotion();

  return (
    <svg
      className={styles.svg}
      viewBox={`0 0 ${VB_WIDTH} ${height}`}
      width="100%"
      height={height}
      preserveAspectRatio="none"
      aria-hidden="true"
    >
      <line
        x1={pad.left}
        y1={baselineY}
        x2={VB_WIDTH - pad.right}
        y2={baselineY}
        className={styles.baseline}
      />
      {data.map((d, i) => {
        const barH = (d.value / max) * innerH;
        const x = pad.left + i * (barW + gap);
        const y = pad.top + innerH - barH;
        const color = barFill(i, colorMode);

        return (
          <g key={d.label}>
            <rect
              x={x}
              y={y}
              width={barW}
              height={Math.max(barH, 2)}
              rx="6"
              ry="6"
              fill={color}
              className={shouldAnimate ? styles.barGrowY : undefined}
              style={
                shouldAnimate
                  ? ({ '--chart-stagger': staggerMs(i) } as CSSProperties)
                  : undefined
              }
            >
              <title>
                {d.label}: {d.value}
              </title>
            </rect>
            {shownLabels.has(i) ? (
              <text
                x={x + barW / 2}
                y={height - 8}
                textAnchor="middle"
                className={styles.axisLabel}
              >
                {d.label}
              </text>
            ) : null}
          </g>
        );
      })}
    </svg>
  );
}

function HorizontalBarChart({
  data,
  height,
  colorMode,
  animate,
}: {
  data: ChartDatum[];
  height: number;
  colorMode: ChartColorMode;
  animate: boolean;
}) {
  const pad = { top: 8, right: 16, bottom: 8, left: 88 };
  const rowH = Math.max(32, (height - pad.top - pad.bottom) / Math.max(data.length, 1));
  const innerW = VB_WIDTH - pad.left - pad.right;
  const max = maxValue(data);
  const svgH = Math.max(height, pad.top + pad.bottom + rowH * data.length);
  const barH = Math.max(10, rowH - 14);
  const shouldAnimate = animate && !prefersReducedMotion();

  return (
    <svg
      className={styles.svg}
      viewBox={`0 0 ${VB_WIDTH} ${svgH}`}
      width="100%"
      height={svgH}
      preserveAspectRatio="xMidYMid meet"
      aria-hidden="true"
    >
      {data.map((d, i) => {
        const barW = (d.value / max) * innerW;
        const y = pad.top + i * rowH + (rowH - barH) / 2;
        const color = barFill(i, colorMode);

        return (
          <g key={d.label}>
            <text
              x={pad.left - 10}
              y={pad.top + i * rowH + rowH / 2}
              textAnchor="end"
              dominantBaseline="middle"
              className={styles.axisLabel}
            >
              {d.label}
            </text>
            <rect
              x={pad.left}
              y={y}
              width={innerW}
              height={barH}
              rx="6"
              ry="6"
              className={styles.barTrack}
            />
            <rect
              x={pad.left}
              y={y}
              width={Math.max(barW, 4)}
              height={barH}
              rx="6"
              ry="6"
              fill={color}
              className={shouldAnimate ? styles.barGrowX : undefined}
              style={
                shouldAnimate
                  ? ({ '--chart-stagger': staggerMs(i) } as CSSProperties)
                  : undefined
              }
            >
              <title>
                {d.label}: {d.value}
              </title>
            </rect>
          </g>
        );
      })}
    </svg>
  );
}

function resolveColorMode(
  type: ChartType,
  colorMode: ChartColorMode | undefined,
): ChartColorMode {
  if (colorMode) return colorMode;
  return type === 'horizontal-bar' || type === 'donut' ? 'auto' : 'single';
}

const DONUT_VB = 200;
const DONUT_CX = 100;
const DONUT_CY = 100;
const DONUT_OUTER = 78;
const DONUT_INNER = 46;

function polar(cx: number, cy: number, r: number, angleRad: number) {
  return {
    x: cx + r * Math.cos(angleRad),
    y: cy + r * Math.sin(angleRad),
  };
}

/** Arc path for a donut slice from startAngle → endAngle (radians, 0 = east). */
function donutSlicePath(
  cx: number,
  cy: number,
  outerR: number,
  innerR: number,
  start: number,
  end: number,
): string {
  const large = end - start > Math.PI ? 1 : 0;
  const os = polar(cx, cy, outerR, start);
  const oe = polar(cx, cy, outerR, end);
  const ie = polar(cx, cy, innerR, end);
  const is = polar(cx, cy, innerR, start);
  return [
    `M ${os.x.toFixed(2)} ${os.y.toFixed(2)}`,
    `A ${outerR} ${outerR} 0 ${large} 1 ${oe.x.toFixed(2)} ${oe.y.toFixed(2)}`,
    `L ${ie.x.toFixed(2)} ${ie.y.toFixed(2)}`,
    `A ${innerR} ${innerR} 0 ${large} 0 ${is.x.toFixed(2)} ${is.y.toFixed(2)}`,
    'Z',
  ].join(' ');
}

function DonutChart({
  data,
  height,
  colorMode,
  animate,
  ariaLabel,
}: {
  data: ChartDatum[];
  height: number;
  colorMode: ChartColorMode;
  animate: boolean;
  ariaLabel: string;
}) {
  const shouldAnimate = animate && !prefersReducedMotion();
  const total = data.reduce((sum, d) => sum + Math.max(0, d.value), 0);
  const isEmpty = data.length === 0 || total <= 0;
  const size = Math.max(120, Math.min(height, 280));

  if (isEmpty) {
    return (
      <div className={styles.donutLayout}>
        <svg
          className={styles.svg}
          viewBox={`0 0 ${DONUT_VB} ${DONUT_VB}`}
          width={size}
          height={size}
          preserveAspectRatio="xMidYMid meet"
          role="img"
          aria-label={ariaLabel}
        >
          <circle
            cx={DONUT_CX}
            cy={DONUT_CY}
            r={(DONUT_OUTER + DONUT_INNER) / 2}
            fill="none"
            stroke="var(--pf-surface-container-low)"
            strokeWidth={DONUT_OUTER - DONUT_INNER}
          />
        </svg>
        <p className={styles.emptyMessage}>Sem dados</p>
      </div>
    );
  }

  // Start at top (−π/2).
  let angle = -Math.PI / 2;
  const slices = data
    .map((d, i) => {
      const value = Math.max(0, d.value);
      if (value <= 0) return null;
      const sweep = (value / total) * Math.PI * 2;
      const start = angle;
      const end = angle + sweep;
      angle = end;
      // Full circle edge case: tiny epsilon so arc path still draws.
      const safeEnd =
        sweep >= Math.PI * 2 - 1e-6 ? start + Math.PI * 2 - 0.0001 : end;
      return {
        key: `${d.label}-${i}`,
        label: d.label,
        value,
        path: donutSlicePath(
          DONUT_CX,
          DONUT_CY,
          DONUT_OUTER,
          DONUT_INNER,
          start,
          safeEnd,
        ),
        fill: barFill(i, colorMode),
        index: i,
      };
    })
    .filter((s): s is NonNullable<typeof s> => s != null);

  return (
    <div className={styles.donutLayout}>
      <svg
        className={styles.svg}
        viewBox={`0 0 ${DONUT_VB} ${DONUT_VB}`}
        width={size}
        height={size}
        preserveAspectRatio="xMidYMid meet"
        role="img"
        aria-label={ariaLabel}
      >
        {slices.map((slice) => (
          <path
            key={slice.key}
            d={slice.path}
            fill={slice.fill}
            data-chart-slice=""
            className={shouldAnimate ? styles.donutReveal : undefined}
            style={
              shouldAnimate
                ? ({ '--chart-stagger': staggerMs(slice.index) } as CSSProperties)
                : undefined
            }
          >
            <title>
              {slice.label}: {slice.value}
            </title>
          </path>
        ))}
      </svg>
      <ul className={styles.legend} aria-label="Legenda do gráfico">
        {data.map((d, i) => (
          <li key={`${d.label}-${i}`} className={styles.legendItem}>
            <span
              className={styles.legendSwatch}
              style={{ backgroundColor: barFill(i, colorMode) }}
              aria-hidden="true"
            />
            <span className={styles.legendLabel}>
              {d.label}: {d.value}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function Chart({
  type,
  data,
  height = 200,
  colorMode,
  animate = true,
  loading = false,
  className,
  'aria-label': ariaLabel = 'Gráfico',
}: ChartProps) {
  const classes = [styles.root, className].filter(Boolean).join(' ');
  const style = { '--chart-height': `${height}px` } as CSSProperties;
  const resolvedColorMode = resolveColorMode(type, colorMode);

  if (loading) {
    return (
      <div
        className={classes}
        style={style}
        role="img"
        aria-label={ariaLabel}
        aria-busy="true"
      >
        <BoneBlock className={styles.skeleton} height={height} width="100%" />
      </div>
    );
  }

  if (type === 'donut') {
    return (
      <div
        className={classes}
        style={style}
        role="group"
        aria-label={ariaLabel}
      >
        <DonutChart
          data={data}
          height={height}
          colorMode={resolvedColorMode}
          animate={animate}
          ariaLabel={ariaLabel}
        />
      </div>
    );
  }

  return (
    <div className={classes} style={style} role="img" aria-label={ariaLabel}>
      {type === 'line' ? (
        <LineChart data={data} height={height} animate={animate} />
      ) : null}
      {type === 'bar' ? (
        <BarChart
          data={data}
          height={height}
          colorMode={resolvedColorMode}
          animate={animate}
        />
      ) : null}
      {type === 'horizontal-bar' ? (
        <HorizontalBarChart
          data={data}
          height={height}
          colorMode={resolvedColorMode}
          animate={animate}
        />
      ) : null}
    </div>
  );
}

