import { Checkbox as BaseCheckbox } from '@base-ui-components/react/checkbox';
import { useId, type ReactNode } from 'react';

import styles from './styles.module.scss';

export type CheckboxProps = {
  checked?: boolean;
  defaultChecked?: boolean;
  onCheckedChange?: (checked: boolean) => void;
  disabled?: boolean;
  label?: ReactNode;
  indeterminate?: boolean;
  id?: string;
  name?: string;
  className?: string;
};

export function Checkbox({
  checked,
  defaultChecked,
  onCheckedChange,
  disabled = false,
  label,
  indeterminate = false,
  id: idProp,
  name,
  className,
}: CheckboxProps) {
  const generatedId = useId();
  const labelId = useId();
  const id = idProp ?? generatedId;
  const classes = [styles.root, className].filter(Boolean).join(' ');
  const stringLabel = typeof label === 'string' ? label : undefined;

  return (
    <label className={classes}>
      <BaseCheckbox.Root
        id={id}
        className={styles.checkbox}
        checked={checked}
        defaultChecked={defaultChecked}
        disabled={disabled}
        indeterminate={indeterminate}
        name={name}
        aria-label={stringLabel}
        aria-labelledby={label != null && !stringLabel ? labelId : undefined}
        onCheckedChange={(next) => onCheckedChange?.(next)}
      >
        <BaseCheckbox.Indicator
          className={styles.indicator}
          keepMounted={indeterminate}
        >
          {indeterminate ? (
            <span className={styles.dash} aria-hidden="true" />
          ) : (
            <svg
              className={styles.check}
              viewBox="0 0 12 12"
              fill="none"
              aria-hidden="true"
            >
              <path
                d="M2.5 6.2 4.8 8.5 9.5 3.5"
                stroke="currentColor"
                strokeWidth="1.75"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          )}
        </BaseCheckbox.Indicator>
      </BaseCheckbox.Root>
      {label != null ? (
        <span id={labelId} className={styles.label}>
          {label}
        </span>
      ) : null}
    </label>
  );
}
