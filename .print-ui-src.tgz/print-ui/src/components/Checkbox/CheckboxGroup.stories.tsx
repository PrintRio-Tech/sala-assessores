import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';

import { CheckboxGroup } from './CheckboxGroup';

const options = [
  { value: 'print', label: 'Imprensa' },
  { value: 'social', label: 'Redes sociais' },
  { value: 'tv', label: 'TV' },
];

const meta = {
  title: 'Forms/CheckboxGroup',
  component: CheckboxGroup,
  tags: ['autodocs'],
  args: {
    legend: 'Canais monitorados',
    name: 'channels',
    options,
    disabled: false,
  },
} satisfies Meta<typeof CheckboxGroup>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: { defaultValue: ['print'] },
};

export const Disabled: Story = {
  args: { disabled: true, defaultValue: ['print', 'social'] },
};

export const Controlled: Story = {
  render: function ControlledGroup(args) {
    const [value, setValue] = useState<string[]>(['social']);
    return (
      <CheckboxGroup {...args} value={value} onValueChange={setValue} />
    );
  },
};
