import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';

import { CheckboxGroup } from './CheckboxGroup';

const options = [
  { value: 'a', label: 'Alpha' },
  { value: 'b', label: 'Beta' },
];

describe('CheckboxGroup', () => {
  it('renderiza legend e opções', () => {
    render(
      <CheckboxGroup
        legend="Grupo"
        name="group"
        options={options}
        defaultValue={['a']}
      />,
    );

    expect(screen.getByText('Grupo')).toBeInTheDocument();
    expect(screen.getByRole('checkbox', { name: 'Alpha' })).toBeChecked();
    expect(screen.getByRole('checkbox', { name: 'Beta' })).not.toBeChecked();
  });

  it('atualiza seleção e chama onValueChange', () => {
    const onValueChange = vi.fn();

    render(
      <CheckboxGroup
        legend="Grupo"
        name="group"
        options={options}
        value={['a']}
        onValueChange={onValueChange}
      />,
    );

    fireEvent.click(screen.getByRole('checkbox', { name: 'Beta' }));
    expect(onValueChange).toHaveBeenCalledWith(['a', 'b']);
  });
});
