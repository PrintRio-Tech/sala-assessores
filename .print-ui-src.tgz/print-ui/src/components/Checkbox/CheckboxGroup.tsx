import { useState } from 'react';

import { Checkbox } from './Checkbox';

import styles from './styles.module.scss';

export type CheckboxGroupOption = {
  value: string;
  label: string;
};

export type CheckboxGroupProps = {
  legend: string;
  name: string;
  options: CheckboxGroupOption[];
  value?: string[];
  defaultValue?: string[];
  onValueChange?: (value: string[]) => void;
  disabled?: boolean;
  className?: string;
};

export function CheckboxGroup({
  legend,
  name,
  options,
  value,
  defaultValue,
  onValueChange,
  disabled = false,
  className,
}: CheckboxGroupProps) {
  const [uncontrolled, setUncontrolled] = useState<string[]>(
    defaultValue ?? [],
  );
  const isControlled = value !== undefined;
  const current = isControlled ? value : uncontrolled;

  const handleCheckedChange = (optionValue: string, checked: boolean) => {
    const next = checked
      ? [...current, optionValue]
      : current.filter((v) => v !== optionValue);

    if (!isControlled) {
      setUncontrolled(next);
    }
    onValueChange?.(next);
  };

  return (
    <fieldset
      className={[styles.group, className].filter(Boolean).join(' ')}
      disabled={disabled}
    >
      <legend className={styles.groupLegend}>{legend}</legend>
      {options.map((option) => (
        <Checkbox
          key={option.value}
          name={`${name}-${option.value}`}
          label={option.label}
          checked={current.includes(option.value)}
          onCheckedChange={(checked) =>
            handleCheckedChange(option.value, checked)
          }
          disabled={disabled}
        />
      ))}
    </fieldset>
  );
}
