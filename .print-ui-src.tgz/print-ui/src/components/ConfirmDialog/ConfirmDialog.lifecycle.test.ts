import { readFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

import { describe, expect, it } from 'vitest';

const here = dirname(fileURLToPath(import.meta.url));
const scss = readFileSync(join(here, 'styles.module.scss'), 'utf8');

describe('ConfirmDialog popup lifecycle CSS', () => {
  it('usa transition mínima (1ms) no popup — Base UI precisa de animations.finished', () => {
    expect(scss).toMatch(/\.popup\s*\{[\s\S]*?opacity 1ms linear/);
    expect(scss).toMatch(/\.popup\s*\{[\s\S]*?transform 1ms linear/);
    expect(scss).not.toMatch(
      /\.popup\s*\{[\s\S]*?transition:\s*[\s\S]*?\$duration-normal/,
    );
  });

  it('não prende enter em &[data-starting-style] — enter via @starting-style', () => {
    const popupBlock =
      scss.match(/\.popup\s*\{[\s\S]*?\n\}\n\n\.header/)?.[0] ?? '';
    expect(popupBlock).toMatch(/@starting-style/);
    expect(popupBlock).not.toMatch(
      /&\[data-starting-style\],\s*\n\s*&\[data-ending-style\]/,
    );
  });

  it('cinto open: data-open sem ending/closed força opacity/transform finais', () => {
    expect(scss).toMatch(
      /&\[data-open\]:not\(\[data-ending-style\]\):not\(\[data-closed\]\)/,
    );
    expect(scss).toMatch(
      /&\[data-open\]:not\(\[data-ending-style\]\):not\(\[data-closed\]\)\s*\{[\s\S]*?opacity:\s*1/,
    );
  });

  it('exit ending/closed esconde imediatamente (visibility + pointer-events)', () => {
    expect(scss).toMatch(/&\[data-ending-style\],\s*\n\s*&\[data-closed\]/);
    expect(scss).toMatch(/visibility:\s*hidden/);
    expect(scss).toMatch(/pointer-events:\s*none/);
  });
});
