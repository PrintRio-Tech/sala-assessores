import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';

import { Button } from '../Button/Button';

import { ConfirmDialog } from './ConfirmDialog';

const meta = {
  title: 'Overlay/ConfirmDialog',
  component: ConfirmDialog,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component: [
          'Diálogo de confirmação canônico do DS (substitui o uso de `Modal`/`Dialog` do print-forms na migração).',
          '',
          '**Paridade com Modal do forms:**',
          '- Trigger: passe `children` (ex.: botão) — modo não controlado',
          '- Controlled: `open` + `onOpenChange`',
          '- `destructive` → botão confirmar com variante `danger`',
          '- `loading` / `loadingLabel` — bloqueia fechar enquanto confirma',
          '',
          '`Dialog`/`Modal` crus do forms ficam no app até migrar; não há export paralelo no print-ui.',
        ].join('\n'),
      },
    },
  },
  args: {
    title: 'Confirmar ação?',
    description: 'Esta ação pode ser revertida depois.',
    confirmLabel: 'Confirmar',
    cancelLabel: 'Cancelar',
  },
} satisfies Meta<typeof ConfirmDialog>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  render: function Render(args) {
    const [open, setOpen] = useState(false);

    return (
      <>
        <Button type="button" onClick={() => setOpen(true)}>
          Abrir diálogo
        </Button>
        <ConfirmDialog
          {...args}
          open={open}
          onOpenChange={setOpen}
          onConfirm={() => setOpen(false)}
        />
      </>
    );
  },
};

export const WithTrigger: Story = {
  name: 'Trigger (como Modal forms)',
  render: function Render(args) {
    return (
      <ConfirmDialog
        {...args}
        title="Publicar release?"
        description="O conteúdo ficará visível para a equipe."
        onConfirm={() => undefined}
      >
        <Button type="button">Abrir via trigger</Button>
      </ConfirmDialog>
    );
  },
};

export const Destructive: Story = {
  args: {
    title: 'Excluir item?',
    description: 'Esta ação não pode ser desfeita.',
    confirmLabel: 'Excluir',
    destructive: true,
  },
  render: function Render(args) {
    const [open, setOpen] = useState(false);

    return (
      <>
        <Button type="button" variant="danger" onClick={() => setOpen(true)}>
          Excluir
        </Button>
        <ConfirmDialog
          {...args}
          open={open}
          onOpenChange={setOpen}
          onConfirm={() => setOpen(false)}
        />
      </>
    );
  },
};

export const WithBody: Story = {
  args: {
    title: 'Revogar acesso?',
    description: 'Esta ação bloqueia o login.',
    body: <p>Revogar o acesso de Maria Silva?</p>,
    confirmLabel: 'Revogar',
  },
  render: function Render(args) {
    const [open, setOpen] = useState(false);

    return (
      <>
        <Button type="button" onClick={() => setOpen(true)}>
          Revogar acesso
        </Button>
        <ConfirmDialog
          {...args}
          open={open}
          onOpenChange={setOpen}
          onConfirm={() => setOpen(false)}
        />
      </>
    );
  },
};

export const Loading: Story = {
  args: {
    title: 'Salvar alterações?',
    description: 'O diálogo permanece aberto enquanto a confirmação roda.',
    confirmLabel: 'Salvar',
    loadingLabel: 'Salvando…',
  },
  render: function Render(args) {
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);

    return (
      <>
        <Button type="button" onClick={() => setOpen(true)}>
          Abrir com loading
        </Button>
        <ConfirmDialog
          {...args}
          open={open}
          onOpenChange={(next) => {
            if (!loading) {
              setOpen(next);
            }
          }}
          loading={loading}
          onConfirm={async () => {
            setLoading(true);
            await new Promise((resolve) => {
              setTimeout(resolve, 1500);
            });
            setLoading(false);
            setOpen(false);
          }}
        />
      </>
    );
  },
};
