import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import type { UserEvent } from '@testing-library/user-event';
import { useState } from 'react';
import { describe, expect, it, vi } from 'vitest';

import { Button } from '../Button/Button';

import { ConfirmDialog } from './ConfirmDialog';

function isWithinDialogPopup(
  activeElement: Element | null,
  dialog: HTMLElement,
): boolean {
  return activeElement !== null && dialog.contains(activeElement);
}

function getDialogBackdrop() {
  const dialog = screen.getByRole('dialog');
  const portal = dialog.closest('[data-base-ui-portal]');
  return portal?.querySelector('[class*="backdrop"]') ?? null;
}

async function openConfirmDialog(user: UserEvent, triggerLabel = 'Abrir diálogo') {
  const trigger = screen.getByRole('button', { name: triggerLabel });
  await user.click(trigger);
  await screen.findByRole('dialog');
  return trigger;
}

describe('ConfirmDialog', () => {
  it('abre via gatilho e exibe título', async () => {
    render(
      <ConfirmDialog title="Excluir item?" onConfirm={() => undefined}>
        <Button type="button">Excluir</Button>
      </ConfirmDialog>,
    );

    fireEvent.click(screen.getByRole('button', { name: 'Excluir' }));

    await waitFor(() => {
      expect(screen.getByRole('dialog')).toBeInTheDocument();
      expect(screen.getByText('Excluir item?')).toBeInTheDocument();
    });
  });

  it('renderiza descrição e corpo quando fornecidos', () => {
    render(
      <ConfirmDialog
        open
        title="Revogar acesso?"
        description="Esta ação bloqueia o login."
        body={<p>Revogar o acesso de Maria?</p>}
        onOpenChange={() => undefined}
        onConfirm={() => undefined}
      />,
    );

    expect(screen.getByText('Esta ação bloqueia o login.')).toBeInTheDocument();
    expect(screen.getByText('Revogar o acesso de Maria?')).toBeInTheDocument();
  });

  it('aberto: dialog data-open sem data-starting-style preso', async () => {
    render(
      <ConfirmDialog
        open
        title="Desativar usuário?"
        onOpenChange={() => undefined}
        onConfirm={() => undefined}
      />,
    );

    const dialog = await screen.findByRole('dialog');
    expect(dialog).toHaveAttribute('data-open');
    expect(dialog).not.toHaveAttribute('data-starting-style');
    expect(dialog).not.toHaveAttribute('data-ending-style');
  });

  it('fechado: remove dialog sem residual ending/closed', async () => {
    function Harness() {
      const [open, setOpen] = useState(true);
      return (
        <>
          <button type="button" onClick={() => setOpen(false)}>
            Fechar harness
          </button>
          <ConfirmDialog
            open={open}
            title="Desativar?"
            onOpenChange={setOpen}
            onConfirm={() => undefined}
          />
        </>
      );
    }

    render(<Harness />);
    expect(await screen.findByRole('dialog')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'Cancelar' }));

    await waitFor(() => {
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    });
    expect(
      document.querySelector('[data-ending-style], [data-closed]'),
    ).toBeNull();
  });

  it('chama onConfirm ao confirmar e não ao cancelar', async () => {
    const onConfirm = vi.fn();

    render(
      <ConfirmDialog
        open
        title="Confirmar"
        onOpenChange={() => undefined}
        onConfirm={onConfirm}
      />,
    );

    fireEvent.click(screen.getByRole('button', { name: 'Cancelar' }));
    expect(onConfirm).not.toHaveBeenCalled();

    fireEvent.click(screen.getByRole('button', { name: 'Confirmar' }));
    await waitFor(() => {
      expect(onConfirm).toHaveBeenCalledTimes(1);
    });
  });

  it('usa rótulos customizados e variante destrutiva', () => {
    render(
      <ConfirmDialog
        open
        title="Revogar acesso?"
        confirmLabel="Revogar acesso"
        cancelLabel="Manter acesso"
        destructive
        onOpenChange={() => undefined}
        onConfirm={() => undefined}
      />,
    );

    expect(screen.getByRole('button', { name: 'Revogar acesso' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Manter acesso' })).toBeInTheDocument();
  });

  it('desabilita ações e exibe loadingLabel enquanto loading', () => {
    render(
      <ConfirmDialog
        open
        title="Revogar acesso?"
        loading
        loadingLabel="Revogando…"
        onOpenChange={() => undefined}
        onConfirm={() => undefined}
      />,
    );

    expect(screen.getByRole('button', { name: 'Revogando…' })).toBeDisabled();
    expect(screen.getByRole('button', { name: 'Cancelar' })).toBeDisabled();
  });

  it('impede duplo disparo de onConfirm durante promise interna', async () => {
    let resolveConfirm: (() => void) | undefined;
    const onConfirm = vi.fn(
      () =>
        new Promise<void>((resolve) => {
          resolveConfirm = resolve;
        }),
    );

    render(
      <ConfirmDialog title="Confirmar" onConfirm={onConfirm}>
        <Button type="button">Abrir</Button>
      </ConfirmDialog>,
    );

    fireEvent.click(screen.getByRole('button', { name: 'Abrir' }));

    await waitFor(() => {
      expect(screen.getByRole('dialog')).toBeInTheDocument();
    });

    const confirmButton = screen.getByRole('button', { name: 'Confirmar' });

    fireEvent.click(confirmButton);
    fireEvent.click(confirmButton);

    await waitFor(() => {
      expect(screen.getByRole('button', { name: 'Confirmando…' })).toBeDisabled();
    });
    expect(onConfirm).toHaveBeenCalledTimes(1);

    resolveConfirm?.();
    await waitFor(() => {
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    });
  });

  describe('critério 5 — focus trap e retorno de foco ao gatilho', () => {
    it('move o foco do gatilho para dentro do Dialog.Popup ao abrir', async () => {
      const user = userEvent.setup();

      render(
        <ConfirmDialog title="Confirmar ação?" onConfirm={() => undefined}>
          <Button type="button">Abrir diálogo</Button>
        </ConfirmDialog>,
      );

      const trigger = screen.getByRole('button', { name: 'Abrir diálogo' });
      trigger.focus();
      expect(document.activeElement).toBe(trigger);

      await user.click(trigger);

      const dialog = await screen.findByRole('dialog');
      await waitFor(() => {
        expect(document.activeElement).not.toBe(trigger);
        expect(isWithinDialogPopup(document.activeElement, dialog)).toBe(true);
      });
    });

    it('mantém Tab cíclico entre os botões do footer sem escapar para fora do Dialog.Popup', async () => {
      const user = userEvent.setup();

      render(
        <>
          <button type="button">Fora do diálogo</button>
          <ConfirmDialog title="Confirmar ação?" onConfirm={() => undefined}>
            <Button type="button">Abrir diálogo</Button>
          </ConfirmDialog>
        </>,
      );

      const outsideButton = screen.getByRole('button', { name: 'Fora do diálogo' });
      await openConfirmDialog(user);

      const dialog = screen.getByRole('dialog');
      const cancel = screen.getByRole('button', { name: 'Cancelar' });
      const confirm = screen.getByRole('button', { name: 'Confirmar' });

      await waitFor(() => {
        expect(isWithinDialogPopup(document.activeElement, dialog)).toBe(true);
      });

      cancel.focus();
      expect(document.activeElement).toBe(cancel);

      await user.tab();
      expect(document.activeElement).toBe(confirm);
      expect(isWithinDialogPopup(document.activeElement, dialog)).toBe(true);

      await user.tab({ shift: true });
      expect(document.activeElement).toBe(cancel);
      expect(isWithinDialogPopup(document.activeElement, dialog)).toBe(true);

      for (let index = 0; index < 3; index += 1) {
        await user.tab();
        expect(document.activeElement).toBe(confirm);
        expect(document.activeElement).not.toBe(outsideButton);
        expect(isWithinDialogPopup(document.activeElement, dialog)).toBe(true);

        await user.tab({ shift: true });
        expect(document.activeElement).toBe(cancel);
        expect(document.activeElement).not.toBe(outsideButton);
        expect(isWithinDialogPopup(document.activeElement, dialog)).toBe(true);
      }
    });

    it('retorna o foco ao gatilho ao fechar com Cancelar', async () => {
      const user = userEvent.setup();

      render(
        <ConfirmDialog title="Confirmar ação?" onConfirm={() => undefined}>
          <Button type="button">Abrir diálogo</Button>
        </ConfirmDialog>,
      );

      const trigger = await openConfirmDialog(user);

      await user.click(screen.getByRole('button', { name: 'Cancelar' }));

      await waitFor(() => {
        expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
      });
      expect(document.activeElement).toBe(trigger);
    });

    it('retorna o foco ao gatilho ao fechar com Confirmar', async () => {
      const user = userEvent.setup();

      render(
        <ConfirmDialog title="Confirmar ação?" onConfirm={() => undefined}>
          <Button type="button">Abrir diálogo</Button>
        </ConfirmDialog>,
      );

      const trigger = await openConfirmDialog(user);

      await user.click(screen.getByRole('button', { name: 'Confirmar' }));

      await waitFor(() => {
        expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
      });
      expect(document.activeElement).toBe(trigger);
    });

    it('retorna o foco ao gatilho ao fechar com Esc', async () => {
      const user = userEvent.setup();

      render(
        <ConfirmDialog title="Confirmar ação?" onConfirm={() => undefined}>
          <Button type="button">Abrir diálogo</Button>
        </ConfirmDialog>,
      );

      const trigger = await openConfirmDialog(user);

      await user.keyboard('{Escape}');

      await waitFor(() => {
        expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
      });
      expect(document.activeElement).toBe(trigger);
    });

    it('retorna o foco ao gatilho ao fechar com clique fora', async () => {
      const user = userEvent.setup();

      render(
        <ConfirmDialog title="Confirmar ação?" onConfirm={() => undefined}>
          <Button type="button">Abrir diálogo</Button>
        </ConfirmDialog>,
      );

      const trigger = await openConfirmDialog(user);
      const backdrop = getDialogBackdrop();
      expect(backdrop).not.toBeNull();

      await user.click(backdrop!);

      await waitFor(() => {
        expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
      });
      expect(document.activeElement).toBe(trigger);
    });
  });
});
