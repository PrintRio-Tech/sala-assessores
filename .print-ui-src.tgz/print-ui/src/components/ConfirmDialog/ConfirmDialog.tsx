import { Dialog } from '@base-ui-components/react/dialog';
import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type ReactElement,
  type ReactNode,
} from 'react';

import { Button } from '../Button/Button';

import styles from './styles.module.scss';

export type ConfirmDialogProps = {
  /** Elemento gatilho (modo não controlado). Omita quando usar `open` / `onOpenChange`. */
  children?: ReactElement<Record<string, unknown>>;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  title: string;
  description?: string;
  body?: ReactNode;
  confirmLabel?: string;
  cancelLabel?: string;
  loadingLabel?: string;
  destructive?: boolean;
  /** Bloqueia fechamento e desabilita ações enquanto a confirmação está em andamento. */
  loading?: boolean;
  onConfirm?: () => void | Promise<void>;
};

/** WebView pode deixar CSS transitions em currentTime=0; Base UI só desmonta no `finished`. */
function finishConfirmExitAnimations() {
  if (typeof document === 'undefined') return;
  document
    .querySelectorAll('[data-ending-style], [data-closed]')
    .forEach((element) => {
      element.getAnimations?.().forEach((animation) => {
        try {
          animation.finish();
        } catch {
          // ignore
        }
      });
    });
}

export function ConfirmDialog({
  children,
  open: openProp,
  onOpenChange,
  title,
  description,
  body,
  confirmLabel = 'Confirmar',
  cancelLabel = 'Cancelar',
  loadingLabel = 'Confirmando…',
  destructive = false,
  loading = false,
  onConfirm,
}: ConfirmDialogProps) {
  const [uncontrolledOpen, setUncontrolledOpen] = useState(false);
  const [internalLoading, setInternalLoading] = useState(false);
  const [mountEpoch, setMountEpoch] = useState(0);
  const triggerElementRef = useRef<HTMLElement | null>(null);
  const wasOpenRef = useRef(false);

  const isControlled = openProp !== undefined;
  const open = isControlled ? openProp : uncontrolledOpen;
  const isLoading = loading || internalLoading;
  const confirmVariant = destructive ? 'danger' : 'primary';

  useEffect(() => {
    if (open) {
      triggerElementRef.current = document.activeElement as HTMLElement | null;
    }
  }, [open]);

  // Controlled close: força finished; se residual persistir, remonta o Root.
  useEffect(() => {
    const wasOpen = wasOpenRef.current;
    wasOpenRef.current = open;
    if (open || !wasOpen) return;

    finishConfirmExitAnimations();
    const timeoutId = window.setTimeout(() => {
      finishConfirmExitAnimations();
      if (document.querySelector('[data-ending-style], [data-closed]')) {
        setMountEpoch((epoch) => epoch + 1);
      }
    }, 48);
    return () => window.clearTimeout(timeoutId);
  }, [open]);

  const handleOpenChangeComplete = useCallback((nextOpen: boolean) => {
    if (!nextOpen && triggerElementRef.current) {
      triggerElementRef.current.focus();
    }
  }, []);
  const setOpen = useCallback(
    (nextOpen: boolean) => {
      if (!isControlled) {
        setUncontrolledOpen(nextOpen);
      }
      onOpenChange?.(nextOpen);
    },
    [isControlled, onOpenChange],
  );

  const handleOpenChange = useCallback(
    (nextOpen: boolean, eventDetails: Dialog.Root.ChangeEventDetails) => {
      if (!nextOpen && isLoading) {
        eventDetails.cancel();
        return;
      }

      setOpen(nextOpen);
    },
    [isLoading, setOpen],
  );

  const handleConfirm = useCallback(async () => {
    if (isLoading || !onConfirm) {
      return;
    }

    const result = onConfirm();

    if (result instanceof Promise) {
      if (loading) {
        await result;
        return;
      }

      setInternalLoading(true);
      try {
        await result;
        setOpen(false);
      } finally {
        setInternalLoading(false);
      }
      return;
    }

    if (!loading) {
      setOpen(false);
    }
  }, [isLoading, loading, onConfirm, setOpen]);

  return (
    <Dialog.Root
      key={mountEpoch}
      open={open}
      onOpenChange={handleOpenChange}
      onOpenChangeComplete={handleOpenChangeComplete}
    >
      {children ? <Dialog.Trigger render={children} /> : null}
      <Dialog.Portal>
        <Dialog.Backdrop className={styles.backdrop} />
        <Dialog.Popup className={styles.popup}>
          <header className={styles.header}>
            <Dialog.Title className={styles.title}>{title}</Dialog.Title>
            {description ? (
              <Dialog.Description className={styles.description}>
                {description}
              </Dialog.Description>
            ) : null}
          </header>
          {body ? <div className={styles.body}>{body}</div> : null}
          <footer className={styles.footer}>
            <Dialog.Close
              render={
                <Button
                  type="button"
                  variant="ghost"
                  className={styles.footerAction}
                  disabled={isLoading}
                >
                  {cancelLabel}
                </Button>
              }
            />
            <Button
              type="button"
              variant={confirmVariant}
              className={styles.footerAction}
              disabled={isLoading}
              onClick={() => void handleConfirm()}
            >
              {isLoading ? loadingLabel : confirmLabel}
            </Button>
          </footer>
        </Dialog.Popup>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
