import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';

import { DatePicker } from './index';

const meta = {
  title: 'Forms/DatePicker',
  component: DatePicker,
  tags: ['autodocs'],
  args: {
    label: 'Data de emissão',
    name: 'issueDate',
    placeholder: 'dd/mm/aaaa',
    size: 'md',
    labelSize: 'md',
    required: false,
    disabled: false,
    hideHint: false,
  },
  argTypes: {
    size: {
      control: 'select',
      options: ['md', 'sm'],
    },
    labelSize: {
      control: 'select',
      options: ['md', 'sm'],
    },
  },
} satisfies Meta<typeof DatePicker>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const WithDefaultValue: Story = {
  args: { defaultValue: '2026-07-26' },
};

export const Required: Story = {
  args: { required: true },
};

export const WithDescription: Story = {
  args: {
    description: 'Data em que o documento foi emitido.',
  },
};

export const Error: Story = {
  args: {
    error: 'Informe uma data válida.',
  },
};

export const Small: Story = {
  args: { size: 'sm', labelSize: 'sm' },
};

export const Disabled: Story = {
  args: {
    disabled: true,
    defaultValue: '2026-01-15',
  },
};

export const WithMinMax: Story = {
  args: {
    min: '2026-01-01',
    max: '2026-12-31',
    description: 'Somente datas de 2026.',
  },
};

export const LabelHidden: Story = {
  args: { labelHidden: true },
};

export const Controlled: Story = {
  render: function ControlledDatePicker(args) {
    const [value, setValue] = useState('2026-07-26');
    return (
      <DatePicker {...args} value={value} onValueChange={setValue} />
    );
  },
};
