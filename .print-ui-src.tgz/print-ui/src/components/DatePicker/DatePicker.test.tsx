import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';

import { DatePicker } from '../index';

describe('DatePicker keyboard', () => {
  it('não submete o formulário ao pressionar Enter no input', () => {
    const onSubmit = vi.fn((event) => event.preventDefault());

    render(
      <form onSubmit={onSubmit}>
        <DatePicker label="Data" name="date-a" />
        <DatePicker label="Próxima data" name="date-b" />
        <button type="submit">Salvar</button>
      </form>,
    );

    const firstInput = screen.getByLabelText('Data');
    fireEvent.keyDown(firstInput, { key: 'Enter' });

    expect(onSubmit).not.toHaveBeenCalled();
  });

  it('move o foco para o próximo campo ao pressionar Enter', () => {
    render(
      <form>
        <DatePicker label="Data" name="date-a" />
        <DatePicker label="Próxima data" name="date-b" />
      </form>,
    );

    const firstInput = screen.getByLabelText('Data');
    const secondInput = screen.getByLabelText('Próxima data');

    firstInput.focus();
    fireEvent.keyDown(firstInput, { key: 'Enter' });

    expect(document.activeElement).toBe(secondInput);
  });

  it('mantém o botão do calendário fora da ordem de tabulação', () => {
    render(<DatePicker label="Data" name="date" />);

    expect(screen.getByLabelText('Abrir calendário')).toHaveAttribute(
      'tabindex',
      '-1',
    );
  });
});
