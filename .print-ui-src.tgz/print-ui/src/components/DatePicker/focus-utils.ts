const TABBABLE_SELECTOR = [
  'a[href]',
  'button:not([disabled])',
  'input:not([disabled]):not([type="hidden"])',
  'select:not([disabled])',
  'textarea:not([disabled])',
  '[tabindex]:not([tabindex="-1"])',
].join(', ');

export function getTabbableElements(root: ParentNode): HTMLElement[] {
  return Array.from(
    root.querySelectorAll<HTMLElement>(TABBABLE_SELECTOR),
  ).filter(
    (element) =>
      element.tabIndex >= 0 &&
      !element.hasAttribute('disabled') &&
      element.getAttribute('type') !== 'hidden' &&
      element.getAttribute('aria-hidden') !== 'true',
  );
}

export function focusNextFormControl(current: HTMLElement) {
  const root =
    current instanceof HTMLInputElement ||
    current instanceof HTMLSelectElement ||
    current instanceof HTMLTextAreaElement ||
    current instanceof HTMLButtonElement
      ? (current.form ?? document)
      : document;
  const tabbable = getTabbableElements(root);
  const index = tabbable.indexOf(current);
  if (index === -1) return false;
  tabbable[index + 1]?.focus();
  return true;
}
