import { Popover } from '@base-ui-components/react/popover';
import { useId, useMemo, useState, type KeyboardEvent } from 'react';

import { ICONS } from '../../assets/icons';
import { Icon } from '../Icon';

import {
  formatDisplayDate,
  getDaysInMonth,
  getFirstWeekday,
  getYearPage,
  getYearPageStart,
  isSameDay,
  maskDisplayDateInput,
  MONTHS,
  parseDisplayDate,
  parseISODate,
  toISODate,
  WEEKDAYS,
} from './calendar-utils';
import { focusNextFormControl } from './focus-utils';
import styles from './styles.module.scss';

export type DatePickerProps = {
  label: string;
  labelHidden?: boolean;
  labelSize?: 'md' | 'sm';
  required?: boolean;
  description?: string;
  error?: string;
  name: string;
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  disabled?: boolean;
  min?: string;
  max?: string;
  size?: 'md' | 'sm';
  hideHint?: boolean;
  placeholder?: string;
};

type CalendarView = 'days' | 'months' | 'years';

function CalendarIcon() {
  return (
    <Icon src={ICONS.datePicker.calendar} className={styles.icon} size={18} />
  );
}

function ChevronLeft() {
  return <Icon src={ICONS.ui.chevronLeft} size={16} />;
}

function ChevronRight() {
  return <Icon src={ICONS.ui.chevronRight} size={16} />;
}

type CalendarPanelProps = {
  viewDate: Date;
  onViewDateChange: (date: Date) => void;
  selectedDate: Date | null;
  onSelect: (date: Date) => void;
  minDate: Date | null;
  maxDate: Date | null;
};

function CalendarPanel({
  viewDate,
  onViewDateChange,
  selectedDate,
  onSelect,
  minDate,
  maxDate,
}: CalendarPanelProps) {
  const [view, setView] = useState<CalendarView>('days');
  const [yearPageStart, setYearPageStart] = useState(() =>
    getYearPageStart(viewDate.getFullYear()),
  );

  const days = useMemo(() => {
    const year = viewDate.getFullYear();
    const month = viewDate.getMonth();
    const totalDays = getDaysInMonth(year, month);
    const firstWeekday = getFirstWeekday(year, month);
    const cells: Array<{ date: Date | null }> = [];

    for (let i = 0; i < firstWeekday; i += 1) {
      cells.push({ date: null });
    }

    for (let day = 1; day <= totalDays; day += 1) {
      cells.push({ date: new Date(year, month, day) });
    }

    return cells;
  }, [viewDate]);

  const yearsOnPage = useMemo(
    () => getYearPage(yearPageStart),
    [yearPageStart],
  );

  const isDateDisabled = (date: Date) => {
    if (minDate && date < minDate) return true;
    if (maxDate && date > maxDate) return true;
    return false;
  };

  const goToPreviousMonth = () => {
    onViewDateChange(
      new Date(viewDate.getFullYear(), viewDate.getMonth() - 1, 1),
    );
  };

  const goToNextMonth = () => {
    onViewDateChange(
      new Date(viewDate.getFullYear(), viewDate.getMonth() + 1, 1),
    );
  };

  if (view === 'years') {
    const pageEnd = yearPageStart + 11;

    return (
      <>
        <div className={styles.header}>
          <button
            type="button"
            className={styles.navButton}
            aria-label="Anos anteriores"
            onClick={() => setYearPageStart((current) => current - 12)}
          >
            <ChevronLeft />
          </button>
          <span className={styles.headerTitle}>
            {yearPageStart} – {pageEnd}
          </span>
          <button
            type="button"
            className={styles.navButton}
            aria-label="Próximos anos"
            onClick={() => setYearPageStart((current) => current + 12)}
          >
            <ChevronRight />
          </button>
        </div>
        <div
          className={styles.yearGrid}
          role="grid"
          aria-label="Selecionar ano"
        >
          {yearsOnPage.map((year) => (
            <button
              key={year}
              type="button"
              role="gridcell"
              className={styles.pickerCell}
              data-selected={viewDate.getFullYear() === year ? true : undefined}
              onClick={() => {
                onViewDateChange(new Date(year, viewDate.getMonth(), 1));
                setView('months');
              }}
            >
              {year}
            </button>
          ))}
        </div>
      </>
    );
  }

  if (view === 'months') {
    return (
      <>
        <div className={styles.header}>
          <span className={styles.headerTitle}>Selecionar mês</span>
          <button
            type="button"
            className={styles.pickerButton}
            onClick={() => {
              setYearPageStart(getYearPageStart(viewDate.getFullYear()));
              setView('years');
            }}
          >
            {viewDate.getFullYear()}
          </button>
        </div>
        <div
          className={styles.monthGrid}
          role="grid"
          aria-label="Selecionar mês"
        >
          {MONTHS.map((monthLabel, monthIndex) => (
            <button
              key={monthLabel}
              type="button"
              role="gridcell"
              className={styles.pickerCell}
              data-selected={
                viewDate.getMonth() === monthIndex ? true : undefined
              }
              onClick={() => {
                onViewDateChange(
                  new Date(viewDate.getFullYear(), monthIndex, 1),
                );
                setView('days');
              }}
            >
              {monthLabel.slice(0, 3)}
            </button>
          ))}
        </div>
      </>
    );
  }

  return (
    <>
      <div className={styles.header}>
        <button
          type="button"
          className={styles.navButton}
          aria-label="Mês anterior"
          onClick={goToPreviousMonth}
        >
          <ChevronLeft />
        </button>
        <div className={styles.headerCenter}>
          <button
            type="button"
            className={styles.pickerButton}
            onClick={() => setView('months')}
          >
            {MONTHS[viewDate.getMonth()]}
          </button>
          <button
            type="button"
            className={styles.pickerButton}
            onClick={() => {
              setYearPageStart(getYearPageStart(viewDate.getFullYear()));
              setView('years');
            }}
          >
            {viewDate.getFullYear()}
          </button>
        </div>
        <button
          type="button"
          className={styles.navButton}
          aria-label="Próximo mês"
          onClick={goToNextMonth}
        >
          <ChevronRight />
        </button>
      </div>
      <div className={styles.weekdays}>
        {WEEKDAYS.map((day) => (
          <span key={day} className={styles.weekday}>
            {day}
          </span>
        ))}
      </div>
      <div className={styles.grid} role="grid" aria-label="Calendário">
        {days.map((cell, index) =>
          cell.date ? (
            <button
              key={toISODate(cell.date)}
              type="button"
              role="gridcell"
              className={styles.day}
              disabled={isDateDisabled(cell.date)}
              data-selected={
                selectedDate && isSameDay(cell.date, selectedDate)
                  ? true
                  : undefined
              }
              onClick={() => onSelect(cell.date!)}
            >
              {cell.date.getDate()}
            </button>
          ) : (
            <span
              key={`empty-${index}`}
              className={styles.empty}
              aria-hidden="true"
            />
          ),
        )}
      </div>
    </>
  );
}

export function DatePicker({
  label,
  labelHidden = false,
  labelSize = 'md',
  required = false,
  description,
  error,
  name,
  value,
  defaultValue,
  onValueChange,
  disabled,
  min,
  max,
  size = 'md',
  hideHint = false,
  placeholder = 'dd/mm/aaaa',
}: DatePickerProps) {
  const inputId = useId();
  const calendarId = useId();
  const initialIso = value ?? defaultValue;
  const initialDate = parseISODate(initialIso ?? '') ?? null;

  const [selected, setSelected] = useState<string | undefined>(initialIso);
  const [inputValue, setInputValue] = useState(
    initialDate ? formatDisplayDate(initialDate) : '',
  );
  const [isTyping, setIsTyping] = useState(false);
  const [inputError, setInputError] = useState<string | undefined>();
  const [open, setOpen] = useState(false);
  const [viewDate, setViewDate] = useState(() => initialDate ?? new Date());
  const [calendarKey, setCalendarKey] = useState(0);

  const isControlled = value !== undefined;
  const controlledDate = isControlled ? parseISODate(value ?? '') : null;
  const effectiveSelected = isControlled ? value : selected;
  const selectedDate = effectiveSelected
    ? parseISODate(effectiveSelected)
    : null;
  const displayInput = isControlled
    ? isTyping
      ? inputValue
      : controlledDate
        ? formatDisplayDate(controlledDate)
        : ''
    : inputValue;
  const minDate = min ? parseISODate(min) : null;
  const maxDate = max ? parseISODate(max) : null;

  const commitDate = (date: Date) => {
    const iso = toISODate(date);
    if (!isControlled) {
      setSelected(iso);
      setInputValue(formatDisplayDate(date));
    }
    setIsTyping(false);
    setInputError(undefined);
    setViewDate(date);
    onValueChange?.(iso);
  };

  const isDisabled = (date: Date) => {
    if (minDate && date < minDate) return true;
    if (maxDate && date > maxDate) return true;
    return false;
  };

  const handleInputChange = (raw: string) => {
    const masked = maskDisplayDateInput(raw);
    setIsTyping(true);
    setInputValue(masked);
    setInputError(undefined);

    if (masked.length < 10) {
      if (!isControlled) setSelected(undefined);
      onValueChange?.('');
      return;
    }

    const parsed = parseDisplayDate(masked);
    if (!parsed) {
      setInputError('Use o formato dd/mm/aaaa.');
      if (!isControlled) setSelected(undefined);
      onValueChange?.('');
      return;
    }

    if (isDisabled(parsed)) {
      setInputError('Data fora do intervalo permitido.');
      if (!isControlled) setSelected(undefined);
      onValueChange?.('');
      return;
    }

    commitDate(parsed);
  };

  const handleInputBlur = () => {
    setIsTyping(false);
    if (!displayInput) return;
    if (displayInput.length < 10) {
      setInputError('Data incompleta. Use dd/mm/aaaa.');
    }
  };

  const handleInputKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      focusNextFormControl(event.currentTarget);
      return;
    }

    if (event.key === 'ArrowDown' && !open) {
      event.preventDefault();
      handleOpenChange(true);
    }
  };

  const handleOpenChange = (next: boolean) => {
    setOpen(next);
    if (next) {
      setCalendarKey((current) => current + 1);
      if (selectedDate) setViewDate(selectedDate);
    }
  };

  const resolvedError = error ?? inputError;

  return (
    <div
      className={[styles.field, labelHidden ? styles.fieldCompact : '']
        .filter(Boolean)
        .join(' ')}
      aria-required={required || undefined}
    >
      <label
        className={[
          styles.label,
          labelSize === 'sm' ? styles.labelSm : '',
          labelHidden ? styles.labelHidden : '',
        ]
          .filter(Boolean)
          .join(' ')}
        htmlFor={inputId}
      >
        {label}
        {required ? (
          <span className={styles.requiredIndicator} aria-hidden="true">
            *
          </span>
        ) : null}
      </label>

      <div
        className={[styles.inputRow, size === 'sm' ? styles.inputRowSm : '']
          .filter(Boolean)
          .join(' ')}
      >
        <input
          id={inputId}
          name={name}
          type="text"
          inputMode="numeric"
          autoComplete="off"
          spellCheck={false}
          className={[styles.input, size === 'sm' ? styles.inputSm : '']
            .filter(Boolean)
            .join(' ')}
          placeholder={placeholder}
          aria-label={labelHidden ? label : undefined}
          value={displayInput}
          disabled={disabled}
          aria-invalid={resolvedError ? true : undefined}
          aria-describedby={
            [
              description ? `${inputId}-description` : undefined,
              resolvedError ? `${inputId}-error` : undefined,
            ]
              .filter(Boolean)
              .join(' ') || undefined
          }
          onChange={(event) => handleInputChange(event.target.value)}
          onBlur={handleInputBlur}
          onKeyDown={handleInputKeyDown}
        />

        <Popover.Root open={open} onOpenChange={handleOpenChange}>
          <Popover.Trigger
            className={[
              styles.calendarButton,
              size === 'sm' ? styles.calendarButtonSm : '',
            ]
              .filter(Boolean)
              .join(' ')}
            disabled={disabled}
            tabIndex={-1}
            aria-label="Abrir calendário"
            aria-controls={calendarId}
            aria-expanded={open}
          >
            <CalendarIcon />
          </Popover.Trigger>
          <Popover.Portal>
            <Popover.Positioner className={styles.positioner} sideOffset={4}>
              <Popover.Popup className={styles.popup} id={calendarId}>
                <CalendarPanel
                  key={calendarKey}
                  viewDate={viewDate}
                  onViewDateChange={setViewDate}
                  selectedDate={selectedDate}
                  minDate={minDate}
                  maxDate={maxDate}
                  onSelect={(date) => {
                    commitDate(date);
                    setOpen(false);
                  }}
                />
              </Popover.Popup>
            </Popover.Positioner>
          </Popover.Portal>
        </Popover.Root>
      </div>

      {description ? (
        <p className={styles.description} id={`${inputId}-description`}>
          {description}
        </p>
      ) : !resolvedError && !hideHint ? (
        <p className={styles.hint}>
          Digite ou use o calendário para selecionar.
        </p>
      ) : null}
      {resolvedError ? (
        <p className={styles.error} id={`${inputId}-error`} role="alert">
          {resolvedError}
        </p>
      ) : null}
    </div>
  );
}
