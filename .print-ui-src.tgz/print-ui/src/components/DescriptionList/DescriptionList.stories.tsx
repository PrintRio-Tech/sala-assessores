import type { Meta, StoryObj } from '@storybook/react-vite';

import {
  DescriptionDetail,
  DescriptionGroup,
  DescriptionList,
  DescriptionTerm,
} from './DescriptionList';

const meta = {
  title: 'Components/DescriptionList',
  component: DescriptionList,
  parameters: { layout: 'padded' },
} satisfies Meta<typeof DescriptionList>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  render: () => (
    <DescriptionList>
      <DescriptionGroup>
        <DescriptionTerm>Status</DescriptionTerm>
        <DescriptionDetail>Ativa</DescriptionDetail>
      </DescriptionGroup>
      <DescriptionGroup>
        <DescriptionTerm>Papel</DescriptionTerm>
        <DescriptionDetail>Admin do escritório</DescriptionDetail>
      </DescriptionGroup>
      <DescriptionGroup>
        <DescriptionTerm>Cliente</DescriptionTerm>
        <DescriptionDetail>Vértice Contabilidade · Fortaleza</DescriptionDetail>
      </DescriptionGroup>
    </DescriptionList>
  ),
};
