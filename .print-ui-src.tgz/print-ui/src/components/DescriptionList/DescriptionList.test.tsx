import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import {
  DescriptionDetail,
  DescriptionGroup,
  DescriptionList,
  DescriptionTerm,
} from './DescriptionList';

describe('DescriptionList', () => {
  it('expõe dl/dt/dd semânticos', () => {
    const { container } = render(
      <DescriptionList>
        <DescriptionGroup>
          <DescriptionTerm>E-mail</DescriptionTerm>
          <DescriptionDetail>user@example.com</DescriptionDetail>
        </DescriptionGroup>
      </DescriptionList>,
    );

    expect(container.querySelector('dl')).toBeTruthy();
    expect(screen.getByText('E-mail').tagName).toBe('DT');
    expect(screen.getByText('user@example.com').tagName).toBe('DD');
  });
});
