import type { ComponentPropsWithoutRef, ReactNode } from 'react';

import styles from './styles.module.scss';

export type DescriptionListProps = ComponentPropsWithoutRef<'dl'> & {
  className?: string;
  children?: ReactNode;
};

/** Lista de descrição semântica (dl) — densidade DS, sem opinião de domínio. */
export function DescriptionList({
  className,
  children,
  ...props
}: DescriptionListProps) {
  const classes = [styles.list, className].filter(Boolean).join(' ');
  return (
    <dl className={classes} {...props}>
      {children}
    </dl>
  );
}

export type DescriptionTermProps = ComponentPropsWithoutRef<'dt'> & {
  className?: string;
  children?: ReactNode;
};

export function DescriptionTerm({
  className,
  children,
  ...props
}: DescriptionTermProps) {
  const classes = [styles.term, className].filter(Boolean).join(' ');
  return (
    <dt className={classes} {...props}>
      {children}
    </dt>
  );
}

export type DescriptionDetailProps = ComponentPropsWithoutRef<'dd'> & {
  className?: string;
  children?: ReactNode;
};

export function DescriptionDetail({
  className,
  children,
  ...props
}: DescriptionDetailProps) {
  const classes = [styles.detail, className].filter(Boolean).join(' ');
  return (
    <dd className={classes} {...props}>
      {children}
    </dd>
  );
}

export type DescriptionGroupProps = ComponentPropsWithoutRef<'div'> & {
  className?: string;
  children?: ReactNode;
};

/** Agrupa Term+Detail em uma linha/bloco responsivo. */
export function DescriptionGroup({
  className,
  children,
  ...props
}: DescriptionGroupProps) {
  const classes = [styles.group, className].filter(Boolean).join(' ');
  return (
    <div className={classes} {...props}>
      {children}
    </div>
  );
}
