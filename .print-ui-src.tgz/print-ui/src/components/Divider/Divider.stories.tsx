import type { Meta, StoryObj } from '@storybook/react-vite';

import { Divider } from './Divider';

const meta = {
  title: 'Components/Divider',
  component: Divider,
  parameters: { layout: 'padded' },
} satisfies Meta<typeof Divider>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Horizontal: Story = {
  render: () => (
    <div style={{ display: 'grid', gap: '1rem' }}>
      <p>Acima</p>
      <Divider />
      <p>Abaixo</p>
    </div>
  ),
};

export const Vertical: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '1rem', alignItems: 'stretch', height: 48 }}>
      <span>A</span>
      <Divider orientation="vertical" />
      <span>B</span>
    </div>
  ),
};
