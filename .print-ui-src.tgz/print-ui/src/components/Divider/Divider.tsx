import type { ComponentPropsWithoutRef } from 'react';

import styles from './styles.module.scss';

export type DividerOrientation = 'horizontal' | 'vertical';

export type DividerProps = ComponentPropsWithoutRef<'hr'> & {
  orientation?: DividerOrientation;
};

/** Separador estrutural — agrupamento sem card-in-card. */
export function Divider({
  orientation = 'horizontal',
  className,
  ...props
}: DividerProps) {
  const classes = [
    styles.divider,
    orientation === 'vertical' ? styles.vertical : styles.horizontal,
    className,
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <hr
      className={classes}
      role="separator"
      aria-orientation={orientation}
      {...props}
    />
  );
}
