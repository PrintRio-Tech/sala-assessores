import { readFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

import { describe, expect, it } from 'vitest';

const here = dirname(fileURLToPath(import.meta.url));
const scss = readFileSync(join(here, 'styles.module.scss'), 'utf8');
const shell = readFileSync(join(here, 'DrawerShell.tsx'), 'utf8');

describe('Drawer backdrop visual semantics', () => {
  it('backdrop faz fade CSS de opacity (0 → final), sem WAAPI fill:forwards', () => {
    const backdropBlock =
      scss.match(/\.backdrop\s*\{[\s\S]*?\n\}\n\n\/\* xl:/)?.[0] ??
      scss.match(/\.backdrop\s*\{[\s\S]*?\n\}/)?.[0] ??
      '';

    expect(backdropBlock).toMatch(/transition:\s*opacity\s+/);
    expect(backdropBlock).toMatch(/\$duration-normal|200ms|DRAWER_MOTION/);
    // Enter/exit: starting + ending em opacity 0 (fade perceptível).
    expect(backdropBlock).toMatch(/data-starting-style/);
    expect(backdropBlock).toMatch(/data-ending-style/);
    expect(backdropBlock).toMatch(/opacity:\s*0/);

    // Painel continua WAAPI; backdrop não deve ser animado via element.animate.
    expect(shell).toMatch(/panel\.animate\s*\(/);
    expect(shell).not.toMatch(/backdrop\?\.animate\s*\(/);
    expect(shell).not.toMatch(/backdrop\.animate\s*\(/);
  });

  it('opacidade final do scrim é suficiente (alpha ≥ 0.4)', () => {
    expect(scss).toMatch(
      /background-color:\s*rgba\(\$grafite,\s*0\.(?:4|45|5|55|6)\)/,
    );
  });

  it('xl: painel deixa faixa de workspace para o backdrop inset aparecer', () => {
    const xl =
      scss.match(/\.panelXl\s*\{[\s\S]*?\n\}\n\n\.panelMobileMd/)?.[0] ?? '';
    // Faixa ≥ $space-4 após a sidebar — sem left colado no sidebar (full-bleed).
    expect(xl).toMatch(
      /left:\s*calc\(\s*var\(--pf-sidebar-width[^)]*\)\s*\+\s*#\{\$space-4\}\s*\)/,
    );
    expect(scss).toMatch(/\.backdropInset\s*\{[\s\S]*?left:\s*var\(--pf-sidebar-width/);
  });

  it('reduced-motion: backdrop sem transition de opacity', () => {
    expect(scss).toMatch(
      /\.backdrop\s*\{[\s\S]*@media \(prefers-reduced-motion: reduce\)\s*\{[\s\S]*?transition:\s*none/,
    );
  });

  it('backdropTone="strong": scrim 0.56–0.66, sem duplicar transition/reduced-motion (herda de .backdrop)', () => {
    const strongBlock = scss.match(/\.backdropStrong\s*\{[\s\S]*?\n\}/)?.[0] ?? '';
    expect(strongBlock).toMatch(/rgba\(\$grafite,\s*0\.(?:5[6-9]|6[0-6])\)/);
    // Fade e reduced-motion são herdados de .backdrop (mesma classe base sempre presente).
    expect(strongBlock).not.toMatch(/transition:/);
    expect(scss).toMatch(/\.backdrop\s*\{[\s\S]*?\.backdropStrong/);
  });
});
