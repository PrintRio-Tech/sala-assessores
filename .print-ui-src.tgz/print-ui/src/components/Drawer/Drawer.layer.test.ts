import { readFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

import { describe, expect, it } from 'vitest';

const here = dirname(fileURLToPath(import.meta.url));
const scss = readFileSync(join(here, 'styles.module.scss'), 'utf8');
const shell = readFileSync(join(here, 'DrawerShell.tsx'), 'utf8');

describe('DrawerShell presentation=layer (visual reset default)', () => {
  it('expõe presentation, origin, responsiveOrigin, backdropTone e backdropInset', () => {
    expect(shell).toMatch(/presentation\?:/);
    expect(shell).toMatch(/origin\?:/);
    expect(shell).toMatch(/responsiveOrigin\?:/);
    expect(shell).toMatch(/backdropTone\?:/);
    expect(shell).toMatch(/backdropInset\?:/);
    expect(shell).toMatch(/'layer'/);
    expect(shell).toMatch(/'strong'/);
  });

  it('strong usa scrim entre 0.56 e 0.66', () => {
    expect(scss).toMatch(
      /\.backdropStrong\s*\{[\s\S]*?rgba\(\$grafite,\s*0\.(?:5[6-9]|6[0-6])\)/,
    );
  });

  it('layer xl não é full-bleed (largura ~650px)', () => {
    expect(scss).toMatch(/\.panelLayerXl/);
    expect(scss).toMatch(/40\.625rem|650px|\$drawer-width-xl-layer/);

    const tokens = readFileSync(
      join(here, '..', '..', 'tokens', '_drawer.scss'),
      'utf8',
    );
    const widthSource = /\$drawer-width-xl-layer/.test(scss)
      ? tokens
      : scss;
    expect(widthSource).toMatch(/40\.625rem|650px/);
  });

  it('mobile xl sheet ~730px (UserDetail timeline)', () => {
    const tokens = readFileSync(
      join(here, '..', '..', 'tokens', '_drawer.scss'),
      'utf8',
    );
    expect(tokens).toMatch(
      /\$drawer-mobile-max-height-xl:\s*45\.625rem/,
    );
  });

  it('defaults canônicos: presentation=layer e backdropTone=strong', () => {
    expect(shell).toMatch(/presentation\s*=\s*'layer'/);
    expect(shell).toMatch(/backdropTone\s*=\s*'strong'/);
  });
});
