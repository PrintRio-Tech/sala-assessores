import { readFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

import { describe, expect, it } from 'vitest';

const here = dirname(fileURLToPath(import.meta.url));
const scss = readFileSync(join(here, 'styles.module.scss'), 'utf8');

describe('DrawerShell panel lifecycle CSS', () => {
  it('não prende enter em &[data-starting-style] no painel', () => {
    const panelBlock =
      scss.match(/\.panel\s*\{[\s\S]*?\n\}\n\n\.panelMd/)?.[0] ?? '';
    expect(panelBlock).not.toMatch(
      /&\[data-starting-style\],\s*\n\s*&\[data-ending-style\]/,
    );
  });

  it('cinto open: data-open sem ending/closed força translate em posição final', () => {
    expect(scss).toMatch(
      /&\[data-open\]:not\(\[data-ending-style\]\):not\(\[data-closed\]\)/,
    );
    expect(scss).toMatch(
      /&\[data-open\]:not\(\[data-ending-style\]\):not\(\[data-closed\]\)\s*\{[\s\S]*?translateX\(0\)/,
    );
  });

  it('exit ending/closed esconde (visibility + pointer-events)', () => {
    expect(scss).toMatch(/&\[data-ending-style\],\s*\n\s*&\[data-closed\]/);
    expect(scss).toMatch(/visibility:\s*hidden/);
    expect(scss).toMatch(/pointer-events:\s*none/);
  });

  it('backdrop usa fade CSS de opacity (não transition:none no scrim)', () => {
    expect(scss).toMatch(/\.backdrop\s*\{[\s\S]*?transition:\s*opacity/);
    expect(scss).toMatch(
      /\.backdrop[\s\S]*?&\[data-open\]:not\(\[data-ending-style\]\):not\(\[data-closed\]\)/,
    );
  });
});
