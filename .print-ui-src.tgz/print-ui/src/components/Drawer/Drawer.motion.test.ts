import { readFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

import { describe, expect, it } from 'vitest';

const here = dirname(fileURLToPath(import.meta.url));
const scss = readFileSync(join(here, 'styles.module.scss'), 'utf8');
const shell = readFileSync(join(here, 'DrawerShell.tsx'), 'utf8');

describe('DrawerShell spatial motion', () => {
  it('define duração espacial curta 180–240ms via WAAPI (não cinto 1ms)', () => {
    const match = shell.match(/DRAWER_MOTION_MS\s*=\s*(\d+)/);
    expect(match).toBeTruthy();
    const ms = Number(match![1]);
    expect(ms).toBeGreaterThanOrEqual(180);
    expect(ms).toBeLessThanOrEqual(240);
    expect(shell).toMatch(/\.animate\s*\(/);
    expect(shell).toMatch(/prefers-reduced-motion/);
  });

  it('CSS do painel não usa transition 1ms como movimento principal', () => {
    const panelBlock =
      scss.match(/\.panel\s*\{[\s\S]*?\n\}\n\n\.panelMd/)?.[0] ?? '';
    expect(panelBlock).not.toMatch(/transform 1ms linear/);
    // Estados finais ainda via data-open / ending (sem starting preso).
    expect(panelBlock).toMatch(
      /&\[data-open\]:not\(\[data-ending-style\]\):not\(\[data-closed\]\)/,
    );
    expect(panelBlock).not.toMatch(
      /&\[data-starting-style\],\s*\n\s*&\[data-ending-style\]/,
    );
  });

  it('reduced-motion e cancelamento de animação estão no shell', () => {
    expect(shell).toMatch(/cancel\(\)/);
    expect(shell).toMatch(/finishDrawerExitAnimations|animation\.finish/);
  });

  it('origin="bottom" no desktop usa transform translateY (mesma duração espacial)', () => {
    expect(shell).toMatch(/fromBottom\s*=\s*activeOrigin\s*===\s*'bottom'/);
    expect(shell).toMatch(/translateY\(100%\)/);
    expect(shell).toMatch(/translateY\(0\)/);
  });

  it('mobile é resolvido só por responsiveOrigin — origin não vaza para mobile', () => {
    expect(shell).toMatch(
      /if \(isMobileDrawerViewport\(\)\)\s*\{\s*return responsiveOrigin \?\? 'bottom';/,
    );
  });
});
