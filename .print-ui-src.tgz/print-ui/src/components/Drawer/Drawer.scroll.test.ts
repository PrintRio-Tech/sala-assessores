import { readFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

import { describe, expect, it } from 'vitest';

const here = dirname(fileURLToPath(import.meta.url));
const scss = readFileSync(join(here, 'styles.module.scss'), 'utf8');
const shell = readFileSync(join(here, 'DrawerShell.tsx'), 'utf8');

describe('DrawerShell body/footer scroll estrutural (mobile)', () => {
  it('bodyScroll é o scrollport (overflow-y auto) com min-height 0 e flex encolhível', () => {
    const bodyBlock =
      scss.match(/\.bodyScroll\s*\{[\s\S]*?\n\}\n\n\.bodyInner/)?.[0] ?? '';
    expect(bodyBlock).toMatch(/min-height:\s*0/);
    expect(bodyBlock).toMatch(/flex:\s*1\s+1\s+0/);
    expect(bodyBlock).toMatch(
      /&\[data-layout='scroll'\]\s*\{[\s\S]*?overflow-y:\s*auto/,
    );
  });

  it('mobile: altura flex definida no cap (height: var) — conteúdo curto aceita espaço', () => {
    // min(..., max-content) colapsa o flex em runtime (sheet ~227px).
    // Cap fixo dá containing block; bodyScroll preenche o resto.
    expect(scss).toMatch(/--pf-drawer-mobile-max-height/);
    expect(scss).not.toMatch(
      /height:\s*min\([^;]*max-content/,
    );
    expect(scss).toMatch(
      /\.panelMobileMd[\s\S]*--pf-drawer-mobile-max-height:\s*#\{\$drawer-mobile-max-height-md\}/,
    );
    expect(scss).toMatch(
      /\.panelMobileMd[\s\S]*height:\s*var\(--pf-drawer-mobile-max-height\)/,
    );
    expect(scss).toMatch(
      /\.panelMobileLg[\s\S]*height:\s*var\(--pf-drawer-mobile-max-height\)/,
    );
    expect(scss).toMatch(
      /\.panelMobileXl[\s\S]*height:\s*var\(--pf-drawer-mobile-max-height\)/,
    );
  });

  it('footer permanece flex-shrink 0 com fundo sólido (não deixa conteúdo vazar por baixo)', () => {
    const footerBlock =
      scss.match(/\.footer\s*\{[\s\S]*?\n\}\n\n\.footerInner/)?.[0] ?? '';
    expect(footerBlock).toMatch(/flex-shrink:\s*0/);
    expect(footerBlock).toMatch(/background-color:\s*\$surface-bright/);
  });

  it('foco visível: scroll-padding no body + scroll-margin em controles focáveis', () => {
    expect(scss).toMatch(/scroll-padding-block-end:/);
    expect(scss).toMatch(/scroll-margin-block:/);
  });

  it('DrawerShell mantém body e footer como irmãos (footer fora do scroll)', () => {
    expect(shell).toMatch(/styles\.bodyScroll/);
    expect(shell).toMatch(/<footer className=\{footerClass\}>/);
    const bodyIdx = shell.indexOf('styles.bodyScroll');
    const footerIdx = shell.indexOf('<footer className={footerClass}>');
    expect(bodyIdx).toBeGreaterThan(-1);
    expect(footerIdx).toBeGreaterThan(bodyIdx);
  });
});
