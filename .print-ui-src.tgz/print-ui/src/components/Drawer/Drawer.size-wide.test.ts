import { readFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

import { describe, expect, it } from 'vitest';

const here = dirname(fileURLToPath(import.meta.url));

function read(rel: string): string {
  return readFileSync(join(here, rel), 'utf8');
}

describe('DrawerSize wide (aditivo)', () => {
  it('token desktop 57.5rem (~920px); mobile reusa altura xl', () => {
    const tokens = read(join('..', '..', 'tokens', '_drawer.scss'));

    expect(tokens).toMatch(
      /\$drawer-width-wide:\s*min\(\s*57\.5rem,\s*100%\s*\)/,
    );
    expect(tokens).toMatch(/\$drawer-width-xl-layer:\s*min\(\s*40\.625rem/);
    expect(tokens).toMatch(
      /\$drawer-mobile-max-height-wide:\s*\$drawer-mobile-max-height-xl/,
    );
  });

  it('DrawerSize inclui wide; defaults md/lg/xl intactos', () => {
    const shell = read('DrawerShell.tsx');
    const scss = read('styles.module.scss');

    expect(shell).toMatch(
      /export type DrawerSize = 'md' \| 'lg' \| 'xl' \| 'wide'/,
    );
    expect(shell).toMatch(/wide:\s*styles\.panelWide/);
    expect(shell).toMatch(/size = 'md'/);
    expect(shell).not.toMatch(/size = 'wide'/);

    expect(scss).toMatch(/\.panelWide\s*\{[\s\S]*\$drawer-width-wide/);
    expect(scss).toMatch(
      /\.panelMobileWide[\s\S]*\$drawer-mobile-max-height-wide/,
    );
  });
});
