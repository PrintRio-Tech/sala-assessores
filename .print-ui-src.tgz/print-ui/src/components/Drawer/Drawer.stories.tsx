import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';

import { Button } from '../Button/Button';

import { Drawer, DrawerShell } from './index';

const meta = {
  title: 'Overlay/Drawer',
  component: Drawer,
  tags: ['autodocs'],
  args: {
    title: 'Detalhes',
    description: 'Revise as informações antes de confirmar.',
    confirmLabel: 'Confirmar',
    cancelLabel: 'Cancelar',
    size: 'md' as const,
    children: <Button type="button">Abrir drawer</Button>,
    body: (
      <p>
        Conteúdo do painel lateral. Em viewports estreitas o drawer sobe como
        sheet; em desktop abre pela lateral.
      </p>
    ),
  },
  argTypes: {
    size: {
      control: 'select',
      options: ['md', 'lg', 'xl', 'wide'],
    },
    children: { control: false },
    body: { control: false },
  },
} satisfies Meta<typeof Drawer>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  render: (args) => <Drawer {...args} />,
};

export const Large: Story = {
  args: {
    size: 'lg',
    title: 'Drawer grande',
    children: <Button type="button">Abrir drawer lg</Button>,
  },
  render: (args) => <Drawer {...args} />,
};

export const Shell: Story = {
  name: 'DrawerShell',
  parameters: {
    docs: {
      description: {
        story:
          'Shell controlado com footer customizado — base usada por fluxos como DrawerSteps.',
      },
    },
  },
  render: function Render() {
    const [open, setOpen] = useState(false);

    return (
      <>
        <Button type="button" onClick={() => setOpen(true)}>
          Abrir DrawerShell
        </Button>
        <DrawerShell
          open={open}
          onOpenChange={setOpen}
          title="Editar perfil"
          description="Atualize os dados do usuário."
          size="lg"
          footer={
            <>
              <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
                Cancelar
              </Button>
              <Button type="button" variant="primary" onClick={() => setOpen(false)}>
                Salvar
              </Button>
            </>
          }
        >
          <label style={{ display: 'grid', gap: 4 }}>
            Nome
            <input defaultValue="Maria Silva" />
          </label>
        </DrawerShell>
      </>
    );
  },
};

export const Layer: Story = {
  name: 'Shell — presentation="layer" (default visual reset)',
  parameters: {
    docs: {
      description: {
        story:
          'Defaults canônicos do visual reset: `presentation="layer"` + `backdropTone="strong"`. ' +
          'No `size="xl"` o painel não é full-bleed — mantém ~650px (`min(40.625rem, 100%)`). ' +
          '`size="wide"` é a jornada larga (~920px / `min(57.5rem, 100%)`) — use em fluxos de 3 decisões. ' +
          'O scrim fica mais forte ' +
          '(0.56 vs. ~0.45 do legado) e continua com fade CSS de 200ms + snap em reduced-motion. ' +
          'Desktop abre pela direita (`origin="end"`, default); no mobile, `responsiveOrigin="bottom"` ' +
          'mantém o sheet subindo da base. Opt-out legado: `presentation="default"` / ' +
          '`backdropTone="default"` restaura o full-bleed xl anterior.',
      },
    },
  },
  render: function Render() {
    const [open, setOpen] = useState(false);

    return (
      <>
        <Button type="button" onClick={() => setOpen(true)}>
          Abrir drawer em camada (layer)
        </Button>
        <DrawerShell
          open={open}
          onOpenChange={setOpen}
          title="Nova configuração"
          description="Painel em camada — contexto ao fundo permanece visível e escurecido."
          size="xl"
          responsiveOrigin="bottom"
          footer={
            <>
              <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
                Cancelar
              </Button>
              <Button type="button" variant="primary" onClick={() => setOpen(false)}>
                Aplicar
              </Button>
            </>
          }
        >
          <p>
            Defaults: `presentation=&quot;layer&quot;` + `backdropTone=&quot;strong&quot;`.
            Em telas largas ocupa ~650px pela direita, com workspace dimmed (scrim 0.56).
            Em mobile continua como bottom sheet (`responsiveOrigin=&quot;bottom&quot;`).
          </p>
        </DrawerShell>
      </>
    );
  },
};

export const LayerWithSidebarInset: Story = {
  name: 'Shell — layer + backdropInset="sidebar"',
  parameters: {
    docs: {
      description: {
        story:
          'Defaults `layer`/`strong` com `backdropInset="sidebar"` explícito: o scrim respeita ' +
          '`--pf-sidebar-width` no desktop (0 no mobile). No legado (`presentation="default"`), ' +
          'xl ainda auto-aplica esse inset.',
      },
    },
  },
  render: function Render() {
    const [open, setOpen] = useState(false);

    return (
      <>
        <Button type="button" onClick={() => setOpen(true)}>
          Abrir drawer (layer + inset sidebar)
        </Button>
        <DrawerShell
          open={open}
          onOpenChange={setOpen}
          title="Detalhes do pedido"
          size="xl"
          backdropInset="sidebar"
          responsiveOrigin="bottom"
          footer={
            <Button type="button" variant="primary" onClick={() => setOpen(false)}>
              Fechar
            </Button>
          }
        >
          <p>Scrim inset respeitando a largura da sidebar.</p>
        </DrawerShell>
      </>
    );
  },
};

export const LayerStrong: Story = {
  name: 'Layer · strong backdrop (default visual reset)',
  parameters: {
    docs: {
      description: {
        story:
          'Defaults canônicos: presentation=layer, backdropTone=strong — origem end/bottom, ' +
          'scrim 56%, xl ~650px. Opt-out com presentation="default" / backdropTone="default".',
      },
    },
  },
  render: function Render() {
    const [open, setOpen] = useState(false);

    return (
      <>
        <Button type="button" onClick={() => setOpen(true)}>
          Abrir timeline (layer)
        </Button>
        <DrawerShell
          open={open}
          onOpenChange={setOpen}
          title="Atividade"
          description="Histórico factual"
          size="xl"
          origin="end"
          responsiveOrigin="bottom"
          backdropInset="sidebar"
        >
          <p>HOJE · eventos em fluxo contínuo (sem cards por item).</p>
          <p>09:42 — Gerou relatório de produção</p>
          <p>08:16 — Revisou lote</p>
        </DrawerShell>
      </>
    );
  },
};

export const Wide: Story = {
  name: 'Shell — size="wide" (~920px)',
  parameters: {
    docs: {
      description: {
        story:
          'Jornada larga oficial: `size="wide"` → `$drawer-width-wide` (`min(57.5rem, 100%)` = 920px). ' +
          'Não usa o recorte de `xl` layer (650px) nem o full-bleed legado. Mobile reusa a altura de `xl`.',
      },
    },
  },
  render: function Render() {
    const [open, setOpen] = useState(false);

    return (
      <>
        <Button type="button" onClick={() => setOpen(true)}>
          Abrir drawer wide
        </Button>
        <DrawerShell
          open={open}
          onOpenChange={setOpen}
          title="Nova demanda"
          description="Jornada de três decisões — painel largo oficial."
          size="wide"
          origin="end"
          responsiveOrigin="bottom"
          footer={
            <>
              <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
                Cancelar
              </Button>
              <Button type="button" variant="primary" onClick={() => setOpen(false)}>
                Registrar
              </Button>
            </>
          }
        >
          <p>
            `size=&quot;wide&quot;` ocupa ~920px na direita. Combine com DrawerSteps
            `orientation=&quot;vertical&quot;` para a jornada de decisões.
          </p>
        </DrawerShell>
      </>
    );
  },
};
