import { render, screen, waitFor } from '@testing-library/react';
import { useState } from 'react';
import { describe, expect, it } from 'vitest';

import { Button } from '../Button/Button';
import { DrawerShell } from '../Drawer/DrawerShell';

function DrawerHarness({ initiallyOpen = true }: { initiallyOpen?: boolean }) {
  const [open, setOpen] = useState(initiallyOpen);
  return (
    <>
      <button type="button" onClick={() => setOpen(true)}>
        Abrir drawer
      </button>
      <button type="button" onClick={() => setOpen(false)}>
        Fechar drawer
      </button>
      <DrawerShell open={open} title="Cadastro" onOpenChange={setOpen}>
        <p>Fluxo principal</p>
      </DrawerShell>
    </>
  );
}

describe('DrawerShell', () => {
  it('renderiza título quando aberto', () => {
    render(
      <DrawerShell open title="Detalhes" onOpenChange={() => undefined}>
        <p>Conteúdo</p>
      </DrawerShell>,
    );

    expect(screen.getByText('Detalhes')).toBeInTheDocument();
    expect(screen.getByText('Conteúdo')).toBeInTheDocument();
  });

  it('renderiza footer customizado', () => {
    render(
      <DrawerShell
        open
        title="Editar"
        onOpenChange={() => undefined}
        footer={<Button type="button">Salvar</Button>}
      >
        <p>Formulário</p>
      </DrawerShell>,
    );

    expect(screen.getByRole('button', { name: 'Salvar' })).toBeInTheDocument();
  });

  it('aberto: dialog data-open sem data-starting-style preso (painel no fluxo)', async () => {
    render(<DrawerHarness initiallyOpen />);

    const dialog = await screen.findByRole('dialog');
    expect(dialog).toHaveAttribute('data-open');
    // Contrato WebView: starting-style preso + translate = painel invisível.
    expect(dialog).not.toHaveAttribute('data-starting-style');
    expect(dialog).not.toHaveAttribute('data-ending-style');
    expect(screen.getByText('Fluxo principal')).toBeVisible();
  });

  it('fechado: remove dialog e overlay do documento', async () => {
    render(<DrawerHarness initiallyOpen />);
    expect(await screen.findByRole('dialog')).toBeInTheDocument();

    // Harness fica aria-hidden sob o modal — fecha via controle do shell.
    screen.getByRole('button', { name: 'Fechar' }).click();

    await waitFor(() => {
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    });
    expect(
      document.querySelector('[data-ending-style], [data-closed]'),
    ).toBeNull();
    expect(document.querySelector('[role="dialog"]')).toBeNull();
    expect(
      document.querySelector('[class*="backdrop"][data-open]'),
    ).toBeNull();
  });

  it('aberto: backdrop com opacity final perceptível (scrim)', async () => {
    render(<DrawerHarness initiallyOpen />);
    await screen.findByRole('dialog');

    await waitFor(() => {
      const backdrop = document.querySelector(
        '[class*="backdrop"]',
      ) as HTMLElement | null;
      expect(backdrop).toBeTruthy();
      expect(backdrop).toHaveAttribute('data-open');
      expect(backdrop).not.toHaveAttribute('data-starting-style');
      expect(backdrop).not.toHaveAttribute('data-ending-style');
      expect(Number(getComputedStyle(backdrop!).opacity)).toBeGreaterThanOrEqual(
        0.99,
      );
    });
  });

  it('Escape fecha sem residual de backdrop/dialog', async () => {
    render(<DrawerHarness initiallyOpen />);
    await screen.findByRole('dialog');

    document.dispatchEvent(
      new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }),
    );

    await waitFor(() => {
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    });
    expect(
      document.querySelector('[class*="backdrop"][data-open]'),
    ).toBeNull();
    expect(
      document.querySelector('[data-ending-style], [data-closed]'),
    ).toBeNull();
  });

  it('defaults: sem presentation/origin/backdropTone → layer/strong canônicos', async () => {
    render(
      <DrawerShell open title="Padrão" onOpenChange={() => undefined}>
        <p>Conteúdo</p>
      </DrawerShell>,
    );

    const dialog = await screen.findByRole('dialog');
    expect(dialog).toHaveAttribute('data-presentation', 'layer');
    expect(dialog).toHaveAttribute('data-origin', 'end');
    expect(dialog.getAttribute('data-responsive-origin')).toBeNull();
    expect(dialog.className).toMatch(/panelLayer/);

    const backdrop = document.querySelector(
      '[class*="backdrop"]',
    ) as HTMLElement | null;
    expect(backdrop).toHaveAttribute('data-presentation', 'layer');
    expect(backdrop).toHaveAttribute('data-backdrop-tone', 'strong');
    expect(backdrop?.className).toMatch(/backdropStrong/);
  });

  it('presentation="layer" + backdropTone="strong" explícitos: classes xl aplicadas', async () => {
    render(
      <DrawerShell
        open
        title="Layer"
        onOpenChange={() => undefined}
        presentation="layer"
        backdropTone="strong"
        size="xl"
      >
        <p>Conteúdo layer</p>
      </DrawerShell>,
    );

    const dialog = await screen.findByRole('dialog');
    expect(dialog).toHaveAttribute('data-presentation', 'layer');
    expect(dialog.className).toMatch(/panelLayer/);
    expect(dialog.className).toMatch(/panelLayerXl/);

    const backdrop = document.querySelector(
      '[class*="backdrop"]',
    ) as HTMLElement | null;
    expect(backdrop).toHaveAttribute('data-presentation', 'layer');
    expect(backdrop).toHaveAttribute('data-backdrop-tone', 'strong');
    expect(backdrop?.className).toMatch(/backdropStrong/);
  });

  it('size="wide" aplica largura semântica (~920px) sem herdar layer xl 650px', async () => {
    render(
      <DrawerShell
        open
        title="Jornada"
        onOpenChange={() => undefined}
        size="wide"
      >
        <p>Conteúdo wide</p>
      </DrawerShell>,
    );

    const dialog = await screen.findByRole('dialog');
    expect(dialog.className).toMatch(/panelWide/);
    expect(dialog.className).toMatch(/panelLayer/);
    expect(dialog.className).not.toMatch(/panelLayerXl/);
    expect(dialog.className).not.toMatch(/panelXl/);
    expect(getComputedStyle(dialog).width).not.toMatch(/40\.625rem|650px/);
  });

  it('escape hatch presentation="default" + backdropTone="default" preserva legado', async () => {
    render(
      <DrawerShell
        open
        title="Legado"
        onOpenChange={() => undefined}
        presentation="default"
        backdropTone="default"
        size="xl"
      >
        <p>Conteúdo legado</p>
      </DrawerShell>,
    );

    const dialog = await screen.findByRole('dialog');
    expect(dialog).toHaveAttribute('data-presentation', 'default');
    expect(dialog.className).not.toMatch(/panelLayer/);

    const backdrop = document.querySelector(
      '[class*="backdrop"]',
    ) as HTMLElement | null;
    expect(backdrop).toHaveAttribute('data-presentation', 'default');
    expect(backdrop).toHaveAttribute('data-backdrop-tone', 'default');
    expect(backdrop?.className).not.toMatch(/backdropStrong/);
  });

  it('backdropInset="sidebar" aplica a classe de inset independente do size', async () => {
    render(
      <DrawerShell
        open
        title="Inset"
        onOpenChange={() => undefined}
        size="md"
        backdropInset="sidebar"
      >
        <p>Conteúdo</p>
      </DrawerShell>,
    );

    await screen.findByRole('dialog');
    const backdrop = document.querySelector(
      '[class*="backdrop"]',
    ) as HTMLElement | null;
    expect(backdrop?.className).toMatch(/backdropInset/);
  });

  it('backdropInset numérico aplica left customizado via style inline', async () => {
    render(
      <DrawerShell
        open
        title="Inset custom"
        onOpenChange={() => undefined}
        size="xl"
        backdropInset={72}
      >
        <p>Conteúdo</p>
      </DrawerShell>,
    );

    await screen.findByRole('dialog');
    const backdrop = document.querySelector(
      '[class*="backdrop"]',
    ) as HTMLElement | null;
    expect(backdrop?.className).not.toMatch(/backdropInset/);
    expect(backdrop?.style.left).toBe('72px');
  });

  it('Escape fecha presentation="layer" sem residual de backdrop/dialog', async () => {
    function LayerHarness() {
      const [open, setOpen] = useState(true);
      return (
        <DrawerShell
          open={open}
          onOpenChange={setOpen}
          title="Layer"
          presentation="layer"
          backdropTone="strong"
          size="xl"
        >
          <p>Conteúdo</p>
        </DrawerShell>
      );
    }

    render(<LayerHarness />);
    await screen.findByRole('dialog');

    document.dispatchEvent(
      new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }),
    );

    await waitFor(() => {
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    });
    expect(
      document.querySelector('[class*="backdrop"][data-open]'),
    ).toBeNull();
    expect(
      document.querySelector('[data-ending-style], [data-closed]'),
    ).toBeNull();
  });
});
