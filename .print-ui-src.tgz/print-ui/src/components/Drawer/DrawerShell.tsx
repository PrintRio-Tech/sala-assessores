import { Dialog } from '@base-ui-components/react/dialog';
import {
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from 'react';

export type DrawerOpenChangeHandler = (
  open: boolean,
  eventDetails?: Dialog.Root.ChangeEventDetails,
) => void;

import { Button } from '../Button/Button';

import styles from './styles.module.scss';

export type DrawerSize = 'md' | 'lg' | 'xl' | 'wide';

export type DrawerContentLayout = 'scroll' | 'fixed';

export type DrawerFooterAlign = 'end' | 'between';

/** Visual reset canônico (`layer`) vs escape hatch legado (`default`). */
export type DrawerPresentation = 'default' | 'layer';

export type DrawerOrigin = 'end' | 'bottom';

/** Mobile hoje só suporta opt-in explícito para "bottom" (padrão atual). */
export type DrawerResponsiveOrigin = 'bottom';

export type DrawerBackdropTone = 'default' | 'strong';

export type DrawerBackdropInset = number | 'sidebar';

export type DrawerShellProps = {
  open: boolean;
  onOpenChange: DrawerOpenChangeHandler;
  onOpenChangeComplete?: (open: boolean) => void;
  title: ReactNode;
  headerAddon?: ReactNode;
  description?: string;
  size?: DrawerSize;
  contentLayout?: DrawerContentLayout;
  footerAlign?: DrawerFooterAlign;
  closeLabel?: string;
  children: ReactNode;
  footer?: ReactNode;
  bodyClassName?: string;
  /**
   * Default `layer` = visual reset (origem/scrim explícitos, xl ~650px).
   * Escape hatch `default` = legado full-bleed xl.
   */
  presentation?: DrawerPresentation;
  /** Origem espacial no viewport atual (desktop tipicamente `end`). */
  origin?: DrawerOrigin;
  /** Origem em viewport mobile; sem definir, mobile mantém o padrão atual (bottom). */
  responsiveOrigin?: DrawerResponsiveOrigin;
  /**
   * Default `strong` = scrim 0.56–0.66.
   * Escape hatch `default` preserva alpha legado.
   */
  backdropTone?: DrawerBackdropTone;
  /** Inset do scrim: `sidebar` ou offset numérico em px. */
  backdropInset?: DrawerBackdropInset;
};

/** Movimento espacial curto; WAAPI evita transition CSS presa no WebView. */
export const DRAWER_MOTION_MS = 200;

const MOTION_EASE = 'cubic-bezier(0.22, 1, 0.36, 1)';

const panelSizeClass: Record<DrawerSize, string> = {
  md: styles.panelMd,
  lg: styles.panelLg,
  xl: styles.panelXl,
  wide: styles.panelWide,
};

const panelMobileHeightClass: Record<DrawerSize, string> = {
  md: styles.panelMobileMd,
  lg: styles.panelMobileLg,
  xl: styles.panelMobileXl,
  wide: styles.panelMobileWide,
};

const footerAlignClass: Record<DrawerFooterAlign, string> = {
  end: styles.footerAlignEnd,
  between: styles.footerAlignBetween,
};

function prefersReducedMotion(): boolean {
  if (typeof window === 'undefined' || !window.matchMedia) return false;
  return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

function isMobileDrawerViewport(): boolean {
  if (typeof window === 'undefined' || !window.matchMedia) return false;
  // Alinha ao mixin `mobile` do DS (~1024px).
  return window.matchMedia('(max-width: 1023.98px)').matches;
}

function motionDurationMs(): number {
  return prefersReducedMotion() ? 1 : DRAWER_MOTION_MS;
}

/**
 * Mobile é controlado só por `responsiveOrigin` (hoje só "bottom", o padrão
 * atual) — `origin` nunca vaza para mobile, preservando o comportamento
 * atual via CSS independente do que for configurado para desktop.
 */
function resolveActiveOrigin(
  origin: DrawerOrigin | undefined,
  responsiveOrigin: DrawerResponsiveOrigin | undefined,
): DrawerOrigin {
  if (isMobileDrawerViewport()) {
    return responsiveOrigin ?? 'bottom';
  }
  return origin ?? 'end';
}

function cancelElementAnimations(element: Element | null) {
  element?.getAnimations?.().forEach((animation) => {
    try {
      animation.cancel();
    } catch {
      // ignore
    }
  });
}

/** WebView pode deixar animações em currentTime=0; Base UI só desmonta no `finished`. */
function finishDrawerExitAnimations() {
  if (typeof document === 'undefined') return;
  document
    .querySelectorAll('[data-ending-style], [data-closed]')
    .forEach((element) => {
      element.getAnimations?.().forEach((animation) => {
        try {
          animation.finish();
        } catch {
          // ignore
        }
      });
    });
}

function runDrawerMotion(
  panel: HTMLElement,
  open: boolean,
  activeOrigin: DrawerOrigin,
) {
  const duration = motionDurationMs();
  const reduced = prefersReducedMotion();
  const fromBottom = activeOrigin === 'bottom';

  cancelElementAnimations(panel);

  const hiddenTransform = fromBottom ? 'translateY(100%)' : 'translateX(100%)';
  const shownTransform = fromBottom ? 'translateY(0)' : 'translateX(0)';

  // Backdrop: fade CSS (opacity) — WAAPI fill:forwards podia prender opacity em 0 no WebView.
  if (reduced) {
    panel.animate(
      [
        { opacity: open ? 0 : 1, transform: shownTransform },
        { opacity: open ? 1 : 0, transform: shownTransform },
      ],
      { duration, easing: 'linear', fill: 'forwards' },
    );
  } else {
    panel.animate(
      open
        ? [
            { transform: hiddenTransform, opacity: 0.96 },
            { transform: shownTransform, opacity: 1 },
          ]
        : [
            { transform: shownTransform, opacity: 1 },
            { transform: hiddenTransform, opacity: 0.96 },
          ],
      { duration, easing: MOTION_EASE, fill: 'forwards' },
    );
  }
}

export function DrawerShell({
  open,
  onOpenChange,
  onOpenChangeComplete,
  title,
  headerAddon,
  description,
  size = 'md',
  contentLayout = 'scroll',
  footerAlign = 'end',
  closeLabel = 'Fechar',
  children,
  footer,
  bodyClassName,
  presentation = 'layer',
  origin,
  responsiveOrigin,
  backdropTone = 'strong',
  backdropInset,
}: DrawerShellProps) {
  const [mountEpoch, setMountEpoch] = useState(0);
  const wasOpenRef = useRef(false);
  const panelRef = useRef<HTMLDivElement | null>(null);
  const layer = presentation === 'layer';
  // Estático (não depende de matchMedia em render): evita que uma classe CSS
  // sem escopo de media query "grude" se o viewport mudar sem novo render.
  // Mobile continua governado pelos blocos `@include mobile` já existentes.
  const desktopOrigin = origin ?? 'end';

  useLayoutEffect(() => {
    const panel = panelRef.current;
    if (!panel) return;
    const wasOpen = wasOpenRef.current;
    if (open === wasOpen && open) {
      // Remount / first paint while already open: still play enter.
    }
    const resolved = resolveActiveOrigin(origin, responsiveOrigin);
    if (open) {
      runDrawerMotion(panel, true, resolved);
    } else if (wasOpen) {
      runDrawerMotion(panel, false, resolved);
    }
    wasOpenRef.current = open;
  }, [open, mountEpoch, origin, responsiveOrigin]);

  // Controlled close: força finished; se residual persistir, remonta o Root
  // (Base UI não reavalia Promises de anim.finished já penduradas).
  useEffect(() => {
    if (open) return;

    finishDrawerExitAnimations();
    const timeoutId = window.setTimeout(() => {
      finishDrawerExitAnimations();
      if (document.querySelector('[data-ending-style], [data-closed]')) {
        setMountEpoch((epoch) => epoch + 1);
      }
    }, Math.max(48, DRAWER_MOTION_MS + 40));
    return () => window.clearTimeout(timeoutId);
  }, [open]);

  const useSidebarInset =
    backdropInset === 'sidebar' ||
    (backdropInset === undefined && size === 'xl' && !layer);

  const panelClass = [
    styles.panel,
    panelSizeClass[size],
    panelMobileHeightClass[size],
    layer ? styles.panelLayer : undefined,
    layer && size === 'xl' ? styles.panelLayerXl : undefined,
    desktopOrigin === 'bottom' ? styles.panelOriginBottom : undefined,
  ]
    .filter(Boolean)
    .join(' ');

  const backdropClass = [
    styles.backdrop,
    backdropTone === 'strong' ? styles.backdropStrong : undefined,
    useSidebarInset ? styles.backdropInset : undefined,
  ]
    .filter(Boolean)
    .join(' ');

  const backdropStyle: CSSProperties | undefined =
    typeof backdropInset === 'number'
      ? { left: backdropInset }
      : undefined;

  const bodyInnerClass = [styles.bodyInner, bodyClassName]
    .filter(Boolean)
    .join(' ');

  const footerClass = [styles.footer, footerAlignClass[footerAlign]]
    .filter(Boolean)
    .join(' ');

  return (
    <Dialog.Root
      key={mountEpoch}
      open={open}
      onOpenChange={onOpenChange}
      onOpenChangeComplete={onOpenChangeComplete}
    >
      <Dialog.Portal>
        <Dialog.Backdrop
          className={backdropClass}
          style={backdropStyle}
          data-presentation={presentation}
          data-backdrop-tone={backdropTone}
          data-origin={desktopOrigin}
        />
        <Dialog.Popup
          ref={panelRef}
          className={panelClass}
          data-presentation={presentation}
          data-origin={desktopOrigin}
          data-responsive-origin={responsiveOrigin}
        >
          <div className={styles.handle} aria-hidden="true" />
          <header className={styles.headerRow}>
            <div className={styles.header}>
              <Dialog.Title className={styles.title}>{title}</Dialog.Title>
              {headerAddon}
              {description ? (
                <Dialog.Description className={styles.description}>
                  {description}
                </Dialog.Description>
              ) : null}
            </div>
            <Dialog.Close
              render={
                <Button
                  type="button"
                  variant="ghost"
                  iconOnly
                  className={styles.close}
                  aria-label={closeLabel}
                >
                  ×
                </Button>
              }
            />
          </header>
          <div className={styles.bodyScroll} data-layout={contentLayout}>
            <div className={bodyInnerClass}>{children}</div>
          </div>
          {footer ? (
            <footer className={footerClass}>
              <div className={styles.footerInner}>{footer}</div>
            </footer>
          ) : null}
        </Dialog.Popup>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
