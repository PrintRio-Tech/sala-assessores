import { readFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

import { describe, expect, it } from 'vitest';

const here = dirname(fileURLToPath(import.meta.url));

function read(rel: string): string {
  return readFileSync(join(here, rel), 'utf8');
}

describe('DrawerSteps orientation (aditivo)', () => {
  it('prop orientation vertical/horizontal; default horizontal', () => {
    const source = read('DrawerSteps.tsx');

    expect(source).toMatch(
      /export type DrawerStepsOrientation = 'horizontal' \| 'vertical'/,
    );
    expect(source).toMatch(/orientation\?: DrawerStepsOrientation/);
    expect(source).toMatch(/orientation = 'horizontal'/);
    expect(source).toMatch(/aria-orientation=\{orientation\}/);
  });

  it('token e CSS da linha de progresso vertical; stepper default permanece row', () => {
    const tokens = readFileSync(
      join(here, '..', '..', 'tokens', '_drawer.scss'),
      'utf8',
    );
    const scss = read('styles.module.scss');

    expect(tokens).toMatch(/\$drawer-stepper-progress-line:/);
    expect(tokens).toMatch(/\$drawer-stepper-rail-width:/);

    const stepper = scss.match(/^\.stepper\s*\{[\s\S]*?\n\}/m)?.[0] ?? '';
    expect(stepper).toMatch(/display:\s*flex/);
    expect(stepper).not.toMatch(/flex-direction:\s*column/);

    expect(scss).toMatch(
      /\.stepperVertical\s*\{[\s\S]*flex-direction:\s*column/,
    );
    expect(scss).toMatch(
      /\.stepperVertical[\s\S]*\$drawer-stepper-progress-line/,
    );
  });
});
