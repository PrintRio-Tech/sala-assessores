import type { Meta, StoryObj } from '@storybook/react-vite';
import { useMemo, useState } from 'react';

import { Button } from '../Button/Button';
import { ConfirmDialog } from '../ConfirmDialog/ConfirmDialog';

import { DrawerSteps, type DrawerStep } from './DrawerSteps';

function ProvisionAccessDemo() {
  const [open, setOpen] = useState(false);
  const [stepIndex, setStepIndex] = useState(0);
  const [personName, setPersonName] = useState('');
  const [email, setEmail] = useState('');
  const [confirmDiscardOpen, setConfirmDiscardOpen] = useState(false);
  const [isCompleting, setIsCompleting] = useState(false);

  const hasUnsavedChanges = personName.trim().length > 0 || email.trim().length > 0;

  const steps = useMemo<DrawerStep[]>(
    () => [
      {
        id: 'person',
        label: 'Buscar pessoa',
        isValid: personName.trim().length > 0,
        content: (
          <label style={{ display: 'grid', gap: 4 }}>
            Nome
            <input
              aria-label="Nome"
              value={personName}
              onChange={(event) => setPersonName(event.target.value)}
              placeholder="Maria Silva"
            />
          </label>
        ),
      },
      {
        id: 'access',
        label: 'Atribuir acesso',
        isValid: email.includes('@'),
        content: (
          <label style={{ display: 'grid', gap: 4 }}>
            E-mail
            <input
              aria-label="E-mail"
              type="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="maria@empresa.com"
            />
          </label>
        ),
      },
    ],
    [personName, email],
  );

  const resetFlow = () => {
    setStepIndex(0);
    setPersonName('');
    setEmail('');
    setIsCompleting(false);
  };

  const handleRequestClose = () => {
    if (hasUnsavedChanges) {
      setConfirmDiscardOpen(true);
      return;
    }

    setOpen(false);
    resetFlow();
  };

  return (
    <>
      <Button
        type="button"
        onClick={() => {
          resetFlow();
          setOpen(true);
        }}
      >
        Conceder acesso
      </Button>

      <DrawerSteps
        open={open}
        onOpenChange={setOpen}
        flowTitle="Conceder acesso"
        steps={steps}
        currentStepIndex={stepIndex}
        onStepChange={setStepIndex}
        completeLabel="Conceder acesso"
        isCompleting={isCompleting}
        size="lg"
        onComplete={async () => {
          setIsCompleting(true);
          await new Promise((resolve) => {
            setTimeout(resolve, 800);
          });
          setIsCompleting(false);
          resetFlow();
        }}
        onRequestClose={handleRequestClose}
      />

      <ConfirmDialog
        open={confirmDiscardOpen}
        onOpenChange={setConfirmDiscardOpen}
        title="Descartar progresso?"
        description="As informações preenchidas neste fluxo serão perdidas."
        confirmLabel="Descartar"
        cancelLabel="Continuar editando"
        destructive
        onConfirm={() => {
          setConfirmDiscardOpen(false);
          setOpen(false);
          resetFlow();
        }}
      />
    </>
  );
}

const meta = {
  title: 'Overlay/DrawerSteps',
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Painel multi-etapas sobre DrawerShell. Stepper numerado no corpo. Default `orientation="horizontal"` (pills). `orientation="vertical"` = trilho discreto com linha de progresso (jornadas em DrawerShell xl). Persistência e validação ficam no consumidor; dirty close usa ConfirmDialog externo.',
      },
    },
  },
} satisfies Meta;

export default meta;
type Story = StoryObj;

export const ProvisionAccess: Story = {
  name: 'Conceder acesso',
  render: () => <ProvisionAccessDemo />,
};

function ThreeDecisionDemo() {
  const [open, setOpen] = useState(false);
  const [stepIndex, setStepIndex] = useState(0);
  const [pedido, setPedido] = useState('');
  const [contexto, setContexto] = useState('');
  const [destino, setDestino] = useState('');
  const [confirmDiscardOpen, setConfirmDiscardOpen] = useState(false);

  const hasUnsavedChanges =
    pedido.trim().length > 0 ||
    contexto.trim().length > 0 ||
    destino.trim().length > 0;

  const steps = useMemo<DrawerStep[]>(
    () => [
      {
        id: 'pedido',
        label: 'Pedido recebido',
        isValid: pedido.trim().length > 0,
        content: (
          <label style={{ display: 'grid', gap: 4 }}>
            Título
            <input
              aria-label="Título"
              value={pedido}
              onChange={(event) => setPedido(event.target.value)}
            />
          </label>
        ),
      },
      {
        id: 'contexto',
        label: 'Contexto',
        isValid: contexto.trim().length > 0,
        content: (
          <label style={{ display: 'grid', gap: 4 }}>
            Notas
            <input
              aria-label="Notas"
              value={contexto}
              onChange={(event) => setContexto(event.target.value)}
            />
          </label>
        ),
      },
      {
        id: 'encaminhamento',
        label: 'Encaminhamento',
        isValid: destino.trim().length > 0,
        content: (
          <label style={{ display: 'grid', gap: 4 }}>
            Destino
            <input
              aria-label="Destino"
              value={destino}
              onChange={(event) => setDestino(event.target.value)}
            />
          </label>
        ),
      },
    ],
    [pedido, contexto, destino],
  );

  const resetFlow = () => {
    setStepIndex(0);
    setPedido('');
    setContexto('');
    setDestino('');
  };

  const handleRequestClose = () => {
    if (hasUnsavedChanges) {
      setConfirmDiscardOpen(true);
      return;
    }

    setOpen(false);
    resetFlow();
  };

  return (
    <>
      <Button
        type="button"
        onClick={() => {
          resetFlow();
          setOpen(true);
        }}
      >
        Nova demanda
      </Button>

      <DrawerSteps
        open={open}
        onOpenChange={setOpen}
        flowTitle="Nova demanda"
        steps={steps}
        currentStepIndex={stepIndex}
        onStepChange={setStepIndex}
        completeLabel="Registrar"
        size="wide"
        orientation="vertical"
        onComplete={() => {
          resetFlow();
        }}
        onRequestClose={handleRequestClose}
      />

      <ConfirmDialog
        open={confirmDiscardOpen}
        onOpenChange={setConfirmDiscardOpen}
        title="Descartar progresso?"
        description="As informações preenchidas neste fluxo serão perdidas."
        confirmLabel="Descartar"
        cancelLabel="Continuar editando"
        destructive
        onConfirm={() => {
          setConfirmDiscardOpen(false);
          setOpen(false);
          resetFlow();
        }}
      />
    </>
  );
}

export const VerticalJourney: Story = {
  name: 'Jornada vertical (wide)',
  render: () => <ThreeDecisionDemo />,
};
