import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { useState, type ReactNode } from 'react';
import { describe, expect, it, vi } from 'vitest';

import { DrawerSteps, type DrawerStep } from './DrawerSteps';

function DrawerStepsHarness({
  initialStepIndex = 0,
  initialOpen = true,
  steps,
  isCompleting = false,
  onComplete = vi.fn(),
  onCompleteStayOpen,
  completeStayOpenLabel,
  completeLabel = 'Conceder acesso',
  onRequestClose = vi.fn(),
  orientation,
  size,
}: {
  initialStepIndex?: number;
  initialOpen?: boolean;
  steps: DrawerStep[];
  isCompleting?: boolean;
  onComplete?: () => void | Promise<void>;
  onCompleteStayOpen?: () => void | Promise<void>;
  completeStayOpenLabel?: string;
  completeLabel?: string;
  onRequestClose?: () => void;
  orientation?: 'horizontal' | 'vertical';
  size?: 'md' | 'lg' | 'xl' | 'wide';
}) {
  const [open, setOpen] = useState(initialOpen);
  const [currentStepIndex, setCurrentStepIndex] = useState(initialStepIndex);
  const [stepOneValue, setStepOneValue] = useState('');
  const [stepTwoValue, setStepTwoValue] = useState('');

  const resolvedSteps: DrawerStep[] = steps.map((step, index) => {
    if (index === 0 && step.id === 'step-one') {
      return {
        ...step,
        content: (
          <label>
            Nome
            <input
              aria-label="Nome"
              value={stepOneValue}
              onChange={(event) => setStepOneValue(event.target.value)}
            />
          </label>
        ),
        isValid: stepOneValue.trim().length > 0,
      };
    }

    if (index === 1 && step.id === 'step-two') {
      return {
        ...step,
        content: (
          <label>
            E-mail
            <input
              aria-label="E-mail"
              value={stepTwoValue}
              onChange={(event) => setStepTwoValue(event.target.value)}
            />
          </label>
        ),
        isValid: stepTwoValue.includes('@'),
      };
    }

    return step;
  });

  return (
    <DrawerSteps
      open={open}
      onOpenChange={setOpen}
      flowTitle="Conceder acesso"
      steps={resolvedSteps}
      currentStepIndex={currentStepIndex}
      onStepChange={setCurrentStepIndex}
      onComplete={onComplete}
      completeLabel={completeLabel}
      onCompleteStayOpen={onCompleteStayOpen}
      completeStayOpenLabel={completeStayOpenLabel}
      isCompleting={isCompleting}
      onRequestClose={onRequestClose}
      orientation={orientation}
      size={size}
    />
  );
}

const baseSteps: DrawerStep[] = [
  {
    id: 'step-one',
    label: 'Buscar pessoa',
    isValid: false,
    content: null as unknown as ReactNode,
  },
  {
    id: 'step-two',
    label: 'Atribuir acesso',
    isValid: false,
    content: null as unknown as ReactNode,
  },
];

describe('DrawerSteps', () => {
  it('renderiza título composto e stepper numerado no corpo', () => {
    render(<DrawerStepsHarness steps={baseSteps} />);

    expect(
      screen.getByRole('heading', { name: 'Conceder acesso — Buscar pessoa' }),
    ).toBeInTheDocument();
    expect(
      screen.getByRole('tablist', { name: 'Etapas do formulário' }),
    ).toBeInTheDocument();

    const firstTab = screen.getByRole('tab', { name: /Buscar pessoa/ });
    const secondTab = screen.getByRole('tab', { name: /Atribuir acesso/ });
    expect(firstTab).toHaveAttribute('aria-selected', 'true');
    expect(firstTab).toHaveAttribute('aria-current', 'step');
    expect(secondTab).toHaveAttribute('aria-selected', 'false');
    expect(firstTab).toHaveTextContent('1');
    expect(secondTab).toHaveTextContent('2');
    expect(
      screen.getByText('Etapa 1 de 2: Buscar pessoa'),
    ).toBeInTheDocument();
    expect(screen.queryByText(/^Etapa \d+ de \d+$/)).not.toBeInTheDocument();

    const tablist = screen.getByRole('tablist', { name: 'Etapas do formulário' });
    expect(tablist).toHaveAttribute('aria-orientation', 'horizontal');
    expect(tablist.className).not.toMatch(/stepperVertical/);
  });

  it('orientation vertical expõe tablist em coluna com linha de progresso', () => {
    render(
      <DrawerStepsHarness
        steps={baseSteps}
        orientation="vertical"
        size="xl"
      />,
    );

    const tablist = screen.getByRole('tablist', { name: 'Etapas do formulário' });
    expect(tablist).toHaveAttribute('aria-orientation', 'vertical');
    expect(tablist).toHaveAttribute('data-orientation', 'vertical');
    expect(tablist.className).toMatch(/stepperVertical/);
    expect(getComputedStyle(tablist).flexDirection).toBe('column');
  });

  it('size="wide" encaminha o painel largo ao DrawerShell', () => {
    render(
      <DrawerStepsHarness
        steps={baseSteps}
        orientation="vertical"
        size="wide"
      />,
    );

    const dialog = screen.getByRole('dialog');
    expect(dialog.className).toMatch(/panelWide/);
    expect(dialog.className).not.toMatch(/panelLayerXl/);
  });

  it('bloqueia avançar quando a etapa atual é inválida', () => {
    render(<DrawerStepsHarness steps={baseSteps} />);

    const advanceButton = screen.getByRole('button', { name: 'Avançar' });
    expect(advanceButton).toBeDisabled();
    expect(advanceButton).toHaveAttribute('aria-describedby');
  });

  it('não avança pelo stepper se a etapa atual isValid=false', () => {
    render(<DrawerStepsHarness steps={baseSteps} />);

    fireEvent.click(screen.getByRole('tab', { name: /Atribuir acesso/ }));

    expect(
      screen.getByRole('heading', { name: 'Conceder acesso — Buscar pessoa' }),
    ).toBeInTheDocument();
    expect(screen.getByRole('tab', { name: /Atribuir acesso/ })).toHaveAttribute(
      'aria-disabled',
      'true',
    );
  });

  it('avança pelo stepper quando a etapa atual é válida e volta ao clicar em etapa anterior', () => {
    render(<DrawerStepsHarness steps={baseSteps} />);

    fireEvent.change(screen.getByLabelText('Nome'), {
      target: { value: 'Maria' },
    });
    fireEvent.click(screen.getByRole('tab', { name: /Atribuir acesso/ }));

    expect(
      screen.getByRole('heading', { name: 'Conceder acesso — Atribuir acesso' }),
    ).toBeInTheDocument();
    expect(screen.getByRole('tab', { name: /Atribuir acesso/ })).toHaveAttribute(
      'aria-selected',
      'true',
    );

    fireEvent.click(screen.getByRole('tab', { name: /Buscar pessoa/ }));

    expect(
      screen.getByRole('heading', { name: 'Conceder acesso — Buscar pessoa' }),
    ).toBeInTheDocument();
    expect(screen.getByLabelText('Nome')).toHaveValue('Maria');
  });

  it('avança e retorna entre etapas preservando dados do consumidor', () => {
    render(<DrawerStepsHarness steps={baseSteps} />);

    fireEvent.change(screen.getByLabelText('Nome'), {
      target: { value: 'Maria' },
    });
    fireEvent.click(screen.getByRole('button', { name: 'Avançar' }));

    expect(
      screen.getByRole('heading', { name: 'Conceder acesso — Atribuir acesso' }),
    ).toBeInTheDocument();
    expect(
      screen.getByText('Etapa 2 de 2: Atribuir acesso'),
    ).toBeInTheDocument();

    fireEvent.change(screen.getByLabelText('E-mail'), {
      target: { value: 'maria@exemplo.com' },
    });
    fireEvent.click(screen.getByRole('button', { name: 'Voltar' }));

    expect(
      screen.getByRole('heading', { name: 'Conceder acesso — Buscar pessoa' }),
    ).toBeInTheDocument();
    expect(screen.getByLabelText('Nome')).toHaveValue('Maria');
  });

  it('oculta Voltar na primeira etapa', () => {
    render(<DrawerStepsHarness steps={baseSteps} />);

    expect(screen.queryByRole('button', { name: 'Voltar' })).not.toBeInTheDocument();
  });

  it('mostra ação de conclusão na última etapa', () => {
    render(<DrawerStepsHarness steps={baseSteps} initialStepIndex={1} />);

    expect(screen.getByRole('button', { name: 'Voltar' })).toBeInTheDocument();
    expect(
      screen.getByRole('button', { name: 'Conceder acesso' }),
    ).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Avançar' })).not.toBeInTheDocument();
  });

  it('chama onRequestClose ao tentar fechar sem fechar sozinho', () => {
    const onRequestClose = vi.fn();

    render(
      <DrawerStepsHarness steps={baseSteps} onRequestClose={onRequestClose} />,
    );

    fireEvent.click(screen.getByRole('button', { name: 'Fechar' }));

    expect(onRequestClose).toHaveBeenCalledTimes(1);
    expect(screen.getByRole('dialog')).toBeInTheDocument();
  });

  it('fecha após onComplete bem-sucedido na última etapa', async () => {
    const onComplete = vi.fn().mockResolvedValue(undefined);

    render(
      <DrawerStepsHarness
        steps={baseSteps}
        initialStepIndex={1}
        onComplete={onComplete}
      />,
    );

    fireEvent.change(screen.getByLabelText('E-mail'), {
      target: { value: 'maria@exemplo.com' },
    });
    fireEvent.click(screen.getByRole('button', { name: 'Conceder acesso' }));

    await waitFor(() => {
      expect(onComplete).toHaveBeenCalledTimes(1);
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    });
  });

  it('com onCompleteStayOpen: primary fica aberto e secondary fecha', async () => {
    const onComplete = vi.fn().mockResolvedValue(undefined);
    const onCompleteStayOpen = vi.fn().mockResolvedValue(undefined);

    render(
      <DrawerStepsHarness
        steps={baseSteps}
        initialStepIndex={1}
        onComplete={onComplete}
        completeLabel="Salvar e fechar"
        onCompleteStayOpen={onCompleteStayOpen}
        completeStayOpenLabel="Salvar e adicionar outro"
      />,
    );

    fireEvent.change(screen.getByLabelText('E-mail'), {
      target: { value: 'maria@exemplo.com' },
    });

    expect(
      screen.getByRole('button', { name: 'Salvar e adicionar outro' }),
    ).toBeInTheDocument();
    expect(
      screen.getByRole('button', { name: 'Salvar e fechar' }),
    ).toBeInTheDocument();

    fireEvent.click(
      screen.getByRole('button', { name: 'Salvar e adicionar outro' }),
    );

    await waitFor(() => {
      expect(onCompleteStayOpen).toHaveBeenCalledTimes(1);
      expect(onComplete).not.toHaveBeenCalled();
      expect(screen.getByRole('dialog')).toBeInTheDocument();
    });

    fireEvent.click(screen.getByRole('button', { name: 'Salvar e fechar' }));

    await waitFor(() => {
      expect(onComplete).toHaveBeenCalledTimes(1);
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    });
  });

  it('bloqueia navegação enquanto isCompleting', () => {
    render(
      <DrawerStepsHarness
        steps={baseSteps}
        initialStepIndex={1}
        isCompleting
      />,
    );

    expect(screen.getByRole('button', { name: 'Conceder acesso…' })).toBeDisabled();
    expect(screen.getByRole('button', { name: 'Voltar' })).toBeDisabled();
  });

  it('move o foco para o título composto ao trocar de etapa', async () => {
    render(<DrawerStepsHarness steps={baseSteps} />);

    fireEvent.change(screen.getByLabelText('Nome'), {
      target: { value: 'Maria' },
    });
    fireEvent.click(screen.getByRole('button', { name: 'Avançar' }));

    const title = screen.getByText('Conceder acesso — Atribuir acesso');

    await waitFor(() => {
      expect(title).toHaveFocus();
    });
  });

  it('anuncia etapa atual e total para leitores de tela', () => {
    render(<DrawerStepsHarness steps={baseSteps} />);

    expect(
      screen.getByText('Etapa 1 de 2: Buscar pessoa'),
    ).toBeInTheDocument();
  });

  it('encaminha presentation/backdropTone ao DrawerShell (passthrough)', () => {
    render(
      <DrawerSteps
        open
        onOpenChange={() => undefined}
        flowTitle="Cadastro"
        steps={[
          {
            id: 'a',
            label: 'Dados',
            isValid: true,
            content: <p>Formulário</p>,
          },
        ]}
        currentStepIndex={0}
        onStepChange={() => undefined}
        onComplete={() => undefined}
        completeLabel="Salvar"
        onRequestClose={() => undefined}
        presentation="layer"
        origin="end"
        responsiveOrigin="bottom"
        backdropTone="strong"
        backdropInset="sidebar"
      />,
    );

    const backdrop = document.querySelector('[class*="backdrop"]');
    expect(backdrop).toBeTruthy();
    expect(backdrop).toHaveAttribute('data-presentation', 'layer');
    expect(backdrop).toHaveAttribute('data-backdrop-tone', 'strong');

    const dialog = screen.getByRole('dialog');
    expect(dialog).toHaveAttribute('data-presentation', 'layer');
    expect(dialog).toHaveAttribute('data-origin', 'end');
    expect(dialog).toHaveAttribute('data-responsive-origin', 'bottom');
  });

  it('sem props de camada: defaults canônicos layer/strong', () => {
    render(<DrawerStepsHarness steps={baseSteps} />);

    const backdrop = document.querySelector('[class*="backdrop"]');
    expect(backdrop).toHaveAttribute('data-presentation', 'layer');
    expect(backdrop).toHaveAttribute('data-backdrop-tone', 'strong');
  });

  it('escape hatch presentation="default" preserva legado', () => {
    render(
      <DrawerSteps
        open
        onOpenChange={() => undefined}
        flowTitle="Cadastro"
        steps={[
          {
            id: 'a',
            label: 'Dados',
            isValid: true,
            content: <p>Formulário</p>,
          },
        ]}
        currentStepIndex={0}
        onStepChange={() => undefined}
        onComplete={() => undefined}
        completeLabel="Salvar"
        onRequestClose={() => undefined}
        presentation="default"
        backdropTone="default"
      />,
    );

    const backdrop = document.querySelector('[class*="backdrop"]');
    expect(backdrop).toHaveAttribute('data-presentation', 'default');
    expect(backdrop).toHaveAttribute('data-backdrop-tone', 'default');

    const dialog = screen.getByRole('dialog');
    expect(dialog).toHaveAttribute('data-presentation', 'default');
    expect(dialog.className).not.toMatch(/panelLayer/);
  });
});