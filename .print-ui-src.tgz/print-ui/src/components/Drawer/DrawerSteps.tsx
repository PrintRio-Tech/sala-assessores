import {
  useCallback,
  useEffect,
  useId,
  useRef,
  type ReactNode,
} from 'react';

import { Button } from '../Button/Button';

import {
  DrawerShell,
  type DrawerShellProps,
  type DrawerSize,
} from './DrawerShell';
import styles from './styles.module.scss';

export type DrawerStep = {
  id: string;
  label: string;
  isValid: boolean;
  content: ReactNode;
};

export type DrawerStepsOrientation = 'horizontal' | 'vertical';

/** Opt-in visual reset — encaminhado tipado ao DrawerShell. Defaults intactos. */
export type DrawerStepsShellPresentationProps = Pick<
  DrawerShellProps,
  | 'presentation'
  | 'origin'
  | 'responsiveOrigin'
  | 'backdropTone'
  | 'backdropInset'
>;

export type DrawerStepsProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  flowTitle: string;
  steps: DrawerStep[];
  currentStepIndex: number;
  onStepChange: (index: number) => void;
  /**
   * Conclusão que fecha o drawer (ex.: "Salvar e fechar").
   * Sempre presente; no modo dual vira ação secundária (outline).
   */
  onComplete: () => void | Promise<void>;
  completeLabel: string;
  /**
   * Conclusão que mantém o drawer aberto (multi-create).
   * Quando definido com `completeStayOpenLabel`, a última etapa mostra
   * primary = stay open + outline = fechar (`onComplete`).
   */
  onCompleteStayOpen?: () => void | Promise<void>;
  completeStayOpenLabel?: string;
  isCompleting?: boolean;
  onRequestClose: () => void;
  size?: DrawerSize;
  /** Default `horizontal` (pills). `vertical` = trilho discreto com linha de progresso. */
  orientation?: DrawerStepsOrientation;
  backLabel?: string;
  advanceLabel?: string;
  closeLabel?: string;
} & DrawerStepsShellPresentationProps;

export function DrawerSteps({
  open,
  onOpenChange,
  flowTitle,
  steps,
  currentStepIndex,
  onStepChange,
  onComplete,
  completeLabel,
  onCompleteStayOpen,
  completeStayOpenLabel,
  isCompleting = false,
  onRequestClose,
  size = 'md',
  orientation = 'horizontal',
  backLabel = 'Voltar',
  advanceLabel = 'Avançar',
  closeLabel = 'Fechar',
  presentation,
  origin,
  responsiveOrigin,
  backdropTone,
  backdropInset,
}: DrawerStepsProps) {
  const titleFocusRef = useRef<HTMLSpanElement>(null);
  const previousStepIndexRef = useRef(currentStepIndex);
  const invalidHintId = useId();
  const progressStatusId = useId();

  const safeStepIndex = Math.min(
    Math.max(currentStepIndex, 0),
    Math.max(steps.length - 1, 0),
  );
  const currentStep = steps[safeStepIndex];
  const isFirstStep = safeStepIndex === 0;
  const isLastStep = safeStepIndex === steps.length - 1;
  const totalSteps = steps.length;
  const currentStepNumber = safeStepIndex + 1;
  const composedTitle = currentStep
    ? `${flowTitle} — ${currentStep.label}`
    : flowTitle;
  const progressAnnouncement = currentStep
    ? `Etapa ${currentStepNumber} de ${totalSteps}: ${currentStep.label}`
    : `Etapa ${currentStepNumber} de ${totalSteps}`;
  const canAdvance = Boolean(currentStep?.isValid) && !isCompleting;
  const hasDualComplete = Boolean(
    onCompleteStayOpen && completeStayOpenLabel,
  );
  const completeButtonLabel = isCompleting ? `${completeLabel}…` : completeLabel;
  const stayOpenButtonLabel = isCompleting
    ? `${completeStayOpenLabel}…`
    : completeStayOpenLabel;

  const handleOpenChange = useCallback(
    (nextOpen: boolean, eventDetails?: { cancel: () => void }) => {
      if (!nextOpen) {
        eventDetails?.cancel();
        onRequestClose();
        return;
      }

      onOpenChange(nextOpen);
    },
    [onOpenChange, onRequestClose],
  );

  const handleBack = useCallback(() => {
    if (isCompleting || isFirstStep) {
      return;
    }

    onStepChange(safeStepIndex - 1);
  }, [isCompleting, isFirstStep, onStepChange, safeStepIndex]);

  const handleComplete = useCallback(
    async (mode: 'close' | 'stay') => {
      if (!currentStep?.isValid || isCompleting) {
        return;
      }

      try {
        if (mode === 'stay') {
          await onCompleteStayOpen?.();
          return;
        }

        await onComplete();
        onOpenChange(false);
      } catch {
        // Mantém o painel aberto quando a conclusão falha.
      }
    },
    [
      currentStep?.isValid,
      isCompleting,
      onComplete,
      onCompleteStayOpen,
      onOpenChange,
    ],
  );

  const handleAdvance = useCallback(() => {
    if (!canAdvance) {
      return;
    }

    if (isLastStep) {
      void handleComplete(hasDualComplete ? 'stay' : 'close');
      return;
    }

    onStepChange(safeStepIndex + 1);
  }, [
    canAdvance,
    handleComplete,
    hasDualComplete,
    isLastStep,
    onStepChange,
    safeStepIndex,
  ]);

  const canSelectStep = useCallback(
    (index: number) => {
      if (isCompleting) {
        return false;
      }

      if (index <= safeStepIndex) {
        return true;
      }

      return steps.slice(safeStepIndex, index).every((step) => step.isValid);
    },
    [isCompleting, safeStepIndex, steps],
  );

  const handleStepSelect = useCallback(
    (index: number) => {
      if (index === safeStepIndex || !canSelectStep(index)) {
        return;
      }

      onStepChange(index);
    },
    [canSelectStep, onStepChange, safeStepIndex],
  );

  useEffect(() => {
    if (!open) {
      previousStepIndexRef.current = safeStepIndex;
      return;
    }

    if (previousStepIndexRef.current !== safeStepIndex) {
      titleFocusRef.current?.focus();
      previousStepIndexRef.current = safeStepIndex;
    }
  }, [open, safeStepIndex]);

  if (!currentStep) {
    return null;
  }

  const title = (
    <span
      ref={titleFocusRef}
      tabIndex={-1}
      className={styles.stepsComposedTitle}
    >
      {composedTitle}
    </span>
  );

  const isVertical = orientation === 'vertical';

  const stepper = (
    <div className={styles.stepperBlock}>
      <div
        className={[
          styles.stepper,
          isVertical ? styles.stepperVertical : undefined,
        ]
          .filter(Boolean)
          .join(' ')}
        role="tablist"
        aria-label="Etapas do formulário"
        aria-orientation={orientation}
        data-orientation={orientation}
      >
        {steps.map((step, index) => {
          const isCurrent = index === safeStepIndex;
          const isComplete = index < safeStepIndex;
          const selectable = canSelectStep(index);

          return (
            <button
              key={step.id}
              type="button"
              role="tab"
              aria-selected={isCurrent}
              aria-current={isCurrent ? 'step' : undefined}
              aria-disabled={!selectable || isCompleting}
              className={[
                styles.step,
                isCurrent ? styles.stepCurrent : undefined,
                isComplete ? styles.stepComplete : undefined,
              ]
                .filter(Boolean)
                .join(' ')}
              onClick={() => handleStepSelect(index)}
            >
              <span className={styles.stepIndex} aria-hidden="true">
                {index + 1}
              </span>
              <span className={styles.stepLabel}>{step.label}</span>
            </button>
          );
        })}
      </div>
      <div
        id={progressStatusId}
        className={styles.srOnly}
        role="status"
        aria-live="polite"
      >
        {progressAnnouncement}
      </div>
    </div>
  );

  const showDualComplete = isLastStep && hasDualComplete;

  const footer = (
    <>
      {!isFirstStep ? (
        <Button
          type="button"
          variant="ghost"
          className={styles.footerAction}
          onClick={handleBack}
          disabled={isCompleting}
        >
          {backLabel}
        </Button>
      ) : null}
      {showDualComplete ? (
        <>
          <Button
            type="button"
            variant="outline"
            className={styles.footerAction}
            onClick={() => void handleComplete('close')}
            disabled={!canAdvance}
            aria-describedby={!canAdvance ? invalidHintId : undefined}
          >
            {completeButtonLabel}
          </Button>
          <Button
            type="button"
            variant="primary"
            className={styles.footerAction}
            onClick={() => void handleComplete('stay')}
            disabled={!canAdvance}
            aria-describedby={!canAdvance ? invalidHintId : undefined}
          >
            {stayOpenButtonLabel}
          </Button>
        </>
      ) : (
        <Button
          type="button"
          variant="primary"
          className={styles.footerAction}
          onClick={handleAdvance}
          disabled={!canAdvance}
          aria-describedby={!canAdvance ? invalidHintId : undefined}
        >
          {isLastStep ? completeButtonLabel : advanceLabel}
        </Button>
      )}
    </>
  );

  return (
    <>
      <span id={invalidHintId} className={styles.srOnly}>
        Etapa incompleta. Corrija os campos obrigatórios antes de avançar.
      </span>
      <DrawerShell
        open={open}
        onOpenChange={handleOpenChange}
        title={title}
        size={size}
        closeLabel={closeLabel}
        footerAlign={isFirstStep ? 'end' : 'between'}
        footer={footer}
        presentation={presentation}
        origin={origin}
        responsiveOrigin={responsiveOrigin}
        backdropTone={backdropTone}
        backdropInset={backdropInset}
      >
        <div
          className={[
            styles.stepsBody,
            isVertical ? styles.stepsBodyVertical : undefined,
          ]
            .filter(Boolean)
            .join(' ')}
        >
          {stepper}
          <div key={currentStep.id}>{currentStep.content}</div>
        </div>
      </DrawerShell>
    </>
  );
}
