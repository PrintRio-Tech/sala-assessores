import { Dialog } from '@base-ui-components/react/dialog';
import type { ReactElement, ReactNode } from 'react';

import { Button } from '../Button/Button';

import type { DrawerSize } from './DrawerShell';
import styles from './styles.module.scss';

export type {
  DrawerSize,
  DrawerShellProps,
  DrawerContentLayout,
  DrawerFooterAlign,
  DrawerOpenChangeHandler,
  DrawerPresentation,
  DrawerOrigin,
  DrawerResponsiveOrigin,
  DrawerBackdropTone,
  DrawerBackdropInset,
} from './DrawerShell';
export { DrawerShell, DRAWER_MOTION_MS } from './DrawerShell';
export {
  DrawerSteps,
  type DrawerStep,
  type DrawerStepsProps,
  type DrawerStepsOrientation,
  type DrawerStepsShellPresentationProps,
} from './DrawerSteps';

export type DrawerProps = {
  children: ReactElement<Record<string, unknown>>;
  title: string;
  description?: string;
  body?: ReactNode;
  confirmLabel?: string;
  cancelLabel?: string;
  onConfirm?: () => void;
  size?: DrawerSize;
};

const panelSizeClass: Record<DrawerSize, string> = {
  md: styles.panelMd,
  lg: styles.panelLg,
  xl: styles.panelXl,
  wide: styles.panelWide,
};

const panelMobileHeightClass: Record<DrawerSize, string> = {
  md: styles.panelMobileMd,
  lg: styles.panelMobileLg,
  xl: styles.panelMobileXl,
  wide: styles.panelMobileWide,
};

export function Drawer({
  children,
  title,
  description,
  body,
  confirmLabel = 'Confirmar',
  cancelLabel = 'Cancelar',
  onConfirm,
  size = 'md',
}: DrawerProps) {
  const panelClass = [
    styles.panel,
    panelSizeClass[size],
    panelMobileHeightClass[size],
  ].join(' ');

  const backdropClass = [
    styles.backdrop,
    size === 'xl' ? styles.backdropInset : undefined,
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <Dialog.Root>
      <Dialog.Trigger render={children} />
      <Dialog.Portal>
        <Dialog.Backdrop className={backdropClass} />
        <Dialog.Popup className={panelClass}>
          <div className={styles.handle} aria-hidden="true" />
          <header className={styles.headerRow}>
            <div className={styles.header}>
              <Dialog.Title className={styles.title}>{title}</Dialog.Title>
              {description ? (
                <Dialog.Description className={styles.description}>
                  {description}
                </Dialog.Description>
              ) : null}
            </div>
          </header>
          {body ? (
            <div className={styles.bodyScroll} data-layout="scroll">
              <div className={styles.bodyInner}>{body}</div>
            </div>
          ) : null}
          <footer className={styles.footer}>
            <div className={styles.footerInner}>
              <Dialog.Close
                render={
                  <Button variant="ghost" className={styles.footerAction}>
                    {cancelLabel}
                  </Button>
                }
              />
              <Dialog.Close
                render={
                  <Button
                    variant="primary"
                    className={styles.footerAction}
                    onClick={onConfirm}
                  >
                    {confirmLabel}
                  </Button>
                }
              />
            </div>
          </footer>
        </Dialog.Popup>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
