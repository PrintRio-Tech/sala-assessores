import type { Meta, StoryObj } from '@storybook/react-vite';
import { fn } from 'storybook/test';

import { EmptyState } from './EmptyState';

const meta = {
  title: 'Foundation/EmptyState',
  component: EmptyState,
  tags: ['autodocs'],
  args: {
    variant: 'empty',
    title: 'Nenhum item ainda',
    description: 'Comece criando o primeiro registro para ver os dados aqui.',
    action: {
      label: 'Criar item',
      onClick: fn(),
    },
  },
  argTypes: {
    variant: {
      control: 'select',
      options: ['empty', 'filtered', 'error'],
    },
  },
} satisfies Meta<typeof EmptyState>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const Empty: Story = {
  args: {
    variant: 'empty',
    title: 'Nenhum clipping',
    description: 'Adicione um clipping para começar a acompanhar a cobertura.',
    action: {
      label: 'Novo clipping',
      onClick: fn(),
    },
  },
};

export const Filtered: Story = {
  args: {
    variant: 'filtered',
    title: 'Nenhum resultado',
    description: 'Ajuste os filtros ou limpe a busca para ver mais itens.',
    action: {
      label: 'Limpar filtros',
      onClick: fn(),
    },
  },
};

export const Error: Story = {
  args: {
    variant: 'error',
    title: 'Não foi possível carregar',
    description: 'Ocorreu um erro ao buscar os dados. Tente novamente.',
    action: {
      label: 'Tentar de novo',
      onClick: fn(),
    },
  },
};

export const WithoutAction: Story = {
  args: {
    variant: 'empty',
    title: 'Lista vazia',
    description: 'Não há itens para exibir no momento.',
    action: undefined,
  },
};
