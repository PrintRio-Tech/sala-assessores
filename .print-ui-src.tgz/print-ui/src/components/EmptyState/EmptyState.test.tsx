import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';

import { EmptyState } from './EmptyState';

describe('EmptyState', () => {
  it('renderiza título e descrição em todas as variantes', () => {
    render(
      <EmptyState
        variant="empty"
        title="Sua base de clientes começa aqui."
        description="Cadastre o primeiro cliente da assessoria."
      />,
    );

    expect(
      screen.getByRole('heading', { level: 2, name: 'Sua base de clientes começa aqui.' }),
    ).toBeInTheDocument();
    expect(screen.getByText('Cadastre o primeiro cliente da assessoria.')).toBeInTheDocument();
  });

  it('expõe role="alert" apenas na variante error', () => {
    const { rerender } = render(
      <EmptyState variant="error" title="Erro" description="Falha ao carregar." />,
    );

    expect(screen.getByRole('alert')).toBeInTheDocument();

    rerender(
      <EmptyState variant="empty" title="Vazio" description="Sem itens." />,
    );
    expect(screen.queryByRole('alert')).not.toBeInTheDocument();

    rerender(
      <EmptyState variant="filtered" title="Filtrado" description="Nenhum resultado." />,
    );
    expect(screen.queryByRole('alert')).not.toBeInTheDocument();
  });

  it('renderiza ação primária na variante empty', () => {
    const onAction = vi.fn();

    render(
      <EmptyState
        variant="empty"
        title="Sua operação na plataforma começa aqui."
        description="Cadastre o primeiro cliente."
        action={{ label: 'Cadastrar primeiro cliente', onClick: onAction }}
      />,
    );

    const button = screen.getByRole('button', { name: 'Cadastrar primeiro cliente' });
    expect(button).toBeInTheDocument();
    fireEvent.click(button);
    expect(onAction).toHaveBeenCalledOnce();
  });

  it('renderiza ação outline na variante filtered', () => {
    const onAction = vi.fn();

    render(
      <EmptyState
        variant="filtered"
        title="Nenhum cliente encontrado."
        description="Ajuste ou limpe a busca."
        action={{ label: 'Limpar filtros', onClick: onAction }}
      />,
    );

    const button = screen.getByRole('button', { name: 'Limpar filtros' });
    fireEvent.click(button);
    expect(onAction).toHaveBeenCalledOnce();
  });

  it('renderiza ação outline na variante error', () => {
    const onAction = vi.fn();

    render(
      <EmptyState
        variant="error"
        title="Não foi possível carregar os clientes."
        description="Verifique sua conexão e tente novamente."
        action={{ label: 'Tentar novamente', onClick: onAction }}
      />,
    );

    const button = screen.getByRole('button', { name: 'Tentar novamente' });
    fireEvent.click(button);
    expect(onAction).toHaveBeenCalledOnce();
  });

  it('omite botão quando action não é fornecida', () => {
    render(
      <EmptyState
        variant="filtered"
        title="Nenhuma métrica no período."
        description="Ajuste ou limpe os filtros."
      />,
    );

    expect(screen.queryByRole('button')).not.toBeInTheDocument();
  });

  it('renderiza marcador decorativo com aria-hidden', () => {
    render(
      <EmptyState
        variant="empty"
        title="Título"
        description="Descrição"
        mark="“"
      />,
    );

    const mark = screen.getByText('“');
    expect(mark).toHaveAttribute('aria-hidden', 'true');
  });

  it('tem paridade estrutural com DashboardEmptyState (empty + error)', () => {
    const onCreate = vi.fn();
    const onRetry = vi.fn();

    const { rerender } = render(
      <EmptyState
        variant="empty"
        title="Sua operação na plataforma começa aqui."
        description="Cadastre o primeiro cliente para liberar relatórios e KPIs no dashboard."
        mark="“"
        action={{ label: 'Cadastrar primeiro cliente', onClick: onCreate }}
      />,
    );

    expect(screen.getByText('“')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Cadastrar primeiro cliente' })).toBeInTheDocument();

    rerender(
      <EmptyState
        variant="error"
        title="Não foi possível carregar o dashboard."
        description="Verifique sua conexão e tente novamente."
        mark="“"
        action={{ label: 'Tentar novamente', onClick: onRetry }}
      />,
    );

    expect(screen.getByRole('alert')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Tentar novamente' })).toBeInTheDocument();
  });
});
