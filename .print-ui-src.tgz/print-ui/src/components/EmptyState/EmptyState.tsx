import type { ReactNode } from 'react';

import { Button } from '../Button/Button';
import { Heading } from '../Heading/Heading';
import { Text } from '../Text/Text';

import styles from './styles.module.scss';

export type EmptyStateVariant = 'empty' | 'filtered' | 'error';

export type EmptyStateAction = {
  label: string;
  onClick: () => void;
};

export type EmptyStateProps = {
  variant: EmptyStateVariant;
  title: string;
  description: string;
  action?: EmptyStateAction;
  mark?: ReactNode;
  className?: string;
};

function actionButtonVariant(variant: EmptyStateVariant): 'primary' | 'outline' {
  return variant === 'empty' ? 'primary' : 'outline';
}

export function EmptyState({
  variant,
  title,
  description,
  action,
  mark,
  className,
}: EmptyStateProps) {
  const classes = [styles.root, className].filter(Boolean).join(' ');

  return (
    <section className={classes} role={variant === 'error' ? 'alert' : undefined}>
      {mark != null ? (
        <span className={styles.mark} aria-hidden="true">
          {mark}
        </span>
      ) : null}
      <Heading level={2}>{title}</Heading>
      <Text tone="muted">{description}</Text>
      {action ? (
        <Button type="button" variant={actionButtonVariant(variant)} onClick={action.onClick}>
          {action.label}
        </Button>
      ) : null}
    </section>
  );
}
