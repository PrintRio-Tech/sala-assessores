import type { Meta, StoryObj } from '@storybook/react-vite';

import inputStyles from '../TextInput/styles.module.scss';
import { TextInput } from '../TextInput/TextInput';
import { FormField } from './FormField';

const meta = {
  title: 'Forms/FormField',
  component: FormField,
  tags: ['autodocs'],
  args: {
    label: 'E-mail',
    labelHidden: false,
    labelSize: 'md',
    required: false,
    description: undefined,
    error: undefined,
    htmlFor: 'email',
    children: (
      <input
        id="email"
        name="email"
        type="email"
        className={inputStyles.input}
        placeholder="voce@empresa.com"
      />
    ),
  },
  argTypes: {
    labelSize: {
      control: 'select',
      options: ['md', 'sm'],
    },
    children: { control: false },
  },
} satisfies Meta<typeof FormField>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const Required: Story = {
  args: { required: true },
};

export const WithDescription: Story = {
  args: {
    description: 'Usamos este e-mail para enviar o recibo.',
  },
};

export const Error: Story = {
  args: {
    error: 'Informe um e-mail válido.',
    children: (
      <input
        id="email"
        name="email"
        type="email"
        className={[inputStyles.input, inputStyles.inputInvalid].join(' ')}
        defaultValue="invalido"
        aria-invalid
      />
    ),
  },
};

export const SmallLabel: Story = {
  args: { labelSize: 'sm' },
};

export const LabelHidden: Story = {
  args: { labelHidden: true },
};

export const Disabled: Story = {
  args: {
    disabled: true,
    name: 'email',
    children: (
      <input
        id="email"
        name="email"
        type="email"
        className={inputStyles.input}
        placeholder="voce@empresa.com"
        disabled
      />
    ),
  },
};

/** TextInput already composes FormField internally. */
export const WithTextInput: Story = {
  render: () => (
    <TextInput
      label="Nome completo"
      name="fullName"
      placeholder="Maria Silva"
      description="Como aparece no comprovante."
    />
  ),
};
