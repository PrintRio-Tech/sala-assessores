import { Field } from '@base-ui-components/react/field';
import type { ReactNode } from 'react';

import styles from './FormField.module.css';

export type FormFieldTone = 'default' | 'onPrimary';

export type FormFieldProps = {
  label: string;
  labelHidden?: boolean;
  labelSize?: 'md' | 'sm';
  /**
   * `onPrimary` — labels/descrições legíveis sobre fundo primary (ex.: sidebar).
   * Não altera o controle filho; combine com inputs `size="sm"` quando a densidade pedir.
   */
  tone?: FormFieldTone;
  required?: boolean;
  description?: string;
  error?: string;
  children: ReactNode;
  htmlFor?: string;
  name?: string;
  disabled?: boolean;
  invalid?: boolean;
};

function labelClassName(
  labelSize: 'md' | 'sm',
  labelHidden: boolean,
  tone: FormFieldTone,
) {
  return [
    styles.label,
    labelSize === 'sm' ? styles.labelSm : '',
    labelHidden ? styles.labelHidden : '',
    tone === 'onPrimary' ? styles.labelOnPrimary : '',
  ]
    .filter(Boolean)
    .join(' ');
}

export function FormField({
  label,
  labelHidden = false,
  labelSize = 'md',
  tone = 'default',
  required = false,
  description,
  error,
  children,
  htmlFor,
  name,
  disabled,
  invalid,
}: FormFieldProps) {
  const labelContent = (
    <>
      {label}
      {required ? (
        <span className={styles.required} aria-hidden="true">
          *
        </span>
      ) : null}
    </>
  );

  const meta = (
    <>
      {description ? (
        <span
          className={[
            styles.description,
            tone === 'onPrimary' ? styles.descriptionOnPrimary : '',
          ]
            .filter(Boolean)
            .join(' ')}
        >
          {description}
        </span>
      ) : null}
      {error ? (
        <span className={styles.error} role="alert">
          {error}
        </span>
      ) : null}
    </>
  );

  const fieldClass = [
    styles.field,
    labelHidden ? styles.fieldCompact : '',
    tone === 'onPrimary' ? styles.fieldOnPrimary : '',
  ]
    .filter(Boolean)
    .join(' ');

  if (name) {
    return (
      <Field.Root
        name={name}
        disabled={disabled}
        invalid={invalid ?? Boolean(error)}
        aria-required={required || undefined}
        className={fieldClass}
        data-tone={tone}
      >
        <Field.Label
          className={labelClassName(labelSize, labelHidden, tone)}
          htmlFor={htmlFor}
        >
          {labelContent}
        </Field.Label>
        {children}
        {meta}
      </Field.Root>
    );
  }

  return (
    <div className={fieldClass} data-tone={tone}>
      <label
        htmlFor={htmlFor}
        className={labelClassName(labelSize, labelHidden, tone)}
      >
        {labelContent}
      </label>
      {children}
      {meta}
    </div>
  );
}
