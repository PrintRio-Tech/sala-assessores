import type { Meta, StoryObj } from '@storybook/react-vite';

import { Heading } from './Heading';

const meta = {
  title: 'Foundation/Heading',
  component: Heading,
  tags: ['autodocs'],
  args: {
    children: 'Título do Print Forms',
    level: 2,
  },
  parameters: {
    docs: {
      description: {
        component:
          'Título semântico. `level` escolhe a tag (h1–h6); `variant` escolhe o tamanho visual. Defaults: 1→xl (48px), 2→lg (32px), 3–6→md (24px). `variant="sm"` é aditivo (20px / line-height 1.2) para títulos compactos — ex. CTA em Card action: `<Heading level={3} variant="sm">`.',
      },
    },
  },
  argTypes: {
    level: {
      control: 'select',
      options: [1, 2, 3, 4, 5, 6],
    },
    variant: {
      control: 'select',
      options: ['xl', 'lg', 'md', 'sm'],
    },
  },
} satisfies Meta<typeof Heading>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const Levels: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <Heading level={1}>Heading level 1</Heading>
      <Heading level={2}>Heading level 2</Heading>
      <Heading level={3}>Heading level 3</Heading>
      <Heading level={4}>Heading level 4</Heading>
      <Heading level={5}>Heading level 5</Heading>
      <Heading level={6}>Heading level 6</Heading>
    </div>
  ),
};

export const Variants: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <Heading variant="xl">Variant xl</Heading>
      <Heading variant="lg">Variant lg</Heading>
      <Heading variant="md">Variant md</Heading>
      <Heading variant="sm">Variant sm</Heading>
    </div>
  ),
};
