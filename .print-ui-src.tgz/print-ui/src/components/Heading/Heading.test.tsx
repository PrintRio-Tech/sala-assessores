import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { Heading } from './Heading';

describe('Heading', () => {
  it('renderiza tag semântica conforme level', () => {
    render(<Heading level={1}>Título</Heading>);

    const heading = screen.getByRole('heading', { level: 1 });
    expect(heading).toHaveTextContent('Título');
    expect(heading.tagName).toBe('H1');
  });

  it('suporta levels h4–h6', () => {
    const { rerender } = render(<Heading level={4}>Nível 4</Heading>);
    expect(screen.getByRole('heading', { level: 4 })).toBeInTheDocument();

    rerender(<Heading level={6}>Nível 6</Heading>);
    expect(screen.getByRole('heading', { level: 6 })).toBeInTheDocument();
  });

  it('variant sm é 20px com line-height curto; level 3 default permanece 24px', () => {
    const { rerender } = render(
      <Heading level={3} variant="sm">
        Nova demanda
      </Heading>,
    );

    const compact = screen.getByRole('heading', { level: 3, name: 'Nova demanda' });
    expect(compact.tagName).toBe('H3');
    expect(getComputedStyle(compact).fontSize).toBe('1.25rem');
    expect(getComputedStyle(compact).lineHeight).toBe('1.2');

    rerender(<Heading level={3}>Seção</Heading>);
    const section = screen.getByRole('heading', { level: 3, name: 'Seção' });
    expect(getComputedStyle(section).fontSize).toBe('1.5rem');
  });

  it('permite elemento polimórfico via as', () => {
    render(
      <Heading as="div" level={2} data-testid="custom-heading">
        Custom
      </Heading>,
    );

    const element = screen.getByTestId('custom-heading');
    expect(element.tagName).toBe('DIV');
    expect(element).toHaveTextContent('Custom');
  });
});
