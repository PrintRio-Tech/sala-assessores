import type { ComponentPropsWithoutRef, ElementType } from 'react';

import styles from './styles.module.scss';

type HeadingLevel = 1 | 2 | 3 | 4 | 5 | 6;
type HeadingVariant = 'xl' | 'lg' | 'md' | 'sm';

const levelTag: Record<HeadingLevel, 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6'> = {
  1: 'h1',
  2: 'h2',
  3: 'h3',
  4: 'h4',
  5: 'h5',
  6: 'h6',
};

const variantClass: Record<HeadingVariant, string> = {
  xl: styles.xl,
  lg: styles.lg,
  md: styles.md,
  sm: styles.sm,
};

function defaultVariantForLevel(level: HeadingLevel): HeadingVariant {
  if (level === 1) return 'xl';
  if (level === 2) return 'lg';
  return 'md';
}

export type HeadingProps<T extends ElementType = 'h1'> = {
  level?: HeadingLevel;
  variant?: HeadingVariant;
  as?: T;
} & ComponentPropsWithoutRef<T>;

export function Heading<T extends ElementType = 'h1'>({
  level = 2,
  variant,
  as,
  className,
  ...props
}: HeadingProps<T>) {
  const Tag = as ?? levelTag[level];
  const resolvedVariant = variant ?? defaultVariantForLevel(level);
  const classes = [styles.heading, variantClass[resolvedVariant], className]
    .filter(Boolean)
    .join(' ');

  return <Tag className={classes} {...props} />;
}
