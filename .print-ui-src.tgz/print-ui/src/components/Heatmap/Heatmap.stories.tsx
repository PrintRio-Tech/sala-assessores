import type { Meta, StoryObj } from '@storybook/react-vite';

import { Heatmap, type HeatmapCell } from './Heatmap';

function buildMockCells(): HeatmapCell[] {
  const cells: HeatmapCell[] = [];

  for (let weekday = 0; weekday < 7; weekday += 1) {
    for (let hour = 0; hour < 24; hour += 1) {
      const isWeekend = weekday === 0 || weekday === 6;
      const peak =
        hour >= 8 && hour <= 11
          ? 1
          : hour >= 14 && hour <= 18
            ? 0.85
            : hour >= 20 && hour <= 22
              ? 0.45
              : 0.1;
      const weekendFactor = isWeekend ? 0.55 : 1;
      const noise = ((weekday * 17 + hour * 13) % 7) / 7;
      const count = Math.round(peak * weekendFactor * (8 + noise * 20));

      if (count > 0) {
        cells.push({ weekday, hour, count });
      }
    }
  }

  return cells;
}

const mockCells = buildMockCells();

const meta = {
  title: 'Data/Heatmap',
  component: Heatmap,
  tags: ['autodocs'],
  args: {
    cells: mockCells,
    loading: false,
    'aria-label': 'Mapa de calor por dia e hora',
  },
  argTypes: {
    loading: { control: 'boolean' },
  },
} satisfies Meta<typeof Heatmap>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const Loading: Story = {
  args: {
    loading: true,
  },
};

export const Sparse: Story = {
  args: {
    cells: [
      { weekday: 1, hour: 9, count: 12 },
      { weekday: 1, hour: 10, count: 18 },
      { weekday: 2, hour: 15, count: 7 },
      { weekday: 3, hour: 11, count: 22 },
      { weekday: 4, hour: 16, count: 9 },
      { weekday: 5, hour: 8, count: 14 },
      { weekday: 5, hour: 20, count: 5 },
    ],
    'aria-label': 'Picos de publicação',
  },
};

export const Empty: Story = {
  args: {
    cells: [],
  },
};
