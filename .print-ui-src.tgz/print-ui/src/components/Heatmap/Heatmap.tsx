import { BoneBlock } from '../Skeleton/bones';

import styles from './styles.module.scss';

export type HeatmapCell = {
  /** 0 = domingo … 6 = sábado */
  weekday: number;
  /** 0–23 */
  hour: number;
  count: number;
};

export type HeatmapProps = {
  cells: HeatmapCell[];
  loading?: boolean;
  className?: string;
  'aria-label'?: string;
};

const WEEKDAYS = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'] as const;
const HOURS = Array.from({ length: 24 }, (_, i) => i);

function intensity(count: number, max: number): number {
  if (max <= 0 || count <= 0) return 0;
  return Math.min(1, count / max);
}

function cellColor(t: number): string {
  if (t <= 0) return 'var(--pf-o-white)';
  // Verde Sálvia → Verde Floresta
  const r = Math.round(136 + (44 - 136) * t);
  const g = Math.round(144 + (65 - 144) * t);
  const b = Math.round(100 + (42 - 100) * t);
  return `rgb(${r} ${g} ${b})`;
}

export function Heatmap({
  cells,
  loading = false,
  className,
  'aria-label': ariaLabel = 'Mapa de calor por dia e hora',
}: HeatmapProps) {
  const classes = [styles.root, className].filter(Boolean).join(' ');
  const max = Math.max(0, ...cells.map((c) => c.count));
  const lookup = new Map(
    cells.map((c) => [`${c.weekday}-${c.hour}`, c.count] as const),
  );

  if (loading) {
    return (
      <div
        className={classes}
        role="img"
        aria-label={ariaLabel}
        aria-busy="true"
      >
        <BoneBlock className={styles.skeleton} height={180} width="100%" />
      </div>
    );
  }

  return (
    <div className={classes} role="img" aria-label={ariaLabel}>
      <div className={styles.grid} aria-hidden="true">
        <div className={styles.hoursRow}>
          <span className={styles.weekdayLabel} />
          {HOURS.map((hour) => (
            <span key={`h-${hour}`} className={styles.hourLabel}>
              {hour % 3 === 0 ? String(hour).padStart(2, '0') : ''}
            </span>
          ))}
        </div>

        {WEEKDAYS.map((label, weekday) => (
          <div key={label} className={styles.row}>
            <span className={styles.weekdayLabel}>{label}</span>
            {HOURS.map((hour) => {
              const count = lookup.get(`${weekday}-${hour}`) ?? 0;
              const t = intensity(count, max);
              return (
                <span
                  key={`${weekday}-${hour}`}
                  className={styles.cell}
                  style={{ backgroundColor: cellColor(t) }}
                  title={`${label} ${hour}h: ${count}`}
                />
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}
