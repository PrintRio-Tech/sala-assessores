import type { Meta, StoryObj } from '@storybook/react-vite';

import { ICONS } from '../../assets/icons';
import { Icon } from './index';

// Icons resolve from `/icons/...`. If they don't load in Storybook,
// set staticDirs: ['../public'] in .storybook/main.ts (parent will handle).

const meta = {
  title: 'Foundation/Icon',
  component: Icon,
  tags: ['autodocs'],
  args: {
    src: ICONS.nav.home,
    size: 24,
    label: 'Home',
  },
  argTypes: {
    size: { control: { type: 'number', min: 12, max: 48, step: 4 } },
  },
} satisfies Meta<typeof Icon>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const Home: Story = {
  args: { src: ICONS.nav.home, label: 'Home' },
};

export const Search: Story = {
  args: { src: ICONS.ui.search, label: 'Search' },
};

export const Check: Story = {
  args: { src: ICONS.ui.check, label: 'Check' },
};

export const ToastSuccess: Story = {
  args: { src: ICONS.toast.success, label: 'Success' },
};

export const NavSet: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: 16, alignItems: 'center', flexWrap: 'wrap' }}>
      {Object.entries(ICONS.nav).map(([name, src]) => (
        <div
          key={name}
          style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}
        >
          <Icon src={src} size={24} label={name} />
          <span style={{ fontSize: 11 }}>{name}</span>
        </div>
      ))}
    </div>
  ),
};

export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
      <Icon src={ICONS.nav.home} size={16} label="16" />
      <Icon src={ICONS.nav.home} size={20} label="20" />
      <Icon src={ICONS.nav.home} size={24} label="24" />
      <Icon src={ICONS.nav.home} size={32} label="32" />
    </div>
  ),
};
