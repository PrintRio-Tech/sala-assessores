import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { ICONS } from '../../assets/icons';
import { Icon } from './index';

const iconModules = import.meta.glob('../../../public/icons/**/*.svg', {
  eager: true,
});

const availableIconPaths = new Set(
  Object.keys(iconModules).map((key) => {
    const match = key.match(/public\/icons\/(.+\.svg)$/);
    return match ? `/icons/${match[1]}` : '';
  }),
);

function collectIconPaths(value: unknown): string[] {
  if (typeof value === 'string') return [value];
  if (value && typeof value === 'object') {
    return Object.values(value).flatMap(collectIconPaths);
  }
  return [];
}

describe('Icon', () => {
  it('aplica mask-image com path entre aspas (D-ICON-04)', () => {
    const { container } = render(<Icon src="/icons/ui/menu.svg" size={24} />);

    const icon = container.querySelector('span');
    expect(icon).toHaveStyle({
      maskImage: 'url("/icons/ui/menu.svg")',
      width: '24px',
      height: '24px',
    });
    expect(icon).toHaveAttribute('aria-hidden', 'true');
  });

  it('expõe role img e aria-label quando label é informado', () => {
    render(<Icon src="/icons/nav/home.svg" label="Início" />);

    expect(screen.getByRole('img', { name: 'Início' })).toBeInTheDocument();
  });

  it('aceita width e height independentes de size', () => {
    const { container } = render(
      <Icon src="/icons/ui/check.svg" width={12} height={16} />,
    );

    const icon = container.querySelector('span');
    expect(icon).toHaveStyle({ width: '12px', height: '16px' });
  });
});

describe('ICONS — catálogo D-ICON-04=A', () => {
  const paths = collectIconPaths(ICONS);

  it('exporta catálogo com pelo menos 28 SVGs', () => {
    expect(paths.length).toBeGreaterThanOrEqual(28);
  });

  it('grupos atendem mínimo nav×6, home×5, ui×6, toast×5, table×3, date-picker×1', () => {
    expect(Object.keys(ICONS.nav).length).toBeGreaterThanOrEqual(6);
    expect(Object.keys(ICONS.home).length).toBeGreaterThanOrEqual(5);
    expect(Object.keys(ICONS.ui).length).toBeGreaterThanOrEqual(6);
    expect(Object.keys(ICONS.toast).length).toBeGreaterThanOrEqual(5);
    expect(Object.keys(ICONS.table).length).toBeGreaterThanOrEqual(3);
    expect(Object.keys(ICONS.datePicker).length).toBeGreaterThanOrEqual(1);
  });

  it('todos os paths usam prefixo /icons/', () => {
    for (const path of paths) {
      expect(path).toMatch(/^\/icons\/.+\.svg$/);
    }
  });

  it('cada path do catálogo tem SVG correspondente em public/icons/', () => {
    for (const iconPath of paths) {
      expect(
        availableIconPaths.has(iconPath),
        `ausente: public/icons${iconPath.replace(/^\/icons/, '')}`,
      ).toBe(true);
    }
  });
});
