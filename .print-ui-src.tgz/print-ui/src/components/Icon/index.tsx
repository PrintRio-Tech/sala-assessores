import styles from './styles.module.scss';

export type IconProps = {
  src: string;
  className?: string;
  size?: number;
  width?: number;
  height?: number;
  label?: string;
};

export function Icon({
  src,
  className,
  size,
  width,
  height,
  label,
}: IconProps) {
  const w = width ?? size ?? 20;
  const h = height ?? size ?? 20;

  const mask = `url("${src}")`;

  return (
    <span
      className={[styles.root, className].filter(Boolean).join(' ')}
      style={{
        width: w,
        height: h,
        WebkitMaskImage: mask,
        maskImage: mask,
      }}
      role={label ? 'img' : undefined}
      aria-label={label}
      aria-hidden={label ? undefined : true}
    />
  );
}
