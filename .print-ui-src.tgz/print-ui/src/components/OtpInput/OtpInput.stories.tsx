import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';

import { OtpInput } from './OtpInput';

const meta = {
  title: 'Forms/OtpInput',
  component: OtpInput,
  tags: ['autodocs'],
  args: {
    label: 'Código de verificação',
    name: 'otp',
    value: '',
    onChange: () => undefined,
    length: 6,
    required: false,
    disabled: false,
    autoFocus: false,
  },
  argTypes: {
    length: {
      control: { type: 'number', min: 4, max: 8 },
    },
  },
  render: function Render(args) {
    const [value, setValue] = useState(args.value);
    return <OtpInput {...args} value={value} onChange={setValue} />;
  },
} satisfies Meta<typeof OtpInput>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const Required: Story = {
  args: { required: true },
};

export const Filled: Story = {
  args: { value: '482910' },
};

export const FourDigits: Story = {
  args: { length: 4, label: 'PIN' },
};

export const Error: Story = {
  args: {
    value: '123456',
    error: 'Código inválido. Tente novamente.',
  },
};

export const Disabled: Story = {
  args: {
    disabled: true,
    value: '000000',
  },
};

export const AutoFocus: Story = {
  args: { autoFocus: true },
};
