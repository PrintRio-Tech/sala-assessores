import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it, vi } from 'vitest';

import { OtpInput } from './OtpInput';

describe('OtpInput', () => {
  it('preenche dígitos e dispara onComplete', async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    const onComplete = vi.fn();

    const { rerender } = render(
      <OtpInput
        label="Código"
        name="code"
        value=""
        onChange={onChange}
        onComplete={onComplete}
      />,
    );

    const first = screen.getByLabelText('Dígito 1 de 6');
    await user.type(first, '1');
    expect(onChange).toHaveBeenLastCalledWith('1');

    rerender(
      <OtpInput
        label="Código"
        name="code"
        value="123456"
        onChange={onChange}
        onComplete={onComplete}
      />,
    );
    expect(onComplete).not.toHaveBeenCalled();
  });
});
