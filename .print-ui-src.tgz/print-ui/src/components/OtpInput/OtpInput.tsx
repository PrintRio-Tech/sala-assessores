import { useRef, type ClipboardEvent, type KeyboardEvent } from 'react';

import { FormField } from '../FormField/FormField';

import styles from './styles.module.scss';

const DEFAULT_LENGTH = 6;

function splitDigits(value: string, length: number) {
  return Array.from({ length }, (_, index) => value[index] ?? '');
}

export type OtpInputProps = {
  label: string;
  required?: boolean;
  name: string;
  value: string;
  onChange: (value: string) => void;
  onComplete?: (value: string) => void;
  length?: number;
  error?: string;
  disabled?: boolean;
  autoFocus?: boolean;
};

export function OtpInput({
  label,
  required = false,
  name,
  value,
  onChange,
  onComplete,
  length = DEFAULT_LENGTH,
  error,
  disabled = false,
  autoFocus = false,
}: OtpInputProps) {
  const inputRefs = useRef<Array<HTMLInputElement | null>>([]);
  const digits = splitDigits(value, length);

  function focusInput(index: number) {
    inputRefs.current[index]?.focus();
    inputRefs.current[index]?.select();
  }

  function updateValue(nextDigits: string[]) {
    const nextValue = nextDigits.join('').slice(0, length);
    onChange(nextValue);

    if (nextValue.length === length && /^\d+$/.test(nextValue)) {
      onComplete?.(nextValue);
    }
  }

  function applyPastedDigits(raw: string, startIndex = 0) {
    const pasted = raw.replace(/\D/g, '').slice(0, length - startIndex);
    if (!pasted) return;

    const nextDigits = splitDigits(value, length);
    for (let offset = 0; offset < pasted.length; offset += 1) {
      nextDigits[startIndex + offset] = pasted[offset] ?? '';
    }

    updateValue(nextDigits);

    const focusIndex = Math.min(startIndex + pasted.length, length - 1);
    if (nextDigits.join('').length < length) {
      focusInput(focusIndex);
    }
  }

  function handleDigitChange(index: number, raw: string) {
    const sanitized = raw.replace(/\D/g, '');
    const nextDigits = splitDigits(value, length);

    if (sanitized.length > 1) {
      applyPastedDigits(sanitized, index);
      return;
    }

    nextDigits[index] = sanitized.slice(-1);
    updateValue(nextDigits);

    if (sanitized && index < length - 1) {
      focusInput(index + 1);
    }
  }

  function handleKeyDown(
    index: number,
    event: KeyboardEvent<HTMLInputElement>,
  ) {
    if (event.key === 'Backspace') {
      event.preventDefault();
      const nextDigits = splitDigits(value, length);

      if (nextDigits[index]) {
        nextDigits[index] = '';
        updateValue(nextDigits);
        return;
      }

      if (index > 0) {
        nextDigits[index - 1] = '';
        updateValue(nextDigits);
        focusInput(index - 1);
      }
      return;
    }

    if (event.key === 'ArrowLeft' && index > 0) {
      event.preventDefault();
      focusInput(index - 1);
      return;
    }

    if (event.key === 'ArrowRight' && index < length - 1) {
      event.preventDefault();
      focusInput(index + 1);
    }
  }

  function handlePaste(event: ClipboardEvent<HTMLInputElement>, index: number) {
    event.preventDefault();
    applyPastedDigits(event.clipboardData.getData('text'), index);
  }

  return (
    <FormField
      label={label}
      required={required}
      name={name}
      error={error}
      disabled={disabled}
      invalid={Boolean(error)}
    >
      <input type="hidden" name={name} value={value} autoComplete="off" />
      <div
        className={styles.group}
        role="group"
        aria-label={label}
        data-invalid={error ? true : undefined}
      >
        {digits.map((digit, index) => (
          <input
            key={index}
            ref={(element) => {
              inputRefs.current[index] = element;
            }}
            className={styles.digit}
            type="text"
            inputMode="numeric"
            pattern="[0-9]*"
            autoComplete={index === 0 ? 'one-time-code' : 'off'}
            autoFocus={autoFocus && index === 0}
            aria-label={`Dígito ${index + 1} de ${length}`}
            maxLength={1}
            value={digit}
            disabled={disabled}
            aria-invalid={error ? true : undefined}
            onChange={(event) => handleDigitChange(index, event.target.value)}
            onKeyDown={(event) => handleKeyDown(index, event)}
            onPaste={(event) => handlePaste(event, index)}
            onFocus={(event) => event.currentTarget.select()}
          />
        ))}
      </div>
    </FormField>
  );
}
