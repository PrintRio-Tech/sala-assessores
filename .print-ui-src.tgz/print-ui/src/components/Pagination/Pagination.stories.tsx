import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { fn } from 'storybook/test';

import { Pagination } from './index';

const meta = {
  title: 'Data/Pagination',
  component: Pagination,
  tags: ['autodocs'],
  args: {
    page: 1,
    pageSize: 10,
    totalItems: 95,
    siblingCount: 1,
    onPageChange: fn(),
  },
  argTypes: {
    page: { control: { type: 'number', min: 1 } },
    pageSize: { control: { type: 'number', min: 1 } },
    totalItems: { control: { type: 'number', min: 0 } },
    siblingCount: { control: { type: 'number', min: 0, max: 3 } },
  },
} satisfies Meta<typeof Pagination>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const MiddlePage: Story = {
  args: {
    page: 5,
    totalItems: 95,
  },
};

export const FewPages: Story = {
  args: {
    page: 1,
    pageSize: 10,
    totalItems: 25,
  },
};

export const Empty: Story = {
  args: {
    page: 1,
    pageSize: 10,
    totalItems: 0,
  },
};

export const Interactive: Story = {
  render: (args) => {
    const [page, setPage] = useState(args.page);

    return (
      <Pagination
        {...args}
        page={page}
        onPageChange={(next) => {
          setPage(next);
          args.onPageChange(next);
        }}
      />
    );
  },
};
