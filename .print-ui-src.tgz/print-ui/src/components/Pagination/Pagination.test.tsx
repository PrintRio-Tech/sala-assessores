import { render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';

import { Pagination } from '../Pagination';

describe('Pagination', () => {
  it('renderiza resumo e controles de página', () => {
    const onPageChange = vi.fn();

    render(
      <Pagination
        page={2}
        pageSize={10}
        totalItems={25}
        onPageChange={onPageChange}
      />,
    );

    expect(screen.getByText('11–20 de 25')).toBeInTheDocument();
    expect(screen.getByLabelText('Página 2')).toHaveAttribute(
      'aria-current',
      'page',
    );
  });
});
