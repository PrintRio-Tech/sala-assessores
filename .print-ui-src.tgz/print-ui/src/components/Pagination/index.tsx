import type { ComponentPropsWithoutRef } from 'react';

import styles from './styles.module.scss';

export type PaginationProps = {
  page: number;
  pageSize: number;
  totalItems: number;
  onPageChange: (page: number) => void;
  siblingCount?: number;
  className?: string;
} & Omit<ComponentPropsWithoutRef<'nav'>, 'children' | 'onChange'>;

function range(start: number, end: number) {
  return Array.from({ length: end - start + 1 }, (_, index) => start + index);
}

function getPageItems(
  page: number,
  totalPages: number,
  siblingCount: number,
): Array<number | 'ellipsis'> {
  if (totalPages <= 1) {
    return [1];
  }

  const totalNumbers = siblingCount * 2 + 5;

  if (totalPages <= totalNumbers) {
    return range(1, totalPages);
  }

  const leftSibling = Math.max(page - siblingCount, 1);
  const rightSibling = Math.min(page + siblingCount, totalPages);
  const showLeftEllipsis = leftSibling > 2;
  const showRightEllipsis = rightSibling < totalPages - 1;

  if (!showLeftEllipsis && showRightEllipsis) {
    return [...range(1, 3 + siblingCount * 2), 'ellipsis', totalPages];
  }

  if (showLeftEllipsis && !showRightEllipsis) {
    return [
      1,
      'ellipsis',
      ...range(totalPages - (2 + siblingCount * 2), totalPages),
    ];
  }

  return [
    1,
    'ellipsis',
    ...range(leftSibling, rightSibling),
    'ellipsis',
    totalPages,
  ];
}

export function Pagination({
  page,
  pageSize,
  totalItems,
  onPageChange,
  siblingCount = 1,
  className,
  ...props
}: PaginationProps) {
  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
  const currentPage = Math.min(Math.max(page, 1), totalPages);
  const startItem = totalItems === 0 ? 0 : (currentPage - 1) * pageSize + 1;
  const endItem = Math.min(currentPage * pageSize, totalItems);
  const items = getPageItems(currentPage, totalPages, siblingCount);

  return (
    <nav
      className={[styles.pagination, className].filter(Boolean).join(' ')}
      aria-label="Paginação"
      {...props}
    >
      <p className={styles.summary}>
        {totalItems === 0
          ? 'Nenhum item'
          : `${startItem}–${endItem} de ${totalItems}`}
      </p>

      <div className={styles.controls}>
        <button
          type="button"
          className={styles.navButton}
          onClick={() => onPageChange(currentPage - 1)}
          disabled={currentPage <= 1}
          aria-label="Página anterior"
        >
          ‹
        </button>

        <ul className={styles.pages}>
          {items.map((item, index) =>
            item === 'ellipsis' ? (
              <li
                key={`ellipsis-${index}`}
                className={styles.ellipsis}
                aria-hidden
              >
                …
              </li>
            ) : (
              <li key={item}>
                <button
                  type="button"
                  className={styles.pageButton}
                  data-active={item === currentPage || undefined}
                  onClick={() => {
                    if (typeof item === 'number') {
                      onPageChange(item);
                    }
                  }}
                  aria-label={`Página ${item}`}
                  aria-current={item === currentPage ? 'page' : undefined}
                >
                  {item}
                </button>
              </li>
            ),
          )}
        </ul>

        <button
          type="button"
          className={styles.navButton}
          onClick={() => onPageChange(currentPage + 1)}
          disabled={currentPage >= totalPages}
          aria-label="Próxima página"
        >
          ›
        </button>
      </div>
    </nav>
  );
}
