import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';

import { RadioGroup } from './RadioGroup';

const options = [
  { value: 'email', label: 'E-mail' },
  { value: 'sms', label: 'SMS' },
  { value: 'push', label: 'Push' },
];

const meta = {
  title: 'Forms/RadioGroup',
  component: RadioGroup,
  tags: ['autodocs'],
  args: {
    legend: 'Canal preferido',
    name: 'channel',
    options,
    orientation: 'vertical',
    disabled: false,
  },
  argTypes: {
    orientation: {
      control: 'select',
      options: ['vertical', 'horizontal'],
    },
  },
} satisfies Meta<typeof RadioGroup>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: { defaultValue: 'email' },
};

export const Horizontal: Story = {
  args: { orientation: 'horizontal', defaultValue: 'sms' },
};

export const Disabled: Story = {
  args: { disabled: true, defaultValue: 'email' },
};

export const Controlled: Story = {
  render: function ControlledRadio(args) {
    const [value, setValue] = useState('push');
    return (
      <RadioGroup {...args} value={value} onValueChange={setValue} />
    );
  },
};
