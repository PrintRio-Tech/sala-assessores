import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';

import { RadioGroup } from './RadioGroup';

const options = [
  { value: 'a', label: 'Opção A' },
  { value: 'b', label: 'Opção B' },
];

describe('RadioGroup', () => {
  it('renderiza legend e opções', () => {
    render(
      <RadioGroup legend="Escolha" options={options} defaultValue="a" />,
    );

    expect(screen.getByText('Escolha')).toBeInTheDocument();
    expect(screen.getByLabelText('Opção A')).toBeInTheDocument();
    expect(screen.getByLabelText('Opção B')).toBeInTheDocument();
  });

  it('notifica onValueChange', () => {
    const onValueChange = vi.fn();

    render(
      <RadioGroup
        legend="Escolha"
        options={options}
        value="a"
        onValueChange={onValueChange}
      />,
    );

    fireEvent.click(screen.getByLabelText('Opção B'));
    expect(onValueChange).toHaveBeenCalledWith('b');
  });

  it('aceita name opcional', () => {
    const { container } = render(
      <RadioGroup
        legend="Escolha"
        name="choice"
        options={options}
        defaultValue="a"
      />,
    );

    expect(container.querySelector('[name="choice"]')).toBeTruthy();
  });
});
