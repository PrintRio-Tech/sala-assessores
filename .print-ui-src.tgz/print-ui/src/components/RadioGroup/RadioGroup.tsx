import { Radio } from '@base-ui-components/react/radio';
import { RadioGroup as BaseRadioGroup } from '@base-ui-components/react/radio-group';

import styles from './styles.module.scss';

export type RadioGroupOption = {
  value: string;
  label: string;
};

export type RadioGroupProps = {
  legend: string;
  name?: string;
  options: RadioGroupOption[];
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  disabled?: boolean;
  orientation?: 'vertical' | 'horizontal';
  className?: string;
};

export function RadioGroup({
  legend,
  name,
  options,
  value,
  defaultValue,
  onValueChange,
  disabled = false,
  orientation = 'vertical',
  className,
}: RadioGroupProps) {
  const optionsClass = [
    styles.options,
    orientation === 'horizontal' ? styles.optionsHorizontal : undefined,
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <fieldset
      className={[styles.group, className].filter(Boolean).join(' ')}
      disabled={disabled}
    >
      <legend className={styles.legend}>{legend}</legend>
      <BaseRadioGroup
        name={name}
        value={value}
        defaultValue={defaultValue}
        onValueChange={(next) => onValueChange?.(String(next))}
        disabled={disabled}
        className={optionsClass}
      >
        {options.map((option) => (
          <label key={option.value} className={styles.item}>
            <Radio.Root value={option.value} className={styles.control}>
              <Radio.Indicator className={styles.indicator} />
            </Radio.Root>
            <span className={styles.label}>{option.label}</span>
          </label>
        ))}
      </BaseRadioGroup>
    </fieldset>
  );
}
