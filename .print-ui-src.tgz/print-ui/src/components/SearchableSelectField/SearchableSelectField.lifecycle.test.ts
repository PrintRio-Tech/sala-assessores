import { readFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

import { describe, expect, it } from 'vitest';

const here = dirname(fileURLToPath(import.meta.url));

describe('SearchableSelectField popup lifecycle CSS', () => {
  const scss = readFileSync(join(here, 'styles.module.scss'), 'utf8');

  it('usa transition mínima (1ms) para Base UI receber animations.finished', () => {
    // Regressão: transition longa/travada impede unmount do portal.
    expect(scss).toMatch(/opacity 1ms linear/);
    expect(scss).toMatch(/transform 1ms linear/);
  });

  it('esconde imediatamente em data-ending-style / data-closed', () => {
    expect(scss).toMatch(/&\[data-ending-style\],\s*\n\s*&\[data-closed\]/);
    expect(scss).toMatch(/visibility:\s*hidden/);
    expect(scss).toMatch(/pointer-events:\s*none/);
  });
});
