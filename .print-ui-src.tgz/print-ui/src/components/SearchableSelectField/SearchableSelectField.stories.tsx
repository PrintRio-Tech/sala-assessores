import type { Meta, StoryObj } from '@storybook/react-vite';
import { useMemo, useState } from 'react';

import { SearchableSelectField } from './SearchableSelectField';

const cityOptions = [
  { value: 'sao-paulo', label: 'São Paulo' },
  { value: 'rio-de-janeiro', label: 'Rio de Janeiro' },
  { value: 'belo-horizonte', label: 'Belo Horizonte' },
  { value: 'curitiba', label: 'Curitiba' },
  { value: 'porto-alegre', label: 'Porto Alegre' },
  { value: 'salvador', label: 'Salvador' },
  { value: 'brasilia', label: 'Brasília' },
  { value: 'fortaleza', label: 'Fortaleza' },
  { value: 'recife', label: 'Recife' },
  { value: 'manaus', label: 'Manaus' },
];

const meta = {
  title: 'Forms/SearchableSelectField',
  component: SearchableSelectField,
  tags: ['autodocs'],
  args: {
    label: 'Cidade',
    name: 'city',
    options: cityOptions,
    value: '',
    onValueChange: () => undefined,
    placeholder: 'Buscar cidade…',
    emptyMessage: 'Nenhuma cidade encontrada.',
    required: false,
    disabled: false,
    loading: false,
  },
  argTypes: {
    labelSize: {
      control: 'select',
      options: ['md', 'sm'],
    },
  },
  render: function Render(args) {
    const [value, setValue] = useState(args.value);
    return (
      <SearchableSelectField
        {...args}
        value={value}
        onValueChange={setValue}
      />
    );
  },
} satisfies Meta<typeof SearchableSelectField>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const WithSelectedValue: Story = {
  args: { value: 'curitiba' },
};

export const Required: Story = {
  args: { required: true },
};

export const WithDescription: Story = {
  args: {
    description: 'Cidade de entrega do pedido.',
  },
};

export const Error: Story = {
  args: {
    error: 'Selecione uma cidade.',
  },
};

export const Loading: Story = {
  args: {
    loading: true,
    options: [],
  },
};

export const Disabled: Story = {
  args: {
    disabled: true,
    value: 'sao-paulo',
  },
};

export const Filtered: Story = {
  render: function FilteredSearchableSelect() {
    const [value, setValue] = useState('');
    const [query, setQuery] = useState('');

    const options = useMemo(() => {
      const normalized = query.trim().toLowerCase();
      if (!normalized) return cityOptions;
      return cityOptions.filter((option) =>
        option.label.toLowerCase().includes(normalized),
      );
    }, [query]);

    return (
      <SearchableSelectField
        label="Cidade"
        name="city"
        options={options}
        value={value}
        onValueChange={setValue}
        onQueryChange={setQuery}
        placeholder="Digite para filtrar…"
      />
    );
  },
};
