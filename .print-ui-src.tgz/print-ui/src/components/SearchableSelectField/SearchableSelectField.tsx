import { Combobox } from '@base-ui-components/react/combobox';
import {
  useCallback,
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';

import { ICONS } from '../../assets/icons';
import {
  FormField,
  type FormFieldTone,
} from '../FormField/FormField';
import { Icon } from '../Icon';

import styles from './styles.module.scss';

export type SearchableSelectOption = {
  value: string;
  label: string;
};

export type SearchableSelectFieldProps = {
  label: string;
  labelHidden?: boolean;
  labelSize?: 'md' | 'sm';
  /** Labels legíveis sobre fundo primary (sidebar). */
  tone?: FormFieldTone;
  /** Densidade do controle — `sm` para contextos compactos (ex.: sidebar). */
  size?: 'md' | 'sm';
  required?: boolean;
  description?: string;
  error?: string;
  name: string;
  options: SearchableSelectOption[];
  value: string;
  onValueChange: (value: string) => void;
  onQueryChange?: (query: string) => void;
  loading?: boolean;
  placeholder?: string;
  emptyMessage?: string;
  disabled?: boolean;
  selectedLabel?: string;
  footerSlot?: ReactNode;
  emptyValue?: string;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
};

function ChevronIcon() {
  return <Icon src={ICONS.ui.chevronDown} className={styles.icon} size={16} />;
}

function CheckIcon() {
  return <Icon src={ICONS.ui.check} size={12} />;
}

function isUserInputReason(reason: string) {
  return reason === 'input-change' || reason === 'input-paste';
}

/** WebView pode deixar CSS transitions em currentTime=0; Base UI só desmonta no `finished`. */
function finishPopupExitAnimations() {
  if (typeof document === 'undefined') return;
  document
    .querySelectorAll('[data-ending-style], [data-closed]')
    .forEach((element) => {
      element.getAnimations?.().forEach((animation) => {
        try {
          animation.finish();
        } catch {
          // ignore
        }
      });
    });
}

export function SearchableSelectField({
  label,
  labelHidden = false,
  labelSize = 'md',
  tone = 'default',
  size = 'md',
  required = false,
  description,
  error,
  name,
  options,
  value,
  onValueChange,
  onQueryChange,
  loading = false,
  placeholder = 'Buscar…',
  emptyMessage = 'Nenhum resultado encontrado.',
  disabled,
  selectedLabel,
  footerSlot,
  emptyValue,
  open: openProp,
  onOpenChange,
}: SearchableSelectFieldProps) {
  const id = useId();
  const [internalOpen, setInternalOpen] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [mountEpoch, setMountEpoch] = useState(0);
  const isSearchingRef = useRef(false);
  const wasOpenRef = useRef(false);

  const isOpenControlled = openProp !== undefined;
  const open = isOpenControlled ? openProp : internalOpen;

  const setOpen = useCallback(
    (nextOpen: boolean) => {
      if (!isOpenControlled) setInternalOpen(nextOpen);
      onOpenChange?.(nextOpen);
    },
    [isOpenControlled, onOpenChange],
  );

  const isUnset =
    emptyValue !== undefined
      ? value === emptyValue
      : value === '' || value === null;

  const items = useMemo(() => {
    if (isUnset) return options;
    if (!value) return options;
    if (options.some((option) => option.value === value)) return options;
    const fallbackLabel = selectedLabel ?? value;
    return [{ value, label: fallbackLabel }, ...options];
  }, [isUnset, options, selectedLabel, value]);

  const selectedItem = useMemo(() => {
    if (isUnset || !value) return null;
    return items.find((option) => option.value === value) ?? null;
  }, [isUnset, items, value]);

  const getDisplayLabel = useCallback(
    (nextValue: string) => {
      if (emptyValue !== undefined && nextValue === emptyValue) return '';
      if (!nextValue) return '';
      return (
        items.find((option) => option.value === nextValue)?.label ??
        selectedLabel ??
        ''
      );
    },
    [emptyValue, items, selectedLabel],
  );

  useEffect(() => {
    if (open || isSearchingRef.current) return;
    setInputValue(getDisplayLabel(value));
  }, [getDisplayLabel, open, value]);

  // Controlled close (ex.: drawer mobile) não passa por handleOpenChange —
  // força finished das animations; se o portal residual persistir, remonta o Root
  // (Base UI não reavalia Promises de anim.finished já penduradas).
  useEffect(() => {
    const wasOpen = wasOpenRef.current;
    wasOpenRef.current = open;
    if (open || !wasOpen) return;

    finishPopupExitAnimations();
    const timeoutId = window.setTimeout(() => {
      finishPopupExitAnimations();
      if (document.querySelector('[data-ending-style], [data-closed]')) {
        setMountEpoch((epoch) => epoch + 1);
      }
    }, 48);
    return () => window.clearTimeout(timeoutId);
  }, [open]);

  const handleOpenChange = useCallback(
    (nextOpen: boolean) => {
      setOpen(nextOpen);

      if (!nextOpen) {
        isSearchingRef.current = false;
        onQueryChange?.('');
        setInputValue(getDisplayLabel(value));
        // Garante unmount do portal se a transition ficar presa no WebView.
        window.requestAnimationFrame(() => {
          finishPopupExitAnimations();
          window.setTimeout(finishPopupExitAnimations, 16);
        });
        return;
      }

      if (isUnset || !value) {
        setInputValue('');
      }
    },
    [getDisplayLabel, isUnset, onQueryChange, setOpen, value],
  );

  const handleInputValueChange = useCallback(
    (query: string, eventDetails: { reason: string }) => {
      if (!isUserInputReason(eventDetails.reason)) return;

      isSearchingRef.current = true;
      setInputValue(query);
      onQueryChange?.(query);

      if (!isUnset && value) {
        const currentLabel = getDisplayLabel(value);
        if (query !== currentLabel) {
          onValueChange(emptyValue ?? '');
        }
      }
    },
    [emptyValue, getDisplayLabel, isUnset, onQueryChange, onValueChange, value],
  );

  const handleValueChange = useCallback(
    (next: SearchableSelectOption | null) => {
      if (!next || typeof next !== 'object' || !('value' in next)) return;

      isSearchingRef.current = false;
      onValueChange(next.value);

      if (emptyValue !== undefined && next.value === emptyValue) {
        setInputValue('');
      } else {
        setInputValue(next.label);
      }

      onQueryChange?.('');
      setOpen(false);
    },
    [emptyValue, onQueryChange, onValueChange, setOpen],
  );

  return (
    <FormField
      label={label}
      labelHidden={labelHidden}
      labelSize={labelSize}
      tone={tone}
      required={required}
      description={description}
      error={error}
      name={name}
      disabled={disabled}
      invalid={Boolean(error)}
    >
      <Combobox.Root
        key={mountEpoch}
        name={name}
        id={id}
        items={items}
        open={open}
        onOpenChange={handleOpenChange}
        inputValue={inputValue}
        onInputValueChange={handleInputValueChange}
        value={selectedItem}
        onValueChange={handleValueChange}
        isItemEqualToValue={(item, selected) => item?.value === selected?.value}
        filter={null}
        disabled={disabled}
      >
        <div
          className={[
            styles.inputGroup,
            size === 'sm' ? styles.inputGroupSm : undefined,
          ]
            .filter(Boolean)
            .join(' ')}
          data-size={size}
        >
          <Combobox.Input
            className={[styles.input, size === 'sm' ? styles.inputSm : undefined]
              .filter(Boolean)
              .join(' ')}
            placeholder={placeholder}
            aria-invalid={error ? true : undefined}
          />
          <Combobox.Trigger
            className={[
              styles.trigger,
              size === 'sm' ? styles.triggerSm : undefined,
            ]
              .filter(Boolean)
              .join(' ')}
            aria-label="Abrir opções"
          >
            <Combobox.Icon>
              <ChevronIcon />
            </Combobox.Icon>
          </Combobox.Trigger>
        </div>
        <Combobox.Portal>
          <Combobox.Positioner className={styles.positioner} sideOffset={4}>
            <Combobox.Popup className={styles.popup}>
              <Combobox.Status className={styles.status}>
                {loading ? 'Buscando…' : null}
              </Combobox.Status>
              <Combobox.Empty className={styles.empty}>
                {!loading ? emptyMessage : null}
              </Combobox.Empty>
              <Combobox.List className={styles.list}>
                {items.map((option) => (
                  <Combobox.Item
                    key={option.value || '__empty__'}
                    value={option}
                    className={styles.item}
                  >
                    <Combobox.ItemIndicator className={styles.itemIndicator}>
                      <CheckIcon />
                    </Combobox.ItemIndicator>
                    <span className={styles.itemText}>{option.label}</span>
                  </Combobox.Item>
                ))}
              </Combobox.List>
              {footerSlot ? (
                <div className={styles.footer}>{footerSlot}</div>
              ) : null}
            </Combobox.Popup>
          </Combobox.Positioner>
        </Combobox.Portal>
      </Combobox.Root>
    </FormField>
  );
}
