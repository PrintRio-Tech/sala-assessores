import type { Meta, StoryObj } from '@storybook/react-vite';
import { fn } from 'storybook/test';

import { SectionState } from './SectionState';

const meta = {
  title: 'Data/SectionState',
  component: SectionState,
  tags: ['autodocs'],
  args: {
    minHeight: 160,
  },
} satisfies Meta<typeof SectionState>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Loading: Story = {
  args: {
    status: 'loading',
    loadingLabel: 'Carregando relatório…',
  },
};

export const LoadingDefaultLabel: Story = {
  args: {
    status: 'loading',
  },
};

export const Error: Story = {
  args: {
    status: 'error',
    errorMessage: 'Não foi possível carregar o relatório.',
    errorDescription: 'Verifique sua conexão e tente novamente.',
    onRetry: fn(),
  },
};

export const ErrorWithoutDescription: Story = {
  args: {
    status: 'error',
    errorMessage: 'Falha ao buscar dados.',
    onRetry: fn(),
  },
};

export const Success: Story = {
  args: {
    status: 'success',
    children: (
      <div style={{ padding: 16 }}>
        <p style={{ margin: 0, fontWeight: 600 }}>Relatório carregado</p>
        <p style={{ margin: '8px 0 0', opacity: 0.7 }}>
          24 matérias publicadas nesta semana.
        </p>
      </div>
    ),
  },
};
