import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';

import { SectionState } from './SectionState';

describe('SectionState', () => {
  it('renderiza conteúdo apenas em success', () => {
    const { rerender } = render(
      <SectionState status="success">
        <p>Conteúdo da seção</p>
      </SectionState>,
    );

    expect(screen.getByText('Conteúdo da seção')).toBeInTheDocument();

    rerender(
      <SectionState status="loading" loadingLabel="Carregando relatório…" />,
    );
    expect(screen.queryByText('Conteúdo da seção')).not.toBeInTheDocument();
    expect(screen.getByText('Carregando relatório…')).toBeInTheDocument();
  });

  it('expõe role="status" e aria-live="polite" em loading', () => {
    render(<SectionState status="loading" />);

    const status = screen.getByRole('status');
    expect(status).toHaveAttribute('aria-live', 'polite');
    expect(status).toHaveTextContent('Carregando…');
  });

  it('expõe role="alert" em error com retry por teclado', () => {
    const onRetry = vi.fn();

    render(
      <SectionState
        status="error"
        errorMessage="Não foi possível carregar o relatório."
        errorDescription="Verifique sua conexão e tente novamente."
        onRetry={onRetry}
      />,
    );

    const alert = screen.getByRole('alert');
    expect(alert).toBeInTheDocument();
    expect(screen.getByText('Não foi possível carregar o relatório.')).toBeInTheDocument();
    expect(screen.getByText('Verifique sua conexão e tente novamente.')).toBeInTheDocument();

    const retryButton = screen.getByRole('button', { name: 'Tentar novamente' });
    fireEvent.click(retryButton);
    expect(onRetry).toHaveBeenCalledOnce();
  });

  it('não sobrepõe loading e error', () => {
    render(
      <SectionState
        status="loading"
        loadingLabel="Carregando…"
      />,
    );

    expect(screen.getByRole('status')).toBeInTheDocument();
    expect(screen.queryByRole('alert')).not.toBeInTheDocument();
    expect(screen.queryByRole('button')).not.toBeInTheDocument();
  });

  it('tem paridade com ReportTableSection (loading + error)', () => {
    const onRetry = vi.fn();

    const { rerender } = render(
      <SectionState status="loading" loadingLabel="Carregando relatório…" />,
    );
    expect(screen.getByRole('status')).toHaveTextContent('Carregando relatório…');

    rerender(
      <SectionState
        status="error"
        errorMessage="Não foi possível carregar o relatório."
        onRetry={onRetry}
      />,
    );

    expect(screen.getByRole('alert')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'Tentar novamente' }));
    expect(onRetry).toHaveBeenCalledOnce();
  });
});
