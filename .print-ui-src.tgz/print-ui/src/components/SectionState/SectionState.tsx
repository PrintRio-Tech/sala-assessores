import type { ReactNode } from 'react';

import { Button } from '../Button/Button';
import { Text } from '../Text/Text';

import styles from './styles.module.scss';

type SectionStateBaseProps = {
  className?: string;
  minHeight?: string | number;
};

export type SectionStateLoadingProps = SectionStateBaseProps & {
  status: 'loading';
  loadingLabel?: string;
};

export type SectionStateErrorProps = SectionStateBaseProps & {
  status: 'error';
  errorMessage: string;
  errorDescription?: string;
  onRetry: () => void;
};

export type SectionStateSuccessProps = SectionStateBaseProps & {
  status: 'success';
  children: ReactNode;
};

export type SectionStateProps =
  | SectionStateLoadingProps
  | SectionStateErrorProps
  | SectionStateSuccessProps;

function panelClass(className?: string) {
  return [styles.panel, className].filter(Boolean).join(' ');
}

function panelStyle(minHeight?: string | number) {
  return minHeight != null ? { minHeight } : undefined;
}

export function SectionState(props: SectionStateProps) {
  const { className, minHeight } = props;

  if (props.status === 'success') {
    return <>{props.children}</>;
  }

  if (props.status === 'loading') {
    const loadingLabel = props.loadingLabel ?? 'Carregando…';

    return (
      <div
        className={panelClass(className)}
        style={panelStyle(minHeight)}
        role="status"
        aria-live="polite"
      >
        <div className={styles.loadingRow}>
          <span className={styles.loadingIndicator} aria-hidden="true" />
          <Text tone="muted">{loadingLabel}</Text>
        </div>
      </div>
    );
  }

  return (
    <div
      className={panelClass(className)}
      style={panelStyle(minHeight)}
      role="alert"
    >
      <Text tone="error">{props.errorMessage}</Text>
      {props.errorDescription ? (
        <Text tone="muted">{props.errorDescription}</Text>
      ) : null}
      <Button type="button" variant="outline" size="sm" onClick={props.onRetry}>
        Tentar novamente
      </Button>
    </div>
  );
}
