import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';

import { SelectField } from './SelectField';

const stateOptions = [
  { value: 'sp', label: 'São Paulo' },
  { value: 'rj', label: 'Rio de Janeiro' },
  { value: 'mg', label: 'Minas Gerais' },
  { value: 'pr', label: 'Paraná' },
  { value: 'rs', label: 'Rio Grande do Sul' },
  { value: 'ba', label: 'Bahia' },
];

const meta = {
  title: 'Forms/SelectField',
  component: SelectField,
  tags: ['autodocs'],
  args: {
    label: 'Estado',
    name: 'state',
    options: stateOptions,
    placeholder: 'Selecione…',
    size: 'md',
    labelSize: 'md',
    required: false,
    disabled: false,
  },
  argTypes: {
    size: {
      control: 'select',
      options: ['md', 'sm'],
    },
    labelSize: {
      control: 'select',
      options: ['md', 'sm'],
    },
  },
} satisfies Meta<typeof SelectField>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const WithDefaultValue: Story = {
  args: { defaultValue: 'sp' },
};

export const Required: Story = {
  args: { required: true },
};

export const WithDescription: Story = {
  args: {
    description: 'Estado de emissão do documento.',
  },
};

export const Error: Story = {
  args: {
    error: 'Selecione um estado.',
  },
};

export const Small: Story = {
  args: { size: 'sm', labelSize: 'sm' },
};

export const Disabled: Story = {
  args: {
    disabled: true,
    defaultValue: 'rj',
  },
};

export const Controlled: Story = {
  render: function ControlledSelect(args) {
    const [value, setValue] = useState('mg');
    return (
      <SelectField {...args} value={value} onValueChange={setValue} />
    );
  },
};
