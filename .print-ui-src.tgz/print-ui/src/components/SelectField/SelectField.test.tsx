import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { SelectField } from './SelectField';

describe('SelectField', () => {
  it('renders custom combobox trigger instead of native select', () => {
    render(
      <SelectField
        label="Escritório"
        name="office"
        options={[
          { value: 'all', label: 'Todos' },
          { value: '1', label: 'São Paulo' },
        ]}
        value="all"
        onValueChange={() => {}}
      />,
    );

    expect(screen.getByRole('combobox')).toBeTruthy();
    expect(screen.getByText('Todos')).toBeTruthy();
    expect(document.querySelector('select')).toBeNull();
  });
});
