import { Select } from '@base-ui-components/react/select';
import { useId } from 'react';

import { ICONS } from '../../assets/icons';
import { FormField } from '../FormField/FormField';
import { Icon } from '../Icon';

import styles from './styles.module.scss';

export type SelectOption = {
  value: string;
  label: string;
};

export type SelectFieldProps = {
  label: string;
  labelHidden?: boolean;
  labelSize?: 'md' | 'sm';
  required?: boolean;
  description?: string;
  error?: string;
  name: string;
  options: SelectOption[];
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  placeholder?: string;
  disabled?: boolean;
  size?: 'md' | 'sm';
  /** Render popup inside the DOM tree (for scrollable drawers/modals). */
  contained?: boolean;
};

function ChevronIcon() {
  return <Icon src={ICONS.ui.chevronDown} className={styles.icon} size={16} />;
}

function CheckIcon() {
  return <Icon src={ICONS.ui.check} size={12} />;
}

export function SelectField({
  label,
  labelHidden = false,
  labelSize = 'md',
  required = false,
  description,
  error,
  name,
  options,
  value,
  defaultValue,
  onValueChange,
  placeholder = 'Selecione…',
  disabled,
  size = 'md',
  contained = false,
}: SelectFieldProps) {
  const id = useId();

  const popup = (
    <Select.Positioner
      className={styles.positioner}
      sideOffset={4}
      alignItemWithTrigger={false}
    >
      <Select.Popup
        className={[styles.popup, size === 'sm' ? styles.popupSm : '']
          .filter(Boolean)
          .join(' ')}
      >
        <Select.List>
          {options.map((option) => (
            <Select.Item
              key={option.value}
              value={option.value}
              className={[styles.item, size === 'sm' ? styles.itemSm : '']
                .filter(Boolean)
                .join(' ')}
            >
              <Select.ItemIndicator className={styles.itemIndicator}>
                <CheckIcon />
              </Select.ItemIndicator>
              <Select.ItemText>{option.label}</Select.ItemText>
            </Select.Item>
          ))}
        </Select.List>
      </Select.Popup>
    </Select.Positioner>
  );

  return (
    <FormField
      label={label}
      labelHidden={labelHidden}
      labelSize={labelSize}
      required={required}
      description={description}
      error={error}
      name={name}
      disabled={disabled}
      invalid={Boolean(error)}
    >
      <Select.Root
        name={name}
        id={id}
        value={value}
        defaultValue={defaultValue}
        onValueChange={(next) => {
          if (next != null) onValueChange?.(next);
        }}
        disabled={disabled}
        items={options}
      >
        <Select.Trigger
          className={[styles.select, size === 'sm' ? styles.selectSm : '']
            .filter(Boolean)
            .join(' ')}
          aria-invalid={error ? true : undefined}
        >
          <Select.Value className={styles.value}>
            {(current) =>
              current
                ? (options.find((o) => o.value === current)?.label ??
                  String(current))
                : placeholder
            }
          </Select.Value>
          <Select.Icon>
            <ChevronIcon />
          </Select.Icon>
        </Select.Trigger>
        {contained ? popup : <Select.Portal>{popup}</Select.Portal>}
      </Select.Root>
    </FormField>
  );
}
