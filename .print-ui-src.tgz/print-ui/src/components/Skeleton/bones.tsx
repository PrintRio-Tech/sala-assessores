import type { ComponentPropsWithoutRef } from 'react';

import styles from './styles.module.scss';

/** Módulo interno — não exportar no pacote público. Use CardSkeleton / TableSkeleton. */

export type BoneRootProps = ComponentPropsWithoutRef<'div'>;

export function BoneRoot({ className, children, ...props }: BoneRootProps) {
  const classes = [styles.root, className].filter(Boolean).join(' ');

  return (
    <div className={classes} aria-busy="true" {...props}>
      {children}
    </div>
  );
}

type BoneShapeProps = ComponentPropsWithoutRef<'span'> & {
  width?: string | number;
  height?: string | number;
};

function boneStyle(
  width?: string | number,
  height?: string | number,
  style?: ComponentPropsWithoutRef<'span'>['style'],
) {
  return {
    ...(width != null ? { width } : undefined),
    ...(height != null ? { height } : undefined),
    ...style,
  };
}

export function BoneLine({
  className,
  width,
  height,
  style,
  ...props
}: BoneShapeProps) {
  const classes = [styles.shimmer, styles.line, className].filter(Boolean).join(' ');

  return (
    <span
      className={classes}
      aria-hidden="true"
      style={boneStyle(width, height, style)}
      {...props}
    />
  );
}

export function BoneBlock({
  className,
  width,
  height,
  style,
  ...props
}: BoneShapeProps) {
  const classes = [styles.shimmer, styles.block, className]
    .filter(Boolean)
    .join(' ');

  return (
    <span
      className={classes}
      aria-hidden="true"
      style={boneStyle(width, height, style)}
      {...props}
    />
  );
}
