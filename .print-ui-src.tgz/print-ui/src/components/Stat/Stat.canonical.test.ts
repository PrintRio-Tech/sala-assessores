import { readFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

import { describe, expect, it } from 'vitest';

const here = dirname(fileURLToPath(import.meta.url));
const scss = readFileSync(join(here, 'styles.module.scss'), 'utf8');
const source = readFileSync(join(here, 'Stat.tsx'), 'utf8');
const indexSource = readFileSync(join(here, '..', 'index.ts'), 'utf8');

describe('Stat gramática canônica (visual reset)', () => {
  it('default do label não é uppercase hero (ex-compact vira único)', () => {
    const labelBlock = scss.match(/\.label\s*\{[\s\S]*?\n\}/)?.[0] ?? '';
    expect(labelBlock).not.toMatch(/text-transform:\s*uppercase/);
    expect(scss).not.toMatch(/\.labelCompact/);
    expect(scss).not.toMatch(/\.valueCompact/);
    expect(scss).not.toMatch(/\.compact\s*\{/);
  });

  it('não expõe size compact nem emphasis quiet', () => {
    expect(source).not.toMatch(/StatSize/);
    expect(source).not.toMatch(/size\?:/);
    expect(source).not.toMatch(/'quiet'/);
    expect(source).not.toMatch(/quiet/);
    expect(indexSource).not.toMatch(/StatSize/);
  });

  it('valor default é escala body/semibold, não headline-lg', () => {
    const valueBlock = scss.match(/\.value\s*\{[\s\S]*?\n\}/)?.[0] ?? '';
    expect(valueBlock).not.toMatch(/headline-lg/);
    expect(valueBlock).toMatch(/font-weight:\s*600|semibold|body-md/);
  });
});
