import type { Meta, StoryObj } from '@storybook/react-vite';

import { Stat } from './Stat';

const meta = {
  title: 'Foundation/Stat',
  component: Stat,
  tags: ['autodocs'],
  args: {
    value: '1.284',
    label: 'Clippings',
    emphasis: 'default',
    loading: false,
  },
  argTypes: {
    emphasis: {
      control: 'select',
      options: ['default', 'primary'],
    },
    loading: { control: 'boolean' },
  },
} satisfies Meta<typeof Stat>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const Primary: Story = {
  name: 'Primary emphasis',
  args: {
    emphasis: 'primary',
    value: '98%',
    label: 'Taxa de entrega',
  },
};

export const Loading: Story = {
  args: {
    loading: true,
    label: 'Clippings',
  },
};

export const Group: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: 32, flexWrap: 'wrap' }}>
      <Stat value="1.284" label="Clippings" />
      <Stat value="56" label="Jornalistas" emphasis="primary" />
      <Stat value="1.042" label="Usuários ativos" />
      <Stat value="—" label="Relatórios" loading />
    </div>
  ),
};
