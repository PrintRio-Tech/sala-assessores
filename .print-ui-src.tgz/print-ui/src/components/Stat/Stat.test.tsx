import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { Stat } from './Stat';

describe('Stat', () => {
  it('associa valor e rótulo semanticamente com role group e aria-label', () => {
    render(<Stat value="3.482" label="Matérias monitoradas" />);

    const group = screen.getByRole('group', { name: '3.482, Matérias monitoradas' });
    expect(group).toBeInTheDocument();
    expect(screen.getByText('3.482')).toBeInTheDocument();
    expect(screen.getByText('Matérias monitoradas')).toBeInTheDocument();
  });

  it('aplica ênfase primary na cor do valor', () => {
    render(
      <Stat value="128" label="Veículos distintos" emphasis="primary" data-testid="stat" />,
    );

    const value = screen.getByText('128');
    expect(value.className).toMatch(/primary/);
  });

  it('expõe aria-busy e placeholder de esqueleto quando loading', () => {
    render(<Stat value="0" label="Matérias monitoradas" loading />);

    const group = screen.getByRole('group', { name: 'Matérias monitoradas' });
    expect(group).toHaveAttribute('aria-busy', 'true');
    expect(screen.queryByText('0')).not.toBeInTheDocument();
    expect(screen.getByText('Matérias monitoradas')).toBeInTheDocument();
    expect(group.querySelector('[aria-hidden="true"]')).toBeInTheDocument();
  });

  it('default não usa classes compact/quiet/hero', () => {
    render(<Stat value="1.042" label="Usuários ativos" data-testid="stat" />);

    const root = screen.getByTestId('stat');
    expect(root.className).not.toMatch(/compact/);
    expect(screen.getByText('Usuários ativos').className).not.toMatch(
      /labelCompact|uppercase/i,
    );
    expect(screen.getByText('1.042').className).not.toMatch(/valueCompact|quiet/);
  });
});
