import type { ComponentPropsWithoutRef } from 'react';

import { BoneLine } from '../Skeleton/bones';
import { Text } from '../Text/Text';

import styles from './styles.module.scss';

export type StatEmphasis = 'default' | 'primary';

export type StatProps = ComponentPropsWithoutRef<'div'> & {
  value: string;
  label: string;
  emphasis?: StatEmphasis;
  loading?: boolean;
};

export function Stat({
  value,
  label,
  emphasis = 'default',
  loading = false,
  className,
  ...props
}: StatProps) {
  const classes = [styles.stat, className].filter(Boolean).join(' ');
  const valueClasses = [
    styles.value,
    emphasis === 'primary' ? styles.primary : undefined,
  ]
    .filter(Boolean)
    .join(' ');

  if (loading) {
    return (
      <div
        role="group"
        aria-label={label}
        aria-busy="true"
        className={classes}
        {...props}
      >
        <Text as="p" variant="labelSm" tone="muted" className={styles.label}>
          {label}
        </Text>
        <BoneLine
          className={styles.valueSkeleton}
          width="55%"
          aria-hidden="true"
        />
      </div>
    );
  }

  return (
    <div
      role="group"
      aria-label={`${value}, ${label}`}
      className={classes}
      {...props}
    >
      <Text as="p" variant="labelSm" tone="muted" className={styles.label}>
        {label}
      </Text>
      <p className={valueClasses}>{value}</p>
    </div>
  );
}
