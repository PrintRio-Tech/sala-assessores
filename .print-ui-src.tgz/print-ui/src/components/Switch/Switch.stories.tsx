import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';

import { Switch } from './Switch';

const meta = {
  title: 'Forms/Switch',
  component: Switch,
  tags: ['autodocs'],
  args: {
    label: 'Receber alertas por e-mail',
    disabled: false,
  },
} satisfies Meta<typeof Switch>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const Checked: Story = {
  args: { defaultChecked: true },
};

export const Disabled: Story = {
  args: { disabled: true },
};

export const DisabledChecked: Story = {
  args: { disabled: true, defaultChecked: true },
};

export const Required: Story = {
  args: { required: true, label: 'Aceito receber comunicações' },
};

export const WithoutLabel: Story = {
  args: { label: undefined },
};

export const Controlled: Story = {
  render: function ControlledSwitch() {
    const [checked, setChecked] = useState(true);
    return (
      <Switch
        label={checked ? 'Modo automático ligado' : 'Modo automático desligado'}
        checked={checked}
        onCheckedChange={setChecked}
      />
    );
  },
};
