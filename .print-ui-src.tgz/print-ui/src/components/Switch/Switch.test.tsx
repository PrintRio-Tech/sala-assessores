import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { Switch } from './Switch';

describe('Switch', () => {
  it('exibe indicador de required no label', () => {
    render(<Switch label="Ativar" required />);

    expect(screen.getByText('*')).toBeInTheDocument();
    expect(screen.getByRole('switch')).toHaveAttribute('aria-required', 'true');
  });
});
