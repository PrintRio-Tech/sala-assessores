import { Switch as BaseSwitch } from '@base-ui-components/react/switch';
import { useId, type ReactNode } from 'react';

import styles from './styles.module.scss';

export type SwitchProps = {
  checked?: boolean;
  defaultChecked?: boolean;
  onCheckedChange?: (checked: boolean) => void;
  disabled?: boolean;
  required?: boolean;
  label?: ReactNode;
  id?: string;
  name?: string;
  className?: string;
};

export function Switch({
  checked,
  defaultChecked,
  onCheckedChange,
  disabled = false,
  required = false,
  label,
  id: idProp,
  name,
  className,
}: SwitchProps) {
  const generatedId = useId();
  const labelId = useId();
  const id = idProp ?? generatedId;
  const classes = [styles.root, className].filter(Boolean).join(' ');
  const stringLabel = typeof label === 'string' ? label : undefined;

  return (
    <label className={classes}>
      <BaseSwitch.Root
        id={id}
        className={styles.switch}
        checked={checked}
        defaultChecked={defaultChecked}
        disabled={disabled}
        name={name}
        required={required || undefined}
        aria-required={required || undefined}
        aria-label={stringLabel}
        aria-labelledby={label != null && !stringLabel ? labelId : undefined}
        onCheckedChange={(next) => onCheckedChange?.(next)}
      >
        <BaseSwitch.Thumb className={styles.thumb} />
      </BaseSwitch.Root>
      {label != null ? (
        <span id={labelId} className={styles.label}>
          {label}
          {required ? (
            <span className={styles.requiredIndicator} aria-hidden="true">
              *
            </span>
          ) : null}
        </span>
      ) : null}
    </label>
  );
}
