import type { Meta, StoryObj } from '@storybook/react-vite';
import type { CSSProperties } from 'react';
import { fn } from 'storybook/test';

import { DetailPreview } from './Cells/DetailPreview';
import { PersonCell } from './Cells/Person';
import { PersonDetailedCell } from './Cells/Person/Detailed';

const stack: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 24,
  maxWidth: 360,
};

const meta = {
  title: 'Data/TableCells',
  component: PersonCell,
  tags: ['autodocs'],
  args: {
    name: 'Ana Costa',
    subtitle: 'ana@print.com',
  },
  argTypes: {
    variant: {
      control: 'select',
      options: ['default', 'compact', 'card'],
    },
  },
} satisfies Meta<typeof PersonCell>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Person: Story = {};

export const PersonCompact: Story = {
  args: {
    variant: 'compact',
  },
};

export const PersonCard: Story = {
  args: {
    variant: 'card',
    subtitle: 'Editora · Política',
  },
};

export const PersonWithAvatar: Story = {
  args: {
    name: 'Bruno Lima',
    subtitle: 'Repórter',
    avatarUrl: 'https://i.pravatar.cc/80?u=bruno',
  },
};

export const PersonDetailed: Story = {
  render: () => (
    <div style={stack}>
      <PersonDetailedCell
        name="Ana Costa"
        subtitle="Editora"
        email="ana@print.com"
        phone="(11) 98888-1111"
        contactAction={{
          label: 'Enviar mensagem',
          onClick: fn(),
        }}
      />
      <p style={{ margin: 0, fontSize: 13, opacity: 0.7 }}>
        Passe o mouse sobre o nome para abrir o preview.
      </p>
    </div>
  ),
};

export const DetailPreviewCard: Story = {
  render: () => (
    <DetailPreview
      trigger={<span style={{ cursor: 'pointer', textDecoration: 'underline' }}>Ver detalhes</span>}
      side="bottom"
      align="start"
    >
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, padding: 4 }}>
        <PersonCell name="Carla Dias" subtitle="Designer" />
        <p style={{ margin: 0, fontSize: 13 }}>
          Responsável pela identidade visual das capas semanais.
        </p>
      </div>
    </DetailPreview>
  ),
};
