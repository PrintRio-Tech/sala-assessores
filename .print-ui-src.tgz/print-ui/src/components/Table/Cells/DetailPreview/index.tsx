import { PreviewCard } from '@base-ui-components/react/preview-card';
import type { ReactNode } from 'react';

import styles from './styles.module.scss';

export type DetailPreviewProps = {
  trigger: ReactNode;
  children: ReactNode;
  side?: 'top' | 'bottom' | 'left' | 'right';
  align?: 'start' | 'center' | 'end';
};

export function DetailPreview({
  trigger,
  children,
  side = 'bottom',
  align = 'start',
}: DetailPreviewProps) {
  return (
    <PreviewCard.Root>
      <PreviewCard.Trigger
        className={styles.trigger}
        delay={250}
        closeDelay={120}
        render={<span />}
      >
        {trigger}
      </PreviewCard.Trigger>
      <PreviewCard.Portal>
        <PreviewCard.Positioner
          className={styles.positioner}
          side={side}
          sideOffset={8}
          align={align}
        >
          <PreviewCard.Popup className={styles.popup}>
            {children}
          </PreviewCard.Popup>
        </PreviewCard.Positioner>
      </PreviewCard.Portal>
    </PreviewCard.Root>
  );
}
