import { Button } from '../../../../Button/Button';

import { DetailPreview } from '../../DetailPreview';
import { useIsMobile } from '../../../RowActions/use-is-mobile';
import { PersonCell } from '../index';
import type { TablePersonDetailValue } from '../types';
import styles from './styles.module.scss';

export type {
  TablePersonDetailValue,
  TablePersonContactAction,
} from '../types';

export type PersonDetailedCellProps = TablePersonDetailValue;

export function PersonDetailedCell({
  name,
  subtitle,
  avatarUrl,
  email,
  phone,
  contactAction,
}: PersonDetailedCellProps) {
  const isMobile = useIsMobile();

  if (isMobile) {
    return <span className={styles.mobileName}>{name}</span>;
  }

  return (
    <DetailPreview
      trigger={<span className={styles.inlineName}>{name}</span>}
      side="bottom"
      align="start"
    >
      <div className={styles.card}>
        <PersonCell name={name} subtitle={subtitle} avatarUrl={avatarUrl} />
        <dl className={styles.details}>
          {email ? (
            <div className={styles.detailRow}>
              <dt>E-mail</dt>
              <dd className={styles.email}>{email}</dd>
            </div>
          ) : null}
          {phone ? (
            <div className={styles.detailRow}>
              <dt>Contato</dt>
              <dd>{phone}</dd>
            </div>
          ) : null}
        </dl>
        {contactAction ? (
          <Button
            type="button"
            variant="outline"
            className={styles.action}
            onClick={contactAction.onClick}
          >
            {contactAction.label}
          </Button>
        ) : null}
      </div>
    </DetailPreview>
  );
}
