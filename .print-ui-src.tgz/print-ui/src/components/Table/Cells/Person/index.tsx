import styles from './styles.module.scss';
import { getPersonInitials, type TablePersonValue } from './types';

export type { TablePersonValue } from './types';
export type PersonCellProps = TablePersonValue & {
  /** @deprecated Use `variant="compact"`. */
  compact?: boolean;
  variant?: 'default' | 'compact' | 'card';
};

export function PersonCell({
  name,
  subtitle,
  avatarUrl,
  compact = false,
  variant: variantProp,
}: PersonCellProps) {
  const variant = variantProp ?? (compact ? 'compact' : 'default');
  const initials = getPersonInitials(name);
  const showSubtitle = variant !== 'compact' && Boolean(subtitle);

  return (
    <div
      className={[
        styles.root,
        variant !== 'default' ? styles[variant] : undefined,
      ]
        .filter(Boolean)
        .join(' ')}
    >
      <span
        className={styles.avatar}
        aria-hidden={avatarUrl ? undefined : true}
      >
        {avatarUrl ? (
          <img className={styles.avatarImage} src={avatarUrl} alt="" />
        ) : (
          initials
        )}
      </span>
      <span className={styles.text}>
        <span className={styles.name}>{name}</span>
        {showSubtitle ? (
          <span className={styles.subtitle}>{subtitle}</span>
        ) : null}
      </span>
    </div>
  );
}
