export type TablePersonValue = {
  name: string;
  subtitle?: string;
  avatarUrl?: string;
};

export type TablePersonContactAction = {
  label: string;
  onClick: () => void;
};

export type TablePersonDetailValue = TablePersonValue & {
  email?: string;
  phone?: string;
  contactAction?: TablePersonContactAction;
};

export function getPersonInitials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);

  if (parts.length === 0) {
    return '?';
  }

  if (parts.length === 1) {
    return parts[0].slice(0, 2).toUpperCase();
  }

  const first = parts[0]?.[0] ?? '';
  const last = parts[parts.length - 1]?.[0] ?? '';

  return `${first}${last}`.toUpperCase();
}
