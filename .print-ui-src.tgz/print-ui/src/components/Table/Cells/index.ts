export { DetailPreview } from './DetailPreview';
export type { DetailPreviewProps } from './DetailPreview';

export { PersonCell } from './Person';
export type { PersonCellProps, TablePersonValue } from './Person';
export { getPersonInitials } from './Person/types';
export type {
  TablePersonDetailValue,
  TablePersonContactAction,
} from './Person/types';

export { PersonDetailedCell } from './Person/Detailed';
export type { PersonDetailedCellProps } from './Person/Detailed';
