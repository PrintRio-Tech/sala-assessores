import type { Meta, StoryObj } from '@storybook/react-vite';
import type { ComponentType } from 'react';
import { useState } from 'react';
import { fn } from 'storybook/test';

import { DataTable, type DataTableProps } from './DataTable';
import type { TableColumnDef, TableSortState } from './DataTable/types';
import { TableRowActions } from './RowActions';

type Employee = {
  id: string;
  name: string;
  email: string;
  role: string;
  department: string;
  articles: number;
};

const employees: Employee[] = [
  {
    id: '1',
    name: 'Ana Costa',
    email: 'ana@print.com',
    role: 'Editora',
    department: 'Política',
    articles: 24,
  },
  {
    id: '2',
    name: 'Bruno Lima',
    email: 'bruno@print.com',
    role: 'Repórter',
    department: 'Esporte',
    articles: 18,
  },
  {
    id: '3',
    name: 'Carla Dias',
    email: 'carla@print.com',
    role: 'Designer',
    department: 'Arte',
    articles: 9,
  },
  {
    id: '4',
    name: 'Diego Alves',
    email: 'diego@print.com',
    role: 'Fotógrafo',
    department: 'Foto',
    articles: 31,
  },
];

const columns: TableColumnDef<Employee>[] = [
  {
    id: 'name',
    header: 'Nome',
    cellType: 'person',
    cell: (row) => ({ name: row.name, subtitle: row.email }),
    priority: { mobile: 1, tablet: 1, desktop: 1 },
    size: 'lg',
    sortable: true,
  },
  {
    id: 'role',
    header: 'Função',
    cell: (row) => row.role,
    priority: { mobile: 2, tablet: 2, desktop: 2 },
    size: 'md',
    sortable: true,
  },
  {
    id: 'department',
    header: 'Departamento',
    cell: (row) => row.department,
    priority: { mobile: 3, tablet: 3, desktop: 3 },
    size: 'md',
  },
  {
    id: 'articles',
    header: 'Matérias',
    cell: (row) => row.articles,
    priority: { mobile: 4, tablet: 4, desktop: 4 },
    size: 'sm',
    align: 'right',
    sortable: true,
  },
];

const detailedColumns: TableColumnDef<Employee>[] = [
  {
    id: 'person',
    header: 'Pessoa',
    cellType: 'personDetailed',
    cell: (row) => ({
      name: row.name,
      subtitle: row.role,
      email: row.email,
      phone: '(11) 99999-0000',
      contactAction: {
        label: 'Enviar mensagem',
        onClick: fn(),
      },
    }),
    priority: { mobile: 1, tablet: 1, desktop: 1 },
    size: 'xl',
  },
  {
    id: 'department',
    header: 'Departamento',
    cell: (row) => row.department,
    priority: { mobile: 2, tablet: 2, desktop: 2 },
    size: 'md',
  },
  {
    id: 'articles',
    header: 'Matérias',
    cell: (row) => row.articles,
    priority: { mobile: 3, tablet: 3, desktop: 3 },
    size: 'sm',
    align: 'right',
  },
];

function sortRows(
  data: Employee[],
  sort: TableSortState | undefined,
): Employee[] {
  if (!sort?.direction || !sort.key) {
    return data;
  }

  const dir = sort.direction === 'asc' ? 1 : -1;

  return [...data].sort((a, b) => {
    const left = a[sort.key as keyof Employee];
    const right = b[sort.key as keyof Employee];

    if (typeof left === 'number' && typeof right === 'number') {
      return (left - right) * dir;
    }

    return String(left).localeCompare(String(right)) * dir;
  });
}

const meta = {
  title: 'Data/DataTable',
  component: DataTable as ComponentType<DataTableProps<Employee>>,
  tags: ['autodocs'],
  args: {
    columns,
    data: employees,
    getRowKey: (row) => row.id,
    striped: false,
    emptyState: 'Nenhum registro encontrado.',
  },
} satisfies Meta<DataTableProps<Employee>>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const Striped: Story = {
  args: { striped: true },
};

export const WithSorting: Story = {
  render: (args) => {
    const [sort, setSort] = useState<TableSortState>({
      key: 'name',
      direction: 'asc',
    });

    return (
      <DataTable
        columns={columns}
        data={sortRows(employees, sort)}
        getRowKey={(row) => row.id}
        striped={args.striped}
        emptyState={args.emptyState}
        sort={sort}
        onSort={(columnId) => {
          setSort((current) => {
            if (current.key !== columnId) {
              return { key: columnId, direction: 'asc' };
            }

            if (current.direction === 'asc') {
              return { key: columnId, direction: 'desc' };
            }

            if (current.direction === 'desc') {
              return { key: columnId, direction: null };
            }

            return { key: columnId, direction: 'asc' };
          });
        }}
      />
    );
  },
};

export const WithRowActions: Story = {
  args: {
    rowActions: (row) => (
      <TableRowActions
        aria-label={`Ações de ${row.name}`}
        actions={[
          { label: 'Ver', icon: 'view', onSelect: fn() },
          { label: 'Editar', icon: 'edit', onSelect: fn() },
          {
            label: 'Excluir',
            icon: 'delete',
            destructive: true,
            onSelect: fn(),
          },
        ]}
      />
    ),
  },
};

export const Empty: Story = {
  args: {
    data: [],
  },
};

export const PersonDetailed: Story = {
  args: {
    columns: detailedColumns,
  },
};
