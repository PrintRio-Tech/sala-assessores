import type { ReactNode } from 'react';
import { useMemo } from 'react';

import { PersonCell } from '../Cells/Person';
import { PersonDetailedCell } from '../Cells/Person/Detailed';
import styles from './styles.module.scss';
import {
  getTabletHiddenColumnIds,
  resolveColumnSize,
  sortColumnsByPriority,
  splitMobileColumns,
} from './utils';
import type { TableColumnDef, TableSortState } from './types';
import {
  Table,
  TableActionsCell,
  TableBody,
  TableCell,
  TableEmpty,
  TableHead,
  TableHeader,
  TableRow,
} from '../primitives';

export type DataTableProps<T> = {
  columns: TableColumnDef<T>[];
  data: T[];
  getRowKey: (row: T) => string;
  striped?: boolean;
  sort?: TableSortState;
  onSort?: (columnId: string) => void;
  rowActions?: (row: T) => ReactNode;
  emptyState?: ReactNode;
  /** Quantas colunas de dados exibir no tablet (ações sempre visíveis). */
  tabletColumnLimit?: number;
  className?: string;
};

function columnSizeAttribute(size: ReturnType<typeof resolveColumnSize>) {
  return size ? ({ 'data-col-size': size } as const) : {};
}

function renderCell<T>(column: TableColumnDef<T>, row: T) {
  if (column.cellType === 'personDetailed') {
    return <PersonDetailedCell {...column.cell(row)} />;
  }

  if (column.cellType === 'person') {
    return <PersonCell {...column.cell(row)} />;
  }

  return column.cell(row);
}

function renderMobileCell<T>(column: TableColumnDef<T>, row: T) {
  if (column.mobileCell) {
    return column.mobileCell(row);
  }

  if (column.cellType === 'personDetailed') {
    return column.cell(row).name;
  }

  if (column.cellType === 'person') {
    return <PersonCell compact {...column.cell(row)} />;
  }

  return column.cell(row);
}

function isPersonColumn<T>(column: TableColumnDef<T>) {
  return column.cellType === 'person' || column.cellType === 'personDetailed';
}

function partitionMobileColumns<T>(columns: TableColumnDef<T>[]) {
  const { primary, secondary } = splitMobileColumns(columns);

  return {
    primary,
    personColumns: secondary.filter((column) => isPersonColumn(column)),
    metaColumns: secondary.filter((column) => !isPersonColumn(column)),
  };
}

export function DataTable<T>({
  columns,
  data,
  getRowKey,
  striped = false,
  sort,
  onSort,
  rowActions,
  emptyState = 'Nenhum registro encontrado.',
  tabletColumnLimit = 4,
  className,
}: DataTableProps<T>) {
  const desktopColumns = useMemo(
    () => sortColumnsByPriority(columns, 'desktop'),
    [columns],
  );

  const tabletHiddenIds = useMemo(
    () => getTabletHiddenColumnIds(columns, tabletColumnLimit),
    [columns, tabletColumnLimit],
  );

  const {
    primary: mobilePrimary,
    personColumns,
    metaColumns,
  } = useMemo(() => partitionMobileColumns(columns), [columns]);

  const hasActions = Boolean(rowActions);

  return (
    <div className={[styles.root, className].filter(Boolean).join(' ')}>
      <div className={styles.tableView}>
        <Table striped={striped}>
          <TableHeader>
            <TableRow>
              {desktopColumns.map((column) => (
                <TableHead
                  key={column.id}
                  align={column.align}
                  sortable={column.sortable}
                  sortDirection={
                    sort?.key === column.id ? (sort.direction ?? null) : null
                  }
                  onSort={
                    column.sortable && onSort
                      ? () => onSort(column.id)
                      : undefined
                  }
                  className={
                    tabletHiddenIds.has(column.id)
                      ? styles.hideOnTablet
                      : undefined
                  }
                  {...columnSizeAttribute(
                    resolveColumnSize(column.size, 'desktop'),
                  )}
                >
                  {column.header}
                </TableHead>
              ))}
              {hasActions ? (
                <TableHead className={styles.actionsHead} aria-label="Ações" />
              ) : null}
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.length === 0 ? (
              <TableEmpty>{emptyState}</TableEmpty>
            ) : (
              data.map((row) => (
                <TableRow key={getRowKey(row)}>
                  {desktopColumns.map((column) => (
                    <TableCell
                      key={column.id}
                      align={column.align}
                      className={
                        tabletHiddenIds.has(column.id)
                          ? styles.hideOnTablet
                          : undefined
                      }
                      {...columnSizeAttribute(
                        resolveColumnSize(column.size, 'desktop'),
                      )}
                    >
                      {renderCell(column, row)}
                    </TableCell>
                  ))}
                  {hasActions ? (
                    <TableActionsCell>{rowActions?.(row)}</TableActionsCell>
                  ) : null}
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <div className={styles.cardView}>
        {data.length === 0 ? (
          <p className={styles.emptyCards}>{emptyState}</p>
        ) : (
          data.map((row) => (
            <article key={getRowKey(row)} className={styles.card}>
              <header className={styles.cardHeader}>
                <div className={styles.cardLead}>
                  {mobilePrimary ? (
                    <div className={styles.cardTitle}>
                      {renderMobileCell(mobilePrimary, row)}
                    </div>
                  ) : null}
                  {personColumns.map((column) =>
                    column.cellType === 'personDetailed' ? (
                      <PersonDetailedCell
                        key={column.id}
                        {...column.cell(row)}
                      />
                    ) : (
                      <PersonCell
                        key={column.id}
                        variant="card"
                        {...column.cell(row)}
                      />
                    ),
                  )}
                </div>
                {hasActions ? (
                  <div className={styles.cardActions}>{rowActions?.(row)}</div>
                ) : null}
              </header>
              {metaColumns.length > 0 ? (
                <p className={styles.cardMeta}>
                  {metaColumns.map((column, index) => (
                    <span key={column.id} className={styles.cardMetaItem}>
                      {index > 0 ? (
                        <span className={styles.cardMetaSep} aria-hidden>
                          ·
                        </span>
                      ) : null}
                      {renderMobileCell(column, row)}
                    </span>
                  ))}
                </p>
              ) : null}
            </article>
          ))
        )}
      </div>
    </div>
  );
}
