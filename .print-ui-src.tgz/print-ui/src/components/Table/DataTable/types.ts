import type { ReactNode } from 'react';

import type { SortDirection } from '../primitives';
import type { TablePersonValue } from '../Cells/Person/types';
import type { TablePersonDetailValue } from '../Cells/Person/types';

export type TableBreakpoint = 'mobile' | 'tablet' | 'desktop';

/** 1 = maior prioridade (aparece primeiro / ocupa destaque no mobile). */
export type TableColumnPriority = number;

export type TableColumnSize =
  | 'xs'
  | 'sm'
  | 'md'
  | 'lg'
  | 'xl'
  | 'auto'
  | 'fill';

export type TableColumnSizeConfig =
  | TableColumnSize
  | Partial<Record<TableBreakpoint, TableColumnSize>>;

export type TableColumnPriorityConfig = Record<
  TableBreakpoint,
  TableColumnPriority
>;

export type TableColumnCellType = 'default' | 'person' | 'personDetailed';

type TableColumnBase<T> = {
  id: string;
  header: ReactNode;
  /** Conteúdo alternativo no card mobile (ex.: texto simples sem badge). */
  mobileCell?: (row: T) => ReactNode;
  priority: TableColumnPriorityConfig;
  size?: TableColumnSizeConfig;
  align?: 'left' | 'right';
  sortable?: boolean;
  visible?: Partial<Record<TableBreakpoint, boolean>>;
};

export type TableColumnDef<T> =
  | (TableColumnBase<T> & {
      cellType?: 'default';
      cell: (row: T) => ReactNode;
    })
  | (TableColumnBase<T> & {
      cellType: 'person';
      cell: (row: T) => TablePersonValue;
    })
  | (TableColumnBase<T> & {
      cellType: 'personDetailed';
      cell: (row: T) => TablePersonDetailValue;
    });

export type TableSortState = {
  key: string;
  direction: SortDirection | null;
};
