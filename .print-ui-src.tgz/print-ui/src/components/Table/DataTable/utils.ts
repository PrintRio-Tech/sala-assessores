import type {
  TableBreakpoint,
  TableColumnDef,
  TableColumnSize,
  TableColumnSizeConfig,
} from './types';

export function sortColumnsByPriority<T>(
  columns: TableColumnDef<T>[],
  breakpoint: TableBreakpoint,
): TableColumnDef<T>[] {
  return [...columns]
    .filter((column) => column.visible?.[breakpoint] !== false)
    .sort(
      (left, right) => left.priority[breakpoint] - right.priority[breakpoint],
    );
}

export function resolveColumnSize(
  size: TableColumnSizeConfig | undefined,
  breakpoint: TableBreakpoint,
): TableColumnSize | undefined {
  if (!size) {
    return undefined;
  }

  if (typeof size === 'string') {
    return size;
  }

  return size[breakpoint] ?? size.desktop ?? size.tablet ?? size.mobile;
}

export function getTabletHiddenColumnIds<T>(
  columns: TableColumnDef<T>[],
  limit: number,
): Set<string> {
  const visibleColumns = sortColumnsByPriority(columns, 'tablet').slice(
    0,
    limit,
  );
  const visibleIds = new Set(visibleColumns.map((column) => column.id));

  return new Set(
    columns
      .filter((column) => !visibleIds.has(column.id))
      .map((column) => column.id),
  );
}

export function splitMobileColumns<T>(columns: TableColumnDef<T>[]) {
  const mobileColumns = sortColumnsByPriority(columns, 'mobile');
  const [primary, ...secondary] = mobileColumns;

  return { primary, secondary };
}
