import { Dialog } from '@base-ui-components/react/dialog';
import { Menu } from '@base-ui-components/react/menu';

import { ICONS } from '../../../assets/icons';
import { Icon } from '../../Icon';

import { useIsMobile } from './use-is-mobile';
import styles from './styles.module.scss';

export type TableRowActionIcon = 'view' | 'edit' | 'delete';

export type TableRowAction = {
  label: string;
  onSelect: () => void;
  destructive?: boolean;
  icon?: TableRowActionIcon;
};

export type TableRowActionsProps = {
  actions: TableRowAction[];
  'aria-label'?: string;
};

function ActionIcon({ icon }: { icon?: TableRowActionIcon }) {
  switch (icon) {
    case 'view':
      return <Icon src={ICONS.table.view} size={16} />;
    case 'edit':
      return <Icon src={ICONS.table.edit} size={16} />;
    case 'delete':
      return <Icon src={ICONS.table.delete} size={16} />;
    default:
      return null;
  }
}

function ActionsMenu({
  actions,
  ariaLabel,
}: {
  actions: TableRowAction[];
  ariaLabel: string;
}) {
  return (
    <Menu.Root>
      <Menu.Trigger className={styles.trigger} aria-label={ariaLabel}>
        ⋮
      </Menu.Trigger>
      <Menu.Portal>
        <Menu.Positioner
          className={styles.positioner}
          sideOffset={4}
          align="end"
        >
          <Menu.Popup className={styles.popup}>
            {actions.map((action) => (
              <Menu.Item
                key={action.label}
                className={
                  action.destructive ? styles.destructive : styles.item
                }
                onClick={action.onSelect}
              >
                <span className={styles.itemIcon}>
                  <ActionIcon icon={action.icon} />
                </span>
                {action.label}
              </Menu.Item>
            ))}
          </Menu.Popup>
        </Menu.Positioner>
      </Menu.Portal>
    </Menu.Root>
  );
}

function ActionsDrawer({
  actions,
  ariaLabel,
}: {
  actions: TableRowAction[];
  ariaLabel: string;
}) {
  return (
    <Dialog.Root>
      <Dialog.Trigger className={styles.trigger} aria-label={ariaLabel}>
        ⋮
      </Dialog.Trigger>
      <Dialog.Portal>
        <Dialog.Backdrop className={styles.drawerBackdrop} />
        <Dialog.Popup className={styles.drawerPanel}>
          <div className={styles.drawerHandle} aria-hidden />
          <Dialog.Title className={styles.drawerTitle}>Ações</Dialog.Title>
          <div className={styles.drawerActions}>
            {actions.map((action) => (
              <Dialog.Close
                key={action.label}
                render={
                  <button
                    type="button"
                    className={
                      action.destructive
                        ? styles.drawerDestructive
                        : styles.drawerAction
                    }
                    onClick={action.onSelect}
                  >
                    <span className={styles.itemIcon}>
                      <ActionIcon icon={action.icon} />
                    </span>
                    {action.label}
                  </button>
                }
              />
            ))}
          </div>
          <Dialog.Close
            render={
              <button type="button" className={styles.drawerCancel}>
                Cancelar
              </button>
            }
          />
        </Dialog.Popup>
      </Dialog.Portal>
    </Dialog.Root>
  );
}

export function TableRowActions({
  actions,
  'aria-label': ariaLabel = 'Ações da linha',
}: TableRowActionsProps) {
  const isMobile = useIsMobile();

  if (isMobile) {
    return <ActionsDrawer actions={actions} ariaLabel={ariaLabel} />;
  }

  return <ActionsMenu actions={actions} ariaLabel={ariaLabel} />;
}
