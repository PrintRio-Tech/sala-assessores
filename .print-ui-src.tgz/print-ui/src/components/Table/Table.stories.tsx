import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { fn } from 'storybook/test';

import {
  Table,
  TableActionsCell,
  TableBody,
  TableCaption,
  TableCell,
  TableEmpty,
  TableHead,
  TableHeader,
  TableRow,
} from './primitives';
import { TableRowActions } from './RowActions';

const rows = [
  { id: '1', name: 'Ana Costa', role: 'Editora', status: 'Ativo' },
  { id: '2', name: 'Bruno Lima', role: 'Repórter', status: 'Ativo' },
  { id: '3', name: 'Carla Dias', role: 'Designer', status: 'Inativo' },
];

const meta = {
  title: 'Data/Table',
  component: Table,
  tags: ['autodocs'],
  args: {
    striped: false,
    children: (
      <>
        <TableCaption>Equipe editorial</TableCaption>
        <TableHeader>
          <TableRow>
            <TableHead>Nome</TableHead>
            <TableHead>Função</TableHead>
            <TableHead>Status</TableHead>
            <TableHead aria-label="Ações" />
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.id}>
              <TableCell>{row.name}</TableCell>
              <TableCell>{row.role}</TableCell>
              <TableCell>{row.status}</TableCell>
              <TableActionsCell>
                <TableRowActions
                  actions={[
                    { label: 'Ver', icon: 'view', onSelect: fn() },
                    { label: 'Editar', icon: 'edit', onSelect: fn() },
                    {
                      label: 'Excluir',
                      icon: 'delete',
                      destructive: true,
                      onSelect: fn(),
                    },
                  ]}
                />
              </TableActionsCell>
            </TableRow>
          ))}
        </TableBody>
      </>
    ),
  },
  argTypes: {
    striped: { control: 'boolean' },
  },
} satisfies Meta<typeof Table>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const Striped: Story = {
  args: {
    striped: true,
    children: (
      <>
        <TableHeader>
          <TableRow>
            <TableHead>Nome</TableHead>
            <TableHead align="right">Matérias</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.map((row, index) => (
            <TableRow key={row.id}>
              <TableCell>{row.name}</TableCell>
              <TableCell align="right">{12 + index * 4}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </>
    ),
  },
};

export const Sortable: Story = {
  render: (args) => {
    const [direction, setDirection] = useState<'asc' | 'desc' | null>('asc');

    return (
      <Table striped={args.striped}>
        <TableHeader>
          <TableRow>
            <TableHead
              sortable
              sortDirection={direction}
              onSort={() =>
                setDirection((current) =>
                  current === 'asc' ? 'desc' : 'asc',
                )
              }
            >
              Nome
            </TableHead>
            <TableHead>Função</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {[...rows]
            .sort((a, b) => {
              const cmp = a.name.localeCompare(b.name);
              return direction === 'desc' ? -cmp : cmp;
            })
            .map((row) => (
              <TableRow key={row.id}>
                <TableCell>{row.name}</TableCell>
                <TableCell>{row.role}</TableCell>
              </TableRow>
            ))}
        </TableBody>
      </Table>
    );
  },
};

export const Empty: Story = {
  args: {
    children: (
      <>
        <TableHeader>
          <TableRow>
            <TableHead>Nome</TableHead>
            <TableHead>Função</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          <TableEmpty>Nenhum registro encontrado.</TableEmpty>
        </TableBody>
      </>
    ),
  },
};
