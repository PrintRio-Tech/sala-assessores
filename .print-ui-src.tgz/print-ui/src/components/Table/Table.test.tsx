import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import {
  Table,
  TableBody,
  TableCell,
  TableEmpty,
  TableHead,
  TableHeader,
  TableRow,
} from '../Table/primitives';

describe('Table primitives', () => {
  it('renderiza cabeçalho e linhas', () => {
    render(
      <Table>
        <TableHeader>
          <tr>
            <TableHead>Nome</TableHead>
          </tr>
        </TableHeader>
        <TableBody>
          <TableRow>
            <TableCell>Item</TableCell>
          </TableRow>
        </TableBody>
      </Table>,
    );

    expect(screen.getByText('Nome')).toBeInTheDocument();
    expect(screen.getByText('Item')).toBeInTheDocument();
  });

  it('renderiza estado vazio', () => {
    render(
      <Table>
        <TableBody>
          <TableEmpty>Sem dados</TableEmpty>
        </TableBody>
      </Table>,
    );

    expect(screen.getByText('Sem dados')).toBeInTheDocument();
  });
});
