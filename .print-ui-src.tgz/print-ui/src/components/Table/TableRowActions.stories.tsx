import type { Meta, StoryObj } from '@storybook/react-vite';
import { fn } from 'storybook/test';

import { TableRowActions } from './RowActions';

const meta = {
  title: 'Data/TableRowActions',
  component: TableRowActions,
  tags: ['autodocs'],
  args: {
    'aria-label': 'Ações da linha',
    actions: [
      { label: 'Ver', icon: 'view', onSelect: fn() },
      { label: 'Editar', icon: 'edit', onSelect: fn() },
      {
        label: 'Excluir',
        icon: 'delete',
        destructive: true,
        onSelect: fn(),
      },
    ],
  },
} satisfies Meta<typeof TableRowActions>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const ViewAndEdit: Story = {
  args: {
    actions: [
      { label: 'Ver', icon: 'view', onSelect: fn() },
      { label: 'Editar', icon: 'edit', onSelect: fn() },
    ],
  },
};

export const DestructiveOnly: Story = {
  args: {
    actions: [
      {
        label: 'Excluir',
        icon: 'delete',
        destructive: true,
        onSelect: fn(),
      },
    ],
  },
};

export const WithoutIcons: Story = {
  args: {
    actions: [
      { label: 'Duplicar', onSelect: fn() },
      { label: 'Arquivar', onSelect: fn() },
      { label: 'Remover', destructive: true, onSelect: fn() },
    ],
  },
};
