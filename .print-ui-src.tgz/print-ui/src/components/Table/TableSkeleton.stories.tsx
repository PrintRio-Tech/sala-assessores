import type { Meta, StoryObj } from '@storybook/react-vite';

import { TableSkeleton } from './TableSkeleton';

const meta = {
  title: 'Data Display/Table/TableSkeleton',
  component: TableSkeleton,
  tags: ['autodocs'],
  args: {
    rows: 5,
    columns: 4,
  },
} satisfies Meta<typeof TableSkeleton>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const Compact: Story = {
  args: { rows: 3, columns: 3 },
};

export const Wide: Story = {
  args: { rows: 6, columns: 6 },
};
