import type { ComponentPropsWithoutRef } from 'react';

import { BoneBlock, BoneLine, BoneRoot } from '../Skeleton/bones';

import styles from './TableSkeleton.module.scss';

export type TableSkeletonProps = {
  rows?: number;
  columns?: number;
  className?: string;
} & Omit<ComponentPropsWithoutRef<'div'>, 'children'>;

export function TableSkeleton({
  rows = 5,
  columns = 4,
  className,
  ...props
}: TableSkeletonProps) {
  const colCount = Math.max(1, columns);
  const rowCount = Math.max(1, rows);

  return (
    <BoneRoot
      className={[styles.root, className].filter(Boolean).join(' ')}
      role="status"
      aria-label="Carregando tabela"
      {...props}
    >
      <div className={styles.header} aria-hidden="true">
        {Array.from({ length: colCount }, (_, i) => (
          <BoneLine key={`h-${i}`} width={`${60 + ((i * 7) % 30)}%`} height="0.65rem" />
        ))}
      </div>
      <div className={styles.body} aria-hidden="true">
        {Array.from({ length: rowCount }, (_, row) => (
          <div key={`r-${row}`} className={styles.row}>
            {Array.from({ length: colCount }, (_, col) =>
              col === 0 ? (
                <BoneBlock
                  key={`c-${row}-${col}`}
                  className={styles.cellBlock}
                  height="1rem"
                  width={`${50 + ((row + col) * 9) % 40}%`}
                />
              ) : (
                <BoneLine
                  key={`c-${row}-${col}`}
                  width={`${45 + ((row + col) * 11) % 45}%`}
                  height="0.7rem"
                />
              ),
            )}
          </div>
        ))}
      </div>
    </BoneRoot>
  );
}
