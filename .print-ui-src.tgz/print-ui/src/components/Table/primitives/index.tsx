import type { ComponentPropsWithoutRef, ReactNode } from 'react';

import styles from './styles.module.scss';

export type TableProps = {
  striped?: boolean;
  children: ReactNode;
} & Omit<ComponentPropsWithoutRef<'table'>, 'children'>;

export type SortDirection = 'asc' | 'desc';

export function Table({
  striped = false,
  className,
  children,
  ...props
}: TableProps) {
  const classes = [
    styles.table,
    striped ? styles.striped : undefined,
    className,
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <div className={styles.wrapper}>
      <table className={classes} {...props}>
        {children}
      </table>
    </div>
  );
}

export function TableCaption({
  className,
  ...props
}: ComponentPropsWithoutRef<'caption'>) {
  return (
    <caption
      className={[styles.caption, className].filter(Boolean).join(' ')}
      {...props}
    />
  );
}

export function TableHeader({
  className,
  ...props
}: ComponentPropsWithoutRef<'thead'>) {
  return (
    <thead
      className={[styles.head, className].filter(Boolean).join(' ')}
      {...props}
    />
  );
}

export function TableBody(props: ComponentPropsWithoutRef<'tbody'>) {
  return <tbody {...props} />;
}

export function TableRow({
  className,
  ...props
}: ComponentPropsWithoutRef<'tr'>) {
  return (
    <tr
      className={[styles.row, className].filter(Boolean).join(' ')}
      {...props}
    />
  );
}

export type TableHeadProps = ComponentPropsWithoutRef<'th'> & {
  align?: 'left' | 'right';
  sortable?: boolean;
  sortDirection?: SortDirection | null;
  onSort?: () => void;
};

export function TableHead({
  className,
  align,
  sortable = false,
  sortDirection = null,
  onSort,
  children,
  ...props
}: TableHeadProps) {
  const ariaSort =
    sortDirection === 'asc'
      ? 'ascending'
      : sortDirection === 'desc'
        ? 'descending'
        : sortable
          ? 'none'
          : undefined;

  if (!sortable) {
    return (
      <th
        className={[
          styles.headCell,
          align === 'right' ? styles.numeric : undefined,
          className,
        ]
          .filter(Boolean)
          .join(' ')}
        {...props}
      >
        {children}
      </th>
    );
  }

  return (
    <th
      className={[
        styles.headCell,
        styles.sortable,
        align === 'right' ? styles.numeric : undefined,
        className,
      ]
        .filter(Boolean)
        .join(' ')}
      aria-sort={ariaSort}
      {...props}
    >
      <button type="button" className={styles.sortButton} onClick={onSort}>
        <span className={styles.sortLabel}>{children}</span>
        <span
          className={styles.sortIcon}
          data-direction={sortDirection ?? 'none'}
          aria-hidden
        />
      </button>
    </th>
  );
}

export function TableCell({
  className,
  align,
  ...props
}: ComponentPropsWithoutRef<'td'> & { align?: 'left' | 'right' }) {
  return (
    <td
      className={[
        styles.cell,
        align === 'right' ? styles.numeric : undefined,
        className,
      ]
        .filter(Boolean)
        .join(' ')}
      {...props}
    />
  );
}

export function TableActionsCell({
  className,
  children,
  ...props
}: ComponentPropsWithoutRef<'td'>) {
  return (
    <td
      className={[styles.cell, styles.actionsCell, className]
        .filter(Boolean)
        .join(' ')}
      {...props}
    >
      {children}
    </td>
  );
}

export function TableEmpty({ children }: { children: ReactNode }) {
  return (
    <tr>
      <td className={styles.empty} colSpan={100}>
        {children}
      </td>
    </tr>
  );
}
