import type { Meta, StoryObj } from '@storybook/react-vite';

import { Tabs, TabsContent, TabsList, TabsTrigger } from './Tabs';

const meta = {
  title: 'Layout/Tabs',
  component: Tabs,
  tags: ['autodocs'],
  args: {
    defaultValue: 'overview',
    variant: 'underline',
  },
  argTypes: {
    variant: {
      control: 'select',
      options: ['underline', 'segmented'],
    },
  },
  render: (args) => (
    <Tabs {...args}>
      <TabsList aria-label="Seções">
        <TabsTrigger value="overview">Visão geral</TabsTrigger>
        <TabsTrigger value="activity">Atividade</TabsTrigger>
        <TabsTrigger value="settings">Configurações</TabsTrigger>
      </TabsList>
      <TabsContent value="overview">
        Resumo do projeto e indicadores principais.
      </TabsContent>
      <TabsContent value="activity">
        Histórico recente de alterações e eventos.
      </TabsContent>
      <TabsContent value="settings">
        Preferências e opções de configuração.
      </TabsContent>
    </Tabs>
  ),
} satisfies Meta<typeof Tabs>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const Underline: Story = {
  args: { variant: 'underline' },
};

export const Segmented: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'Controle segmentado (padrão ReportsSectionTabs): tablist padded, surface-container-low, tab ativa surface-bright + shadow-ambient, sem indicator.',
      },
    },
  },
  args: { variant: 'segmented' },
};
