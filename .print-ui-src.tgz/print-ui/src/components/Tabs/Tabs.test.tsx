import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { Tabs, TabsContent, TabsList, TabsTrigger } from './Tabs';

function SampleTabs({ variant }: { variant?: 'underline' | 'segmented' }) {
  return (
    <Tabs defaultValue="a" variant={variant}>
      <TabsList aria-label="Seções">
        <TabsTrigger value="a">Alpha</TabsTrigger>
        <TabsTrigger value="b">Beta</TabsTrigger>
      </TabsList>
      <TabsContent value="a">Painel A</TabsContent>
      <TabsContent value="b">Painel B</TabsContent>
    </Tabs>
  );
}

describe('Tabs', () => {
  it('troca painel ao ativar tab (underline)', () => {
    render(<SampleTabs variant="underline" />);

    expect(screen.getByText('Painel A')).toBeVisible();
    fireEvent.click(screen.getByRole('tab', { name: 'Beta' }));
    expect(screen.getByRole('tab', { name: 'Beta' })).toHaveAttribute(
      'aria-selected',
      'true',
    );
    expect(screen.getByText('Painel B')).toBeVisible();
  });

  it('variant segmented expõe data-variant e mantém a11y de tabs', () => {
    const { container } = render(<SampleTabs variant="segmented" />);

    expect(container.querySelector('[data-variant="segmented"]')).toBeTruthy();
    expect(screen.getByRole('tab', { name: 'Alpha' })).toHaveAttribute(
      'aria-selected',
      'true',
    );

    fireEvent.click(screen.getByRole('tab', { name: 'Beta' }));
    expect(screen.getByRole('tab', { name: 'Beta' })).toHaveAttribute(
      'aria-selected',
      'true',
    );
  });
});
