import { Tabs as BaseTabs } from '@base-ui-components/react/tabs';
import {
  createContext,
  useContext,
  type ComponentPropsWithoutRef,
} from 'react';

import styles from './styles.module.scss';

export type TabsVariant = 'underline' | 'segmented';

const TabsVariantContext = createContext<TabsVariant>('underline');

function useTabsVariant() {
  return useContext(TabsVariantContext);
}

export type TabsProps = ComponentPropsWithoutRef<typeof BaseTabs.Root> & {
  className?: string;
  /** `underline` (default) com indicator; `segmented` espelha ReportsSectionTabs. */
  variant?: TabsVariant;
};

export function Tabs({
  className,
  variant = 'underline',
  ...props
}: TabsProps) {
  const classes = [
    styles.root,
    variant === 'segmented' ? styles.rootSegmented : undefined,
    className,
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <TabsVariantContext.Provider value={variant}>
      <BaseTabs.Root
        className={classes}
        data-variant={variant}
        {...props}
      />
    </TabsVariantContext.Provider>
  );
}

export type TabsListProps = ComponentPropsWithoutRef<typeof BaseTabs.List> & {
  className?: string;
};

export function TabsList({ className, children, ...props }: TabsListProps) {
  const variant = useTabsVariant();
  const classes = [
    styles.list,
    variant === 'segmented' ? styles.listSegmented : undefined,
    className,
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <BaseTabs.List className={classes} {...props}>
      {children}
      <BaseTabs.Indicator
        className={
          variant === 'segmented' ? styles.indicatorSegmented : styles.indicator
        }
      />
    </BaseTabs.List>
  );
}

export type TabsTriggerProps = ComponentPropsWithoutRef<typeof BaseTabs.Tab> & {
  className?: string;
};

export function TabsTrigger({ className, ...props }: TabsTriggerProps) {
  const variant = useTabsVariant();
  const classes = [
    styles.trigger,
    variant === 'segmented' ? styles.triggerSegmented : undefined,
    className,
  ]
    .filter(Boolean)
    .join(' ');
  return <BaseTabs.Tab className={classes} {...props} />;
}

export type TabsContentProps = ComponentPropsWithoutRef<
  typeof BaseTabs.Panel
> & {
  className?: string;
};

export function TabsContent({ className, ...props }: TabsContentProps) {
  const variant = useTabsVariant();
  const classes = [
    styles.content,
    variant === 'segmented' ? styles.contentSegmented : undefined,
    className,
  ]
    .filter(Boolean)
    .join(' ');
  return <BaseTabs.Panel className={classes} {...props} />;
}
