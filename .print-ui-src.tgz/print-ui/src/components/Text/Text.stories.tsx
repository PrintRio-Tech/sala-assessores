import type { Meta, StoryObj } from '@storybook/react-vite';

import { Text } from './Text';

const meta = {
  title: 'Foundation/Text',
  component: Text,
  tags: ['autodocs'],
  args: {
    children: 'Texto de corpo do design system Print Forms.',
    variant: 'bodyMd',
    tone: 'default',
  },
  argTypes: {
    variant: {
      control: 'select',
      options: ['bodyLg', 'bodyMd', 'labelMd', 'labelSm'],
    },
    tone: {
      control: 'select',
      options: ['default', 'muted', 'error', 'primary'],
    },
    wrap: {
      control: 'select',
      options: ['normal', 'balance', 'pretty'],
    },
    tabular: { control: 'boolean' },
  },
} satisfies Meta<typeof Text>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const Variants: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <Text variant="bodyLg">bodyLg — parágrafo destacado</Text>
      <Text variant="bodyMd">bodyMd — parágrafo padrão</Text>
      <Text variant="labelMd">labelMd — rótulo médio</Text>
      <Text variant="labelSm">labelSm — rótulo pequeno</Text>
    </div>
  ),
};

export const Tones: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <Text tone="default">tone default</Text>
      <Text tone="muted">tone muted</Text>
      <Text tone="error">tone error</Text>
      <Text tone="primary">tone primary</Text>
    </div>
  ),
};

export const Tabular: Story = {
  args: {
    tabular: true,
    children: '1.234.567,89',
  },
};

export const WrapBalance: Story = {
  args: {
    wrap: 'balance',
    children:
      'Texto longo com wrap balance para demonstrar o comportamento tipográfico em títulos e parágrafos.',
  },
};
