import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { Text } from './Text';

describe('Text', () => {
  it('renderiza com variant e tone', () => {
    render(
      <Text variant="labelSm" tone="muted">
        Legenda
      </Text>,
    );

    expect(screen.getByText('Legenda')).toBeInTheDocument();
  });

  it('permite elemento polimórfico via as', () => {
    render(
      <Text as="span" variant="bodyMd" tone="primary">
        Destaque
      </Text>,
    );

    const element = screen.getByText('Destaque');
    expect(element.tagName).toBe('SPAN');
  });
});
