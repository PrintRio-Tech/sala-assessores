import type { ComponentPropsWithoutRef, ElementType } from 'react';

import styles from './styles.module.scss';

type TextVariant = 'bodyLg' | 'bodyMd' | 'labelMd' | 'labelSm';
type TextTone = 'default' | 'muted' | 'error' | 'primary';
type TextWrap = 'normal' | 'balance' | 'pretty';

export type TextProps<T extends ElementType = 'p'> = {
  as?: T;
  variant?: TextVariant;
  tone?: TextTone;
  wrap?: TextWrap;
  tabular?: boolean;
} & ComponentPropsWithoutRef<T>;

const variantClass: Record<TextVariant, string> = {
  bodyLg: styles.bodyLg,
  bodyMd: styles.bodyMd,
  labelMd: styles.labelMd,
  labelSm: styles.labelSm,
};

const toneClass: Record<TextTone, string | undefined> = {
  default: undefined,
  muted: styles.muted,
  error: styles.error,
  primary: styles.primary,
};

const wrapClass: Record<TextWrap, string | undefined> = {
  normal: undefined,
  balance: styles.balance,
  pretty: styles.pretty,
};

export function Text<T extends ElementType = 'p'>({
  as,
  variant = 'bodyMd',
  tone = 'default',
  wrap = 'normal',
  tabular = false,
  className,
  ...props
}: TextProps<T>) {
  const Component = as ?? 'p';
  const classes = [
    styles.text,
    variantClass[variant],
    toneClass[tone],
    wrapClass[wrap],
    tabular ? styles.tabular : undefined,
    className,
  ]
    .filter(Boolean)
    .join(' ');

  return <Component className={classes} {...props} />;
}
