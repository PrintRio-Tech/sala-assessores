import type { Meta, StoryObj } from '@storybook/react-vite';

import { ICONS } from '../../assets/icons';
import { Icon } from '../Icon';
import { TextInput } from './TextInput';

const meta = {
  title: 'Forms/TextInput',
  component: TextInput,
  tags: ['autodocs'],
  args: {
    label: 'Nome completo',
    name: 'fullName',
    placeholder: 'Maria Silva',
    size: 'md',
    labelSize: 'md',
    required: false,
    disabled: false,
  },
  argTypes: {
    size: {
      control: 'select',
      options: ['md', 'sm'],
    },
    labelSize: {
      control: 'select',
      options: ['md', 'sm'],
    },
    type: {
      control: 'select',
      options: ['text', 'email', 'password', 'tel', 'url', 'search'],
    },
  },
} satisfies Meta<typeof TextInput>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const Required: Story = {
  args: { required: true },
};

export const WithDescription: Story = {
  args: {
    description: 'Como aparece no comprovante.',
  },
};

export const Error: Story = {
  args: {
    error: 'Campo obrigatório.',
    defaultValue: '',
  },
};

export const Small: Story = {
  args: { size: 'sm', labelSize: 'sm' },
};

export const Disabled: Story = {
  args: {
    disabled: true,
    defaultValue: 'Valor bloqueado',
  },
};

export const Password: Story = {
  args: {
    label: 'Senha',
    name: 'password',
    type: 'password',
    placeholder: '••••••••',
  },
};

export const LabelHidden: Story = {
  args: {
    labelHidden: true,
    placeholder: 'Buscar…',
  },
};

export const WithLeadingIcon: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'Ícone à esquerda (busca). O raio permanece `$radius-md` — o mesmo dos botões; não é pill.',
      },
    },
  },
  args: {
    label: 'Buscar cliente ou usuário',
    labelHidden: true,
    name: 'q',
    type: 'search',
    placeholder: 'Buscar cliente ou usuário',
    leadingIcon: <Icon src={ICONS.ui.search} size={16} />,
  },
};
