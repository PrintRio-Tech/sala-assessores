import { readFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';
import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { Button } from '../Button/Button';
import { SelectField } from '../SelectField/SelectField';
import { TextInput } from './TextInput';

const here = dirname(fileURLToPath(import.meta.url));

describe('TextInput', () => {
  it('passa name ao FormField (Field.Root) e ao input nativo', () => {
    render(<TextInput label="Nome" name="fullName" />);

    const input = screen.getByLabelText('Nome');
    expect(input).toBeInstanceOf(HTMLInputElement);
    expect(input).toHaveAttribute('name', 'fullName');
    // Field.Root envolve o controle quando name é passado ao FormField
    expect(input.parentElement?.tagName).toBe('DIV');
  });

  it('mantém input nativo (sem role textbox custom)', () => {
    render(<TextInput label="E-mail" name="email" type="email" />);

    const input = screen.getByLabelText('E-mail');
    expect(input).toBeInstanceOf(HTMLInputElement);
    expect(input).toHaveAttribute('type', 'email');
  });

  it('alinha md/sm ao form-control do SelectField (min-height + surface-bright)', () => {
    render(
      <>
        <TextInput label="Busca" name="search" />
        <TextInput label="Busca sm" name="searchSm" size="sm" />
        <SelectField
          label="Filtro"
          name="filter"
          options={[{ value: 'a', label: 'A' }]}
          value="a"
          onValueChange={() => {}}
        />
        <SelectField
          label="Filtro sm"
          name="filterSm"
          size="sm"
          options={[{ value: 'a', label: 'A' }]}
          value="a"
          onValueChange={() => {}}
        />
      </>,
    );

    const textMd = screen.getByLabelText('Busca');
    const textSm = screen.getByLabelText('Busca sm');
    const selectMd = screen.getByLabelText('Filtro');
    const selectSm = screen.getByLabelText('Filtro sm');

    const textMdStyle = getComputedStyle(textMd);
    const selectMdStyle = getComputedStyle(selectMd);
    const textSmStyle = getComputedStyle(textSm);
    const selectSmStyle = getComputedStyle(selectSm);

    expect(textMdStyle.minHeight).toBe(selectMdStyle.minHeight);
    expect(textMdStyle.backgroundColor).toBe(selectMdStyle.backgroundColor);
    expect(textMdStyle.borderRadius).toBe(selectMdStyle.borderRadius);
    expect(textSmStyle.minHeight).toBe(selectSmStyle.minHeight);
    expect(textSmStyle.minHeight).not.toBe(textMdStyle.minHeight);
  });

  it('raio do input coincide com o do botão ($radius-md) e leadingIcon não vira pill', () => {
    render(
      <>
        <Button type="button">Salvar</Button>
        <TextInput label="Nome" name="fullName" />
        <TextInput
          label="Busca"
          name="q"
          leadingIcon={<span data-testid="lupa">⌕</span>}
        />
      </>,
    );

    const button = screen.getByRole('button', { name: 'Salvar' });
    const input = screen.getByLabelText('Nome');
    const search = screen.getByLabelText('Busca');

    expect(getComputedStyle(input).borderRadius).toBe(
      getComputedStyle(button).borderRadius,
    );
    expect(getComputedStyle(search).borderRadius).toBe(
      getComputedStyle(input).borderRadius,
    );
    expect(getComputedStyle(search).borderRadius).not.toBe('9999px');
  });

  it('leadingIcon opcional não quebra o label e marca o ícone como aria-hidden', () => {
    render(
      <TextInput
        label="Buscar cliente ou usuário"
        labelHidden
        name="q"
        size="sm"
        placeholder="Buscar cliente ou usuário"
        leadingIcon={<span data-testid="lupa">⌕</span>}
      />,
    );

    const input = screen.getByLabelText('Buscar cliente ou usuário');
    expect(input).toBeInstanceOf(HTMLInputElement);
    expect(input).toHaveAttribute('placeholder', 'Buscar cliente ou usuário');
    expect(screen.getByTestId('lupa')).toBeInTheDocument();
    expect(screen.getByTestId('lupa').parentElement).toHaveAttribute(
      'aria-hidden',
      'true',
    );
  });

  it('type=search remove chrome nativo (appearance + webkit search buttons)', () => {
    const scss = readFileSync(join(here, 'styles.module.scss'), 'utf8');

    expect(scss).toMatch(/appearance:\s*none/);
    expect(scss).toMatch(/&\[type='search'\]/);
    expect(scss).toMatch(/::-webkit-search-cancel-button/);
  });
});
