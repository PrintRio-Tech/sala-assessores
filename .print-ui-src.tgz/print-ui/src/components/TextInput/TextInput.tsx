import { useId, type InputHTMLAttributes, type ReactNode } from 'react';

import { FormField } from '../FormField/FormField';

import styles from './styles.module.scss';

export type TextInputProps = {
  label: string;
  labelHidden?: boolean;
  labelSize?: 'md' | 'sm';
  required?: boolean;
  description?: string;
  error?: string;
  name: string;
  size?: 'md' | 'sm';
  /** Ícone à esquerda do campo (ex.: lupa). Sem SearchBar paralelo. */
  leadingIcon?: ReactNode;
} & Omit<InputHTMLAttributes<HTMLInputElement>, 'name' | 'size'>;

export function TextInput({
  label,
  labelHidden = false,
  labelSize = 'md',
  required = false,
  description,
  error,
  name,
  size = 'md',
  leadingIcon,
  className,
  id,
  ...props
}: TextInputProps) {
  const autoId = useId();
  const inputId = id ?? autoId;
  const hasLeading = leadingIcon != null;

  const input = (
    <input
      id={inputId}
      name={name}
      className={[
        styles.input,
        size === 'sm' ? styles.inputSm : undefined,
        hasLeading ? styles.inputWithLeading : undefined,
        className,
      ]
        .filter(Boolean)
        .join(' ')}
      aria-invalid={error ? true : undefined}
      {...props}
    />
  );

  return (
    <FormField
      label={label}
      labelHidden={labelHidden}
      labelSize={labelSize}
      required={required}
      description={description}
      error={error}
      htmlFor={inputId}
      name={name}
    >
      {hasLeading ? (
        <div
          className={[
            styles.control,
            size === 'sm' ? styles.controlSm : undefined,
          ]
            .filter(Boolean)
            .join(' ')}
        >
          <span className={styles.leadingIcon} aria-hidden="true">
            {leadingIcon}
          </span>
          {input}
        </div>
      ) : (
        input
      )}
    </FormField>
  );
}
