import type { Meta, StoryObj } from '@storybook/react-vite';

import { Textarea } from './Textarea';

const meta = {
  title: 'Forms/Textarea',
  component: Textarea,
  tags: ['autodocs'],
  args: {
    label: 'Observações',
    name: 'notes',
    placeholder: 'Descreva o contexto…',
    required: false,
    disabled: false,
  },
} satisfies Meta<typeof Textarea>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const Required: Story = {
  args: { required: true },
};

export const WithDescription: Story = {
  args: {
    description: 'Aparece no relatório e no e-mail de confirmação.',
  },
};

export const Error: Story = {
  args: {
    error: 'Campo obrigatório.',
    defaultValue: '',
  },
};

export const Disabled: Story = {
  args: { disabled: true, defaultValue: 'Texto bloqueado.' },
};
