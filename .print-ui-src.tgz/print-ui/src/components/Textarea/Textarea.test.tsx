import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { Textarea } from './Textarea';

describe('Textarea', () => {
  it('renderiza label e textarea', () => {
    render(<Textarea label="Notas" name="notes" />);

    expect(screen.getByLabelText('Notas')).toBeInTheDocument();
    expect(screen.getByRole('textbox')).toHaveAttribute('name', 'notes');
  });

  it('marca aria-invalid quando há erro', () => {
    render(<Textarea label="Notas" error="Obrigatório" />);

    expect(screen.getByRole('textbox')).toHaveAttribute('aria-invalid', 'true');
    expect(screen.getByRole('alert')).toHaveTextContent('Obrigatório');
  });

  it('usa autoComplete off por padrão', () => {
    render(<Textarea label="Notas" />);

    expect(screen.getByRole('textbox')).toHaveAttribute('autocomplete', 'off');
  });
});
