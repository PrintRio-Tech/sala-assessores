import { useId, type ComponentProps } from 'react';

import { FormField } from '../FormField/FormField';

import styles from './styles.module.scss';

export type TextareaProps = {
  label: string;
  required?: boolean;
  description?: string;
  error?: string;
  name?: string;
} & Omit<ComponentProps<'textarea'>, 'name'>;

export function Textarea({
  label,
  required = false,
  description,
  error,
  name,
  className,
  placeholder,
  autoComplete = 'off',
  id,
  ...props
}: TextareaProps) {
  const autoId = useId();
  const textareaId = id ?? autoId;

  return (
    <FormField
      label={label}
      required={required}
      description={description}
      error={error}
      htmlFor={textareaId}
    >
      <textarea
        id={textareaId}
        name={name}
        className={[styles.textarea, className].filter(Boolean).join(' ')}
        placeholder={placeholder}
        autoComplete={autoComplete}
        aria-invalid={error ? true : undefined}
        {...props}
      />
    </FormField>
  );
}
