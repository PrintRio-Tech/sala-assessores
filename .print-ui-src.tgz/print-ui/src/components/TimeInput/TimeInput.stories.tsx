import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState, type ComponentProps } from 'react';

import { TimeInput } from './TimeInput';

const meta = {
  title: 'Forms/TimeInput',
  component: TimeInput,
  tags: ['autodocs'],
  args: {
    label: 'Horário',
    name: 'time',
    size: 'md',
    labelSize: 'md',
    required: false,
    disabled: false,
    placeholder: '00:00',
  },
  argTypes: {
    size: { control: 'select', options: ['md', 'sm'] },
    labelSize: { control: 'select', options: ['md', 'sm'] },
  },
} satisfies Meta<typeof TimeInput>;

export default meta;
type Story = StoryObj<typeof meta>;

function Controlled(props: ComponentProps<typeof TimeInput>) {
  const [value, setValue] = useState(props.value ?? '');
  return (
    <TimeInput {...props} value={value} onValueChange={setValue} />
  );
}

export const Default: Story = {
  render: (args) => <Controlled {...args} />,
};

export const Small: Story = {
  args: { size: 'sm', labelSize: 'sm' },
  render: (args) => <Controlled {...args} />,
};

export const Error: Story = {
  args: { error: 'Horário inválido.', value: '25:00' },
  render: (args) => <Controlled {...args} />,
};

export const Disabled: Story = {
  args: { disabled: true, value: '09:30' },
  render: (args) => <Controlled {...args} />,
};
