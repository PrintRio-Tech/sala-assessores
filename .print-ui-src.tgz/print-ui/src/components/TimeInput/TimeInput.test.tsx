import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';

import { TimeInput } from './TimeInput';

describe('TimeInput', () => {
  it('aplica máscara ao digitar', () => {
    const onValueChange = vi.fn();

    render(
      <TimeInput label="Horário" name="time" value="" onValueChange={onValueChange} />,
    );

    fireEvent.change(screen.getByLabelText('Horário'), {
      target: { value: '0930' },
    });

    expect(onValueChange).toHaveBeenCalledWith('09:30');
  });

  it('mostra erro interno ao sair com valor incompleto', () => {
    render(<TimeInput label="Horário" value="09" onValueChange={vi.fn()} />);

    fireEvent.blur(screen.getByLabelText('Horário'));

    expect(screen.getByRole('alert')).toHaveTextContent(
      'Horário incompleto. Use 00:00.',
    );
  });
});
