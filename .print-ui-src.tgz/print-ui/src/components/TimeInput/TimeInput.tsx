import { useId, useState } from 'react';

import { ICONS } from '../../assets/icons';
import { FormField } from '../FormField/FormField';
import { Icon } from '../Icon';

import { isValidTime, maskTimeInput } from './time-utils';
import styles from './styles.module.scss';

export type TimeInputProps = {
  label: string;
  labelSize?: 'md' | 'sm';
  required?: boolean;
  name?: string;
  value?: string;
  onValueChange?: (value: string) => void;
  disabled?: boolean;
  error?: string;
  size?: 'md' | 'sm';
  placeholder?: string;
};

export function TimeInput({
  label,
  labelSize = 'md',
  required = false,
  name,
  value = '',
  onValueChange,
  disabled,
  error,
  size = 'md',
  placeholder = '00:00',
}: TimeInputProps) {
  const inputId = useId();
  const [inputError, setInputError] = useState<string | undefined>();

  const resolvedError = error ?? inputError;

  const handleChange = (raw: string) => {
    const masked = maskTimeInput(raw);
    setInputError(undefined);
    onValueChange?.(masked);

    if (masked.length === 5 && !isValidTime(masked)) {
      setInputError('Use o formato 00:00.');
    }
  };

  const handleBlur = () => {
    if (!value) return;

    if (value.length < 5) {
      setInputError('Horário incompleto. Use 00:00.');
      return;
    }

    if (!isValidTime(value)) {
      setInputError('Horário inválido.');
    }
  };

  return (
    <FormField
      label={label}
      labelSize={labelSize}
      required={required}
      error={resolvedError}
      htmlFor={inputId}
    >
      <div
        className={[styles.inputRow, size === 'sm' ? styles.inputRowSm : '']
          .filter(Boolean)
          .join(' ')}
      >
        <input
          id={inputId}
          name={name}
          type="text"
          inputMode="numeric"
          autoComplete="off"
          spellCheck={false}
          className={[styles.input, size === 'sm' ? styles.inputSm : '']
            .filter(Boolean)
            .join(' ')}
          placeholder={placeholder}
          value={value}
          disabled={disabled}
          aria-invalid={resolvedError ? true : undefined}
          onChange={(event) => handleChange(event.target.value)}
          onBlur={handleBlur}
        />

        <span
          className={[styles.adornment, size === 'sm' ? styles.adornmentSm : '']
            .filter(Boolean)
            .join(' ')}
          aria-hidden="true"
        >
          <Icon
            src={ICONS.datePicker.clock}
            className={styles.icon}
            size={18}
          />
        </span>
      </div>
    </FormField>
  );
}
