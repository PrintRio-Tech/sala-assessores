import { describe, expect, it } from 'vitest';

import { isValidTime, maskTimeInput } from './time-utils';

describe('maskTimeInput', () => {
  it('mantém só dígitos e formata HH:mm', () => {
    expect(maskTimeInput('1')).toBe('1');
    expect(maskTimeInput('12')).toBe('12');
    expect(maskTimeInput('123')).toBe('12:3');
    expect(maskTimeInput('1234')).toBe('12:34');
    expect(maskTimeInput('12:34')).toBe('12:34');
    expect(maskTimeInput('abc12x3y4z9')).toBe('12:34');
  });
});

describe('isValidTime', () => {
  it('valida faixa 00–23 / 00–59', () => {
    expect(isValidTime('00:00')).toBe(true);
    expect(isValidTime('23:59')).toBe(true);
    expect(isValidTime('09:30')).toBe(true);
    expect(isValidTime('24:00')).toBe(false);
    expect(isValidTime('12:60')).toBe(false);
    expect(isValidTime('1:30')).toBe(false);
    expect(isValidTime('')).toBe(false);
  });
});
