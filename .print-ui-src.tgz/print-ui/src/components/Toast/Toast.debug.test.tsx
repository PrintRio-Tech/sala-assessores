import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it } from 'vitest';
import { Toaster } from './Toaster';
import { useToast } from './useToast';

function Probe() {
  const toast = useToast();
  return (
    <button
      type="button"
      onClick={() =>
        toast.show({
          title: 'OTP falhou',
          description: 'Authentication required',
          variant: 'error',
          priority: 'high',
          timeout: 5000,
        })
      }
    >
      Go
    </button>
  );
}

describe('debug', () => {
  it('shows high priority toast', async () => {
    const user = userEvent.setup();
    render(
      <Toaster>
        <Probe />
      </Toaster>,
    );
    await user.click(screen.getByRole('button', { name: 'Go' }));
    // eslint-disable-next-line no-console
    console.log('HTML', document.body.innerHTML.slice(0, 1500));
    expect(document.body.innerHTML).toContain('OTP falhou');
  });
});
