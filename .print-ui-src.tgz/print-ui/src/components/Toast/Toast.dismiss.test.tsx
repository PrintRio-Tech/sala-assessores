import { act, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it } from 'vitest';

import { Toaster } from './Toaster';
import { useToast } from './useToast';

const DISMISS_MS = 200;

function ToastProbe() {
  const toast = useToast();

  return (
    <button
      type="button"
      onClick={() =>
        toast.show({
          title: 'Salvo',
          description: 'Registro atualizado',
          variant: 'success',
          timeout: DISMISS_MS,
        })
      }
    >
      Disparar
    </button>
  );
}

function ErrorProbe() {
  const toast = useToast();

  return (
    <button
      type="button"
      onClick={() =>
        toast.show({
          title: 'Falhou',
          description: 'Não foi possível salvar',
          variant: 'error',
          timeout: DISMISS_MS,
        })
      }
    >
      Disparar erro
    </button>
  );
}

describe('Toast auto-dismiss', () => {
  it('fecha sozinho ~timeout mesmo com window blur (portal sem foco)', async () => {
    const user = userEvent.setup();

    render(
      <Toaster>
        <ToastProbe />
      </Toaster>,
    );

    await user.click(screen.getByRole('button', { name: 'Disparar' }));
    expect(
      await screen.findByRole('heading', { name: 'Salvo' }),
    ).toBeInTheDocument();

    // Base UI: blur pausa o timer e, sem focus posterior, nunca retoma.
    act(() => {
      window.dispatchEvent(new Event('blur'));
    });

    await waitFor(
      () => {
        expect(
          screen.queryByRole('heading', { name: 'Salvo' }),
        ).not.toBeInTheDocument();
      },
      { timeout: DISMISS_MS + 1500 },
    );

    expect(
      document.querySelector('[data-variant], [data-ending-style]'),
    ).toBeNull();
  });

  it('pausa em hover no viewport e retoma ao sair', async () => {
    const user = userEvent.setup();

    render(
      <Toaster>
        <ErrorProbe />
      </Toaster>,
    );

    await user.click(screen.getByRole('button', { name: 'Disparar erro' }));
    const heading = await screen.findByRole('heading', { name: 'Falhou' });
    expect(heading).toBeInTheDocument();

    const viewport = document.querySelector('[class*="viewport"]');
    expect(viewport).toBeTruthy();

    await user.hover(viewport!);

    await act(async () => {
      // Ainda abaixo do hard-cap (2× timeout).
      await new Promise((resolve) => setTimeout(resolve, DISMISS_MS + 80));
    });
    expect(screen.getByRole('heading', { name: 'Falhou' })).toBeInTheDocument();

    await user.unhover(viewport!);

    await waitFor(
      () => {
        expect(
          screen.queryByRole('heading', { name: 'Falhou' }),
        ).not.toBeInTheDocument();
      },
      { timeout: DISMISS_MS + 1500 },
    );
  });
});
