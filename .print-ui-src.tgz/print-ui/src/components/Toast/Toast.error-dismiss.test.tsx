import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';

import { Toaster } from './Toaster';
import { useToast } from './useToast';

const DISMISS_MS = 200;

function TimedHighPriorityErrorProbe({ label = 'OTP erro' }: { label?: string }) {
  const toast = useToast();

  return (
    <button
      type="button"
      onClick={() =>
        toast.show({
          title: 'OTP falhou',
          description: 'Authentication required',
          variant: 'error',
          priority: 'high',
          timeout: DISMISS_MS,
        })
      }
    >
      {label}
    </button>
  );
}

function ErrorApiProbe() {
  const toast = useToast();

  return (
    <button
      type="button"
      onClick={() =>
        toast.show({
          title: 'Auth',
          description: 'Authentication required',
          variant: 'error',
          priority: 'high',
          timeout: DISMISS_MS,
        })
      }
    >
      Erro API
    </button>
  );
}

describe('Toast error autodismiss (ADM OTP / priority high)', () => {
  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('toast.error() path (priority high) remove alertdialog+alert após hard-cap sob hover eterno', async () => {
    const user = userEvent.setup();

    render(
      <Toaster>
        <TimedHighPriorityErrorProbe />
      </Toaster>,
    );

    await user.click(screen.getByRole('button', { name: 'OTP erro' }));
    await waitFor(() => {
      expect(document.querySelector('[role="alertdialog"]')).toBeTruthy();
    });
    expect(document.body.textContent).toContain('OTP falhou');

    const viewport = document.querySelector('[class*="viewport"]');
    expect(viewport).toBeTruthy();
    await user.hover(viewport!);

    await waitFor(
      () => {
        expect(document.querySelector('[role="alertdialog"]')).toBeNull();
        expect(document.querySelector('[role="alert"]')).toBeNull();
        expect(
          document.querySelector('[data-variant], [data-ending-style]'),
        ).toBeNull();
      },
      { timeout: DISMISS_MS * 2 + 2000 },
    );
  });

  it('remove residual mesmo com WAAPI stuck (anim.finished nunca resolve)', async () => {
    const user = userEvent.setup();
    const originalGetAnimations = Element.prototype.getAnimations;
    const stuck = {
      playState: 'running' as const,
      currentTime: 120,
      // finished nunca resolve — Base UI sozinho não remove; Toaster força remove().
      finished: new Promise<void>(() => {
        /* pending forever */
      }),
      finish: vi.fn(),
      cancel: vi.fn(),
    };
    Element.prototype.getAnimations = function getAnimations(
      this: Element,
      ...args: Parameters<Element['getAnimations']>
    ) {
      if (this.hasAttribute?.('data-ending-style')) {
        return [stuck as unknown as Animation];
      }
      return originalGetAnimations?.apply(this, args) ?? [];
    };

    try {
      render(
        <Toaster>
          <TimedHighPriorityErrorProbe />
        </Toaster>,
      );

      await user.click(screen.getByRole('button', { name: 'OTP erro' }));
      await waitFor(() => {
        expect(document.querySelector('[role="alertdialog"]')).toBeTruthy();
      });
      expect(document.body.textContent).toContain('OTP falhou');

      await waitFor(
        () => {
          expect(document.querySelector('[role="alertdialog"]')).toBeNull();
          expect(document.querySelector('[role="alert"]')).toBeNull();
          expect(
            document.querySelector('[data-variant], [data-ending-style]'),
          ).toBeNull();
        },
        { timeout: DISMISS_MS * 2 + 2500 },
      );
    } finally {
      Element.prototype.getAnimations = originalGetAnimations;
    }
  });

  it('não acumula alertdialog/alert após várias tentativas OTP', async () => {
    const user = userEvent.setup();

    render(
      <Toaster>
        <ErrorApiProbe />
      </Toaster>,
    );

    for (let i = 0; i < 5; i += 1) {
      await user.click(screen.getByRole('button', { name: 'Erro API' }));
    }

    await waitFor(
      () => {
        expect(document.querySelectorAll('[role="alertdialog"]').length).toBe(
          0,
        );
        expect(document.querySelectorAll('[role="alert"]').length).toBe(0);
        expect(
          document.querySelector('[data-variant], [data-ending-style]'),
        ).toBeNull();
      },
      { timeout: DISMISS_MS * 2 + 3000 },
    );
  });
});
