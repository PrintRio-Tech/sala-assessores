import { StrictMode } from 'react';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';

import { Toaster } from './Toaster';
import { useToast } from './useToast';

function ToastProbe() {
  const toast = useToast();

  return (
    <button
      type="button"
      onClick={() => toast.success('Salvo', 'Registro atualizado')}
    >
      Disparar
    </button>
  );
}

function isFlushSyncLifecycleWarning(...args: unknown[]) {
  return args.some(
    (arg) =>
      typeof arg === 'string' &&
      arg.includes('flushSync was called from inside a lifecycle method'),
  );
}

describe('Toast flushSync lifecycle', () => {
  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('não emite warning de flushSync ao abrir um toast (incl. StrictMode)', async () => {
    const user = userEvent.setup();
    const consoleError = vi.spyOn(console, 'error').mockImplementation(() => {});

    render(
      <StrictMode>
        <Toaster>
          <ToastProbe />
        </Toaster>
      </StrictMode>,
    );

    await user.click(screen.getByRole('button', { name: 'Disparar' }));
    expect(await screen.findByText('Salvo')).toBeInTheDocument();
    expect(screen.getByText('Registro atualizado')).toBeInTheDocument();

    const flushSyncWarnings = consoleError.mock.calls.filter((call) =>
      isFlushSyncLifecycleWarning(...call),
    );
    expect(flushSyncWarnings).toHaveLength(0);
  });
});
