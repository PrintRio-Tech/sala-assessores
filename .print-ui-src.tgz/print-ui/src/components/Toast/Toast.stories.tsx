import type { Meta, StoryObj } from '@storybook/react-vite';

import { Button } from '../Button/Button';

import { useToast } from './useToast';

function ToastTriggers() {
  const toast = useToast();

  return (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
      <Button
        type="button"
        variant="primary"
        onClick={() => toast.success('Salvo', 'Registro atualizado com sucesso.')}
      >
        Success
      </Button>
      <Button
        type="button"
        variant="danger"
        onClick={() => toast.error('Falha', 'Não foi possível concluir a operação.')}
      >
        Error
      </Button>
      <Button
        type="button"
        variant="secondary"
        onClick={() => toast.warning('Atenção', 'Verifique os dados antes de continuar.')}
      >
        Warning
      </Button>
      <Button
        type="button"
        variant="outline"
        onClick={() => toast.info('Informação', 'Há uma atualização disponível.')}
      >
        Info
      </Button>
    </div>
  );
}

const meta = {
  title: 'Feedback/Toast',
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Toasts são disparados via `useToast`. O `Toaster` já está no decorator global do Storybook.',
      },
    },
  },
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

export const Variants: Story = {
  render: () => <ToastTriggers />,
};
