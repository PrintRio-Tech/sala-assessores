import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { Toaster } from '../Toast/Toaster';
import { useToast } from '../Toast/useToast';

function ToastProbe() {
  const toast = useToast();

  return (
    <button type="button" onClick={() => toast.success('Salvo', 'Registro atualizado')}>
      Disparar
    </button>
  );
}

describe('Toast', () => {
  it('renderiza provider e viewport', () => {
    render(
      <Toaster>
        <ToastProbe />
      </Toaster>,
    );

    expect(screen.getByRole('button', { name: 'Disparar' })).toBeInTheDocument();
  });
});
