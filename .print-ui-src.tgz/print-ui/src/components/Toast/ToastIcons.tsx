import type { ToastVariant } from './useToast';

import { ICONS } from '../../assets/icons';
import { Icon } from '../Icon';

type ToastIconProps = {
  type?: ToastVariant;
};

const TOAST_ICON_SRC: Record<NonNullable<ToastVariant>, string> = {
  success: ICONS.toast.success,
  error: ICONS.toast.error,
  warning: ICONS.toast.warning,
  info: ICONS.toast.info,
  default: ICONS.toast.default,
};

export function ToastIcon({ type = 'default' }: ToastIconProps) {
  return <Icon src={TOAST_ICON_SRC[type]} size={16} />;
}
