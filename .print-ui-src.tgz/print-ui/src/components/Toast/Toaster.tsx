/**
 * Toast stack uses `@base-ui/react`.
 *
 * Auto-dismiss próprio (~5s, pausa em hover, hard-cap 2×): Base UI pausa em
 * window blur (portal/WebView). Não usamos Toast.Content — ResizeObserver
 * zera `transitionStatus: "ending"` e impede close limpo.
 *
 * Arquitetura pública: `Toast.createToastManager()` no Toaster → mesmo manager
 * no Provider e no `useToast` (sem deep import de context privado).
 * `BASE_UI_ANIMATIONS_DISABLED` no mount: close → remove síncrono (anti-residual
 * alertdialog/alert quando WAAPI prende anim.finished).
 */
import { Toast, type ToastManager } from '@base-ui/react/toast';
import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from 'react';

import { PrintToastManagerContext } from './printToastManagerContext';
import { ToastDismissScheduler } from './toastDismissScheduler';
import { ToastIcon } from './ToastIcons';
import styles from './styles.module.scss';
import type { ToastVariant } from './useToast';

const DEFAULT_TIMEOUT_MS = 5000;
const TICK_MS = 250;

function finishToastExitAnimations() {
  if (typeof document === 'undefined') return;
  document
    .querySelectorAll('[data-ending-style], [data-variant]')
    .forEach((element) => {
      element.getAnimations?.().forEach((animation) => {
        try {
          animation.finish();
        } catch {
          try {
            animation.cancel();
          } catch {
            // ignore
          }
        }
      });
    });
}

function ToastList({ manager }: { manager: ToastManager }) {
  const { toasts } = Toast.useToastManager();
  const pausedRef = useRef(false);
  const schedulerRef = useRef(new ToastDismissScheduler());
  const [, setPaused] = useState(false);

  const dismiss = useCallback(
    (id: string) => {
      schedulerRef.current.release(id);
      manager.close(id);
      finishToastExitAnimations();
    },
    [manager],
  );

  useEffect(() => {
    const scheduler = schedulerRef.current;
    const liveIds = new Set(toasts.map((toast) => toast.id));
    scheduler.sync(liveIds);

    const now = Date.now();
    for (const toast of toasts) {
      if (toast.transitionStatus === 'ending' || toast.type === 'loading') {
        continue;
      }
      const timeout =
        typeof toast.timeout === 'number' ? toast.timeout : DEFAULT_TIMEOUT_MS;
      if (timeout <= 0) continue;
      scheduler.track(toast.id, timeout, now);
    }

    const tick = () => {
      const due = scheduler.dueIds(Date.now(), pausedRef.current);
      for (const id of due) {
        dismiss(id);
      }
      finishToastExitAnimations();
    };

    const intervalId = window.setInterval(tick, TICK_MS);
    const wake = (event?: Event) => {
      if (event?.type === 'pointerdown') {
        const target = event.target;
        const viewport = document.querySelector('[class*="viewport"]');
        if (
          viewport &&
          target instanceof Node &&
          !viewport.contains(target)
        ) {
          pausedRef.current = false;
        }
      }
      if (event?.type === 'visibilitychange' || event?.type === 'focus') {
        pausedRef.current = false;
      }
      tick();
    };

    document.addEventListener('visibilitychange', wake);
    window.addEventListener('focus', wake);
    document.addEventListener('pointerdown', wake, true);
    tick();

    return () => {
      window.clearInterval(intervalId);
      document.removeEventListener('visibilitychange', wake);
      window.removeEventListener('focus', wake);
      document.removeEventListener('pointerdown', wake, true);
    };
  }, [toasts, dismiss]);

  const setViewportPaused = (value: boolean) => {
    pausedRef.current = value;
    setPaused(value);
  };

  return (
    <Toast.Viewport
      className={styles.viewport}
      onMouseEnter={() => setViewportPaused(true)}
      onMouseLeave={() => setViewportPaused(false)}
      onPointerEnter={() => setViewportPaused(true)}
      onPointerLeave={() => setViewportPaused(false)}
    >
      {toasts.map((toast) => {
        const type = (toast.type ?? 'default') as ToastVariant;

        return (
          <Toast.Root
            key={toast.id}
            toast={toast}
            className={styles.toast}
            data-variant={type}
          >
            <div className={styles.content}>
              <span className={styles.icon} data-variant={type}>
                <ToastIcon type={type} />
              </span>
              <div className={styles.text}>
                <Toast.Title className={styles.title} />
                <Toast.Description className={styles.description} />
              </div>
              <button
                type="button"
                className={styles.close}
                aria-label="Fechar notificação"
                onClick={() => dismiss(toast.id)}
              >
                ×
              </button>
            </div>
          </Toast.Root>
        );
      })}
    </Toast.Viewport>
  );
}

export type ToasterProps = {
  children: ReactNode;
};

export function Toaster({ children }: ToasterProps) {
  const managerRef = useRef<ToastManager | null>(null);
  if (managerRef.current == null) {
    managerRef.current = Toast.createToastManager();
  }
  const manager = managerRef.current;

  // Contrato público Base UI: sem esperar anim.finished (WAAPI preso = residual eterno).
  useEffect(() => {
    const globalScope = globalThis as typeof globalThis & {
      BASE_UI_ANIMATIONS_DISABLED?: boolean;
    };
    const previous = globalScope.BASE_UI_ANIMATIONS_DISABLED;
    globalScope.BASE_UI_ANIMATIONS_DISABLED = true;
    return () => {
      globalScope.BASE_UI_ANIMATIONS_DISABLED = previous;
    };
  }, []);

  return (
    <PrintToastManagerContext.Provider value={manager}>
      <Toast.Provider
        limit={3}
        timeout={DEFAULT_TIMEOUT_MS}
        toastManager={manager}
      >
        {children}
        {/* Sem Portal: Viewport já é fixed; Portal podia duplicar context. */}
        <ToastList manager={manager} />
      </Toast.Provider>
    </PrintToastManagerContext.Provider>
  );
}
