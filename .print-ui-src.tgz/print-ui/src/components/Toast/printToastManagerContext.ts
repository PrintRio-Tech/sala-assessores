import { createContext, useContext } from 'react';

import type { ToastManager } from '@base-ui/react/toast';

/** Manager canônico do `<Toaster />` — mesmo add/close do Provider. */
export const PrintToastManagerContext = createContext<ToastManager | null>(
  null,
);

export function usePrintToastManager() {
  return useContext(PrintToastManagerContext);
}
