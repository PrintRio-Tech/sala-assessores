import { describe, expect, it } from 'vitest';

import { ToastDismissScheduler } from './toastDismissScheduler';

describe('ToastDismissScheduler', () => {
  it('agenda dismiss após timeout e ignora enquanto paused (hover/foco)', () => {
    const scheduler = new ToastDismissScheduler();
    scheduler.track('toast-1', 5000, 0);

    expect(scheduler.dueIds(4999, false)).toEqual([]);
    expect(scheduler.dueIds(5000, false)).toEqual(['toast-1']);
    expect(scheduler.dueIds(8000, true)).toEqual([]);
  });

  it('hard-cap em 2× timeout mesmo paused (anti-toast eterno)', () => {
    const scheduler = new ToastDismissScheduler();
    scheduler.track('toast-1', 5000, 0);
    expect(scheduler.dueIds(9999, true)).toEqual([]);
    expect(scheduler.dueIds(10_000, true)).toEqual(['toast-1']);
  });

  it('não reagenda o mesmo id e esquece após release', () => {
    const scheduler = new ToastDismissScheduler();
    scheduler.track('toast-1', 1000, 0);
    scheduler.track('toast-1', 9999, 0);
    expect(scheduler.dueIds(1000, false)).toEqual(['toast-1']);

    scheduler.release('toast-1');
    expect(scheduler.dueIds(10_000, false)).toEqual([]);
  });

  it('ignora timeout <= 0 (loading / sticky)', () => {
    const scheduler = new ToastDismissScheduler();
    scheduler.track('sticky', 0, 0);
    expect(scheduler.dueIds(10_000, false)).toEqual([]);
  });
});
