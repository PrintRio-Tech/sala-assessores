type TrackedToast = {
  startedAt: number;
  timeout: number;
};

/**
 * Dismiss confiável fora do timer do Base UI Toast.
 * O Provider pausa em window blur / visibility e, em portal/WebView,
 * pode nunca retomar — toast fica no DOM para sempre.
 */
export class ToastDismissScheduler {
  private readonly entries = new Map<string, TrackedToast>();

  track(id: string, timeout: number, now: number): void {
    if (this.entries.has(id)) return;
    this.entries.set(id, { startedAt: now, timeout });
  }

  release(id: string): void {
    this.entries.delete(id);
  }

  /** Remove ids that left the live stack (closed / limited). */
  sync(liveIds: ReadonlySet<string>): void {
    for (const id of this.entries.keys()) {
      if (!liveIds.has(id)) this.entries.delete(id);
    }
  }

  dueIds(now: number, paused: boolean): string[] {
    const due: string[] = [];
    for (const [id, entry] of this.entries) {
      if (entry.timeout <= 0) continue;
      const elapsed = now - entry.startedAt;
      // Hard cap: mesmo em hover/foco, não prende o toast para sempre.
      if (elapsed >= entry.timeout * 2) {
        due.push(id);
        continue;
      }
      if (!paused && elapsed >= entry.timeout) due.push(id);
    }
    return due;
  }
}
