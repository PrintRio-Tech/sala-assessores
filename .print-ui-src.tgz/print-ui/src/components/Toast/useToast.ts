import { Toast } from '@base-ui/react/toast';

import { usePrintToastManager } from './printToastManagerContext';

export type ToastVariant = 'default' | 'success' | 'error' | 'warning' | 'info';

export type ShowToastOptions = {
  title: string;
  description?: string;
  variant?: ToastVariant;
  timeout?: number;
  priority?: 'low' | 'high';
};

export function useToast() {
  const printManager = usePrintToastManager();
  const hookManager = Toast.useToastManager();
  // Prefer manager canônico do <Toaster /> (createToastManager).
  const add = printManager?.add ?? hookManager.add;
  const close = printManager?.close ?? hookManager.close;
  const promise = printManager?.promise ?? hookManager.promise;

  const show = ({
    title,
    description,
    variant = 'default',
    timeout,
    priority,
  }: ShowToastOptions) =>
    add({
      title,
      description,
      type: variant === 'default' ? undefined : variant,
      timeout,
      priority,
    });

  return {
    show,
    success: (title: string, description?: string) =>
      show({ title, description, variant: 'success' }),
    error: (title: string, description?: string) =>
      show({ title, description, variant: 'error', priority: 'high' }),
    warning: (title: string, description?: string) =>
      show({ title, description, variant: 'warning' }),
    info: (title: string, description?: string) =>
      show({ title, description, variant: 'info' }),
    promise,
    dismiss: close,
  };
}
