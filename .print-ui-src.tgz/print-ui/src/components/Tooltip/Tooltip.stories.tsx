import type { Meta, StoryObj } from '@storybook/react-vite';

import { Button } from '../Button/Button';

import { Tooltip } from './Tooltip';

const meta = {
  title: 'Feedback/Tooltip',
  component: Tooltip,
  tags: ['autodocs'],
  args: {
    content: 'Dica útil sobre esta ação',
    sideOffset: 6,
    children: <Button type="button">Passe o mouse</Button>,
  },
  argTypes: {
    side: {
      control: 'select',
      options: ['top', 'bottom', 'left', 'right'],
    },
    placement: {
      control: 'select',
      options: ['top', 'bottom', 'left', 'right'],
    },
    children: { control: false },
  },
  render: (args) => (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        minHeight: 160,
      }}
    >
      <Tooltip {...args} />
    </div>
  ),
} satisfies Meta<typeof Tooltip>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Top: Story = {
  args: { side: 'top' },
};

export const Bottom: Story = {
  args: { side: 'bottom' },
};

export const Left: Story = {
  args: { side: 'left' },
};

export const Right: Story = {
  args: { side: 'right' },
};
