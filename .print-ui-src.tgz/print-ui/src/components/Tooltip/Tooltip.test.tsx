import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import type { ComponentProps } from 'react';
import { describe, expect, it } from 'vitest';

import { Tooltip, TooltipProvider } from './Tooltip';

function renderTooltip(props: Partial<ComponentProps<typeof Tooltip>> = {}) {
  return render(
    <TooltipProvider delay={0}>
      <Tooltip content="Dica útil" delay={0} {...props}>
        <button type="button">Ação</button>
      </Tooltip>
    </TooltipProvider>,
  );
}

describe('Tooltip', () => {
  it('renderiza trigger sem tooltip quando disabled', () => {
    renderTooltip({ disabled: true });

    expect(screen.getByRole('button', { name: 'Ação' })).toBeInTheDocument();
    expect(screen.queryByRole('tooltip')).not.toBeInTheDocument();
  });

  it('exibe conteúdo no hover com role tooltip', async () => {
    renderTooltip();

    fireEvent.mouseEnter(screen.getByRole('button', { name: 'Ação' }));

    await waitFor(() => {
      expect(screen.getByRole('tooltip')).toHaveTextContent('Dica útil');
    });
  });

  it('exibe conteúdo no foco com role tooltip', async () => {
    renderTooltip();

    fireEvent.focus(screen.getByRole('button', { name: 'Ação' }));

    await waitFor(() => {
      expect(screen.getByRole('tooltip')).toHaveTextContent('Dica útil');
    });
  });

  it('aceita placement como alias de side', async () => {
    render(
      <TooltipProvider delay={0}>
        <Tooltip content="À direita" placement="right" delay={0}>
          <button type="button">Item</button>
        </Tooltip>
      </TooltipProvider>,
    );

    fireEvent.focus(screen.getByRole('button', { name: 'Item' }));

    await waitFor(() => {
      const tooltip = screen.getByRole('tooltip');
      expect(tooltip).toHaveTextContent('À direita');
      expect(tooltip).toHaveAttribute('data-side', 'right');
    });
  });
});
