import { Tooltip as BaseTooltip } from '@base-ui-components/react/tooltip';
import type { ReactElement, ReactNode } from 'react';

import styles from './styles.module.scss';

export type TooltipProviderProps = BaseTooltip.Provider.Props;

export function TooltipProvider(props: TooltipProviderProps) {
  return <BaseTooltip.Provider {...props} />;
}

export type TooltipPlacement = 'top' | 'bottom' | 'left' | 'right';

export type TooltipProps = {
  content: ReactNode;
  children: ReactElement<Record<string, unknown>>;
  /** Posicionamento do tooltip em relação ao trigger (alias semântico: placement). */
  side?: TooltipPlacement;
  /** Alias de `side` para compatibilidade com APIs que usam `placement`. */
  placement?: TooltipPlacement;
  sideOffset?: number;
  delay?: number;
  closeDelay?: number;
  disabled?: boolean;
};

export function Tooltip({
  content,
  children,
  side,
  placement,
  sideOffset = 6,
  delay = 300,
  closeDelay = 0,
  disabled = false,
}: TooltipProps) {
  const resolvedSide = placement ?? side ?? 'top';

  if (disabled) {
    return children;
  }

  return (
    <BaseTooltip.Root disableHoverablePopup>
      <BaseTooltip.Trigger
        delay={delay}
        closeDelay={closeDelay}
        render={children}
      />
      <BaseTooltip.Portal>
        <BaseTooltip.Positioner
          className={styles.positioner}
          side={resolvedSide}
          sideOffset={sideOffset}
        >
          <BaseTooltip.Popup className={styles.popup} role="tooltip">
            {content}
          </BaseTooltip.Popup>
        </BaseTooltip.Positioner>
      </BaseTooltip.Portal>
    </BaseTooltip.Root>
  );
}
