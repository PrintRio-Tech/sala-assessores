/**
 * Smoke S4 P0 — exports públicos importáveis pelo barrel e renderizáveis.
 * Não cobre visual/layout; só consumibilidade de consumidor (`@print/ui`).
 */
import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import {
  AppShell,
  Avatar,
  Badge,
  Card,
  Chart,
  Checkbox,
  Heading,
  Heatmap,
  Switch,
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
  Text,
  Textarea,
} from './index';
import type { ChartType } from './Chart/Chart';

describe('S4 P0 consumabilidade (barrel público)', () => {
  it('exporta os símbolos P0 como funções/componentes', () => {
    const symbols: Array<[string, unknown]> = [
      ['AppShell', AppShell],
      ['Chart', Chart],
      ['Heatmap', Heatmap],
      ['Checkbox', Checkbox],
      ['Switch', Switch],
      ['Textarea', Textarea],
      ['Tabs', Tabs],
      ['TabsList', TabsList],
      ['TabsTrigger', TabsTrigger],
      ['TabsContent', TabsContent],
      ['Badge', Badge],
      ['Avatar', Avatar],
    ];

    for (const [name, value] of symbols) {
      expect(typeof value, `${name} deve ser função`).toBe('function');
    }
  });

  it('ChartType cobre bar/line/horizontal-bar/donut', () => {
    const allowed: ChartType[] = ['line', 'bar', 'horizontal-bar', 'donut'];
    expect(allowed).toContain('bar');
    expect(allowed).toContain('line');
    expect(allowed).toContain('horizontal-bar');
    expect(allowed).toContain('donut');
  });


  it('renderiza AppShell + Chart + inputs + Tabs + Badge + Avatar sem throw', () => {
    render(
      <AppShell
        logo={<span>Print</span>}
        navItems={[
          {
            id: 'home',
            label: 'Home',
            active: true,
            onClick: () => undefined,
          },
        ]}
        contentWidth="fluid"
      >
        <div>
          <Chart
            type="bar"
            data={[
              { label: 'A', value: 2 },
              { label: 'B', value: 5 },
            ]}
            aria-label="Série P0"
          />
          <Chart
            type="line"
            data={[
              { label: '1', value: 1 },
              { label: '2', value: 3 },
            ]}
            aria-label="Linha P0"
          />
          <Chart
            type="donut"
            data={[
              { label: 'A', value: 60 },
              { label: 'B', value: 40 },
            ]}
            aria-label="Donut P0"
          />
          <Checkbox label="Aceito" />

          <Switch label="Ativo" />
          <Textarea aria-label="Notas" defaultValue="texto" />
          <Tabs defaultValue="a">
            <TabsList>
              <TabsTrigger value="a">A</TabsTrigger>
              <TabsTrigger value="b">B</TabsTrigger>
            </TabsList>
            <TabsContent value="a">Painel A</TabsContent>
          </Tabs>
          <Badge tone="success">sucesso</Badge>
          <Avatar name="Ana Silva" />
        </div>
      </AppShell>,
    );

    expect(screen.getByRole('img', { name: 'Série P0' })).toBeInTheDocument();
    expect(screen.getByRole('img', { name: 'Linha P0' })).toBeInTheDocument();
    expect(screen.getByRole('img', { name: 'Donut P0' })).toBeInTheDocument();
    expect(screen.getByRole('checkbox', { name: 'Aceito' })).toBeInTheDocument();

    expect(screen.getByRole('switch', { name: 'Ativo' })).toBeInTheDocument();
    expect(screen.getByLabelText('Notas')).toBeInTheDocument();
    expect(screen.getByText('Painel A')).toBeInTheDocument();
    expect(screen.getByText('sucesso')).toBeInTheDocument();
    expect(screen.getByRole('img', { name: 'Ana Silva' })).toBeInTheDocument();
  });

  it('Card action: Heading e Text default herdam $on-primary (sem CSS local)', () => {
    render(
      <Card variant="action" data-testid="cta">
        <Heading level={3} variant="sm">
          Nova demanda
        </Heading>
        <Text>Registre o pedido recebido.</Text>
        <Text tone="muted">metadado</Text>
      </Card>,
    );

    const card = screen.getByTestId('cta');
    const heading = screen.getByRole('heading', { name: 'Nova demanda' });
    const body = screen.getByText('Registre o pedido recebido.');
    const muted = screen.getByText('metadado');

    expect(heading.tagName).toBe('H3');
    expect(getComputedStyle(card).backgroundColor).toBe('rgb(44, 65, 42)');
    expect(getComputedStyle(card).color).toBe('rgb(255, 255, 255)');
    expect(getComputedStyle(heading).color).toBe('rgb(255, 255, 255)');
    expect(getComputedStyle(heading).fontSize).toBe('1.25rem');
    expect(getComputedStyle(body).color).toBe('rgb(255, 255, 255)');
    expect(getComputedStyle(muted).color).not.toBe('rgb(255, 255, 255)');
  });
});
