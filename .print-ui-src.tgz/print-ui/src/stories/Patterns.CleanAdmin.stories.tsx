import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState, type CSSProperties } from 'react';

import { ActionGroup } from '../components/ActionGroup/ActionGroup';
import { Avatar } from '../components/Avatar/Avatar';
import { Button } from '../components/Button/Button';
import { Card } from '../components/Card/Card';
import {
  DescriptionDetail,
  DescriptionGroup,
  DescriptionList,
  DescriptionTerm,
} from '../components/DescriptionList/DescriptionList';
import { Divider } from '../components/Divider/Divider';
import { DrawerShell } from '../components/Drawer';
import { Heading } from '../components/Heading/Heading';
import { Stat } from '../components/Stat/Stat';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '../components/Tabs/Tabs';
import { Text } from '../components/Text/Text';

/**
 * Patterns do visual clean ADM (PO).
 * Dados ilustrativos — não reutilizar datasets fake de produto.
 * Defaults de Card/Stat já são clean; estes stories compõem o layout ADM.
 */
const meta = {
  title: 'Patterns/CleanAdmin',
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        component:
          'Composições alinhadas a print-adm/docs/visual-reset. Card/Stat usam defaults clean. Consumo ADM só após dist local.',
      },
    },
  },
} satisfies Meta;

export default meta;
type Story = StoryObj;

const pagePad: CSSProperties = {
  padding: '32px',
  maxWidth: 960,
  margin: '0 auto',
  background: 'var(--pf-background, #F0EBE4)',
  minHeight: '100vh',
  boxSizing: 'border-box',
};

export const Home: Story = {
  name: 'Home',
  render: () => (
    <div style={pagePad}>
      <Heading level={2} variant="lg">
        Bom dia
      </Heading>
      <Text tone="muted">Operação em um só lugar.</Text>
      <div style={{ marginTop: 24, display: 'flex', gap: 16, alignItems: 'flex-end' }}>
        <Card padding="sm" style={{ flex: 1 }}>
          <Stat value="1.248" label="Total de usuários" />
        </Card>
        <Button type="button" variant="primary">
          Cadastrar usuário
        </Button>
      </div>
      <div
        style={{
          marginTop: 32,
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'baseline',
        }}
      >
        <Heading level={3} variant="md">
          Clientes
        </Heading>
        <Button type="button" variant="ghost" size="sm">
          Ver todos
        </Button>
      </div>
      <Divider />
      <div
        style={{
          marginTop: 16,
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))',
          gap: 12,
        }}
      >
        {['Vértice', 'Norte', 'Atlas'].map((name) => (
          <Card key={name} padding="sm" interactive>
            <Text variant="labelMd">{name}</Text>
            <Stat value="486" label="usuários" />
          </Card>
        ))}
      </div>
    </div>
  ),
};

export const Reports: Story = {
  name: 'Relatórios',
  render: () => (
    <div style={pagePad}>
      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 16 }}>
        <div>
          <Heading level={2} variant="lg">
            Relatórios
          </Heading>
          <Text tone="muted">Leitura factual de uso e produção.</Text>
        </div>
        <Button type="button" variant="outline">
          Exportar
        </Button>
      </div>
      <div style={{ marginTop: 16 }}>
        <Tabs defaultValue="comparativo" variant="underline">
          <TabsList>
            <TabsTrigger value="geral">Visão geral</TabsTrigger>
            <TabsTrigger value="comparativo">Comparativo</TabsTrigger>
            <TabsTrigger value="cliente">Cliente</TabsTrigger>
          </TabsList>
          <TabsContent value="comparativo">
            <div style={{ display: 'flex', gap: 24, flexWrap: 'wrap', marginTop: 16 }}>
              <Stat value="1.042" label="Usuários ativos" />
              <Stat value="18.460" label="Documentos" />
              <Stat value="74.902" label="Páginas" />
            </div>
            <Divider />
            <Card padding="md" style={{ marginTop: 16 }}>
              <Heading level={3} variant="md">
                Comparativo por cliente
              </Heading>
              <Text as="p" tone="muted">
                Ranking factual — sem score composto.
              </Text>
            </Card>
          </TabsContent>
          <TabsContent value="geral">
            <Text>Visão geral</Text>
          </TabsContent>
          <TabsContent value="cliente">
            <Text>Filtro local por cliente</Text>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  ),
};

export const UserDetail: Story = {
  name: 'UserDetail',
  render: function Render() {
    const [timelineOpen, setTimelineOpen] = useState(false);

    return (
      <div style={pagePad}>
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            gap: 16,
            flexWrap: 'wrap',
          }}
        >
          <Button type="button" variant="ghost" size="sm">
            ← Usuários
          </Button>
          <ActionGroup>
            <Button type="button" variant="outline">
              Suspender
            </Button>
            <Button type="button" variant="primary">
              Editar
            </Button>
          </ActionGroup>
        </div>
        <Divider />
        <div style={{ display: 'flex', gap: 16, alignItems: 'flex-start', marginTop: 16 }}>
          <Avatar name="Marina Costa" size="lg" />
          <div>
            <Heading level={3} variant="md">
              Marina Costa
            </Heading>
            <Text tone="muted">marina.costa@example.com</Text>
            <DescriptionList style={{ marginTop: 12 }}>
              <DescriptionGroup>
                <DescriptionTerm>Status</DescriptionTerm>
                <DescriptionDetail>Ativa · Admin</DescriptionDetail>
              </DescriptionGroup>
              <DescriptionGroup>
                <DescriptionTerm>Cliente</DescriptionTerm>
                <DescriptionDetail>Vértice · Fortaleza</DescriptionDetail>
              </DescriptionGroup>
            </DescriptionList>
          </div>
        </div>
        <Divider />
        <Heading level={3} variant="md">
          Produção · 30 dias
        </Heading>
        <div style={{ display: 'flex', gap: 24, flexWrap: 'wrap', marginTop: 8 }}>
          <Stat value="286" label="Documentos" />
          <Stat value="1.148" label="Páginas" />
          <Stat value="13,6" label="Média/dia" />
        </div>
        <Divider />
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          <Heading level={3} variant="md">
            Atividade recente
          </Heading>
          <Button type="button" variant="outline" size="sm" onClick={() => setTimelineOpen(true)}>
            Ver linha do tempo
          </Button>
        </div>
        <ol style={{ margin: '12px 0 0', paddingLeft: 18, lineHeight: 1.6 }}>
          <li>Hoje 09:42 — Gerou relatório de produção</li>
          <li>Ontem 16:18 — Importou 42 documentos</li>
        </ol>
        <DrawerShell
          open={timelineOpen}
          onOpenChange={setTimelineOpen}
          title="Atividade de Marina"
          description="Histórico factual"
          size="xl"
          presentation="layer"
          origin="end"
          responsiveOrigin="bottom"
          backdropTone="strong"
          backdropInset="sidebar"
        >
          <Text as="p" variant="labelSm" tone="muted">
            HOJE · 12 AGO
          </Text>
          <Divider />
          <p>09:42 — Gerou relatório de produção mensal</p>
          <p>08:16 — Revisou Fechamento fiscal</p>
        </DrawerShell>
      </div>
    );
  },
};
