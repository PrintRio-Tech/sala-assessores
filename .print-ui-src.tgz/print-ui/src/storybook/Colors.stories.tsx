import type { Meta, StoryObj } from '@storybook/react-vite';
import type { CSSProperties } from 'react';

import { palette, semantic } from '../theme';

const swatchGrid: CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))',
  gap: 16,
};

const swatchCard: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 8,
};

const swatch: CSSProperties = {
  width: '100%',
  height: 72,
  borderRadius: 8,
  border: '1px solid color-mix(in srgb, currentColor 12%, transparent)',
};

function ColorSwatches({
  tokens,
}: {
  tokens: Record<string, string>;
}) {
  return (
    <div style={swatchGrid}>
      {Object.entries(tokens).map(([name, hex]) => (
        <div key={name} style={swatchCard}>
          <div style={{ ...swatch, backgroundColor: hex }} />
          <div style={{ fontSize: 13, fontWeight: 600 }}>{name}</div>
          <div style={{ fontSize: 12, opacity: 0.7, fontFamily: 'monospace' }}>
            {hex}
          </div>
        </div>
      ))}
    </div>
  );
}

const meta = {
  title: 'Foundation/Colors',
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
  },
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

export const Palette: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
      <h3 style={{ margin: 0 }}>Palette</h3>
      <ColorSwatches tokens={palette} />
    </div>
  ),
};

export const Semantic: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
      <h3 style={{ margin: 0 }}>Semantic</h3>
      <ColorSwatches tokens={semantic} />
    </div>
  ),
};

export const All: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 40 }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
        <h3 style={{ margin: 0 }}>Palette</h3>
        <ColorSwatches tokens={palette} />
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
        <h3 style={{ margin: 0 }}>Semantic</h3>
        <ColorSwatches tokens={semantic} />
      </div>
    </div>
  ),
};
