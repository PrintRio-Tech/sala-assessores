import type { Meta, StoryObj } from '@storybook/react-vite';
import type { CSSProperties } from 'react';

import { ICONS } from '../assets/icons';
import { Icon } from '../components/Icon';

// Icons resolve from `/icons/...`. If they don't load in Storybook,
// set staticDirs: ['../public'] in .storybook/main.ts (parent will handle).

type FlatIcon = { group: string; name: string; src: string };

function flattenIcons(
  catalog: Record<string, Record<string, string>>,
): FlatIcon[] {
  return Object.entries(catalog).flatMap(([group, icons]) =>
    Object.entries(icons).map(([name, src]) => ({ group, name, src })),
  );
}

const flatIcons = flattenIcons(ICONS);

const grid: CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fill, minmax(120px, 1fr))',
  gap: 16,
};

const cell: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  gap: 8,
  padding: 12,
  borderRadius: 8,
  backgroundColor: 'color-mix(in srgb, currentColor 5%, transparent)',
};

const meta = {
  title: 'Foundation/Icons',
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
  },
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

export const All: Story = {
  render: () => (
    <div style={grid}>
      {flatIcons.map(({ group, name, src }) => (
        <div key={`${group}.${name}`} style={cell}>
          <Icon src={src} size={24} label={`${group}.${name}`} />
          <span style={{ fontSize: 11, textAlign: 'center', wordBreak: 'break-all' }}>
            {group}.{name}
          </span>
        </div>
      ))}
    </div>
  ),
};

export const ByGroup: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 32 }}>
      {Object.entries(ICONS).map(([group, icons]) => (
        <div key={group} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <h3 style={{ margin: 0, textTransform: 'capitalize' }}>{group}</h3>
          <div style={grid}>
            {Object.entries(icons).map(([name, src]) => (
              <div key={name} style={cell}>
                <Icon src={src} size={24} label={`${group}.${name}`} />
                <span style={{ fontSize: 11, textAlign: 'center' }}>{name}</span>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  ),
};
