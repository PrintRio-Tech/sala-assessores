import type { Meta, StoryObj } from '@storybook/react-vite';
import type { CSSProperties } from 'react';

import { Button } from '../components/Button/Button';
import { TextInput } from '../components/TextInput/TextInput';
import { layout, radius } from '../theme';

const radiusRole: Record<keyof typeof radius, string> = {
  sm: 'micro (checkbox, pagination)',
  default: 'compacto (menu, toast, tooltip)',
  md: 'control canônico (botões, inputs, selects, cards)',
  lg: 'container grande (accordion, table)',
  xl: 'sheet / modal (drawer, dialog)',
  full: 'circular intencional (avatar, badge, switch, radio)',
};

const grid: CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))',
  gap: 20,
};

const boxBase: CSSProperties = {
  width: 96,
  height: 96,
  backgroundColor: 'var(--pf-primary, #2C412A)',
  opacity: 0.9,
};

const meta = {
  title: 'Foundation/Radius',
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
  },
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

export const RadiusTokens: Story = {
  name: 'Radius',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
      <h3 style={{ margin: 0 }}>Radius</h3>
      <div style={grid}>
        {Object.entries(radius).map(([name, value]) => (
          <div
            key={name}
            style={{ display: 'flex', flexDirection: 'column', gap: 8, alignItems: 'flex-start' }}
          >
            <div style={{ ...boxBase, borderRadius: value }} />
            <span style={{ fontSize: 13, fontWeight: 600 }}>{name}</span>
            <span style={{ fontSize: 12, opacity: 0.7, fontFamily: 'monospace' }}>
              {value}px
            </span>
            <span style={{ fontSize: 11, opacity: 0.65, maxWidth: 140 }}>
              {radiusRole[name as keyof typeof radius]}
            </span>
          </div>
        ))}
      </div>
    </div>
  ),
};

export const ControlRadius: Story = {
  name: 'Control radius',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16, maxWidth: 360 }}>
      <p style={{ margin: 0, fontSize: 13, opacity: 0.75 }}>
        Botão e input compartilham <code>$radius-md</code> (12px). Busca com ícone não é pill.
      </p>
      <Button type="button">Continuar</Button>
      <TextInput label="Nome" name="fullName" placeholder="Maria Silva" />
      <TextInput
        label="Busca"
        labelHidden
        name="q"
        placeholder="Buscar…"
        leadingIcon={<span aria-hidden>⌕</span>}
      />
    </div>
  ),
};

export const LayoutTokens: Story = {
  name: 'Layout',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16, maxWidth: 420 }}>
      <h3 style={{ margin: 0 }}>Layout</h3>
      {Object.entries(layout).map(([name, value]) => (
        <div
          key={name}
          style={{
            display: 'grid',
            gridTemplateColumns: '1fr auto',
            gap: 12,
            padding: '10px 12px',
            borderRadius: radius.default,
            backgroundColor: 'color-mix(in srgb, currentColor 6%, transparent)',
          }}
        >
          <span style={{ fontSize: 13, fontWeight: 600 }}>{name}</span>
          <span style={{ fontSize: 12, opacity: 0.7, fontFamily: 'monospace' }}>
            {value}px
          </span>
        </div>
      ))}
    </div>
  ),
};
