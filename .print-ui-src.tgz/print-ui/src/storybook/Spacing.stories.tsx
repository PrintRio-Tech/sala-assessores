import type { Meta, StoryObj } from '@storybook/react-vite';
import type { CSSProperties } from 'react';

import { spacing } from '../theme';

const row: CSSProperties = {
  display: 'grid',
  gridTemplateColumns: '160px 1fr 64px',
  alignItems: 'center',
  gap: 16,
  padding: '8px 0',
};

const meta = {
  title: 'Foundation/Spacing',
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
  },
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', maxWidth: 560 }}>
      {Object.entries(spacing).map(([name, value]) => (
        <div key={name} style={row}>
          <span style={{ fontSize: 13, fontWeight: 600 }}>{name}</span>
          <div
            style={{
              height: 16,
              width: value,
              maxWidth: '100%',
              borderRadius: 4,
              backgroundColor: 'var(--pf-primary, #2C412A)',
              opacity: 0.85,
            }}
          />
          <span style={{ fontSize: 12, opacity: 0.7, fontFamily: 'monospace' }}>
            {value}px
          </span>
        </div>
      ))}
    </div>
  ),
};
