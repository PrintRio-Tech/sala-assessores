import type { Meta, StoryObj } from '@storybook/react-vite';

import { Heading } from '../components/Heading/Heading';
import { Text } from '../components/Text/Text';
import { typography } from '../theme';

const meta = {
  title: 'Foundation/Typography',
  tags: ['autodocs'],
  parameters: {
    controls: { disable: true },
  },
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

export const Scale: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24, maxWidth: 640 }}>
      <Text tone="muted" variant="labelSm">
        Primary: {typography.fontPrimary}
      </Text>
      <Text tone="muted" variant="labelSm">
        Fallback: {typography.fontFallback}
      </Text>
      <Text tone="muted" variant="labelSm">
        Pesos: 300–800; tabela usa emphasis 650 e heavy 750 (
        {typography.fontWeight.emphasis}/{typography.fontWeight.heavy})
      </Text>

      <Heading level={1}>Heading XL (level 1)</Heading>
      <Heading level={2}>Heading LG (level 2)</Heading>
      <Heading level={3}>Heading MD (level 3)</Heading>
      <Heading level={3} variant="sm">
        Heading SM (level 3 compacto)
      </Heading>

      <Text variant="bodyLg">Body large — texto corrido para leitura em destaques.</Text>
      <Text variant="bodyMd">Body medium — texto padrão de interface e formulários.</Text>
      <Text variant="labelMd">Label medium — rótulos de campo e ações.</Text>
      <Text variant="labelSm">Label small — metadados e legendas.</Text>

      <Text tone="muted">Tone muted</Text>
      <Text tone="primary">Tone primary</Text>
      <Text tone="error">Tone error</Text>
    </div>
  ),
};
