import type { Decorator } from '@storybook/react-vite';

import { Toaster } from '../components/Toast/Toaster';
import { TooltipProvider } from '../components/Tooltip/Tooltip';

export const withProviders: Decorator = (Story) => (
  <TooltipProvider>
    <Toaster>
      <Story />
    </Toaster>
  </TooltipProvider>
);
