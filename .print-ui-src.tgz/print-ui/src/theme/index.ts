/**
 * Tokens TypeScript do design system Print.
 * Espelham as variáveis CSS (--pf-*) para uso programático (gráficos, etc.).
 */

export const palette = {
  verdeFloresta: '#2C412A',
  verdeSalvia: '#889064',
  oWhite: '#F0EBE4',
  marrom: '#4B3D19',
  areia: '#CFBB9A',
  azulArdosia: '#588B9D',
  dourado: '#DDB050',
  grafite: '#252525',
  white: '#FFFFFF',
} as const;

export const semantic = {
  surface: palette.oWhite,
  surfaceBright: palette.white,
  onSurface: palette.grafite,
  onSurfaceVariant: palette.marrom,
  primary: palette.verdeFloresta,
  onPrimary: palette.white,
  primaryContainer: palette.verdeSalvia,
  secondary: palette.marrom,
  tertiary: palette.azulArdosia,
  accentGold: palette.dourado,
  background: palette.oWhite,
  onBackground: palette.grafite,
  error: '#BA1A1A',
  onError: '#FFFFFF',
  errorContainer: '#FFDAD6',
  onErrorContainer: '#93000A',
  success: palette.verdeSalvia,
  onSuccess: palette.white,
  successContainer: 'rgba(136, 144, 100, 0.2)',
  onSuccessContainer: palette.verdeFloresta,
  warning: palette.dourado,
  onWarning: palette.marrom,
  warningContainer: 'rgba(221, 176, 80, 0.22)',
  onWarningContainer: palette.marrom,
  info: palette.azulArdosia,
  onInfo: palette.white,
  infoContainer: 'rgba(88, 139, 157, 0.16)',
  onInfoContainer: palette.azulArdosia,
} as const;

export const spacing = {
  base: 8,
  gutter: 24,
  fieldGap: 32,
  labelGap: 8,
  sectionGap: 80,
  marginMobile: 20,
  marginDesktop: 64,
  inputMinHeight: 56,
} as const;

/** Espelha `_radius.scss`. `md` (12) é o raio canônico de controles. `full` só para círculos/pills. */
export const radius = {
  sm: 4,
  default: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 9999,
} as const;

export const layout = {
  maxWidth: 1024,
  logoMinWidth: 120,
  logoClearSpace: 56,
  sidebarWidth: 236,
  sidebarWidthCollapsed: 72,
  headerHeight: 64,
} as const;

export const typography = {
  fontPrimary: "'Nexa', 'Barlow', system-ui, sans-serif",
  fontFallback: "'Barlow', system-ui, sans-serif",
  fontWeight: {
    light: 300,
    regular: 400,
    medium: 500,
    semibold: 600,
    emphasis: 650,
    650: 650,
    bold: 700,
    heavy: 750,
    750: 750,
    extrabold: 800,
  },
} as const;

/** Prefixo das custom properties CSS expostas em :root */
export const cssVarPrefix = 'pf' as const;

export function cssVar(token: string): string {
  return `var(--${cssVarPrefix}-${token})`;
}
