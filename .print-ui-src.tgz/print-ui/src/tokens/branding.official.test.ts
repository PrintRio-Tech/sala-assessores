import { readFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

import { describe, expect, it } from 'vitest';

import { palette, semantic, typography } from '../theme';

const here = dirname(fileURLToPath(import.meta.url));

/**
 * Guard imutável: paleta oficial Print (Mirada) — nunca remapear para
 * neutros de protótipo ADM (#F6F6F2 / #20221F / #20251F / #E4E5DF).
 */
describe('branding oficial Print (guard)', () => {
  it('palette SCSS: 8 cores oficiais exatas; sem neutros de protótipo', () => {
    const scss = readFileSync(join(here, '_palette.scss'), 'utf8');

    expect(scss).toMatch(/\$verde-floresta:\s*#2c412a/i);
    expect(scss).toMatch(/\$verde-salvia:\s*#889064/i);
    expect(scss).toMatch(/\$o-white:\s*#f0ebe4/i);
    expect(scss).toMatch(/\$marrom:\s*#4b3d19/i);
    expect(scss).toMatch(/\$areia:\s*#cfbb9a/i);
    expect(scss).toMatch(/\$azul-ardosia:\s*#588b9d/i);
    expect(scss).toMatch(/\$dourado:\s*#ddb050/i);
    expect(scss).toMatch(/\$grafite:\s*#252525/i);

    expect(scss).not.toMatch(/#f6f6f2/i);
    expect(scss).not.toMatch(/#20221f/i);
    expect(scss).not.toMatch(/#20251f/i);
    expect(scss).not.toMatch(/#e4e5df/i);
    expect(scss).not.toMatch(/\$canvas\s*:/);
    expect(scss).not.toMatch(/\$ink\s*:/);
    expect(scss).not.toMatch(/\$shell-sidebar\s*:/);
    expect(scss).not.toMatch(/\$border-muted\s*:/);
  });

  it('semantic SCSS: surface/background=O-White; on*=Grafite; outlineVariant=Areia; sem $shell', () => {
    const scss = readFileSync(join(here, '_semantic.scss'), 'utf8');

    expect(scss).toMatch(/\$surface:\s*\$o-white/);
    expect(scss).toMatch(/\$background:\s*\$o-white/);
    expect(scss).toMatch(/\$on-surface:\s*\$grafite/);
    expect(scss).toMatch(/\$on-background:\s*\$grafite/);
    expect(scss).toMatch(/\$outline-variant:\s*\$areia/);
    expect(scss).toMatch(/\$inverse-surface:\s*\$grafite/);
    expect(scss).toMatch(/\$inverse-on-surface:\s*\$o-white/);
    expect(scss).toMatch(/\$primary:\s*\$verde-floresta/);

    expect(scss).not.toMatch(/\$shell\s*:/);
    expect(scss).not.toMatch(/\$on-shell\s*:/);
    expect(scss).not.toMatch(/\$canvas/);
    expect(scss).not.toMatch(/\$ink/);
    expect(scss).not.toMatch(/\$border-muted/);
  });

  it('elevation: border-subtle/default oficiais (grafite-10 / areia)', () => {
    const scss = readFileSync(join(here, '_elevation.scss'), 'utf8');
    expect(scss).toMatch(/\$border-subtle:\s*1px solid \$grafite-10/);
    expect(scss).toMatch(/\$border-default:\s*1px solid \$areia/);
    expect(scss).not.toMatch(/\$border-muted/);
  });

  it('theme TS espelha branding oficial', () => {
    expect(palette.verdeFloresta.toLowerCase()).toBe('#2c412a');
    expect(palette.verdeSalvia.toLowerCase()).toBe('#889064');
    expect(palette.oWhite.toLowerCase()).toBe('#f0ebe4');
    expect(palette.marrom.toLowerCase()).toBe('#4b3d19');
    expect(palette.areia.toLowerCase()).toBe('#cfbb9a');
    expect(palette.azulArdosia.toLowerCase()).toBe('#588b9d');
    expect(palette.dourado.toLowerCase()).toBe('#ddb050');
    expect(palette.grafite.toLowerCase()).toBe('#252525');

    expect(semantic.surface).toBe(palette.oWhite);
    expect(semantic.background).toBe(palette.oWhite);
    expect(semantic.onSurface).toBe(palette.grafite);
    expect(semantic.onBackground).toBe(palette.grafite);
    expect(semantic.primary).toBe(palette.verdeFloresta);

    expect(palette).not.toHaveProperty('canvas');
    expect(palette).not.toHaveProperty('ink');
    expect(palette).not.toHaveProperty('shellSidebar');
    expect(palette).not.toHaveProperty('borderMuted');
    expect(semantic).not.toHaveProperty('shell');
    expect(semantic).not.toHaveProperty('onShell');
  });

  it('AppShell sidebar default usa $primary / $on-primary; inverse opt-in usa $inverse-*', () => {
    const scss = readFileSync(
      join(here, '..', 'components', 'AppShell', 'styles.module.scss'),
      'utf8',
    );
    const sidebar =
      scss.match(/\.sidebar\s*\{[\s\S]*?(?=\n\.sidebarCollapsed)/)?.[0] ?? '';
    expect(sidebar).toMatch(/background-color:\s*\$primary/);
    expect(sidebar).toMatch(/color:\s*\$on-primary/);
    expect(scss).toMatch(/\.shellInverse[\s\S]*\$inverse-surface/);
    expect(scss).toMatch(/\.shellInverse[\s\S]*\$inverse-on-surface/);
    expect(scss).not.toMatch(/\$on-shell/);
    expect(scss).not.toMatch(/\$shell(?!-)/);
  });

  it('tipografia oficial: Nexa + Barlow; sem serif paralela (Georgia/Times/editorial)', () => {
    const typo = readFileSync(join(here, '_typography.scss'), 'utf8');
    const mixin = readFileSync(
      join(here, '..', 'mixins', '_typography.scss'),
      'utf8',
    );
    const cssVars = readFileSync(
      join(here, '..', 'theme', '_css-variables.scss'),
      'utf8',
    );

    expect(typo).toMatch(
      /\$font-primary:\s*'Nexa',\s*'Barlow',\s*system-ui,\s*sans-serif/,
    );
    expect(typo).toMatch(/\$font-fallback:\s*'Barlow'/);
    expect(typo).not.toMatch(/Georgia/i);
    expect(typo).not.toMatch(/Times New Roman/i);
    expect(typo).not.toMatch(/\$font-editorial/);
    expect(typo).toMatch(/\$headline-xl-size:\s*3rem/);
    expect(typo).toMatch(
      /\$headline-xl-weight:\s*\$font-weight-extrabold/,
    );

    expect(mixin).toMatch(/@mixin headline-xl[\s\S]*@include font-primary/);
    expect(mixin).not.toMatch(/font-editorial/);
    expect(mixin).not.toMatch(/Georgia/i);

    expect(cssVars).not.toMatch(/--pf-font-editorial/);
    expect(typography.fontPrimary).toMatch(/Nexa/);
    expect(typography.fontFallback).toMatch(/Barlow/);
    expect(typography).not.toHaveProperty('fontEditorial');
  });

  it('subpath @print/ui/fonts expõe @font-face Nexa sem trocar família', () => {
    const pkg = JSON.parse(
      readFileSync(join(here, '..', '..', 'package.json'), 'utf8'),
    ) as { exports: Record<string, string> };
    const nexa = readFileSync(join(here, '..', 'fonts', '_nexa.scss'), 'utf8');

    expect(pkg.exports['./fonts']).toBe('./dist/fonts/_index.scss');
    expect(nexa).toMatch(/font-family:\s*'Nexa'/);
    expect(nexa).toMatch(/url\('\/fonts\/nexa\/NexaExtraBold\.woff2'\)/);
    expect(nexa).not.toMatch(/Georgia/i);
  });
});

describe('WIP estrutural preservado (não-branding)', () => {
  it('Button mixin radius 12px', () => {
    const button = readFileSync(
      join(here, '..', 'mixins', '_button.scss'),
      'utf8',
    );
    expect(button).toMatch(/border-radius:\s*\$radius-md/);
    expect(button).not.toMatch(/border-radius:\s*\$radius-full/);
  });
});
