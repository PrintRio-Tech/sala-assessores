import { readFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

import { describe, expect, it } from 'vitest';

const here = dirname(fileURLToPath(import.meta.url));
const src = join(here, '..');

function read(rel: string): string {
  return readFileSync(join(src, rel), 'utf8');
}

describe('headline-sm (Heading compacto ~20px)', () => {
  it('token oficial 1.25rem / bold / line-height 1.2 (caixa 24px, alinha ícone)', () => {
    const scss = read('tokens/_typography.scss');

    expect(scss).toMatch(/\$headline-sm-size:\s*1\.25rem/);
    expect(scss).toMatch(/\$headline-sm-weight:\s*\$font-weight-bold/);
    expect(scss).toMatch(/\$headline-sm-line-height:\s*1\.2/);
    expect(scss).toMatch(/\$headline-md-size:\s*1\.5rem/);
  });

  it('mixin headline-sm e Heading variant sm; levels 1–3 não mudam o default', () => {
    const mixin = read('mixins/_typography.scss');
    const headingTs = read('components/Heading/Heading.tsx');
    const headingScss = read('components/Heading/styles.module.scss');

    expect(mixin).toMatch(/@mixin headline-sm/);
    expect(mixin).toMatch(
      /@mixin headline-sm[\s\S]*font-size:\s*\$headline-sm-size/,
    );

    expect(headingTs).toMatch(/'xl' \| 'lg' \| 'md' \| 'sm'/);
    expect(headingTs).toMatch(/sm:\s*styles\.sm/);
    expect(headingTs).toMatch(/if \(level === 1\) return 'xl'/);
    expect(headingTs).toMatch(/if \(level === 2\) return 'lg'/);
    expect(headingTs).toMatch(/return 'md'/);
    expect(headingTs).not.toMatch(/return 'sm'/);

    expect(headingScss).toMatch(/\.sm\s*\{[\s\S]*@include headline-sm/);
  });
});
