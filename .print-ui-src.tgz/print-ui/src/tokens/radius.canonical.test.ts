import { readFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

import { describe, expect, it } from 'vitest';

import { radius } from '../theme';

const here = dirname(fileURLToPath(import.meta.url));
const src = join(here, '..');

function read(rel: string): string {
  return readFileSync(join(src, rel), 'utf8');
}

function block(source: string, selector: string): string {
  const escaped = selector.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return (
    source.match(new RegExp(`(?:^|\\n)(${escaped}\\s*\\{[\\s\\S]*?\\n\\})`, 'm'))?.[1] ??
    ''
  );
}

describe('radius scale contract', () => {
  it('escala numérica estável: sm 4 / default 8 / md 12 / lg 16 / xl 24 / full pill', () => {
    const scss = read('tokens/_radius.scss');

    expect(scss).toMatch(/\$radius-sm:\s*0\.25rem/);
    expect(scss).toMatch(/\$radius-default:\s*0\.5rem/);
    expect(scss).toMatch(/\$radius-md:\s*0\.75rem/);
    expect(scss).toMatch(/\$radius-lg:\s*1rem/);
    expect(scss).toMatch(/\$radius-xl:\s*1\.5rem/);
    expect(scss).toMatch(/\$radius-full:\s*9999px/);

    expect(radius).toEqual({
      sm: 4,
      default: 8,
      md: 12,
      lg: 16,
      xl: 24,
      full: 9999,
    });
  });

  it('CSS variables espelham a escala (sem token novo, sem remoção)', () => {
    const cssVars = read('theme/_css-variables.scss');

    expect(cssVars).toMatch(/--pf-radius-sm:\s*#\{\$radius-sm\}/);
    expect(cssVars).toMatch(/--pf-radius:\s*#\{\$radius-default\}/);
    expect(cssVars).toMatch(/--pf-radius-md:\s*#\{\$radius-md\}/);
    expect(cssVars).toMatch(/--pf-radius-lg:\s*#\{\$radius-lg\}/);
    expect(cssVars).toMatch(/--pf-radius-xl:\s*#\{\$radius-xl\}/);
    expect(cssVars).toMatch(/--pf-radius-full:\s*#\{\$radius-full\}/);
  });
});

describe('control radius = $radius-md (coerente com botões)', () => {
  it('form-control usa $radius-md, nunca lg nem full', () => {
    const mixin = read('mixins/_form-control.scss');
    const block = mixin.match(/@mixin form-control\s*\{[\s\S]*?\n\}/)?.[0] ?? '';

    expect(block).toMatch(/border-radius:\s*\$radius-md/);
    expect(block).not.toMatch(/\$radius-lg/);
    expect(block).not.toMatch(/\$radius-full/);
  });

  it('button mixin permanece $radius-md (não pill)', () => {
    const button = read('mixins/_button.scss');
    expect(button).toMatch(/border-radius:\s*\$radius-md/);
    expect(button).not.toMatch(/border-radius:\s*\$radius-full/);
  });

  it('TextInput não sobrescreve para pill ($radius-full)', () => {
    const scss = read('components/TextInput/styles.module.scss');
    expect(scss).not.toMatch(/border-radius:\s*\$radius-full/);
  });

  it('popups de select/datepicker e dígitos OTP usam $radius-md', () => {
    expect(block(read('components/SelectField/styles.module.scss'), '.popup')).toMatch(
      /border-radius:\s*\$radius-md/,
    );
    expect(
      block(read('components/SearchableSelectField/styles.module.scss'), '.popup'),
    ).toMatch(/border-radius:\s*\$radius-md/);
    expect(block(read('components/DatePicker/styles.module.scss'), '.popup')).toMatch(
      /border-radius:\s*\$radius-md/,
    );
    expect(block(read('components/OtpInput/styles.module.scss'), '.digit')).toMatch(
      /border-radius:\s*\$radius-md/,
    );
  });

  it('Tabs segmented e ActionTile usam $radius-md (superfície interativa)', () => {
    expect(block(read('components/Tabs/styles.module.scss'), '.listSegmented')).toMatch(
      /border-radius:\s*\$radius-md/,
    );
    expect(block(read('components/ActionTile/styles.module.scss'), '.tile')).toMatch(
      /border-radius:\s*\$radius-md/,
    );
  });
});

describe('intencionalmente circular permanece $radius-full', () => {
  it('Avatar, Badge, Switch e Radio (controle + indicador)', () => {
    expect(read('components/Avatar/styles.module.scss')).toMatch(
      /\.avatar\s*\{[\s\S]*?border-radius:\s*\$radius-full/,
    );
    expect(read('components/Badge/styles.module.scss')).toMatch(
      /\.badge\s*\{[\s\S]*?border-radius:\s*\$radius-full/,
    );
    expect(read('components/Switch/styles.module.scss')).toMatch(
      /\.switch\s*\{[\s\S]*?border-radius:\s*\$radius-full/,
    );
    expect(read('components/Switch/styles.module.scss')).toMatch(
      /\.thumb\s*\{[\s\S]*?border-radius:\s*\$radius-full/,
    );
    expect(read('components/RadioGroup/styles.module.scss')).toMatch(
      /\.control\s*\{[\s\S]*?border-radius:\s*\$radius-full/,
    );
    expect(read('components/RadioGroup/styles.module.scss')).toMatch(
      /\.indicator\s*\{[\s\S]*?border-radius:\s*\$radius-full/,
    );
  });

  it('AppShell nav brand continua pill', () => {
    expect(read('components/AppShell/styles.module.scss')).toMatch(
      /border-radius:\s*\$radius-full/,
    );
  });

  it('DatePicker day cells continuam circulares', () => {
    expect(read('components/DatePicker/styles.module.scss')).toMatch(
      /\.day\s*\{[\s\S]*?border-radius:\s*\$radius-full/,
    );
  });
});
