import { readFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

import { describe, expect, it } from 'vitest';

import { semantic, typography } from '../theme';

const here = dirname(fileURLToPath(import.meta.url));
const src = join(here, '..');

function read(rel: string): string {
  return readFileSync(join(src, rel), 'utf8');
}

describe('pesos tipográficos intermediários (tabela)', () => {
  it('escala 300–800 permanece; 650 e 750 entram como emphasis/heavy', () => {
    const scss = read('tokens/_typography.scss');

    expect(scss).toMatch(/\$font-weight-light:\s*300/);
    expect(scss).toMatch(/\$font-weight-regular:\s*400/);
    expect(scss).toMatch(/\$font-weight-medium:\s*500/);
    expect(scss).toMatch(/\$font-weight-semibold:\s*600/);
    expect(scss).toMatch(/\$font-weight-emphasis:\s*650/);
    expect(scss).toMatch(/\$font-weight-650:\s*\$font-weight-emphasis/);
    expect(scss).toMatch(/\$font-weight-bold:\s*700/);
    expect(scss).toMatch(/\$font-weight-heavy:\s*750/);
    expect(scss).toMatch(/\$font-weight-750:\s*\$font-weight-heavy/);
    expect(scss).toMatch(/\$font-weight-extrabold:\s*800/);
  });

  it('CSS vars numéricas e nomeadas espelham 650/750', () => {
    const css = read('theme/_css-variables.scss');

    expect(css).toMatch(
      /--pf-font-weight-emphasis:\s*#\{\$font-weight-emphasis\}/,
    );
    expect(css).toMatch(/--pf-font-weight-650:\s*#\{\$font-weight-650\}/);
    expect(css).toMatch(/--pf-font-weight-heavy:\s*#\{\$font-weight-heavy\}/);
    expect(css).toMatch(/--pf-font-weight-750:\s*#\{\$font-weight-750\}/);
  });

  it('theme TS expõe fontWeight.emphasis=650 e fontWeight.heavy=750', () => {
    expect(typography.fontWeight).toMatchObject({
      light: 300,
      regular: 400,
      medium: 500,
      semibold: 600,
      emphasis: 650,
      bold: 700,
      heavy: 750,
      extrabold: 800,
    });
    expect(typography.fontWeight[650]).toBe(650);
    expect(typography.fontWeight[750]).toBe(750);
  });
});

describe('status semântico (success/warning/info/error surface+on)', () => {
  it('SCSS deriva da paleta oficial; error existente permanece', () => {
    const scss = read('tokens/_semantic.scss');

    expect(scss).toMatch(/\$success:\s*\$verde-salvia/);
    expect(scss).toMatch(/\$on-success:\s*\$white/);
    expect(scss).toMatch(/\$success-container:\s*rgba\(\$verde-salvia,\s*0\.2\)/);
    expect(scss).toMatch(/\$on-success-container:\s*\$verde-floresta/);

    expect(scss).toMatch(/\$warning:\s*\$dourado/);
    expect(scss).toMatch(/\$on-warning:\s*\$marrom/);
    expect(scss).toMatch(/\$warning-container:\s*rgba\(\$dourado,\s*0\.22\)/);
    expect(scss).toMatch(/\$on-warning-container:\s*\$marrom/);

    expect(scss).toMatch(/\$info:\s*\$azul-ardosia/);
    expect(scss).toMatch(/\$on-info:\s*\$white/);
    expect(scss).toMatch(/\$info-container:\s*rgba\(\$azul-ardosia,\s*0\.16\)/);
    expect(scss).toMatch(/\$on-info-container:\s*\$azul-ardosia/);

    expect(scss).toMatch(/\$error:\s*#ba1a1a/i);
    expect(scss).toMatch(/\$on-error:\s*\$white/);
    expect(scss).toMatch(/\$error-container:\s*#ffdad6/i);
    expect(scss).toMatch(/\$on-error-container:\s*#93000a/i);

    expect(scss).not.toMatch(/#f6f6f2/i);
    expect(scss).not.toMatch(/#d52d29/i);
    expect(scss).not.toMatch(/#659679/i);
  });

  it('CSS vars --pf-{status} e --pf-{status}-container (+ on-*)', () => {
    const css = read('theme/_css-variables.scss');

    for (const name of [
      'success',
      'on-success',
      'success-container',
      'on-success-container',
      'warning',
      'on-warning',
      'warning-container',
      'on-warning-container',
      'info',
      'on-info',
      'info-container',
      'on-info-container',
      'error',
      'on-error',
      'error-container',
      'on-error-container',
    ]) {
      expect(css).toMatch(new RegExp(`--pf-${name}:\\s*#\\{\\$${name}\\}`));
    }
  });

  it('theme TS espelha o quarteto de status', () => {
    expect(semantic.success).toBe('#889064');
    expect(semantic.onSuccess).toBe('#FFFFFF');
    expect(semantic.successContainer).toBe('rgba(136, 144, 100, 0.2)');
    expect(semantic.onSuccessContainer).toBe('#2C412A');

    expect(semantic.warning).toBe('#DDB050');
    expect(semantic.onWarning).toBe('#4B3D19');
    expect(semantic.warningContainer).toBe('rgba(221, 176, 80, 0.22)');
    expect(semantic.onWarningContainer).toBe('#4B3D19');

    expect(semantic.info).toBe('#588B9D');
    expect(semantic.onInfo).toBe('#FFFFFF');
    expect(semantic.infoContainer).toBe('rgba(88, 139, 157, 0.16)');
    expect(semantic.onInfoContainer).toBe('#588B9D');

    expect(semantic.error.toUpperCase()).toBe('#BA1A1A');
    expect(semantic.onError).toBe('#FFFFFF');
    expect(semantic.errorContainer.toLowerCase()).toBe('#ffdad6');
    expect(semantic.onErrorContainer.toLowerCase()).toBe('#93000a');
  });
});
